import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot2.getRangeMarkers(3, layer4);
        java.util.List list6 = categoryPlot2.getAnnotations();
        java.awt.Paint paint7 = categoryPlot2.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double11 = dateAxis10.getFixedDimension();
        boolean boolean12 = dateAxis10.isAutoTickUnitSelection();
        categoryPlot2.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis10, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis10.getTickUnit();
        org.jfree.chart.entity.EntityCollection entityCollection16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo(entityCollection16);
        int int18 = dateTickUnit15.compareTo((java.lang.Object) entityCollection16);
        int int19 = dateTickUnit15.getRollUnit();
        boolean boolean20 = unitType0.equals((java.lang.Object) int19);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 'a', Double.POSITIVE_INFINITY, (double) '4', (double) 1);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name SerialDate.weekInMonthToString(): invalid code., locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle7.getBounds();
        chartRenderingInfo5.setChartArea(rectangle2D9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D9, (java.awt.Paint) color11);
        org.jfree.data.general.Dataset dataset13 = legendItem12.getDataset();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset14, valueAxis15, polarItemRenderer16);
        polarPlot17.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        java.awt.Font font23 = textTitle21.getFont();
        polarPlot17.setAngleLabelFont(font23);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean27 = stackedBarRenderer3D25.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer28 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer28.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color30);
        stackedBarRenderer3D25.setWallPaint((java.awt.Paint) color30);
        polarPlot17.setNoDataMessagePaint((java.awt.Paint) color30);
        boolean boolean34 = legendItem12.equals((java.lang.Object) polarPlot17);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer35 = legendItem12.getFillPaintTransformer();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(dataset13);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer35);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        categoryPlot0.clearRangeMarkers((-1));
        categoryPlot0.setRangeGridlinesVisible(true);
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray15, numberArray20, numberArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray26);
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset27);
        org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset27, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset27);
        categoryPlot0.setDataset(categoryDataset27);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 300.0d + "'", number28.equals(300.0d));
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 11);
        java.lang.String str3 = rectangleConstraint2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getWidthConstraintType();
        java.lang.String str6 = rectangleConstraint4.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]" + "'", str3.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=11.0]" + "'", str6.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=11.0]"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) '4', 0.0d);
        double double3 = size2D2.width;
        java.lang.Object obj4 = size2D2.clone();
        double double5 = size2D2.height;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(100, (int) (short) 0, (-1), 5, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.awt.Font font3 = textTitle1.getFont();
        java.awt.Paint paint4 = textTitle1.getPaint();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (-3407872));
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer4 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean6 = ganttRenderer4.equals((java.lang.Object) '#');
        ganttRenderer4.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke12 = ganttRenderer4.getSeriesStroke(0);
        boolean boolean13 = itemLabelPosition3.equals((java.lang.Object) ganttRenderer4);
        double double14 = itemLabelPosition3.getAngle();
        ganttRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition3, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = ganttRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot19.getRangeMarkers(3, layer21);
        java.util.List list23 = categoryPlot19.getAnnotations();
        categoryPlot19.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset25, valueAxis26, polarItemRenderer27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot28.setRadiusGridlineStroke(stroke29);
        categoryPlot19.setDomainGridlineStroke(stroke29);
        boolean boolean32 = categoryPlot19.isRangeGridlinesVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = categoryPlot19.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 128);
        java.text.DateFormat dateFormat41 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit42 = new org.jfree.chart.axis.DateTickUnit(0, 12, 1, (int) (short) 1, dateFormat41);
        categoryMarker36.setKey((java.lang.Comparable) 1);
        org.jfree.chart.entity.EntityCollection entityCollection48 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo49 = new org.jfree.chart.ChartRenderingInfo(entityCollection48);
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str52 = textTitle51.getText();
        java.awt.geom.Rectangle2D rectangle2D53 = textTitle51.getBounds();
        chartRenderingInfo49.setChartArea(rectangle2D53);
        java.awt.Color color55 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem56 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D53, (java.awt.Paint) color55);
        org.jfree.chart.title.TextTitle textTitle58 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str59 = textTitle58.getText();
        java.awt.geom.Rectangle2D rectangle2D60 = textTitle58.getBounds();
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D60, (double) (short) 10, 100.0f, (float) (short) -1);
        boolean boolean65 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D53, rectangle2D60);
        try {
            ganttRenderer0.drawDomainMarker(graphics2D18, categoryPlot19, categoryAxis34, categoryMarker36, rectangle2D60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(categoryAnchor33);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.axis.NumberAxis numberAxis2 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.awt.Font font10 = textTitle8.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis2, (double) 12, 300.0d, (double) 10.0f, 0.25d, font10);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean14 = stackedBarRenderer3D12.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer15 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer15.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color17);
        stackedBarRenderer3D12.setWallPaint((java.awt.Paint) color17);
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("", font10, (java.awt.Paint) color17);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("RectangleEdge.TOP", font10);
        textTitle21.setText("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        stackedBarRenderer0.setRenderAsPercentages(false);
        java.awt.Paint paint3 = stackedBarRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        stackedBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator4);
        java.awt.Paint paint7 = stackedBarRenderer0.getSeriesFillPaint((int) (short) 10);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        boolean boolean2 = verticalAlignment0.equals((java.lang.Object) itemLabelAnchor1);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke3 = stackedBarRenderer3D0.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot4);
        boolean boolean9 = stackedBarRenderer3D0.getRenderAsPercentages();
        boolean boolean10 = stackedBarRenderer3D0.isDrawBarOutline();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint5 = null;
        textTitle4.setBackgroundPaint(paint5);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle8.setTextAlignment(horizontalAlignment9);
        textTitle4.setTextAlignment(horizontalAlignment9);
        textTitle1.setHorizontalAlignment(horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment13, 0.5d, 0.35d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment13);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot1);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str8 = color7.toString();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str8.equals("java.awt.Color[r=128,g=128,b=255]"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        java.lang.Object obj6 = polarPlot3.clone();
        polarPlot3.addCornerTextItem("");
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) 1.0f);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        boolean boolean5 = rectangleInsets0.equals((java.lang.Object) pieDataset3);
        java.awt.Font font7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        polarPlot11.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str16 = textTitle15.getText();
        java.awt.Font font17 = textTitle15.getFont();
        polarPlot11.setAngleLabelFont(font17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", font7, (org.jfree.chart.plot.Plot) polarPlot11, true);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str24 = textTitle23.getText();
        java.awt.Font font25 = textTitle23.getFont();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str29 = textTitle28.getText();
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle28.getBounds();
        textTitle23.draw(graphics2D26, rectangle2D30);
        java.awt.geom.Point2D point2D32 = null;
        org.jfree.chart.plot.PlotState plotState33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        polarPlot11.draw(graphics2D21, rectangle2D30, point2D32, plotState33, plotRenderingInfo34);
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets0.createInsetRectangle(rectangle2D30);
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray45, numberArray50, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray56);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity60 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D36, "hi!", "({0}, {1}) = {2}", categoryDataset57, (java.lang.Comparable) 0.0f, (java.lang.Comparable) 0);
        boolean boolean62 = categoryItemEntity60.equals((java.lang.Object) 'a');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot5);
        categoryPlot4.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart9);
        java.awt.Font font11 = categoryPlot4.getNoDataMessageFont();
        dateAxis1.setLabelFont(font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = dateAxis1.getTickLabelInsets();
        double double14 = rectangleInsets13.getBottom();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.entity.EntityCollection entityCollection8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo(entityCollection8);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str12 = textTitle11.getText();
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle11.getBounds();
        chartRenderingInfo9.setChartArea(rectangle2D13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D13, (java.awt.Paint) color15);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str19 = textTitle18.getText();
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle18.getBounds();
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D20, (double) (short) 10, 100.0f, (float) (short) -1);
        boolean boolean25 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D13, rectangle2D20);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D20);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        try {
            org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem(attributedString0, "ChartEntity: tooltip = ClassContext", "SerialDate.weekInMonthToString(): invalid code.", "ChartEntity: tooltip = ClassContext", (java.awt.Shape) rectangle2D20, (java.awt.Paint) color27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = ganttRenderer0.getGradientPaintTransformer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = ganttRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
        org.junit.Assert.assertNull(itemLabelPosition8);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", graphics2D1, (float) (byte) -1, (float) 7, (double) (-6553600), (float) 12, (float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        double double4 = dateAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getShadowYOffset();
        double double4 = piePlot3D1.getExplodePercent((java.lang.Comparable) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        int int2 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 128 + "'", int2 == 128);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        java.util.Date date3 = dateAxis1.getMaximumDate();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = dateAxis1.getLabelInsets();
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(unitType5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double7 = dateAxis6.getFixedDimension();
        boolean boolean8 = dateAxis6.isAxisLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot10);
        categoryPlot9.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart14);
        java.awt.Font font16 = categoryPlot9.getNoDataMessageFont();
        dateAxis6.setLabelFont(font16);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D0, (double) (short) 0, (double) ' ', 300.0d, (double) (short) 100, font16);
        numberAxis3D0.setAutoRangeIncludesZero(false);
        boolean boolean21 = numberAxis3D0.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
//        org.junit.Assert.assertNull(timeZone0);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.awt.Font font3 = textTitle1.getFont();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str7 = textTitle6.getText();
        java.awt.geom.Rectangle2D rectangle2D8 = textTitle6.getBounds();
        textTitle1.draw(graphics2D4, rectangle2D8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getRangeMarkers(3, layer12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getRangeAxisEdge(2019);
        textTitle1.setPosition(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "java.awt.Color[r=128,g=128,b=255]", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.awt.Font font11 = textTitle9.getFont();
        polarPlot5.setAngleLabelFont(font11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) polarPlot5, true);
        java.awt.Stroke stroke15 = polarPlot5.getAngleGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot(xYDataset17, valueAxis18, polarItemRenderer19);
        polarPlot20.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str25 = textTitle24.getText();
        java.awt.Font font26 = textTitle24.getFont();
        polarPlot20.setAngleLabelFont(font26);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot20);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean31 = stackedBarRenderer3D29.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer32 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer32.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color34);
        stackedBarRenderer3D29.setWallPaint((java.awt.Paint) color34);
        jFreeChart28.setBorderPaint((java.awt.Paint) color34);
        polarPlot5.setRadiusGridlinePaint((java.awt.Paint) color34);
        java.awt.Color color39 = org.jfree.chart.ChartColor.DARK_RED;
        polarPlot5.setRadiusGridlinePaint((java.awt.Paint) color39);
        org.jfree.chart.block.BlockBorder blockBorder41 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color39);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color39);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset18, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.chart.entity.EntityCollection entityCollection27 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = new org.jfree.chart.ChartRenderingInfo(entityCollection27);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str31 = textTitle30.getText();
        java.awt.geom.Rectangle2D rectangle2D32 = textTitle30.getBounds();
        chartRenderingInfo28.setChartArea(rectangle2D32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D32, (java.awt.Paint) color34);
        multiplePiePlot22.setAggregatedItemsPaint((java.awt.Paint) color34);
        org.jfree.data.category.CategoryDataset categoryDataset37 = multiplePiePlot22.getDataset();
        java.lang.String str38 = multiplePiePlot22.getPlotType();
        org.jfree.chart.util.TableOrder tableOrder39 = multiplePiePlot22.getDataExtractOrder();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 300.0d + "'", number19.equals(300.0d));
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Multiple Pie Plot" + "'", str38.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(tableOrder39);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        textTitle1.setMargin((double) 100.0f, (double) 11, (double) 0, 0.0d);
        java.lang.Object obj8 = textTitle1.clone();
        java.awt.Paint paint9 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset7 = categoryPlot0.getDataset(128);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer8 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean10 = ganttRenderer8.equals((java.lang.Object) '#');
        ganttRenderer8.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke16 = ganttRenderer8.getSeriesStroke(0);
        java.lang.Boolean boolean18 = ganttRenderer8.getSeriesCreateEntities((int) '#');
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer8.setIncompletePaint((java.awt.Paint) color19);
        categoryPlot0.setOutlinePaint((java.awt.Paint) color19);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNull(boolean18);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Object obj1 = null;
        boolean boolean2 = boxAndWhiskerRenderer0.equals(obj1);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        try {
            boxAndWhiskerRenderer0.setSeriesPaint((-3407872), (java.awt.Paint) color4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 3, (double) 2019);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.awt.Font font11 = textTitle9.getFont();
        polarPlot5.setAngleLabelFont(font11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) polarPlot5, true);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str18 = textTitle17.getText();
        java.awt.Font font19 = textTitle17.getFont();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str23 = textTitle22.getText();
        java.awt.geom.Rectangle2D rectangle2D24 = textTitle22.getBounds();
        textTitle17.draw(graphics2D20, rectangle2D24);
        java.awt.geom.Point2D point2D26 = null;
        org.jfree.chart.plot.PlotState plotState27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        polarPlot5.draw(graphics2D15, rectangle2D24, point2D26, plotState27, plotRenderingInfo28);
        java.awt.Paint paint30 = polarPlot5.getAngleGridlinePaint();
        boolean boolean31 = polarPlot5.isAngleGridlinesVisible();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.Number[][] numberArray1 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot7.setRadiusGridlineStroke(stroke8);
        boolean boolean10 = defaultIntervalCategoryDataset3.hasListener((java.util.EventListener) polarPlot7);
        java.awt.Paint paint11 = polarPlot7.getRadiusGridlinePaint();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) -1);
        java.awt.Font font8 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getDomainMarkers(layer9);
        float float11 = categoryPlot0.getBackgroundImageAlpha();
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint9, stroke10);
        categoryPlot0.setRangeCrosshairStroke(stroke10);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        polarPlot3.datasetChanged(datasetChangeEvent6);
        int int8 = polarPlot3.getSeriesCount();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Object obj1 = null;
        boolean boolean2 = boxAndWhiskerRenderer0.equals(obj1);
        java.awt.Paint paint4 = null;
        boxAndWhiskerRenderer0.setSeriesPaint((int) (short) 100, paint4, true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = null;
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str17 = textTitle16.getText();
        java.awt.geom.Rectangle2D rectangle2D18 = textTitle16.getBounds();
        chartRenderingInfo14.setChartArea(rectangle2D18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D18, (java.awt.Paint) color20);
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str24 = textTitle23.getText();
        java.awt.geom.Rectangle2D rectangle2D25 = textTitle23.getBounds();
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D25, (double) (short) 10, 100.0f, (float) (short) -1);
        boolean boolean30 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D18, rectangle2D25);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot31.getRangeMarkers(3, layer33);
        java.util.List list35 = categoryPlot31.getAnnotations();
        categoryPlot31.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer39 = null;
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot(xYDataset37, valueAxis38, polarItemRenderer39);
        java.awt.Stroke stroke41 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot40.setRadiusGridlineStroke(stroke41);
        categoryPlot31.setDomainGridlineStroke(stroke41);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double47 = dateAxis46.getFixedDimension();
        java.util.Date date48 = dateAxis46.getMinimumDate();
        java.lang.Number[] numberArray55 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray60 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray65 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray66 = new java.lang.Number[][] { numberArray55, numberArray60, numberArray65 };
        org.jfree.data.category.CategoryDataset categoryDataset67 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray66);
        java.lang.Number number68 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset67);
        org.jfree.data.Range range70 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset67, false);
        try {
            boxAndWhiskerRenderer0.drawVerticalItem(graphics2D7, categoryItemRendererState8, rectangle2D25, categoryPlot31, categoryAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis46, categoryDataset67, (int) (byte) 1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.category.DefaultCategoryDataset cannot be cast to org.jfree.data.statistics.BoxAndWhiskerCategoryDataset");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(numberArray65);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(categoryDataset67);
        org.junit.Assert.assertTrue("'" + number68 + "' != '" + 300.0d + "'", number68.equals(300.0d));
        org.junit.Assert.assertNotNull(range70);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset18, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.chart.entity.EntityCollection entityCollection27 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = new org.jfree.chart.ChartRenderingInfo(entityCollection27);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str31 = textTitle30.getText();
        java.awt.geom.Rectangle2D rectangle2D32 = textTitle30.getBounds();
        chartRenderingInfo28.setChartArea(rectangle2D32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D32, (java.awt.Paint) color34);
        multiplePiePlot22.setAggregatedItemsPaint((java.awt.Paint) color34);
        java.lang.String str37 = multiplePiePlot22.getPlotType();
        java.awt.Paint paint38 = multiplePiePlot22.getAggregatedItemsPaint();
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 300.0d + "'", number19.equals(300.0d));
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Multiple Pie Plot" + "'", str37.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke8 = ganttRenderer0.getSeriesStroke(0);
        java.lang.Boolean boolean10 = ganttRenderer0.getSeriesCreateEntities((int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot11.getRangeMarkers(3, layer13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot11.setRangeGridlinePaint((java.awt.Paint) color15);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot11.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint20, stroke21);
        categoryPlot11.setRangeCrosshairStroke(stroke21);
        boolean boolean24 = ganttRenderer0.hasListener((java.util.EventListener) categoryPlot11);
        boolean boolean25 = ganttRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.util.Locale locale1 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.lang.Class<?> wildcardClass4 = stackedBarRenderer3D3.getClass();
        java.lang.Class class5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double8 = dateAxis7.getFixedDimension();
        java.util.Date date9 = dateAxis7.getMinimumDate();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date9, timeZone10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot12.getRangeMarkers(3, layer14);
        java.util.List list16 = categoryPlot12.getAnnotations();
        java.awt.Paint paint17 = categoryPlot12.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double21 = dateAxis20.getFixedDimension();
        boolean boolean22 = dateAxis20.isAutoTickUnitSelection();
        categoryPlot12.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis20, true);
        dateAxis20.setRangeAboutValue((double) 0, (double) (short) 100);
        java.util.TimeZone timeZone28 = dateAxis20.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone28);
        java.io.InputStream inputStream30 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleEdge.TOP", (java.lang.Class) wildcardClass4);
        java.lang.ClassLoader classLoader31 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        try {
            java.util.ResourceBundle resourceBundle32 = java.util.ResourceBundle.getBundle("PlotOrientation.HORIZONTAL", locale1, classLoader31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNull(inputStream30);
        org.junit.Assert.assertNotNull(classLoader31);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Image image4 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxisForDataset((int) (short) 1);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorRight((double) 10);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer4 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendTitle5.getLegendItemGraphicLocation();
        java.awt.Paint paint7 = legendTitle5.getBackgroundPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendTitle5.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle5.setLegendItemGraphicEdge(rectangleEdge9);
        double double11 = legendTitle5.getHeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.TOP;
        legendTitle5.setLegendItemGraphicEdge(rectangleEdge12);
        axisState0.moveCursor((double) (byte) 10, rectangleEdge12);
        double double15 = axisState0.getMax();
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        double double3 = size2D2.height;
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer6 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendTitle7.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle7.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.TOP;
        legendTitle7.setLegendItemGraphicLocation(rectangleAnchor10);
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, (double) (-6553600), 0.05d, rectangleAnchor10);
        size2D2.height = 'a';
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 128);
        java.awt.Paint paint2 = categoryMarker1.getLabelPaint();
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            categoryMarker1.setLabelTextAnchor(textAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Object obj1 = null;
        boolean boolean2 = boxAndWhiskerRenderer0.equals(obj1);
        java.awt.Paint paint4 = boxAndWhiskerRenderer0.getSeriesItemLabelPaint((int) (byte) 10);
        java.awt.Paint paint5 = boxAndWhiskerRenderer0.getArtifactPaint();
        boolean boolean7 = boxAndWhiskerRenderer0.isSeriesItemLabelsVisible(4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setMaximumItemWidth((double) '4');
        double double3 = levelRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        java.lang.String str4 = dateAxis1.getLabelURL();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot5.getRangeMarkers(3, layer7);
        java.util.List list9 = categoryPlot5.getAnnotations();
        java.awt.Paint paint10 = categoryPlot5.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double14 = dateAxis13.getFixedDimension();
        boolean boolean15 = dateAxis13.isAutoTickUnitSelection();
        categoryPlot5.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis13, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis13.getTickUnit();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date21 = spreadsheetDate20.toDate();
        int int22 = dateTickUnit18.compareTo((java.lang.Object) date21);
        dateAxis1.setMaximumDate(date21);
        float float24 = dateAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.lang.Boolean boolean2 = lineRenderer3D0.getSeriesShapesFilled(15);
        lineRenderer3D0.setSeriesCreateEntities(2, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection2 = waferMapPlot1.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        java.awt.Paint paint4 = dateAxis3.getTickLabelPaint();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer7 = new org.jfree.chart.text.G2TextMeasurer(graphics2D6);
        try {
            org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("PlotOrientation.HORIZONTAL", font1, paint4, 0.5f, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.awt.Font font11 = textTitle9.getFont();
        polarPlot5.setAngleLabelFont(font11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) polarPlot5, true);
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart14.createBufferedImage((int) '#', 1);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        jFreeChart14.setBorderStroke(stroke18);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(bufferedImage17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke3 = stackedBarRenderer3D0.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedBarRenderer3D0.getItemLabelGenerator((int) (short) -1, 0);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator11 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "ClassContext");
        stackedBarRenderer3D0.setSeriesURLGenerator(5, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator11);
        stackedBarRenderer3D0.setBaseSeriesVisibleInLegend(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = stackedBarRenderer3D0.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double3 = piePlot3D1.getExplodePercent((java.lang.Comparable) 0.2d);
        piePlot3D1.setForegroundAlpha((float) 100L);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot3D1.getLegendLabelToolTipGenerator();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer7 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle8.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendTitle8.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle8.getLegendItemGraphicPadding();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean14 = stackedBarRenderer3D12.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke15 = stackedBarRenderer3D12.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D12.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot21.getRangeMarkers(3, layer23);
        java.util.List list25 = categoryPlot21.getAnnotations();
        categoryPlot21.clearRangeAxes();
        boolean boolean27 = categoryPlot16.equals((java.lang.Object) categoryPlot21);
        org.jfree.chart.axis.AxisSpace axisSpace28 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot16.setFixedDomainAxisSpace(axisSpace28);
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str32 = textTitle31.getText();
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle31.getBounds();
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D33, (double) (short) 10, 100.0f, (float) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double40 = rectangleInsets38.calculateBottomOutset(0.4d);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str45 = textTitle44.getText();
        java.awt.Font font46 = textTitle44.getFont();
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str50 = textTitle49.getText();
        java.awt.geom.Rectangle2D rectangle2D51 = textTitle49.getBounds();
        textTitle44.draw(graphics2D47, rectangle2D51);
        java.awt.geom.Point2D point2D53 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 10, (double) (-1L), rectangle2D51);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType54 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType55 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets38.createAdjustedRectangle(rectangle2D51, lengthAdjustmentType54, lengthAdjustmentType55);
        java.awt.geom.Rectangle2D rectangle2D57 = axisSpace28.shrink(rectangle2D33, rectangle2D56);
        java.awt.geom.Rectangle2D rectangle2D58 = rectangleInsets11.createInsetRectangle(rectangle2D56);
        piePlot3D1.setLegendItemShape((java.awt.Shape) rectangle2D58);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 3.0d + "'", double40 == 3.0d);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(point2D53);
        org.junit.Assert.assertNotNull(lengthAdjustmentType54);
        org.junit.Assert.assertNotNull(lengthAdjustmentType55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangle2D58);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean3 = stackedBarRenderer3D1.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke4 = stackedBarRenderer3D1.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot5);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getColumnRenderingOrder();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        boolean boolean12 = sortOrder10.equals((java.lang.Object) color11);
        defaultKeyedValues0.sortByKeys(sortOrder10);
        try {
            defaultKeyedValues0.removeValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        piePlot3D1.datasetChanged(datasetChangeEvent2);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer5 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendTitle6.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendTitle6.getLegendItemGraphicLocation();
        org.jfree.chart.block.BlockContainer blockContainer9 = null;
        legendTitle6.setWrapper(blockContainer9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_RED;
        legendTitle6.setBackgroundPaint((java.awt.Paint) color11);
        piePlot3D1.setSectionOutlinePaint((java.lang.Comparable) 128, (java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        stackedBarRenderer3D0.setBaseCreateEntities(false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator9 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "ClassContext");
        stackedBarRenderer3D0.setSeriesURLGenerator((int) 'a', (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = stackedBarRenderer3D0.getNegativeItemLabelPosition((-6553600), 2958465);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier6);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer9 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = levelRenderer9.getBaseNegativeItemLabelPosition();
        categoryPlot0.setRenderer((int) '#', (org.jfree.chart.renderer.category.CategoryItemRenderer) levelRenderer9, false);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.lang.Class<?> wildcardClass1 = stackedBarRenderer3D0.getClass();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double4 = dateAxis3.getFixedDimension();
        java.util.Date date5 = dateAxis3.getMaximumDate();
        dateAxis3.setAutoRangeMinimumSize(3.0d);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer8 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendTitle9.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean14 = rectangleAnchor10.equals((java.lang.Object) simpleTimePeriod13);
        java.util.Date date15 = simpleTimePeriod13.getStart();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = dateAxis3.dateToJava2D(date15, rectangle2D16, rectangleEdge17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot19.getRangeMarkers(3, layer21);
        java.util.List list23 = categoryPlot19.getAnnotations();
        java.awt.Paint paint24 = categoryPlot19.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double28 = dateAxis27.getFixedDimension();
        boolean boolean29 = dateAxis27.isAutoTickUnitSelection();
        categoryPlot19.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis27, true);
        dateAxis27.setRangeAboutValue((double) 0, (double) (short) 100);
        java.util.TimeZone timeZone35 = dateAxis27.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date15, timeZone35);
        java.lang.Class class37 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double40 = dateAxis39.getFixedDimension();
        java.util.Date date41 = dateAxis39.getMinimumDate();
        java.util.TimeZone timeZone42 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date41, timeZone42);
        org.jfree.data.time.DateRange dateRange44 = new org.jfree.data.time.DateRange(date15, date41);
        java.lang.Class class45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double48 = dateAxis47.getFixedDimension();
        java.util.Date date49 = dateAxis47.getMinimumDate();
        java.util.TimeZone timeZone50 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date49, timeZone50);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date49);
        org.jfree.data.time.DateRange dateRange53 = new org.jfree.data.time.DateRange(date15, date49);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(serialDate52);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Shape shape8 = ganttRenderer0.getSeriesShape(5);
        ganttRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = ganttRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint12 = ganttRenderer0.getBasePaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        ganttRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator13, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double3 = piePlot3D1.getExplodePercent((java.lang.Comparable) 0.2d);
        int int4 = piePlot3D1.getPieIndex();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer6 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean8 = ganttRenderer6.equals((java.lang.Object) '#');
        double double9 = ganttRenderer6.getItemLabelAnchorOffset();
        double double10 = ganttRenderer6.getStartPercent();
        java.awt.Paint paint12 = ganttRenderer6.lookupSeriesPaint(100);
        piePlot3D1.setSectionPaint((java.lang.Comparable) "({0}, {1}) = {2}", paint12);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.35d + "'", double10 == 0.35d);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Object obj1 = null;
        boolean boolean2 = boxAndWhiskerRenderer0.equals(obj1);
        java.awt.Paint paint4 = boxAndWhiskerRenderer0.getSeriesItemLabelPaint((int) (byte) 10);
        java.awt.Paint paint5 = boxAndWhiskerRenderer0.getArtifactPaint();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot7.getRangeMarkers(3, layer9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot7.getInsets();
        org.jfree.chart.entity.EntityCollection entityCollection16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo(entityCollection16);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getText();
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle19.getBounds();
        chartRenderingInfo17.setChartArea(rectangle2D21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D21, (java.awt.Paint) color23);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str27 = textTitle26.getText();
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle26.getBounds();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D28, (double) (short) 10, 100.0f, (float) (short) -1);
        boolean boolean33 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D21, rectangle2D28);
        try {
            boxAndWhiskerRenderer0.drawDomainGridline(graphics2D6, categoryPlot7, rectangle2D21, 12.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        try {
            java.awt.Color color1 = java.awt.Color.decode("java.awt.Color[r=128,g=128,b=255]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java.awt.Color[r=128,g=128,b=255]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset(0.4d);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str7 = textTitle6.getText();
        java.awt.Font font8 = textTitle6.getFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str12 = textTitle11.getText();
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle11.getBounds();
        textTitle6.draw(graphics2D9, rectangle2D13);
        java.awt.geom.Point2D point2D15 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 10, (double) (-1L), rectangle2D13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets0.createAdjustedRectangle(rectangle2D13, lengthAdjustmentType16, lengthAdjustmentType17);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(point2D15);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        int int5 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 'a');
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        org.jfree.data.gantt.Task task10 = new org.jfree.data.gantt.Task("java.awt.Color[r=128,g=128,b=255]", (org.jfree.data.time.TimePeriod) simpleTimePeriod9);
        int int11 = task10.getSubtaskCount();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer12 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendTitle13.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean18 = rectangleAnchor14.equals((java.lang.Object) simpleTimePeriod17);
        task10.setDuration((org.jfree.data.time.TimePeriod) simpleTimePeriod17);
        try {
            java.lang.Number number21 = defaultKeyedValues2D1.getValue((java.lang.Comparable) simpleTimePeriod17, (java.lang.Comparable) 128);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 128");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        polarPlot8.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str13 = textTitle12.getText();
        java.awt.Font font14 = textTitle12.getFont();
        polarPlot8.setAngleLabelFont(font14);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = polarPlot8.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        polarPlot8.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis17);
        java.awt.Paint paint19 = polarPlot8.getAngleLabelPaint();
        java.awt.Paint paint20 = polarPlot8.getAngleLabelPaint();
        java.awt.Stroke stroke21 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) spreadsheetDate2, paint20, stroke21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Font font2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        polarPlot6.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str11 = textTitle10.getText();
        java.awt.Font font12 = textTitle10.getFont();
        polarPlot6.setAngleLabelFont(font12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) polarPlot6, true);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart15, chartChangeEventType16);
        java.awt.Image image18 = jFreeChart15.getBackgroundImage();
        jFreeChart15.fireChartChanged();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(image18);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("java.awt.Color[r=128,g=128,b=255]", (int) '#', (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.clear();
        try {
            java.lang.Number number5 = defaultKeyedValues2D1.getValue(0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        java.awt.Paint paint2 = dateAxis1.getTickLabelPaint();
        double double3 = dateAxis1.getUpperMargin();
        double double4 = dateAxis1.getAutoRangeMinimumSize();
        boolean boolean5 = dateAxis1.isAutoRange();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean3 = lineRenderer3D0.getItemShapeVisible((int) ' ', (int) ' ');
        java.awt.Paint paint4 = lineRenderer3D0.getWallPaint();
        double double5 = lineRenderer3D0.getYOffset();
        boolean boolean6 = lineRenderer3D0.getAutoPopulateSeriesPaint();
        lineRenderer3D0.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str5 = textTitle4.getText();
        textTitle4.setMargin((double) 100.0f, (double) 11, (double) 0, 0.0d);
        java.lang.Object obj11 = textTitle4.clone();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        textTitle4.setPaint((java.awt.Paint) color12);
        stackedBarRenderer3D0.setBasePaint((java.awt.Paint) color12, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(8);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "August" + "'", str1.equals("August"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        boolean boolean3 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) color1);
        try {
            org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem6 = defaultBoxAndWhiskerCategoryDataset0.getItem((int) (byte) 100, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint9, stroke10);
        categoryPlot0.setRangeCrosshairStroke(stroke10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double19 = dateAxis18.getFixedDimension();
        boolean boolean20 = dateAxis18.isAxisLineVisible();
        java.lang.String str21 = dateAxis18.getLabelURL();
        dateAxis18.setTickMarksVisible(true);
        java.lang.String[] strArray24 = new java.lang.String[] {};
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray24, numberArray25, numberArray26);
        org.jfree.data.general.DatasetGroup datasetGroup29 = new org.jfree.data.general.DatasetGroup("hi!");
        defaultIntervalCategoryDataset27.setGroup(datasetGroup29);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str33 = textTitle32.getText();
        java.awt.Font font34 = textTitle32.getFont();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str38 = textTitle37.getText();
        java.awt.geom.Rectangle2D rectangle2D39 = textTitle37.getBounds();
        textTitle32.draw(graphics2D35, rectangle2D39);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer41 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer41);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = legendTitle42.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean47 = rectangleAnchor43.equals((java.lang.Object) simpleTimePeriod46);
        java.awt.Shape shape50 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D39, rectangleAnchor43, 4.0d, (double) 100L);
        org.jfree.chart.title.TextTitle textTitle52 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str53 = textTitle52.getText();
        java.awt.Font font54 = textTitle52.getFont();
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str58 = textTitle57.getText();
        java.awt.geom.Rectangle2D rectangle2D59 = textTitle57.getBounds();
        textTitle52.draw(graphics2D55, rectangle2D59);
        boolean boolean61 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D39, rectangle2D59);
        boolean boolean62 = datasetGroup29.equals((java.lang.Object) rectangle2D59);
        dateAxis18.setLeftArrow((java.awt.Shape) rectangle2D59);
        java.awt.geom.Point2D point2D64 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 0.0f, (double) (short) 0, rectangle2D59);
        categoryPlot0.zoomRangeAxes(4.0d, plotRenderingInfo14, point2D64);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "" + "'", str58.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(point2D64);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle7.getBounds();
        chartRenderingInfo5.setChartArea(rectangle2D9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D9, (java.awt.Paint) color11);
        org.jfree.data.general.Dataset dataset13 = legendItem12.getDataset();
        boolean boolean14 = legendItem12.isLineVisible();
        java.lang.String str15 = legendItem12.getToolTipText();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(dataset13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke3 = defaultDrawingSupplier2.getNextStroke();
        java.awt.Stroke[] strokeArray4 = new java.awt.Stroke[] { stroke3 };
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str12 = textTitle11.getText();
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle11.getBounds();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D13, (double) (short) 10, 100.0f, (float) (short) -1);
        java.awt.Color color19 = java.awt.Color.white;
        java.awt.Color color21 = java.awt.Color.white;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str26 = textTitle25.getText();
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle25.getBounds();
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D27, (double) (short) 10, 100.0f, (float) (short) -1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean34 = stackedBarRenderer3D32.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke35 = stackedBarRenderer3D32.getBaseStroke();
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("hi!", "java.awt.Color[r=128,g=128,b=255]", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "RectangleEdge.TOP", true, (java.awt.Shape) rectangle2D13, true, (java.awt.Paint) color19, false, (java.awt.Paint) color21, stroke22, true, (java.awt.Shape) rectangle2D27, stroke35, (java.awt.Paint) color36);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer38 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean40 = ganttRenderer38.equals((java.lang.Object) '#');
        java.awt.Stroke stroke43 = ganttRenderer38.getItemOutlineStroke(11, 1);
        java.awt.Stroke[] strokeArray44 = new java.awt.Stroke[] { stroke35, stroke43 };
        java.awt.Shape[] shapeArray45 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier46 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray4, strokeArray44, shapeArray45);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(strokeArray44);
        org.junit.Assert.assertNotNull(shapeArray45);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Object obj1 = null;
        boolean boolean2 = flowArrangement0.equals(obj1);
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray5 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray3, numberArray4, numberArray5);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer7 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle8.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean13 = rectangleAnchor9.equals((java.lang.Object) simpleTimePeriod12);
        java.util.Date date14 = simpleTimePeriod12.getStart();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) defaultIntervalCategoryDataset6, (java.lang.Comparable) simpleTimePeriod12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = new org.jfree.chart.labels.ItemLabelPosition();
        boolean boolean17 = flowArrangement0.equals((java.lang.Object) itemLabelPosition16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset1, valueAxis2, polarItemRenderer3);
        polarPlot4.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.awt.Font font10 = textTitle8.getFont();
        polarPlot4.setAngleLabelFont(font10);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean14 = stackedBarRenderer3D12.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer15 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer15.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color17);
        stackedBarRenderer3D12.setWallPaint((java.awt.Paint) color17);
        polarPlot4.setNoDataMessagePaint((java.awt.Paint) color17);
        boolean boolean21 = areaRendererEndType0.equals((java.lang.Object) polarPlot4);
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle1.getLegendItemGraphicPadding();
        double double6 = rectangleInsets4.trimHeight((double) (short) 100);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 96.0d + "'", double6 == 96.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.lang.Boolean boolean2 = lineRenderer3D0.getSeriesShapesFilled(15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = lineRenderer3D0.getPositiveItemLabelPosition(8, 1);
        double double6 = lineRenderer3D0.getYOffset();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Object obj1 = null;
        boolean boolean2 = flowArrangement0.equals(obj1);
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray5 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray3, numberArray4, numberArray5);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer7 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle8.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean13 = rectangleAnchor9.equals((java.lang.Object) simpleTimePeriod12);
        java.util.Date date14 = simpleTimePeriod12.getStart();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) defaultIntervalCategoryDataset6, (java.lang.Comparable) simpleTimePeriod12);
        try {
            int int17 = defaultIntervalCategoryDataset6.getSeriesIndex((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = levelRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        levelRenderer0.setSeriesOutlinePaint((int) (short) 10, (java.awt.Paint) color3);
        levelRenderer0.setMaximumItemWidth(0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        java.awt.Paint paint3 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = blockContainer6.arrange(graphics2D7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment9, verticalAlignment10, (double) (-1), (double) (-1.0f));
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement13);
        blockContainer6.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement13);
        legendTitle1.setWrapper(blockContainer6);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(size2D8);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.lang.Boolean boolean2 = lineRenderer3D0.getSeriesShapesFilled(15);
        double double3 = lineRenderer3D0.getXOffset();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot4.getRangeMarkers(3, layer6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot4.setRangeGridlinePaint((java.awt.Paint) color8);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot4.getRangeAxisForDataset((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot12.getRangeMarkers(3, layer14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot12.setRangeGridlinePaint((java.awt.Paint) color16);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot12.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint21, stroke22);
        categoryPlot12.setRangeCrosshairStroke(stroke22);
        categoryPlot4.setOutlineStroke(stroke22);
        boolean boolean26 = lineRenderer3D0.equals((java.lang.Object) categoryPlot4);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.0d + "'", double3 == 12.0d);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean2 = lineAndShapeRenderer0.equals((java.lang.Object) 12);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesShapesVisible((-1));
        java.lang.Object obj5 = lineAndShapeRenderer0.clone();
        java.lang.Boolean boolean7 = lineAndShapeRenderer0.getSeriesVisibleInLegend(100);
        boolean boolean8 = lineAndShapeRenderer0.getUseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot3.setRadiusGridlineStroke(stroke4);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer6 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean8 = ganttRenderer6.equals((java.lang.Object) '#');
        ganttRenderer6.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Shape shape14 = ganttRenderer6.getSeriesShape(5);
        ganttRenderer6.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean17 = polarPlot3.equals((java.lang.Object) true);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double20 = dateAxis19.getFixedDimension();
        java.util.Date date21 = dateAxis19.getMinimumDate();
        dateAxis19.setAutoRangeMinimumSize(49.5d, false);
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        dateAxis19.setTickMarkStroke(stroke25);
        polarPlot3.setAngleGridlineStroke(stroke25);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        java.lang.Object obj1 = null;
        boolean boolean2 = intervalCategoryToolTipGenerator0.equals(obj1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean5 = stackedBarRenderer3D3.equals((java.lang.Object) (short) 10);
        stackedBarRenderer3D3.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        boolean boolean11 = stackedBarRenderer3D3.isItemLabelVisible(3, 0);
        double double12 = stackedBarRenderer3D3.getMinimumBarLength();
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray19, numberArray24, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray30);
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset31);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset31, false);
        org.jfree.data.Range range35 = stackedBarRenderer3D3.findRangeBounds(categoryDataset31);
        java.lang.String str37 = intervalCategoryToolTipGenerator0.generateColumnLabel(categoryDataset31, 1);
        org.jfree.chart.plot.PlotState plotState38 = new org.jfree.chart.plot.PlotState();
        java.util.Map map39 = plotState38.getSharedAxisStates();
        boolean boolean40 = intervalCategoryToolTipGenerator0.equals((java.lang.Object) map39);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 300.0d + "'", number32.equals(300.0d));
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!2" + "'", str37.equals("hi!2"));
        org.junit.Assert.assertNotNull(map39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray7, numberArray12, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray18);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset19, false);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset19);
        double double24 = range23.getLength();
        org.jfree.data.KeyedObject keyedObject25 = new org.jfree.data.KeyedObject((java.lang.Comparable) 5, (java.lang.Object) double24);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.lang.Class<?> wildcardClass27 = stackedBarRenderer3D26.getClass();
        keyedObject25.setObject((java.lang.Object) stackedBarRenderer3D26);
        java.lang.Object obj29 = keyedObject25.getObject();
        java.lang.Object obj30 = keyedObject25.clone();
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 300.0d + "'", number20.equals(300.0d));
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 303.0d + "'", double24 == 303.0d);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Shape shape8 = ganttRenderer0.getSeriesShape(5);
        ganttRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        ganttRenderer0.setAutoPopulateSeriesStroke(true);
        boolean boolean13 = ganttRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = ganttRenderer0.getBasePositiveItemLabelPosition();
        ganttRenderer0.setItemLabelAnchorOffset((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.awt.Font font11 = textTitle9.getFont();
        polarPlot5.setAngleLabelFont(font11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) polarPlot5, true);
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart14.createBufferedImage((int) '#', 1);
        java.awt.Paint paint18 = jFreeChart14.getBorderPaint();
        jFreeChart14.removeLegend();
        try {
            java.awt.image.BufferedImage bufferedImage22 = jFreeChart14.createBufferedImage((int) (short) 0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (6) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(bufferedImage17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean3 = lineRenderer3D0.getItemShapeVisible((int) ' ', (int) ' ');
        boolean boolean6 = lineRenderer3D0.getItemShapeVisible((int) (byte) 0, 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot1);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot0.setDomainAxis(categoryAxis7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = null;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str17 = textTitle16.getText();
        java.awt.Font font18 = textTitle16.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis10, (double) 12, 300.0d, (double) 10.0f, 0.25d, font18);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean22 = stackedBarRenderer3D20.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer23 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer23.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color25);
        stackedBarRenderer3D20.setWallPaint((java.awt.Paint) color25);
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("", font18, (java.awt.Paint) color25);
        java.awt.Paint paint29 = labelBlock28.getPaint();
        categoryPlot0.setRangeCrosshairPaint(paint29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot(xYDataset34, valueAxis35, polarItemRenderer36);
        polarPlot37.removeCornerTextItem("");
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = polarPlot37.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation33, plotOrientation40);
        org.jfree.chart.plot.PlotOrientation plotOrientation42 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation33, plotOrientation42);
        categoryPlot0.setDomainAxisLocation(axisLocation33);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(plotOrientation40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(plotOrientation42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        int int5 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 'a');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date9 = spreadsheetDate8.toDate();
        int int10 = spreadsheetDate8.getMonth();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.lang.Class<?> wildcardClass12 = stackedBarRenderer3D11.getClass();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double15 = dateAxis14.getFixedDimension();
        java.util.Date date16 = dateAxis14.getMaximumDate();
        dateAxis14.setAutoRangeMinimumSize(3.0d);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer19 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendTitle20.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean25 = rectangleAnchor21.equals((java.lang.Object) simpleTimePeriod24);
        java.util.Date date26 = simpleTimePeriod24.getStart();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = dateAxis14.dateToJava2D(date26, rectangle2D27, rectangleEdge28);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = categoryPlot30.getRangeMarkers(3, layer32);
        java.util.List list34 = categoryPlot30.getAnnotations();
        java.awt.Paint paint35 = categoryPlot30.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double39 = dateAxis38.getFixedDimension();
        boolean boolean40 = dateAxis38.isAutoTickUnitSelection();
        categoryPlot30.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis38, true);
        dateAxis38.setRangeAboutValue((double) 0, (double) (short) 100);
        java.util.TimeZone timeZone46 = dateAxis38.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date26, timeZone46);
        try {
            defaultKeyedValues2D1.setValue((java.lang.Number) 10.0f, (java.lang.Comparable) int10, (java.lang.Comparable) regularTimePeriod47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double7 = dateAxis6.getFixedDimension();
        boolean boolean8 = dateAxis6.isAxisLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot10);
        categoryPlot9.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart14);
        java.awt.Font font16 = categoryPlot9.getNoDataMessageFont();
        dateAxis6.setLabelFont(font16);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D0, (double) (short) 0, (double) ' ', 300.0d, (double) (short) 100, font16);
        numberAxis3D0.setAutoRangeIncludesZero(false);
        java.text.NumberFormat numberFormat21 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat21);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator1 = boxAndWhiskerRenderer0.getBaseURLGenerator();
        int int2 = boxAndWhiskerRenderer0.getPassCount();
        org.junit.Assert.assertNull(categoryURLGenerator1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers(3, layer10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot8.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint17, stroke18);
        categoryPlot8.setRangeCrosshairStroke(stroke18);
        categoryPlot0.setOutlineStroke(stroke18);
        java.lang.String str22 = categoryPlot0.getNoDataMessage();
        categoryPlot0.setOutlineVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        java.awt.Paint paint28 = dateAxis27.getTickLabelPaint();
        double double29 = dateAxis27.getUpperMargin();
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis27);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        java.util.Date date3 = dateAxis1.getMinimumDate();
        java.awt.Stroke stroke4 = dateAxis1.getTickMarkStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setCircular(false);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot3D1.setToolTipGenerator(pieToolTipGenerator4);
        boolean boolean6 = piePlot3D1.getLabelLinksVisible();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean9 = stackedBarRenderer3D7.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke10 = stackedBarRenderer3D7.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = stackedBarRenderer3D7.getItemLabelGenerator((int) (short) -1, 0);
        java.awt.Paint paint14 = stackedBarRenderer3D7.getBaseItemLabelPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot15.getRangeMarkers(3, layer17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot15.setRangeGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot15.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint24, stroke25);
        categoryPlot15.setRangeCrosshairStroke(stroke25);
        stackedBarRenderer3D7.setBaseStroke(stroke25, true);
        piePlot3D1.setLabelLinkStroke(stroke25);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.NumberAxis numberAxis1 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.Font font9 = textTitle7.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, (double) 12, 300.0d, (double) 10.0f, 0.25d, font9);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean13 = stackedBarRenderer3D11.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer14 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer14.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color16);
        stackedBarRenderer3D11.setWallPaint((java.awt.Paint) color16);
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("", font9, (java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double22 = rectangleInsets20.calculateBottomOutset(0.4d);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str27 = textTitle26.getText();
        java.awt.Font font28 = textTitle26.getFont();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str32 = textTitle31.getText();
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle31.getBounds();
        textTitle26.draw(graphics2D29, rectangle2D33);
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 10, (double) (-1L), rectangle2D33);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType37 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets20.createAdjustedRectangle(rectangle2D33, lengthAdjustmentType36, lengthAdjustmentType37);
        labelBlock19.setBounds(rectangle2D38);
        labelBlock19.setURLText("hi!2");
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = null;
        try {
            labelBlock19.setPadding(rectangleInsets42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.0d + "'", double22 == 3.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNotNull(lengthAdjustmentType36);
        org.junit.Assert.assertNotNull(lengthAdjustmentType37);
        org.junit.Assert.assertNotNull(rectangle2D38);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double9 = dateAxis8.getFixedDimension();
        boolean boolean10 = dateAxis8.isAutoTickUnitSelection();
        categoryPlot0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis8, true);
        dateAxis8.setRangeAboutValue((double) (short) 10, (double) 86400000L);
        double double16 = dateAxis8.getFixedDimension();
        float float17 = dateAxis8.getTickMarkInsideLength();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) 1.0f);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        boolean boolean5 = rectangleInsets0.equals((java.lang.Object) pieDataset3);
        java.awt.Font font7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        polarPlot11.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str16 = textTitle15.getText();
        java.awt.Font font17 = textTitle15.getFont();
        polarPlot11.setAngleLabelFont(font17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", font7, (org.jfree.chart.plot.Plot) polarPlot11, true);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str24 = textTitle23.getText();
        java.awt.Font font25 = textTitle23.getFont();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str29 = textTitle28.getText();
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle28.getBounds();
        textTitle23.draw(graphics2D26, rectangle2D30);
        java.awt.geom.Point2D point2D32 = null;
        org.jfree.chart.plot.PlotState plotState33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        polarPlot11.draw(graphics2D21, rectangle2D30, point2D32, plotState33, plotRenderingInfo34);
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets0.createInsetRectangle(rectangle2D30);
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray45, numberArray50, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray56);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity60 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D36, "hi!", "({0}, {1}) = {2}", categoryDataset57, (java.lang.Comparable) 0.0f, (java.lang.Comparable) 0);
        java.lang.String[] strArray61 = new java.lang.String[] {};
        java.lang.Number[][] numberArray62 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray63 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset64 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray61, numberArray62, numberArray63);
        org.jfree.data.xy.XYDataset xYDataset65 = null;
        org.jfree.chart.axis.ValueAxis valueAxis66 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer67 = null;
        org.jfree.chart.plot.PolarPlot polarPlot68 = new org.jfree.chart.plot.PolarPlot(xYDataset65, valueAxis66, polarItemRenderer67);
        java.awt.Stroke stroke69 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot68.setRadiusGridlineStroke(stroke69);
        boolean boolean71 = defaultIntervalCategoryDataset64.hasListener((java.util.EventListener) polarPlot68);
        org.jfree.data.general.DatasetGroup datasetGroup73 = new org.jfree.data.general.DatasetGroup("ClassContext");
        defaultIntervalCategoryDataset64.setGroup(datasetGroup73);
        categoryItemEntity60.setDataset((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset64);
        java.lang.String str76 = categoryItemEntity60.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertNotNull(strArray61);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        int int6 = categoryPlot0.getDomainAxisIndex(categoryAxis5);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(6, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        double double1 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot5);
        java.lang.Object obj10 = lineAndShapeRenderer0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        java.lang.Object obj2 = standardGradientPaintTransformer0.clone();
        java.awt.GradientPaint gradientPaint3 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double6 = rectangleInsets4.calculateBottomOutset(0.4d);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str11 = textTitle10.getText();
        java.awt.Font font12 = textTitle10.getFont();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str16 = textTitle15.getText();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle15.getBounds();
        textTitle10.draw(graphics2D13, rectangle2D17);
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 10, (double) (-1L), rectangle2D17);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets4.createAdjustedRectangle(rectangle2D17, lengthAdjustmentType20, lengthAdjustmentType21);
        try {
            java.awt.GradientPaint gradientPaint23 = standardGradientPaintTransformer0.transform(gradientPaint3, (java.awt.Shape) rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertNotNull(lengthAdjustmentType20);
        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint1, stroke2);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker3.setLabelTextAnchor(textAnchor4);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        valueMarker3.notifyListeners(markerChangeEvent6);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        java.lang.Object obj1 = null;
        boolean boolean2 = intervalCategoryToolTipGenerator0.equals(obj1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean5 = stackedBarRenderer3D3.equals((java.lang.Object) (short) 10);
        stackedBarRenderer3D3.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        boolean boolean11 = stackedBarRenderer3D3.isItemLabelVisible(3, 0);
        double double12 = stackedBarRenderer3D3.getMinimumBarLength();
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray19, numberArray24, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray30);
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset31);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset31, false);
        org.jfree.data.Range range35 = stackedBarRenderer3D3.findRangeBounds(categoryDataset31);
        java.lang.String str37 = intervalCategoryToolTipGenerator0.generateColumnLabel(categoryDataset31, 1);
        java.lang.Number number38 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset31);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 300.0d + "'", number32.equals(300.0d));
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!2" + "'", str37.equals("hi!2"));
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + (-1.0d) + "'", number38.equals((-1.0d)));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 100, false);
        categoryPlot0.setAnchorValue((double) 1);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getTop();
        double double2 = axisSpace0.getRight();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) 1.0f);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        boolean boolean5 = rectangleInsets0.equals((java.lang.Object) pieDataset3);
        java.awt.Font font7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        polarPlot11.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str16 = textTitle15.getText();
        java.awt.Font font17 = textTitle15.getFont();
        polarPlot11.setAngleLabelFont(font17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", font7, (org.jfree.chart.plot.Plot) polarPlot11, true);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str24 = textTitle23.getText();
        java.awt.Font font25 = textTitle23.getFont();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str29 = textTitle28.getText();
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle28.getBounds();
        textTitle23.draw(graphics2D26, rectangle2D30);
        java.awt.geom.Point2D point2D32 = null;
        org.jfree.chart.plot.PlotState plotState33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        polarPlot11.draw(graphics2D21, rectangle2D30, point2D32, plotState33, plotRenderingInfo34);
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets0.createInsetRectangle(rectangle2D30);
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray45, numberArray50, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray56);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity60 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D36, "hi!", "({0}, {1}) = {2}", categoryDataset57, (java.lang.Comparable) 0.0f, (java.lang.Comparable) 0);
        org.jfree.data.general.PieDataset pieDataset62 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset57, 3);
        org.jfree.chart.plot.PiePlot piePlot63 = new org.jfree.chart.plot.PiePlot(pieDataset62);
        boolean boolean64 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset62);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertNotNull(pieDataset62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean3 = lineRenderer3D0.getItemShapeVisible((int) ' ', (int) ' ');
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font5 = dateAxis4.getTickLabelFont();
        boolean boolean6 = lineRenderer3D0.equals((java.lang.Object) font5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) 1.0f);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        boolean boolean5 = rectangleInsets0.equals((java.lang.Object) pieDataset3);
        java.awt.Font font7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        polarPlot11.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str16 = textTitle15.getText();
        java.awt.Font font17 = textTitle15.getFont();
        polarPlot11.setAngleLabelFont(font17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", font7, (org.jfree.chart.plot.Plot) polarPlot11, true);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str24 = textTitle23.getText();
        java.awt.Font font25 = textTitle23.getFont();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str29 = textTitle28.getText();
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle28.getBounds();
        textTitle23.draw(graphics2D26, rectangle2D30);
        java.awt.geom.Point2D point2D32 = null;
        org.jfree.chart.plot.PlotState plotState33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        polarPlot11.draw(graphics2D21, rectangle2D30, point2D32, plotState33, plotRenderingInfo34);
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets0.createInsetRectangle(rectangle2D30);
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray45, numberArray50, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray56);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity60 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D36, "hi!", "({0}, {1}) = {2}", categoryDataset57, (java.lang.Comparable) 0.0f, (java.lang.Comparable) 0);
        org.jfree.data.general.PieDataset pieDataset62 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset57, 3);
        org.jfree.chart.plot.PiePlot piePlot63 = new org.jfree.chart.plot.PiePlot(pieDataset62);
        java.lang.Comparable comparable64 = null;
        try {
            java.awt.Paint paint65 = piePlot63.getSectionPaint(comparable64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertNotNull(pieDataset62);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double10 = rectangleInsets8.trimHeight((double) 1.0f);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D(pieDataset11);
        boolean boolean13 = rectangleInsets8.equals((java.lang.Object) pieDataset11);
        java.awt.Font font15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot(xYDataset16, valueAxis17, polarItemRenderer18);
        polarPlot19.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str24 = textTitle23.getText();
        java.awt.Font font25 = textTitle23.getFont();
        polarPlot19.setAngleLabelFont(font25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("", font15, (org.jfree.chart.plot.Plot) polarPlot19, true);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str32 = textTitle31.getText();
        java.awt.Font font33 = textTitle31.getFont();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str37 = textTitle36.getText();
        java.awt.geom.Rectangle2D rectangle2D38 = textTitle36.getBounds();
        textTitle31.draw(graphics2D34, rectangle2D38);
        java.awt.geom.Point2D point2D40 = null;
        org.jfree.chart.plot.PlotState plotState41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        polarPlot19.draw(graphics2D29, rectangle2D38, point2D40, plotState41, plotRenderingInfo42);
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets8.createInsetRectangle(rectangle2D38);
        java.lang.Number[] numberArray53 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray58 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray63 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray64 = new java.lang.Number[][] { numberArray53, numberArray58, numberArray63 };
        org.jfree.data.category.CategoryDataset categoryDataset65 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray64);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity68 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D44, "hi!", "({0}, {1}) = {2}", categoryDataset65, (java.lang.Comparable) 0.0f, (java.lang.Comparable) 0);
        java.lang.String[] strArray69 = new java.lang.String[] {};
        java.lang.Number[][] numberArray70 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray71 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset72 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray69, numberArray70, numberArray71);
        org.jfree.data.xy.XYDataset xYDataset73 = null;
        org.jfree.chart.axis.ValueAxis valueAxis74 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer75 = null;
        org.jfree.chart.plot.PolarPlot polarPlot76 = new org.jfree.chart.plot.PolarPlot(xYDataset73, valueAxis74, polarItemRenderer75);
        java.awt.Stroke stroke77 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot76.setRadiusGridlineStroke(stroke77);
        boolean boolean79 = defaultIntervalCategoryDataset72.hasListener((java.util.EventListener) polarPlot76);
        org.jfree.data.general.DatasetGroup datasetGroup81 = new org.jfree.data.general.DatasetGroup("ClassContext");
        defaultIntervalCategoryDataset72.setGroup(datasetGroup81);
        categoryItemEntity68.setDataset((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset72);
        try {
            categoryPlot0.setDataset((int) (byte) -1, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray58);
        org.junit.Assert.assertNotNull(numberArray63);
        org.junit.Assert.assertNotNull(numberArray64);
        org.junit.Assert.assertNotNull(categoryDataset65);
        org.junit.Assert.assertNotNull(strArray69);
        org.junit.Assert.assertNotNull(numberArray70);
        org.junit.Assert.assertNotNull(numberArray71);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.awt.Paint paint4 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (byte) 100, 0.0d, (-1.0d), (double) 3, paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle7.getBounds();
        chartRenderingInfo5.setChartArea(rectangle2D9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D9, (java.awt.Paint) color11);
        org.jfree.data.general.Dataset dataset13 = legendItem12.getDataset();
        legendItem12.setSeriesKey((java.lang.Comparable) '#');
        java.awt.Stroke stroke16 = legendItem12.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(dataset13);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.equals((java.lang.Object) (short) 10);
        stackedBarRenderer3D0.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        boolean boolean8 = stackedBarRenderer3D0.isItemLabelVisible(3, 0);
        double double9 = stackedBarRenderer3D0.getMinimumBarLength();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot12);
        categoryPlot11.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart16);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double20 = dateAxis19.getFixedDimension();
        java.util.Date date21 = dateAxis19.getMinimumDate();
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str30 = textTitle29.getText();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle29.getBounds();
        chartRenderingInfo27.setChartArea(rectangle2D31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D31, (java.awt.Paint) color33);
        stackedBarRenderer3D0.drawRangeGridline(graphics2D10, categoryPlot11, (org.jfree.chart.axis.ValueAxis) dateAxis19, rectangle2D31, 300.0d);
        dateAxis19.setAutoTickUnitSelection(false);
        dateAxis19.setTickMarkOutsideLength((float) 3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.axis.NumberAxis numberAxis3 = null;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.awt.Font font11 = textTitle9.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis3, (double) 12, 300.0d, (double) 10.0f, 0.25d, font11);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str15 = textTitle14.getText();
        textTitle14.setMargin((double) 100.0f, (double) 11, (double) 0, 0.0d);
        java.lang.Object obj21 = textTitle14.clone();
        java.lang.Object obj22 = textTitle14.clone();
        java.awt.Paint paint23 = textTitle14.getPaint();
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("org.jfree.data.UnknownKeyException: hi!", font11, paint23);
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("RectangleEdge.TOP", font11);
        java.awt.geom.Rectangle2D rectangle2D26 = labelBlock25.getBounds();
        rectangleInsets0.trim(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangle2D26);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.NumberAxis numberAxis1 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.Font font9 = textTitle7.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, (double) 12, 300.0d, (double) 10.0f, 0.25d, font9);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str13 = textTitle12.getText();
        textTitle12.setMargin((double) 100.0f, (double) 11, (double) 0, 0.0d);
        java.lang.Object obj19 = textTitle12.clone();
        java.lang.Object obj20 = textTitle12.clone();
        java.awt.Paint paint21 = textTitle12.getPaint();
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("org.jfree.data.UnknownKeyException: hi!", font9, paint21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer24 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint26 = ganttRenderer24.getSeriesFillPaint((int) ' ');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = ganttRenderer24.getSeriesNegativeItemLabelPosition(10);
        org.jfree.chart.text.TextAnchor textAnchor29 = itemLabelPosition28.getRotationAnchor();
        try {
            float float30 = textFragment22.calculateBaselineOffset(graphics2D23, textAnchor29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(textAnchor29);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!2");
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.awt.Font font11 = textTitle9.getFont();
        polarPlot5.setAngleLabelFont(font11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) polarPlot5, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        polarPlot5.rendererChanged(rendererChangeEvent15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot20);
        categoryPlot20.clearRangeMarkers((-1));
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot20.getDomainAxisLocation((int) (byte) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str36 = textTitle35.getText();
        java.awt.Font font37 = textTitle35.getFont();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str41 = textTitle40.getText();
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle40.getBounds();
        textTitle35.draw(graphics2D38, rectangle2D42);
        java.awt.geom.Point2D point2D44 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 10, (double) (-1L), rectangle2D42);
        categoryPlot20.zoomRangeAxes((double) (byte) 10, (double) 1.0f, plotRenderingInfo31, point2D44);
        polarPlot5.zoomDomainAxes((double) (byte) -1, 8.0d, plotRenderingInfo19, point2D44);
        java.awt.Stroke stroke47 = polarPlot5.getAngleGridlineStroke();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(point2D44);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke3 = stackedBarRenderer3D0.getBaseStroke();
        double double4 = stackedBarRenderer3D0.getLowerClip();
        java.awt.Paint paint5 = stackedBarRenderer3D0.getWallPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=255]");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.Range range3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, (double) 11);
        java.lang.String str6 = rectangleConstraint5.toString();
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray13, numberArray18, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray24);
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset25);
        org.jfree.data.Range range28 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset25, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = rectangleConstraint5.toRangeHeight(range28);
        try {
            org.jfree.chart.util.Size2D size2D30 = textTitle1.arrange(graphics2D2, rectangleConstraint29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]" + "'", str6.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]"));
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 300.0d + "'", number26.equals(300.0d));
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double5 = rectangleInsets3.trimHeight((double) 1.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D(pieDataset6);
        boolean boolean8 = rectangleInsets3.equals((java.lang.Object) pieDataset6);
        java.awt.Font font10 = null;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot(xYDataset11, valueAxis12, polarItemRenderer13);
        polarPlot14.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str19 = textTitle18.getText();
        java.awt.Font font20 = textTitle18.getFont();
        polarPlot14.setAngleLabelFont(font20);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("", font10, (org.jfree.chart.plot.Plot) polarPlot14, true);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str27 = textTitle26.getText();
        java.awt.Font font28 = textTitle26.getFont();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str32 = textTitle31.getText();
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle31.getBounds();
        textTitle26.draw(graphics2D29, rectangle2D33);
        java.awt.geom.Point2D point2D35 = null;
        org.jfree.chart.plot.PlotState plotState36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        polarPlot14.draw(graphics2D24, rectangle2D33, point2D35, plotState36, plotRenderingInfo37);
        java.awt.geom.Rectangle2D rectangle2D39 = rectangleInsets3.createInsetRectangle(rectangle2D33);
        java.lang.Number[] numberArray48 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray53 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray58 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray59 = new java.lang.Number[][] { numberArray48, numberArray53, numberArray58 };
        org.jfree.data.category.CategoryDataset categoryDataset60 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray59);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity63 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D39, "hi!", "({0}, {1}) = {2}", categoryDataset60, (java.lang.Comparable) 0.0f, (java.lang.Comparable) 0);
        org.jfree.data.Range range64 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset60);
        org.jfree.data.Range range65 = stackedBarRenderer3D0.findRangeBounds(categoryDataset60);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray53);
        org.junit.Assert.assertNotNull(numberArray58);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(categoryDataset60);
        org.junit.Assert.assertNotNull(range64);
        org.junit.Assert.assertNotNull(range65);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = categoryPlot1.getRangeMarkers(3, layer3);
        java.util.List list5 = categoryPlot1.getAnnotations();
        categoryPlot1.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot10.setRadiusGridlineStroke(stroke11);
        categoryPlot1.setDomainGridlineStroke(stroke11);
        boolean boolean14 = shapeList0.equals((java.lang.Object) categoryPlot1);
        int int15 = shapeList0.size();
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.lang.Object obj2 = null;
        try {
            int int3 = spreadsheetDate1.compareTo(obj2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        try {
            org.jfree.data.gantt.Task task3 = taskSeries1.get((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis6);
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str7 = textTitle6.getText();
        java.awt.geom.Rectangle2D rectangle2D8 = textTitle6.getBounds();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D8, (double) (short) 10, 100.0f, (float) (short) -1);
        java.awt.Color color14 = java.awt.Color.white;
        java.awt.Color color16 = java.awt.Color.white;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str21 = textTitle20.getText();
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle20.getBounds();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D22, (double) (short) 10, 100.0f, (float) (short) -1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean29 = stackedBarRenderer3D27.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke30 = stackedBarRenderer3D27.getBaseStroke();
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("hi!", "java.awt.Color[r=128,g=128,b=255]", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "RectangleEdge.TOP", true, (java.awt.Shape) rectangle2D8, true, (java.awt.Paint) color14, false, (java.awt.Paint) color16, stroke17, true, (java.awt.Shape) rectangle2D22, stroke30, (java.awt.Paint) color31);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        float[] floatArray42 = new float[] { 4, (short) 1, (-1.0f), 128, 7 };
        float[] floatArray43 = color36.getColorComponents(floatArray42);
        float[] floatArray44 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) '#', 0, floatArray43);
        float[] floatArray45 = color16.getRGBComponents(floatArray43);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("java.awt.Color[r=128,g=128,b=255]");
        blockContainer0.add((org.jfree.chart.block.Block) labelBlock2);
        java.lang.Object obj4 = blockContainer0.clone();
        boolean boolean5 = blockContainer0.isEmpty();
        boolean boolean6 = blockContainer0.isEmpty();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        java.util.Date date3 = dateAxis1.getMaximumDate();
        dateAxis1.setAutoRangeMinimumSize(3.0d);
        dateAxis1.setTickMarkOutsideLength((float) 2);
        dateAxis1.setVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double3 = piePlot3D1.getExplodePercent((java.lang.Comparable) 0.2d);
        java.lang.Object obj4 = piePlot3D1.clone();
        piePlot3D1.setDepthFactor((double) (short) 100);
        boolean boolean7 = piePlot3D1.getLabelLinksVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator8);
        piePlot3D1.setLabelLinksVisible(true);
        java.awt.Paint paint12 = piePlot3D1.getLabelLinkPaint();
        float float13 = piePlot3D1.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        java.awt.geom.Rectangle2D rectangle2D3 = textTitle1.getBounds();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D3, (double) (short) 10, 100.0f, (float) (short) -1);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D3);
        java.lang.String str9 = chartEntity8.getShapeType();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "rect" + "'", str9.equals("rect"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.awt.Font font2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        polarPlot6.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str11 = textTitle10.getText();
        java.awt.Font font12 = textTitle10.getFont();
        polarPlot6.setAngleLabelFont(font12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) polarPlot6, true);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent18 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (-1.0f), jFreeChart15, (int) '4', (int) 'a');
        org.jfree.chart.JFreeChart jFreeChart19 = chartProgressEvent18.getChart();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(jFreeChart19);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke8 = ganttRenderer0.getSeriesStroke(0);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = null;
        org.jfree.chart.entity.EntityCollection entityCollection11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo(entityCollection11);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean15 = stackedBarRenderer3D13.equals((java.lang.Object) (short) 10);
        stackedBarRenderer3D13.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        boolean boolean21 = stackedBarRenderer3D13.isItemLabelVisible(3, 0);
        double double22 = stackedBarRenderer3D13.getMinimumBarLength();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot25);
        categoryPlot24.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart29);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double33 = dateAxis32.getFixedDimension();
        java.util.Date date34 = dateAxis32.getMinimumDate();
        org.jfree.chart.entity.EntityCollection entityCollection39 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = new org.jfree.chart.ChartRenderingInfo(entityCollection39);
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str43 = textTitle42.getText();
        java.awt.geom.Rectangle2D rectangle2D44 = textTitle42.getBounds();
        chartRenderingInfo40.setChartArea(rectangle2D44);
        java.awt.Color color46 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D44, (java.awt.Paint) color46);
        stackedBarRenderer3D13.drawRangeGridline(graphics2D23, categoryPlot24, (org.jfree.chart.axis.ValueAxis) dateAxis32, rectangle2D44, 300.0d);
        chartRenderingInfo12.setChartArea(rectangle2D44);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer53 = null;
        java.util.Collection collection54 = categoryPlot51.getRangeMarkers(3, layer53);
        java.awt.Color color55 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot51.setRangeGridlinePaint((java.awt.Paint) color55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        java.awt.Paint paint60 = dateAxis59.getTickLabelPaint();
        double double61 = dateAxis59.getUpperMargin();
        dateAxis59.resizeRange((double) (short) 1, 0.0d);
        java.awt.Font font65 = dateAxis59.getTickLabelFont();
        java.lang.String[] strArray66 = new java.lang.String[] {};
        java.lang.Number[][] numberArray67 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray68 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset69 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray66, numberArray67, numberArray68);
        org.jfree.data.general.DatasetGroup datasetGroup71 = new org.jfree.data.general.DatasetGroup("hi!");
        defaultIntervalCategoryDataset69.setGroup(datasetGroup71);
        try {
            ganttRenderer0.drawItem(graphics2D9, categoryItemRendererState10, rectangle2D44, categoryPlot51, categoryAxis57, (org.jfree.chart.axis.ValueAxis) dateAxis59, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset69, 7, (int) (byte) 10, (-3407872));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNull(collection54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.05d + "'", double61 == 0.05d);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNotNull(strArray66);
        org.junit.Assert.assertNotNull(numberArray67);
        org.junit.Assert.assertNotNull(numberArray68);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean3 = lineRenderer3D0.getItemShapeVisible((int) ' ', (int) ' ');
        java.awt.Paint paint4 = lineRenderer3D0.getWallPaint();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        polarPlot8.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str13 = textTitle12.getText();
        java.awt.Font font14 = textTitle12.getFont();
        polarPlot8.setAngleLabelFont(font14);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = polarPlot8.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        polarPlot8.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis17);
        java.awt.Paint paint19 = polarPlot8.getAngleLabelPaint();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color21 = color20.darker();
        polarPlot8.setNoDataMessagePaint((java.awt.Paint) color21);
        lineRenderer3D0.setBaseFillPaint((java.awt.Paint) color21);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D24 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean27 = lineRenderer3D24.getItemShapeVisible((int) ' ', (int) ' ');
        java.awt.Paint paint28 = lineRenderer3D24.getWallPaint();
        double double29 = lineRenderer3D24.getYOffset();
        boolean boolean30 = lineRenderer3D0.equals((java.lang.Object) double29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot32.getRangeMarkers(3, layer34);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot32.getRangeAxisEdge(2019);
        categoryPlot32.configureRangeAxes();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor39 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot32.setDomainGridlinePosition(categoryAnchor39);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer43 = null;
        java.util.Collection collection44 = categoryPlot41.getRangeMarkers(3, layer43);
        java.util.List list45 = categoryPlot41.getAnnotations();
        java.awt.Paint paint46 = categoryPlot41.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double50 = dateAxis49.getFixedDimension();
        boolean boolean51 = dateAxis49.isAutoTickUnitSelection();
        categoryPlot41.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis49, true);
        boolean boolean54 = dateAxis49.isVerticalTickLabels();
        double double55 = dateAxis49.getLowerMargin();
        dateAxis49.setTickMarkInsideLength((float) 10);
        dateAxis49.setInverted(true);
        java.awt.Font font61 = null;
        org.jfree.data.xy.XYDataset xYDataset62 = null;
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer64 = null;
        org.jfree.chart.plot.PolarPlot polarPlot65 = new org.jfree.chart.plot.PolarPlot(xYDataset62, valueAxis63, polarItemRenderer64);
        polarPlot65.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle69 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str70 = textTitle69.getText();
        java.awt.Font font71 = textTitle69.getFont();
        polarPlot65.setAngleLabelFont(font71);
        org.jfree.chart.JFreeChart jFreeChart74 = new org.jfree.chart.JFreeChart("", font61, (org.jfree.chart.plot.Plot) polarPlot65, true);
        java.awt.Graphics2D graphics2D75 = null;
        org.jfree.chart.title.TextTitle textTitle77 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str78 = textTitle77.getText();
        java.awt.Font font79 = textTitle77.getFont();
        java.awt.Graphics2D graphics2D80 = null;
        org.jfree.chart.title.TextTitle textTitle82 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str83 = textTitle82.getText();
        java.awt.geom.Rectangle2D rectangle2D84 = textTitle82.getBounds();
        textTitle77.draw(graphics2D80, rectangle2D84);
        java.awt.geom.Point2D point2D86 = null;
        org.jfree.chart.plot.PlotState plotState87 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo88 = null;
        polarPlot65.draw(graphics2D75, rectangle2D84, point2D86, plotState87, plotRenderingInfo88);
        try {
            lineRenderer3D0.drawRangeGridline(graphics2D31, categoryPlot32, (org.jfree.chart.axis.ValueAxis) dateAxis49, rectangle2D84, 0.25d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 8.0d + "'", double29 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(categoryAnchor39);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.05d + "'", double55 == 0.05d);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "" + "'", str70.equals(""));
        org.junit.Assert.assertNotNull(font71);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "" + "'", str78.equals(""));
        org.junit.Assert.assertNotNull(font79);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "" + "'", str83.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D84);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.clearRangeAxes();
        int int7 = categoryPlot0.getWeight();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray8);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.START;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor10);
        float float12 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean3 = lineRenderer3D0.getItemShapeVisible((int) ' ', (int) ' ');
        java.awt.Paint paint4 = lineRenderer3D0.getWallPaint();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        polarPlot8.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str13 = textTitle12.getText();
        java.awt.Font font14 = textTitle12.getFont();
        polarPlot8.setAngleLabelFont(font14);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = polarPlot8.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        polarPlot8.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis17);
        java.awt.Paint paint19 = polarPlot8.getAngleLabelPaint();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color21 = color20.darker();
        polarPlot8.setNoDataMessagePaint((java.awt.Paint) color21);
        lineRenderer3D0.setBaseFillPaint((java.awt.Paint) color21);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D24 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean27 = lineRenderer3D24.getItemShapeVisible((int) ' ', (int) ' ');
        java.awt.Paint paint28 = lineRenderer3D24.getWallPaint();
        double double29 = lineRenderer3D24.getYOffset();
        boolean boolean30 = lineRenderer3D0.equals((java.lang.Object) double29);
        lineRenderer3D0.setYOffset(1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 8.0d + "'", double29 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("java.awt.Color[r=128,g=128,b=255]");
        blockContainer0.add((org.jfree.chart.block.Block) labelBlock2);
        java.lang.Object obj4 = blockContainer0.clone();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.Range range6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range6, (double) 11);
        java.lang.String str9 = rectangleConstraint8.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint8.toUnconstrainedWidth();
        try {
            org.jfree.chart.util.Size2D size2D11 = blockContainer0.arrange(graphics2D5, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]" + "'", str9.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint10);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo1 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo1);
        basicProjectInfo0.addOptionalLibrary("SerialDate.weekInMonthToString(): invalid code.");
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double3 = dateAxis2.getFixedDimension();
        double double4 = dateAxis2.getLowerBound();
        float float5 = dateAxis2.getTickMarkInsideLength();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double5 = dateAxis4.getFixedDimension();
        boolean boolean6 = dateAxis4.isAxisLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot8);
        categoryPlot7.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart12);
        java.awt.Font font14 = categoryPlot7.getNoDataMessageFont();
        dateAxis4.setLabelFont(font14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = dateAxis4.getTickLabelInsets();
        textTitle1.setPadding(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.NumberAxis numberAxis2 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.awt.Font font10 = textTitle8.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis2, (double) 12, 300.0d, (double) 10.0f, 0.25d, font10);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean14 = stackedBarRenderer3D12.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer15 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer15.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color17);
        stackedBarRenderer3D12.setWallPaint((java.awt.Paint) color17);
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("", font10, (java.awt.Paint) color17);
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("hi!", font10);
        boolean boolean23 = textFragment21.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot25);
        categoryPlot24.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart29);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent33 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) boolean23, jFreeChart29, 5, 2958465);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        textTitle1.setMargin((double) 100.0f, (double) 11, (double) 0, 0.0d);
        java.lang.Object obj8 = textTitle1.clone();
        java.lang.Object obj9 = textTitle1.clone();
        java.awt.Paint paint10 = textTitle1.getPaint();
        textTitle1.setExpandToFitSpace(false);
        java.awt.Font font15 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ClassContext", font15);
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("", font15);
        textTitle1.setFont(font15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot1);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart5);
        java.awt.Font font7 = categoryPlot0.getNoDataMessageFont();
        int int8 = categoryPlot0.getRangeAxisCount();
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("ClassContext", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "", "hi!");
        boolean boolean6 = lengthAdjustmentType0.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke8 = ganttRenderer0.getSeriesStroke(0);
        java.lang.Boolean boolean10 = ganttRenderer0.getSeriesCreateEntities((int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot11.getRangeMarkers(3, layer13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot11.setRangeGridlinePaint((java.awt.Paint) color15);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot11.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint20, stroke21);
        categoryPlot11.setRangeCrosshairStroke(stroke21);
        boolean boolean24 = ganttRenderer0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = null;
        categoryPlot11.datasetChanged(datasetChangeEvent25);
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint28, stroke29);
        java.awt.Paint paint31 = valueMarker30.getLabelPaint();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int33 = color32.getTransparency();
        valueMarker30.setLabelPaint((java.awt.Paint) color32);
        valueMarker30.setAlpha(0.0f);
        double double37 = valueMarker30.getValue();
        boolean boolean38 = categoryPlot11.equals((java.lang.Object) valueMarker30);
        categoryPlot11.setDomainGridlinesVisible(false);
        org.jfree.chart.LegendItemCollection legendItemCollection41 = categoryPlot11.getLegendItems();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + (-1.0d) + "'", double37 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(legendItemCollection41);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        double double3 = ganttRenderer0.getItemLabelAnchorOffset();
        java.awt.Paint paint4 = ganttRenderer0.getBaseItemLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        boolean boolean3 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) color1);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (java.lang.Comparable) 1L);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(pieDataset5);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Font font2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset3, valueAxis4, polarItemRenderer5);
        polarPlot6.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str11 = textTitle10.getText();
        java.awt.Font font12 = textTitle10.getFont();
        polarPlot6.setAngleLabelFont(font12);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("", font2, (org.jfree.chart.plot.Plot) polarPlot6, true);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart15, chartChangeEventType16);
        java.awt.Image image18 = jFreeChart15.getBackgroundImage();
        boolean boolean19 = jFreeChart15.isNotify();
        try {
            org.jfree.chart.plot.XYPlot xYPlot20 = jFreeChart15.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PolarPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.Number[][] numberArray1 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot7.setRadiusGridlineStroke(stroke8);
        boolean boolean10 = defaultIntervalCategoryDataset3.hasListener((java.util.EventListener) polarPlot7);
        polarPlot7.clearCornerTextItems();
        java.awt.Stroke stroke12 = polarPlot7.getAngleGridlineStroke();
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean6 = rectangleAnchor2.equals((java.lang.Object) simpleTimePeriod5);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType8 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor7, categoryLabelWidthType8, (float) (-6553600));
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 10L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity15 = new org.jfree.chart.entity.TickLabelEntity(shape12, "AxisLocation.TOP_OR_LEFT", "AxisLocation.TOP_OR_LEFT");
        boolean boolean16 = categoryLabelPosition10.equals((java.lang.Object) tickLabelEntity15);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelWidthType8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        stackedBarRenderer3D0.setBaseStroke(stroke1, false);
        double double4 = stackedBarRenderer3D0.getLowerClip();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.awt.Font font11 = textTitle9.getFont();
        polarPlot5.setAngleLabelFont(font11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) polarPlot5, true);
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart14.createBufferedImage((int) '#', 1);
        org.jfree.chart.title.TextTitle textTitle18 = null;
        jFreeChart14.setTitle(textTitle18);
        int int20 = jFreeChart14.getSubtitleCount();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(bufferedImage17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean3 = lineRenderer3D0.getItemShapeVisible((int) ' ', (int) ' ');
        java.awt.Paint paint4 = lineRenderer3D0.getWallPaint();
        double double5 = lineRenderer3D0.getYOffset();
        boolean boolean6 = lineRenderer3D0.getAutoPopulateSeriesPaint();
        lineRenderer3D0.setUseFillPaint(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        textTitle1.setMargin((double) 100.0f, (double) 11, (double) 0, 0.0d);
        java.lang.Object obj8 = textTitle1.clone();
        java.lang.Object obj9 = textTitle1.clone();
        java.awt.Paint paint10 = textTitle1.getPaint();
        java.lang.String str11 = textTitle1.getToolTipText();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        boolean boolean3 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) color1);
        int int5 = defaultBoxAndWhiskerCategoryDataset0.getColumnIndex((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        java.awt.Paint paint2 = dateAxis1.getTickLabelPaint();
        dateAxis1.setAxisLineVisible(false);
        dateAxis1.setTickMarkInsideLength((float) '4');
        boolean boolean7 = dateAxis1.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.awt.Font font11 = textTitle9.getFont();
        polarPlot5.setAngleLabelFont(font11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) polarPlot5, true);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str18 = textTitle17.getText();
        java.awt.Font font19 = textTitle17.getFont();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str23 = textTitle22.getText();
        java.awt.geom.Rectangle2D rectangle2D24 = textTitle22.getBounds();
        textTitle17.draw(graphics2D20, rectangle2D24);
        java.awt.geom.Point2D point2D26 = null;
        org.jfree.chart.plot.PlotState plotState27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        polarPlot5.draw(graphics2D15, rectangle2D24, point2D26, plotState27, plotRenderingInfo28);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = null;
        polarPlot5.datasetChanged(datasetChangeEvent30);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer32 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer32);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = legendTitle33.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = legendTitle33.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendTitle33.getLegendItemGraphicPadding();
        polarPlot5.setInsets(rectangleInsets36);
        double double39 = rectangleInsets36.calculateLeftOutset(0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 2.0d + "'", double39 == 2.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.25d, 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getRGBColorComponents(floatArray1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("java.awt.Color[r=128,g=128,b=255]");
        labelBlock1.setURLText("August");
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke8 = ganttRenderer0.getSeriesStroke(0);
        java.lang.Boolean boolean10 = ganttRenderer0.getSeriesCreateEntities((int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot11.getRangeMarkers(3, layer13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot11.setRangeGridlinePaint((java.awt.Paint) color15);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot11.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint20, stroke21);
        categoryPlot11.setRangeCrosshairStroke(stroke21);
        boolean boolean24 = ganttRenderer0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = null;
        categoryPlot11.datasetChanged(datasetChangeEvent25);
        java.awt.Font font28 = null;
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = null;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot(xYDataset29, valueAxis30, polarItemRenderer31);
        polarPlot32.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str37 = textTitle36.getText();
        java.awt.Font font38 = textTitle36.getFont();
        polarPlot32.setAngleLabelFont(font38);
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("", font28, (org.jfree.chart.plot.Plot) polarPlot32, true);
        java.awt.image.BufferedImage bufferedImage44 = jFreeChart41.createBufferedImage((int) '#', 1);
        jFreeChart41.setBorderVisible(false);
        categoryPlot11.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart41);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(bufferedImage44);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean1 = ganttRenderer0.getAutoPopulateSeriesStroke();
        ganttRenderer0.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, false);
        ganttRenderer0.setMaximumBarWidth((double) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers(3, layer10);
        java.util.List list12 = categoryPlot8.getAnnotations();
        categoryPlot8.clearRangeAxes();
        categoryPlot8.clearRangeAxes();
        categoryPlot8.setRangeCrosshairVisible(true);
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) 49.5d);
        boolean boolean19 = ganttRenderer0.equals((java.lang.Object) boolean18);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = ganttRenderer0.getSeriesItemLabelGenerator(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.equals((java.lang.Object) (short) 10);
        stackedBarRenderer3D0.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        boolean boolean8 = stackedBarRenderer3D0.isItemLabelVisible(3, 0);
        double double9 = stackedBarRenderer3D0.getMinimumBarLength();
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray16, numberArray21, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray27);
        java.lang.Number number29 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset28);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range32 = stackedBarRenderer3D0.findRangeBounds(categoryDataset28);
        boolean boolean35 = range32.intersects(3.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 300.0d + "'", number29.equals(300.0d));
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date4 = spreadsheetDate3.toDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint12 = null;
        textTitle11.setBackgroundPaint(paint12);
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle15.setTextAlignment(horizontalAlignment16);
        textTitle11.setTextAlignment(horizontalAlignment16);
        textTitle8.setHorizontalAlignment(horizontalAlignment16);
        boolean boolean20 = spreadsheetDate3.equals((java.lang.Object) textTitle8);
        org.jfree.data.time.SerialDate serialDate21 = null;
        try {
            int int22 = spreadsheetDate3.compare(serialDate21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.setRangeCrosshairVisible(true);
        boolean boolean10 = categoryPlot0.equals((java.lang.Object) 49.5d);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot0.getDomainAxisEdge(0);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.clear();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot3.getRangeMarkers(3, layer5);
        java.util.List list7 = categoryPlot3.getAnnotations();
        java.awt.Paint paint8 = categoryPlot3.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double12 = dateAxis11.getFixedDimension();
        boolean boolean13 = dateAxis11.isAutoTickUnitSelection();
        categoryPlot3.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis11, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = dateAxis11.getTickUnit();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date19 = spreadsheetDate18.toDate();
        int int20 = dateTickUnit16.compareTo((java.lang.Object) date19);
        defaultKeyedValues2D1.removeColumn((java.lang.Comparable) date19);
        int int23 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 1.0E-5d);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset18, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.chart.entity.EntityCollection entityCollection27 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = new org.jfree.chart.ChartRenderingInfo(entityCollection27);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str31 = textTitle30.getText();
        java.awt.geom.Rectangle2D rectangle2D32 = textTitle30.getBounds();
        chartRenderingInfo28.setChartArea(rectangle2D32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D32, (java.awt.Paint) color34);
        multiplePiePlot22.setAggregatedItemsPaint((java.awt.Paint) color34);
        org.jfree.chart.axis.NumberAxis numberAxis38 = null;
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str45 = textTitle44.getText();
        java.awt.Font font46 = textTitle44.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis38, (double) 12, 300.0d, (double) 10.0f, 0.25d, font46);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D48 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean50 = stackedBarRenderer3D48.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer51 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color53 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer51.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color53);
        stackedBarRenderer3D48.setWallPaint((java.awt.Paint) color53);
        org.jfree.chart.block.LabelBlock labelBlock56 = new org.jfree.chart.block.LabelBlock("", font46, (java.awt.Paint) color53);
        multiplePiePlot22.setAggregatedItemsPaint((java.awt.Paint) color53);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 300.0d + "'", number19.equals(300.0d));
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(color53);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers(3, layer10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot8.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint17, stroke18);
        categoryPlot8.setRangeCrosshairStroke(stroke18);
        categoryPlot0.setOutlineStroke(stroke18);
        java.lang.String str22 = categoryPlot0.getNoDataMessage();
        categoryPlot0.setOutlineVisible(false);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        double double1 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot5);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getRangeMarkers(3, layer12);
        java.util.List list14 = categoryPlot10.getAnnotations();
        java.awt.Paint paint15 = categoryPlot10.getOutlinePaint();
        lineAndShapeRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot10);
        java.awt.Stroke stroke17 = categoryPlot10.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean6 = rectangleAnchor2.equals((java.lang.Object) simpleTimePeriod5);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType8 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor7, categoryLabelWidthType8, (float) (-6553600));
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = categoryLabelPosition10.getLabelAnchor();
        double double12 = categoryLabelPosition10.getAngle();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelWidthType8);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot5);
        categoryPlot4.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart9);
        java.awt.Font font11 = categoryPlot4.getNoDataMessageFont();
        dateAxis1.setLabelFont(font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = dateAxis1.getTickLabelInsets();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str18 = textTitle17.getText();
        java.awt.Font font19 = textTitle17.getFont();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str23 = textTitle22.getText();
        java.awt.geom.Rectangle2D rectangle2D24 = textTitle22.getBounds();
        textTitle17.draw(graphics2D20, rectangle2D24);
        java.awt.geom.Point2D point2D26 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 10, (double) (-1L), rectangle2D24);
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets13.createOutsetRectangle(rectangle2D24);
        double double29 = rectangleInsets13.extendHeight((double) 10L);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer30 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean31 = ganttRenderer30.getAutoPopulateSeriesStroke();
        ganttRenderer30.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true, false);
        ganttRenderer30.setMaximumBarWidth((double) (short) 100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator39 = null;
        ganttRenderer30.setSeriesItemLabelGenerator(11, categoryItemLabelGenerator39);
        boolean boolean41 = rectangleInsets13.equals((java.lang.Object) ganttRenderer30);
        double double43 = rectangleInsets13.calculateRightOutset((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 14.0d + "'", double29 == 14.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        java.util.Date date2 = month0.getStart();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean3 = lineRenderer3D0.getItemShapeVisible((int) ' ', (int) ' ');
        java.awt.Paint paint4 = lineRenderer3D0.getWallPaint();
        double double5 = lineRenderer3D0.getYOffset();
        lineRenderer3D0.setYOffset((double) 4);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean11 = stackedBarRenderer3D9.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke12 = stackedBarRenderer3D9.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D9.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot13);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot18.getRangeMarkers(3, layer20);
        java.util.List list22 = categoryPlot18.getAnnotations();
        categoryPlot18.clearRangeAxes();
        boolean boolean24 = categoryPlot13.equals((java.lang.Object) categoryPlot18);
        categoryPlot13.configureDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double28 = dateAxis27.getFixedDimension();
        double double29 = dateAxis27.getLowerBound();
        java.awt.Paint paint30 = dateAxis27.getTickLabelPaint();
        dateAxis27.setVerticalTickLabels(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = categoryPlot33.getRangeMarkers(3, layer35);
        java.util.List list37 = categoryPlot33.getAnnotations();
        java.awt.Paint paint38 = categoryPlot33.getOutlinePaint();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke41 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint40, stroke41);
        java.awt.Paint paint43 = valueMarker42.getLabelPaint();
        categoryPlot33.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker42);
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str47 = textTitle46.getText();
        java.awt.Font font48 = textTitle46.getFont();
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str52 = textTitle51.getText();
        java.awt.geom.Rectangle2D rectangle2D53 = textTitle51.getBounds();
        textTitle46.draw(graphics2D49, rectangle2D53);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer55 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer55);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = legendTitle56.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean61 = rectangleAnchor57.equals((java.lang.Object) simpleTimePeriod60);
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D53, rectangleAnchor57, 4.0d, (double) 100L);
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str67 = textTitle66.getText();
        java.awt.Font font68 = textTitle66.getFont();
        java.awt.Graphics2D graphics2D69 = null;
        org.jfree.chart.title.TextTitle textTitle71 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str72 = textTitle71.getText();
        java.awt.geom.Rectangle2D rectangle2D73 = textTitle71.getBounds();
        textTitle66.draw(graphics2D69, rectangle2D73);
        boolean boolean75 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D53, rectangle2D73);
        lineRenderer3D0.drawRangeMarker(graphics2D8, categoryPlot13, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.chart.plot.Marker) valueMarker42, rectangle2D73);
        boolean boolean77 = lineRenderer3D0.getBaseShapesFilled();
        org.jfree.chart.ui.Library library82 = new org.jfree.chart.ui.Library("ClassContext", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "", "");
        java.lang.String str83 = library82.getLicenceName();
        boolean boolean84 = lineRenderer3D0.equals((java.lang.Object) library82);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "" + "'", str67.equals(""));
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "" + "'", str72.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "" + "'", str83.equals(""));
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str7 = textTitle6.getText();
        java.awt.Font font8 = textTitle6.getFont();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str12 = textTitle11.getText();
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle11.getBounds();
        textTitle6.draw(graphics2D9, rectangle2D13);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer15 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean21 = rectangleAnchor17.equals((java.lang.Object) simpleTimePeriod20);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D13, rectangleAnchor17, 4.0d, (double) 100L);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str27 = textTitle26.getText();
        java.awt.Font font28 = textTitle26.getFont();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str32 = textTitle31.getText();
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle31.getBounds();
        textTitle26.draw(graphics2D29, rectangle2D33);
        boolean boolean35 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D13, rectangle2D33);
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets4.createOutsetRectangle(rectangle2D33);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str44 = textTitle43.getText();
        java.awt.geom.Rectangle2D rectangle2D45 = textTitle43.getBounds();
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D45, (double) (short) 10, 100.0f, (float) (short) -1);
        java.awt.Color color51 = java.awt.Color.white;
        java.awt.Color color53 = java.awt.Color.white;
        java.awt.Stroke stroke54 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.title.TextTitle textTitle57 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str58 = textTitle57.getText();
        java.awt.geom.Rectangle2D rectangle2D59 = textTitle57.getBounds();
        java.awt.Shape shape63 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D59, (double) (short) 10, 100.0f, (float) (short) -1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D64 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean66 = stackedBarRenderer3D64.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke67 = stackedBarRenderer3D64.getBaseStroke();
        java.awt.Color color68 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("hi!", "java.awt.Color[r=128,g=128,b=255]", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "RectangleEdge.TOP", true, (java.awt.Shape) rectangle2D45, true, (java.awt.Paint) color51, false, (java.awt.Paint) color53, stroke54, true, (java.awt.Shape) rectangle2D59, stroke67, (java.awt.Paint) color68);
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer72 = null;
        java.util.Collection collection73 = categoryPlot70.getRangeMarkers(3, layer72);
        java.util.List list74 = categoryPlot70.getAnnotations();
        java.awt.Paint paint75 = categoryPlot70.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis78 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double79 = dateAxis78.getFixedDimension();
        boolean boolean80 = dateAxis78.isAutoTickUnitSelection();
        categoryPlot70.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis78, true);
        org.jfree.data.Range range83 = dateAxis78.getDefaultAutoRange();
        java.awt.Paint paint84 = dateAxis78.getTickLabelPaint();
        org.jfree.chart.LegendItem legendItem85 = new org.jfree.chart.LegendItem("({0}, {1}) = {3} - {4}", "({0}, {1}) = {3} - {4}", "rect", "{0}", (java.awt.Shape) rectangle2D33, stroke54, paint84);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "" + "'", str58.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNull(collection73);
        org.junit.Assert.assertNotNull(list74);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(range83);
        org.junit.Assert.assertNotNull(paint84);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date6 = spreadsheetDate5.toDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(128, serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean14 = spreadsheetDate1.isInRange(serialDate7, serialDate13);
        try {
            org.jfree.data.time.SerialDate serialDate16 = serialDate13.getPreviousDayOfWeek(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint9, stroke10);
        categoryPlot0.setRangeCrosshairStroke(stroke10);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke14 = defaultDrawingSupplier13.getNextStroke();
        categoryPlot0.setOutlineStroke(stroke14);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAutoTickUnitSelection();
        java.awt.Shape shape4 = dateAxis1.getDownArrow();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        double double3 = ganttRenderer0.getItemLabelAnchorOffset();
        java.lang.Boolean boolean5 = ganttRenderer0.getSeriesItemLabelsVisible((int) ' ');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer7 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean9 = ganttRenderer7.equals((java.lang.Object) '#');
        ganttRenderer7.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke15 = ganttRenderer7.getSeriesStroke(0);
        boolean boolean16 = itemLabelPosition6.equals((java.lang.Object) ganttRenderer7);
        double double17 = itemLabelPosition6.getAngle();
        double double18 = itemLabelPosition6.getAngle();
        ganttRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition6);
        double double20 = itemLabelPosition6.getAngle();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int int0 = org.jfree.chart.axis.DateTickUnit.MINUTE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double3 = piePlot3D1.getExplodePercent((java.lang.Comparable) 0.2d);
        int int4 = piePlot3D1.getPieIndex();
        java.awt.Color color5 = java.awt.Color.gray;
        piePlot3D1.setLabelPaint((java.awt.Paint) color5);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(100.0d, (double) 2);
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray9, numberArray14, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray20);
        java.lang.Number number22 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset21);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset21, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot25 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset21);
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset21);
        org.jfree.data.Range range27 = barRenderer3D2.findRangeBounds(categoryDataset21);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 300.0d + "'", number22.equals(300.0d));
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(range27);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) 3.0d, (java.lang.Comparable) 100L, (java.lang.Comparable) (byte) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.lang.Class<?> wildcardClass8 = stackedBarRenderer3D7.getClass();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double11 = dateAxis10.getFixedDimension();
        java.util.Date date12 = dateAxis10.getMaximumDate();
        dateAxis10.setAutoRangeMinimumSize(3.0d);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer15 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean21 = rectangleAnchor17.equals((java.lang.Object) simpleTimePeriod20);
        java.util.Date date22 = simpleTimePeriod20.getStart();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = dateAxis10.dateToJava2D(date22, rectangle2D23, rectangleEdge24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot26.getRangeMarkers(3, layer28);
        java.util.List list30 = categoryPlot26.getAnnotations();
        java.awt.Paint paint31 = categoryPlot26.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double35 = dateAxis34.getFixedDimension();
        boolean boolean36 = dateAxis34.isAutoTickUnitSelection();
        categoryPlot26.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis34, true);
        dateAxis34.setRangeAboutValue((double) 0, (double) (short) 100);
        java.util.TimeZone timeZone42 = dateAxis34.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date22, timeZone42);
        java.lang.Class class44 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double47 = dateAxis46.getFixedDimension();
        java.util.Date date48 = dateAxis46.getMinimumDate();
        java.util.TimeZone timeZone49 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date48, timeZone49);
        org.jfree.data.time.DateRange dateRange51 = new org.jfree.data.time.DateRange(date22, date48);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date58 = spreadsheetDate57.toDate();
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.addDays(128, serialDate59);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date64 = spreadsheetDate63.toDate();
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate63);
        boolean boolean66 = spreadsheetDate53.isInRange(serialDate59, serialDate65);
        try {
            defaultKeyedValues2D1.addValue((java.lang.Number) 100L, (java.lang.Comparable) date22, (java.lang.Comparable) serialDate65);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to java.lang.Long");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        double double1 = stackedBarRenderer3D0.getMaximumBarWidth();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = categoryPlot1.getRangeMarkers(3, layer3);
        java.util.List list5 = categoryPlot1.getAnnotations();
        java.awt.Paint paint6 = categoryPlot1.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double10 = dateAxis9.getFixedDimension();
        boolean boolean11 = dateAxis9.isAutoTickUnitSelection();
        categoryPlot1.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis9, true);
        org.jfree.data.Range range14 = dateAxis9.getDefaultAutoRange();
        org.jfree.data.Range range15 = dateAxis9.getRange();
        double double16 = range15.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint(49.5d, range15);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType18 = rectangleConstraint17.getWidthConstraintType();
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.5d + "'", double16 == 0.5d);
        org.junit.Assert.assertNotNull(lengthConstraintType18);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = null;
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint8, stroke9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int12 = color11.getBlue();
        valueMarker10.setLabelPaint((java.awt.Paint) color11);
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str18 = textTitle17.getText();
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle17.getBounds();
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color11.createContext(colorModel14, rectangle15, rectangle2D19, affineTransform20, renderingHints21);
        java.awt.Paint paint25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint25, stroke26);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer28 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean30 = ganttRenderer28.equals((java.lang.Object) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer32 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean34 = ganttRenderer32.equals((java.lang.Object) '#');
        ganttRenderer32.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke40 = ganttRenderer32.getSeriesStroke(0);
        boolean boolean41 = itemLabelPosition31.equals((java.lang.Object) ganttRenderer32);
        double double42 = itemLabelPosition31.getAngle();
        ganttRenderer28.setBaseNegativeItemLabelPosition(itemLabelPosition31, false);
        java.awt.Stroke stroke46 = ganttRenderer28.lookupSeriesStroke((int) (short) 100);
        java.lang.String[] strArray48 = new java.lang.String[] {};
        java.lang.Number[][] numberArray49 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset51 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray48, numberArray49, numberArray50);
        org.jfree.data.general.DatasetGroup datasetGroup53 = new org.jfree.data.general.DatasetGroup("hi!");
        defaultIntervalCategoryDataset51.setGroup(datasetGroup53);
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str57 = textTitle56.getText();
        java.awt.Font font58 = textTitle56.getFont();
        java.awt.Graphics2D graphics2D59 = null;
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str62 = textTitle61.getText();
        java.awt.geom.Rectangle2D rectangle2D63 = textTitle61.getBounds();
        textTitle56.draw(graphics2D59, rectangle2D63);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer65 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle66 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer65);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor67 = legendTitle66.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod70 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean71 = rectangleAnchor67.equals((java.lang.Object) simpleTimePeriod70);
        java.awt.Shape shape74 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D63, rectangleAnchor67, 4.0d, (double) 100L);
        org.jfree.chart.title.TextTitle textTitle76 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str77 = textTitle76.getText();
        java.awt.Font font78 = textTitle76.getFont();
        java.awt.Graphics2D graphics2D79 = null;
        org.jfree.chart.title.TextTitle textTitle81 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str82 = textTitle81.getText();
        java.awt.geom.Rectangle2D rectangle2D83 = textTitle81.getBounds();
        textTitle76.draw(graphics2D79, rectangle2D83);
        boolean boolean85 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D63, rectangle2D83);
        boolean boolean86 = datasetGroup53.equals((java.lang.Object) rectangle2D83);
        java.awt.Shape shape87 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D83);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer88 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color90 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer88.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color90);
        java.awt.Stroke stroke94 = ganttRenderer88.getItemOutlineStroke((int) (byte) 0, 5);
        java.awt.Color color95 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int96 = color95.getBlue();
        try {
            org.jfree.chart.LegendItem legendItem97 = new org.jfree.chart.LegendItem(attributedString0, "August", "org.jfree.data.UnknownKeyException: hi!", "", false, shape5, false, (java.awt.Paint) color11, false, paint25, stroke46, true, shape87, stroke94, (java.awt.Paint) color95);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 128 + "'", int12 == 128);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(paintContext22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "" + "'", str57.equals(""));
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "" + "'", str62.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangleAnchor67);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(shape74);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "" + "'", str77.equals(""));
        org.junit.Assert.assertNotNull(font78);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "" + "'", str82.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(shape87);
        org.junit.Assert.assertNotNull(color90);
        org.junit.Assert.assertNotNull(stroke94);
        org.junit.Assert.assertNotNull(color95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 128 + "'", int96 == 128);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("java.awt.Color[r=128,g=128,b=255]");
        blockContainer0.add((org.jfree.chart.block.Block) labelBlock2);
        double double4 = blockContainer0.getContentYOffset();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        textTitle1.setMargin((double) 100.0f, (double) 11, (double) 0, 0.0d);
        java.lang.Object obj8 = textTitle1.clone();
        java.lang.Object obj9 = textTitle1.clone();
        java.awt.Font font10 = textTitle1.getFont();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean3 = stackedBarRenderer3D1.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke4 = stackedBarRenderer3D1.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot5);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getColumnRenderingOrder();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        boolean boolean12 = sortOrder10.equals((java.lang.Object) color11);
        defaultKeyedValues0.sortByKeys(sortOrder10);
        defaultKeyedValues0.setValue((java.lang.Comparable) 0.4d, (java.lang.Number) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle1.setTextAlignment(horizontalAlignment2);
        java.awt.Font font4 = textTitle1.getFont();
        java.awt.Color color5 = java.awt.Color.white;
        boolean boolean6 = textTitle1.equals((java.lang.Object) color5);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean3 = lineRenderer3D0.getItemShapeVisible((int) ' ', (int) ' ');
        java.awt.Paint paint4 = lineRenderer3D0.getWallPaint();
        double double5 = lineRenderer3D0.getYOffset();
        boolean boolean6 = lineRenderer3D0.getAutoPopulateSeriesPaint();
        java.awt.Paint paint8 = null;
        lineRenderer3D0.setSeriesOutlinePaint(0, paint8);
        lineRenderer3D0.setUseOutlinePaint(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) -1);
        java.awt.Font font8 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getDomainMarkers(layer9);
        categoryPlot0.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot0.removeChangeListener(plotChangeListener13);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(collection10);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Color color0 = java.awt.Color.green;
        java.lang.String str1 = org.jfree.chart.util.PaintUtilities.colorToString(color0);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "green" + "'", str1.equals("green"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint2 = null;
        textTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle5.setTextAlignment(horizontalAlignment6);
        textTitle1.setTextAlignment(horizontalAlignment6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle1.getVerticalAlignment();
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment9);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 7);
        double double3 = intervalMarker2.getStartValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("ClassContext", "Multiple Pie Plot");
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle1.getLegendItemGraphicLocation();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str13 = textTitle12.getText();
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle12.getBounds();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D14, (double) (short) 10, 100.0f, (float) (short) -1);
        java.awt.Color color20 = java.awt.Color.white;
        java.awt.Color color22 = java.awt.Color.white;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str27 = textTitle26.getText();
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle26.getBounds();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D28, (double) (short) 10, 100.0f, (float) (short) -1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean35 = stackedBarRenderer3D33.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke36 = stackedBarRenderer3D33.getBaseStroke();
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("hi!", "java.awt.Color[r=128,g=128,b=255]", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "RectangleEdge.TOP", true, (java.awt.Shape) rectangle2D14, true, (java.awt.Paint) color20, false, (java.awt.Paint) color22, stroke23, true, (java.awt.Shape) rectangle2D28, stroke36, (java.awt.Paint) color37);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double42 = rectangleInsets40.calculateBottomOutset(0.4d);
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str47 = textTitle46.getText();
        java.awt.Font font48 = textTitle46.getFont();
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str52 = textTitle51.getText();
        java.awt.geom.Rectangle2D rectangle2D53 = textTitle51.getBounds();
        textTitle46.draw(graphics2D49, rectangle2D53);
        java.awt.geom.Point2D point2D55 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 10, (double) (-1L), rectangle2D53);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType56 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType57 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D58 = rectangleInsets40.createAdjustedRectangle(rectangle2D53, lengthAdjustmentType56, lengthAdjustmentType57);
        java.awt.Color color59 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int60 = color59.getBlue();
        boolean boolean61 = lengthAdjustmentType56.equals((java.lang.Object) color59);
        java.awt.geom.Rectangle2D rectangle2D62 = rectangleInsets5.createAdjustedRectangle(rectangle2D14, lengthAdjustmentType39, lengthAdjustmentType56);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer63 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint65 = ganttRenderer63.getSeriesFillPaint((int) ' ');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition67 = ganttRenderer63.getSeriesNegativeItemLabelPosition(10);
        org.jfree.chart.text.TextAnchor textAnchor68 = itemLabelPosition67.getRotationAnchor();
        try {
            java.lang.Object obj69 = legendTitle1.draw(graphics2D4, rectangle2D14, (java.lang.Object) textAnchor68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 3.0d + "'", double42 == 3.0d);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(point2D55);
        org.junit.Assert.assertNotNull(lengthAdjustmentType56);
        org.junit.Assert.assertNotNull(lengthAdjustmentType57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 128 + "'", int60 == 128);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNull(paint65);
        org.junit.Assert.assertNotNull(itemLabelPosition67);
        org.junit.Assert.assertNotNull(textAnchor68);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.axis.NumberAxis numberAxis1 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.Font font9 = textTitle7.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, (double) 12, 300.0d, (double) 10.0f, 0.25d, font9);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean13 = stackedBarRenderer3D11.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer14 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer14.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color16);
        stackedBarRenderer3D11.setWallPaint((java.awt.Paint) color16);
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("", font9, (java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double22 = rectangleInsets20.calculateBottomOutset(0.4d);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str27 = textTitle26.getText();
        java.awt.Font font28 = textTitle26.getFont();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str32 = textTitle31.getText();
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle31.getBounds();
        textTitle26.draw(graphics2D29, rectangle2D33);
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 10, (double) (-1L), rectangle2D33);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType37 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets20.createAdjustedRectangle(rectangle2D33, lengthAdjustmentType36, lengthAdjustmentType37);
        labelBlock19.setBounds(rectangle2D38);
        labelBlock19.setURLText("hi!2");
        java.lang.Object obj42 = labelBlock19.clone();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.0d + "'", double22 == 3.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNotNull(lengthAdjustmentType36);
        org.junit.Assert.assertNotNull(lengthAdjustmentType37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double3 = piePlot3D1.getExplodePercent((java.lang.Comparable) 0.2d);
        int int4 = piePlot3D1.getPieIndex();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot3D6.getLabelGenerator();
        piePlot3D1.setLegendLabelGenerator(pieSectionLabelGenerator7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray1 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray1);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer4 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean6 = ganttRenderer4.equals((java.lang.Object) '#');
        ganttRenderer4.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = ganttRenderer4.getGradientPaintTransformer();
        ganttRenderer4.setSeriesCreateEntities((int) (byte) 0, (java.lang.Boolean) false, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = ganttRenderer4.getURLGenerator((int) (byte) 1, 3);
        categoryPlot0.setRenderer(6, (org.jfree.chart.renderer.category.CategoryItemRenderer) ganttRenderer4);
        java.awt.Font font21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot(xYDataset22, valueAxis23, polarItemRenderer24);
        polarPlot25.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str30 = textTitle29.getText();
        java.awt.Font font31 = textTitle29.getFont();
        polarPlot25.setAngleLabelFont(font31);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("", font21, (org.jfree.chart.plot.Plot) polarPlot25, true);
        java.awt.Stroke stroke35 = polarPlot25.getAngleGridlineStroke();
        boolean boolean36 = polarPlot25.isAngleGridlinesVisible();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer37 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Object obj38 = null;
        boolean boolean39 = boxAndWhiskerRenderer37.equals(obj38);
        java.awt.Paint paint41 = null;
        boxAndWhiskerRenderer37.setSeriesPaint((int) (short) 100, paint41, true);
        boxAndWhiskerRenderer37.setFillBox(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent46 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) boxAndWhiskerRenderer37);
        polarPlot25.rendererChanged(rendererChangeEvent46);
        categoryPlot0.rendererChanged(rendererChangeEvent46);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType49 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        rendererChangeEvent46.setType(chartChangeEventType49);
        org.junit.Assert.assertNotNull(categoryAxisArray1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer11);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType49);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle7.getBounds();
        chartRenderingInfo5.setChartArea(rectangle2D9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D9, (java.awt.Paint) color11);
        org.jfree.data.general.Dataset dataset13 = legendItem12.getDataset();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset14, valueAxis15, polarItemRenderer16);
        polarPlot17.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str22 = textTitle21.getText();
        java.awt.Font font23 = textTitle21.getFont();
        polarPlot17.setAngleLabelFont(font23);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean27 = stackedBarRenderer3D25.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer28 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer28.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color30);
        stackedBarRenderer3D25.setWallPaint((java.awt.Paint) color30);
        polarPlot17.setNoDataMessagePaint((java.awt.Paint) color30);
        boolean boolean34 = legendItem12.equals((java.lang.Object) polarPlot17);
        org.jfree.chart.JFreeChart jFreeChart35 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) polarPlot17, jFreeChart35);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(dataset13);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean4 = lineAndShapeRenderer1.getItemLineVisible((int) (short) -1, 8);
        boolean boolean5 = unitType0.equals((java.lang.Object) boolean4);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        taskSeries1.fireSeriesChanged();
        taskSeries1.setKey((java.lang.Comparable) Double.POSITIVE_INFINITY);
        java.lang.String str5 = taskSeries1.getDescription();
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        java.util.Date date3 = dateAxis1.getMaximumDate();
        java.awt.Font font5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset6, valueAxis7, polarItemRenderer8);
        polarPlot9.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str14 = textTitle13.getText();
        java.awt.Font font15 = textTitle13.getFont();
        polarPlot9.setAngleLabelFont(font15);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("", font5, (org.jfree.chart.plot.Plot) polarPlot9, true);
        java.awt.Stroke stroke19 = polarPlot9.getAngleGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot(xYDataset21, valueAxis22, polarItemRenderer23);
        polarPlot24.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str29 = textTitle28.getText();
        java.awt.Font font30 = textTitle28.getFont();
        polarPlot24.setAngleLabelFont(font30);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) polarPlot24);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean35 = stackedBarRenderer3D33.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer36 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer36.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color38);
        stackedBarRenderer3D33.setWallPaint((java.awt.Paint) color38);
        jFreeChart32.setBorderPaint((java.awt.Paint) color38);
        polarPlot9.setRadiusGridlinePaint((java.awt.Paint) color38);
        java.awt.Color color43 = org.jfree.chart.ChartColor.DARK_RED;
        polarPlot9.setRadiusGridlinePaint((java.awt.Paint) color43);
        dateAxis1.setTickMarkPaint((java.awt.Paint) color43);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D46 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean48 = stackedBarRenderer3D46.isSeriesVisibleInLegend(11);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer49 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        ganttRenderer49.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color51);
        stackedBarRenderer3D46.setWallPaint((java.awt.Paint) color51);
        float[] floatArray54 = null;
        float[] floatArray55 = color51.getRGBComponents(floatArray54);
        float[] floatArray56 = color43.getComponents(floatArray54);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray56);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.setValue((java.lang.Number) 3.0d, (java.lang.Comparable) 100L, (java.lang.Comparable) (byte) 100);
        java.util.List list6 = defaultKeyedValues2D1.getRowKeys();
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Object obj1 = null;
        boolean boolean2 = flowArrangement0.equals(obj1);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle4.setTextAlignment(horizontalAlignment5);
        java.lang.String str7 = textTitle4.getURLText();
        textTitle4.setURLText("hi!");
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str12 = textTitle11.getText();
        java.awt.Font font13 = textTitle11.getFont();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str17 = textTitle16.getText();
        java.awt.geom.Rectangle2D rectangle2D18 = textTitle16.getBounds();
        textTitle11.draw(graphics2D14, rectangle2D18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot20.getRangeMarkers(3, layer22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot20.setRangeGridlinePaint((java.awt.Paint) color24);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot20.getRangeAxisForDataset((int) (short) -1);
        java.awt.Font font28 = categoryPlot20.getNoDataMessageFont();
        textTitle11.setFont(font28);
        flowArrangement0.add((org.jfree.chart.block.Block) textTitle4, (java.lang.Object) font28);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(font28);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("ClassContext", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "", "hi!");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo5);
        basicProjectInfo5.setName("PlotOrientation.HORIZONTAL");
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        double double1 = stackedBarRenderer3D0.getMinimumBarLength();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        stackedBarRenderer3D0.setBaseStroke(stroke1, false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = null;
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint7, stroke8);
        java.awt.Paint paint10 = valueMarker9.getLabelPaint();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int12 = color11.getTransparency();
        valueMarker9.setLabelPaint((java.awt.Paint) color11);
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        java.awt.Font font17 = null;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot(xYDataset18, valueAxis19, polarItemRenderer20);
        polarPlot21.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str26 = textTitle25.getText();
        java.awt.Font font27 = textTitle25.getFont();
        polarPlot21.setAngleLabelFont(font27);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("", font17, (org.jfree.chart.plot.Plot) polarPlot21, true);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str34 = textTitle33.getText();
        java.awt.Font font35 = textTitle33.getFont();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str39 = textTitle38.getText();
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle38.getBounds();
        textTitle33.draw(graphics2D36, rectangle2D40);
        java.awt.geom.Point2D point2D42 = null;
        org.jfree.chart.plot.PlotState plotState43 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        polarPlot21.draw(graphics2D31, rectangle2D40, point2D42, plotState43, plotRenderingInfo44);
        java.awt.geom.AffineTransform affineTransform46 = null;
        java.awt.RenderingHints renderingHints47 = null;
        java.awt.PaintContext paintContext48 = color11.createContext(colorModel14, rectangle15, rectangle2D40, affineTransform46, renderingHints47);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D49 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean51 = stackedBarRenderer3D49.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke52 = stackedBarRenderer3D49.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot53.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D49.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot53);
        org.jfree.chart.util.SortOrder sortOrder58 = categoryPlot53.getColumnRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = null;
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        java.awt.Paint paint62 = dateAxis61.getTickLabelPaint();
        dateAxis61.setAxisLineVisible(false);
        java.lang.String[] strArray65 = new java.lang.String[] {};
        java.lang.Number[][] numberArray66 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray67 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset68 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray65, numberArray66, numberArray67);
        org.jfree.data.general.DatasetGroup datasetGroup70 = new org.jfree.data.general.DatasetGroup("hi!");
        defaultIntervalCategoryDataset68.setGroup(datasetGroup70);
        try {
            stackedBarRenderer3D0.drawItem(graphics2D4, categoryItemRendererState5, rectangle2D40, categoryPlot53, categoryAxis59, (org.jfree.chart.axis.ValueAxis) dateAxis61, (org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset68, 0, 10, (-3407872));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(paintContext48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(sortOrder58);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(strArray65);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray67);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double3 = piePlot3D1.getExplodePercent((java.lang.Comparable) 0.2d);
        java.lang.Object obj4 = piePlot3D1.clone();
        piePlot3D1.setDepthFactor((double) (short) 100);
        boolean boolean7 = piePlot3D1.getLabelLinksVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator8);
        piePlot3D1.setLabelLinksVisible(true);
        java.awt.Paint paint12 = piePlot3D1.getLabelLinkPaint();
        java.awt.Color color13 = java.awt.Color.LIGHT_GRAY;
        piePlot3D1.setLabelShadowPaint((java.awt.Paint) color13);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset18, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.chart.entity.EntityCollection entityCollection27 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = new org.jfree.chart.ChartRenderingInfo(entityCollection27);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str31 = textTitle30.getText();
        java.awt.geom.Rectangle2D rectangle2D32 = textTitle30.getBounds();
        chartRenderingInfo28.setChartArea(rectangle2D32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D32, (java.awt.Paint) color34);
        multiplePiePlot22.setAggregatedItemsPaint((java.awt.Paint) color34);
        java.lang.String str37 = multiplePiePlot22.getPlotType();
        java.lang.Object obj38 = null;
        boolean boolean39 = multiplePiePlot22.equals(obj38);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 300.0d + "'", number19.equals(300.0d));
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Multiple Pie Plot" + "'", str37.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke8 = ganttRenderer0.getSeriesStroke(0);
        java.lang.Boolean boolean10 = ganttRenderer0.getSeriesCreateEntities((int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot11.getRangeMarkers(3, layer13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot11.setRangeGridlinePaint((java.awt.Paint) color15);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot11.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint20, stroke21);
        categoryPlot11.setRangeCrosshairStroke(stroke21);
        boolean boolean24 = ganttRenderer0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = null;
        categoryPlot11.datasetChanged(datasetChangeEvent25);
        org.jfree.data.category.CategoryDataset categoryDataset27 = categoryPlot11.getDataset();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(categoryDataset27);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.awt.Font font1 = null;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.awt.Font font11 = textTitle9.getFont();
        polarPlot5.setAngleLabelFont(font11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) polarPlot5, true);
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart14.createBufferedImage((int) '#', 1);
        jFreeChart14.setBorderVisible(false);
        org.jfree.chart.entity.EntityCollection entityCollection22 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo(entityCollection22);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str26 = textTitle25.getText();
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle25.getBounds();
        chartRenderingInfo23.setChartArea(rectangle2D27);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection30 = chartRenderingInfo29.getEntityCollection();
        chartRenderingInfo23.setEntityCollection(entityCollection30);
        chartRenderingInfo23.clear();
        java.awt.geom.Rectangle2D rectangle2D33 = chartRenderingInfo23.getChartArea();
        try {
            java.awt.image.BufferedImage bufferedImage34 = jFreeChart14.createBufferedImage((-3407872), (int) ' ', chartRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-3407872) and height (32) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(bufferedImage17);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(entityCollection30);
        org.junit.Assert.assertNotNull(rectangle2D33);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str5 = textTitle4.getText();
        java.awt.geom.Rectangle2D rectangle2D6 = textTitle4.getBounds();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D6, (double) (short) 10, 100.0f, (float) (short) -1);
        boolean boolean11 = spreadsheetDate1.equals((java.lang.Object) 100.0f);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        java.lang.String str3 = dateAxis1.getLabelURL();
        java.text.DateFormat dateFormat4 = dateAxis1.getDateFormatOverride();
        dateAxis1.setAxisLineVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(dateFormat4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset(0.4d);
        double double4 = rectangleInsets0.calculateTopOutset(30.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.Font font9 = textTitle7.getFont();
        polarPlot3.setAngleLabelFont(font9);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = polarPlot3.getOrientation();
        boolean boolean12 = polarPlot3.isRadiusGridlinesVisible();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean3 = lineRenderer3D0.getItemShapeVisible((int) ' ', (int) ' ');
        java.awt.Paint paint4 = lineRenderer3D0.getWallPaint();
        double double5 = lineRenderer3D0.getYOffset();
        lineRenderer3D0.setBaseSeriesVisibleInLegend(true);
        boolean boolean8 = lineRenderer3D0.getBaseItemLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint5 = null;
        textTitle4.setBackgroundPaint(paint5);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle8.setTextAlignment(horizontalAlignment9);
        textTitle4.setTextAlignment(horizontalAlignment9);
        textTitle1.setHorizontalAlignment(horizontalAlignment9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment9, verticalAlignment13, 10.0d, 1.0E-5d);
        java.lang.String[] strArray17 = new java.lang.String[] {};
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset20 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray17, numberArray18, numberArray19);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot(xYDataset21, valueAxis22, polarItemRenderer23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot24.setRadiusGridlineStroke(stroke25);
        boolean boolean27 = defaultIntervalCategoryDataset20.hasListener((java.util.EventListener) polarPlot24);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer29 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement16, (org.jfree.data.general.Dataset) defaultIntervalCategoryDataset20, (java.lang.Comparable) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle7.getBounds();
        chartRenderingInfo5.setChartArea(rectangle2D9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D9, (java.awt.Paint) color11);
        org.jfree.data.general.Dataset dataset13 = legendItem12.getDataset();
        boolean boolean14 = legendItem12.isShapeOutlineVisible();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(dataset13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        double double1 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot5);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot10.getRangeMarkers(3, layer12);
        java.util.List list14 = categoryPlot10.getAnnotations();
        java.awt.Paint paint15 = categoryPlot10.getOutlinePaint();
        lineAndShapeRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot10);
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot10.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(axisSpace17);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int2 = defaultKeyedValues2D1.getRowCount();
        try {
            defaultKeyedValues2D1.removeColumn((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double3 = dateAxis2.getFixedDimension();
        java.util.Date date4 = dateAxis2.getMinimumDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.gantt.Task task6 = new org.jfree.data.gantt.Task("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.time.TimePeriod) month5);
        int int7 = task6.getSubtaskCount();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemLineVisible((int) (short) -1, 8);
        java.lang.Object obj4 = lineAndShapeRenderer0.clone();
        java.awt.Font font6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot(xYDataset7, valueAxis8, polarItemRenderer9);
        polarPlot10.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str15 = textTitle14.getText();
        java.awt.Font font16 = textTitle14.getFont();
        polarPlot10.setAngleLabelFont(font16);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("", font6, (org.jfree.chart.plot.Plot) polarPlot10, true);
        java.awt.Stroke stroke20 = polarPlot10.getAngleGridlineStroke();
        boolean boolean21 = polarPlot10.isAngleGridlinesVisible();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer22 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Object obj23 = null;
        boolean boolean24 = boxAndWhiskerRenderer22.equals(obj23);
        java.awt.Paint paint26 = null;
        boxAndWhiskerRenderer22.setSeriesPaint((int) (short) 100, paint26, true);
        boxAndWhiskerRenderer22.setFillBox(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent31 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) boxAndWhiskerRenderer22);
        polarPlot10.rendererChanged(rendererChangeEvent31);
        lineAndShapeRenderer0.notifyListeners(rendererChangeEvent31);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        org.jfree.data.gantt.Task task4 = new org.jfree.data.gantt.Task("java.awt.Color[r=128,g=128,b=255]", (org.jfree.data.time.TimePeriod) simpleTimePeriod3);
        org.jfree.data.DefaultKeyedValue defaultKeyedValue6 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) simpleTimePeriod3, (java.lang.Number) (short) 1);
        java.lang.String str7 = defaultKeyedValue6.toString();
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        categoryPlot0.clearRangeMarkers((-1));
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Shape shape8 = ganttRenderer0.getSeriesShape(5);
        ganttRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        boolean boolean13 = ganttRenderer0.isItemLabelVisible((int) (byte) 0, 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        boolean boolean3 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) color1);
        java.util.List list4 = defaultBoxAndWhiskerCategoryDataset0.getColumnKeys();
        defaultBoxAndWhiskerCategoryDataset0.validateObject();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date8 = spreadsheetDate7.toDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        org.jfree.data.gantt.Task task13 = new org.jfree.data.gantt.Task("java.awt.Color[r=128,g=128,b=255]", (org.jfree.data.time.TimePeriod) simpleTimePeriod12);
        org.jfree.data.DefaultKeyedValue defaultKeyedValue15 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) simpleTimePeriod12, (java.lang.Number) (short) 1);
        java.util.Date date16 = simpleTimePeriod12.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(date8, date16);
        int int18 = defaultBoxAndWhiskerCategoryDataset0.getRowIndex((java.lang.Comparable) date16);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double9 = dateAxis8.getFixedDimension();
        boolean boolean10 = dateAxis8.isAutoTickUnitSelection();
        categoryPlot0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis8, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = dateAxis8.getTickUnit();
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        int int16 = dateTickUnit13.compareTo((java.lang.Object) entityCollection14);
        double double17 = dateTickUnit13.getSize();
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(0.0d, (double) (byte) -1, (double) (byte) 0, 0.5d);
        int int23 = dateTickUnit13.compareTo((java.lang.Object) 0.0d);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 8.64E7d + "'", double17 == 8.64E7d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            org.jfree.data.gantt.TaskSeries taskSeries2 = taskSeriesCollection0.getSeries((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double7 = dateAxis6.getFixedDimension();
        boolean boolean8 = dateAxis6.isAxisLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot10);
        categoryPlot9.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart14);
        java.awt.Font font16 = categoryPlot9.getNoDataMessageFont();
        dateAxis6.setLabelFont(font16);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D0, (double) (short) 0, (double) ' ', 300.0d, (double) (short) 100, font16);
        numberAxis3D0.setLowerBound((double) 0.5f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset18, false);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset18);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double26 = dateAxis25.getFixedDimension();
        boolean boolean27 = dateAxis25.isAutoTickUnitSelection();
        org.jfree.data.Range range28 = dateAxis25.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range23, range28);
        boolean boolean31 = range28.contains((double) (-3407872));
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 300.0d + "'", number19.equals(300.0d));
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Shape shape8 = ganttRenderer0.getSeriesShape(5);
        ganttRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        ganttRenderer0.setAutoPopulateSeriesStroke(true);
        boolean boolean13 = ganttRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = ganttRenderer0.getBasePositiveItemLabelPosition();
        ganttRenderer0.setBase((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 11, 0.0f);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape5, "ClassContext", "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity11 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis1, shape5, "org.jfree.data.UnknownKeyException: hi!", "{0}");
        org.jfree.chart.axis.Axis axis12 = axisLabelEntity11.getAxis();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(axis12);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.util.List list1 = defaultKeyedValues0.getKeys();
        try {
            java.lang.Number number3 = defaultKeyedValues0.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        outlierListCollection0.setHighFarOut(false);
        org.jfree.chart.renderer.Outlier outlier3 = null;
        boolean boolean4 = outlierListCollection0.add(outlier3);
        org.jfree.chart.renderer.Outlier outlier5 = null;
        boolean boolean6 = outlierListCollection0.add(outlier5);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke3 = stackedBarRenderer3D0.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot4);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getRangeMarkers(3, layer11);
        java.util.List list13 = categoryPlot9.getAnnotations();
        categoryPlot9.clearRangeAxes();
        boolean boolean15 = categoryPlot4.equals((java.lang.Object) categoryPlot9);
        org.jfree.chart.axis.AxisSpace axisSpace16 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot4.setFixedDomainAxisSpace(axisSpace16);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer19 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendTitle20.getLegendItemGraphicLocation();
        java.awt.Paint paint22 = legendTitle20.getBackgroundPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = legendTitle20.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle20.setLegendItemGraphicEdge(rectangleEdge24);
        axisSpace16.ensureAtLeast(49.5d, rectangleEdge24);
        axisSpace16.setLeft((double) 60000L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        java.awt.geom.Rectangle2D rectangle2D4 = textTitle2.getBounds();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean8 = lineAndShapeRenderer5.getItemLineVisible((int) (short) -1, 8);
        boolean boolean9 = textTitle2.equals((java.lang.Object) lineAndShapeRenderer5);
        org.jfree.data.KeyedObject keyedObject10 = new org.jfree.data.KeyedObject((java.lang.Comparable) 10L, (java.lang.Object) boolean9);
        java.lang.Object obj11 = keyedObject10.clone();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str14 = textTitle13.getText();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint17 = null;
        textTitle16.setBackgroundPaint(paint17);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle20.setTextAlignment(horizontalAlignment21);
        textTitle16.setTextAlignment(horizontalAlignment21);
        textTitle13.setHorizontalAlignment(horizontalAlignment21);
        boolean boolean25 = spreadsheetDate8.equals((java.lang.Object) textTitle13);
        boolean boolean26 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean3 = lineRenderer3D0.getItemShapeVisible((int) ' ', (int) ' ');
        java.awt.Paint paint4 = lineRenderer3D0.getWallPaint();
        double double5 = lineRenderer3D0.getYOffset();
        lineRenderer3D0.setYOffset((double) 4);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean11 = stackedBarRenderer3D9.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke12 = stackedBarRenderer3D9.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D9.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot13);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot18.getRangeMarkers(3, layer20);
        java.util.List list22 = categoryPlot18.getAnnotations();
        categoryPlot18.clearRangeAxes();
        boolean boolean24 = categoryPlot13.equals((java.lang.Object) categoryPlot18);
        categoryPlot13.configureDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double28 = dateAxis27.getFixedDimension();
        double double29 = dateAxis27.getLowerBound();
        java.awt.Paint paint30 = dateAxis27.getTickLabelPaint();
        dateAxis27.setVerticalTickLabels(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = categoryPlot33.getRangeMarkers(3, layer35);
        java.util.List list37 = categoryPlot33.getAnnotations();
        java.awt.Paint paint38 = categoryPlot33.getOutlinePaint();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke41 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint40, stroke41);
        java.awt.Paint paint43 = valueMarker42.getLabelPaint();
        categoryPlot33.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker42);
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str47 = textTitle46.getText();
        java.awt.Font font48 = textTitle46.getFont();
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str52 = textTitle51.getText();
        java.awt.geom.Rectangle2D rectangle2D53 = textTitle51.getBounds();
        textTitle46.draw(graphics2D49, rectangle2D53);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer55 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer55);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = legendTitle56.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean61 = rectangleAnchor57.equals((java.lang.Object) simpleTimePeriod60);
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D53, rectangleAnchor57, 4.0d, (double) 100L);
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str67 = textTitle66.getText();
        java.awt.Font font68 = textTitle66.getFont();
        java.awt.Graphics2D graphics2D69 = null;
        org.jfree.chart.title.TextTitle textTitle71 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str72 = textTitle71.getText();
        java.awt.geom.Rectangle2D rectangle2D73 = textTitle71.getBounds();
        textTitle66.draw(graphics2D69, rectangle2D73);
        boolean boolean75 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D53, rectangle2D73);
        lineRenderer3D0.drawRangeMarker(graphics2D8, categoryPlot13, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.chart.plot.Marker) valueMarker42, rectangle2D73);
        dateAxis27.resizeRange((double) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "" + "'", str67.equals(""));
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "" + "'", str72.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.lang.Object obj1 = paintList0.clone();
        int int2 = paintList0.size();
        java.awt.Paint paint4 = paintList0.getPaint(5);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1, (double) 7);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = intervalMarker2.getGradientPaintTransformer();
        double double4 = intervalMarker2.getEndValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = intervalMarker2.getLabelAnchor();
        org.junit.Assert.assertNull(gradientPaintTransformer3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.0d + "'", double4 == 7.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers(3, layer10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot8.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint17, stroke18);
        categoryPlot8.setRangeCrosshairStroke(stroke18);
        categoryPlot0.setOutlineStroke(stroke18);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot0.getDomainAxisLocation();
        boolean boolean23 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double3 = piePlot3D1.getExplodePercent((java.lang.Comparable) 0.2d);
        piePlot3D1.setForegroundAlpha((float) 100L);
        boolean boolean6 = piePlot3D1.isCircular();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3D8.getLabelDistributor();
        piePlot3D1.setLabelDistributor(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke8 = ganttRenderer0.getSeriesStroke(0);
        java.lang.Boolean boolean10 = ganttRenderer0.getSeriesCreateEntities((int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot11.getRangeMarkers(3, layer13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot11.setRangeGridlinePaint((java.awt.Paint) color15);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot11.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint20, stroke21);
        categoryPlot11.setRangeCrosshairStroke(stroke21);
        boolean boolean24 = ganttRenderer0.hasListener((java.util.EventListener) categoryPlot11);
        java.awt.Shape shape26 = ganttRenderer0.lookupSeriesShape((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape26);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double9 = dateAxis8.getFixedDimension();
        boolean boolean10 = dateAxis8.isAutoTickUnitSelection();
        categoryPlot0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis8, true);
        org.jfree.data.Range range13 = dateAxis8.getDefaultAutoRange();
        boolean boolean15 = range13.contains(0.0d);
        double double16 = range13.getUpperBound();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double3 = dateAxis2.getFixedDimension();
        dateAxis2.setVerticalTickLabels(false);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer6);
        float float8 = dateAxis2.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("August", graphics2D1, (float) (-3407872), (float) (short) 10, 0.0d, (float) (short) 0, (float) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double3 = dateAxis2.getFixedDimension();
        java.util.Date date4 = dateAxis2.getMinimumDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.lang.Class<?> wildcardClass7 = stackedBarRenderer3D6.getClass();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double10 = dateAxis9.getFixedDimension();
        java.util.Date date11 = dateAxis9.getMaximumDate();
        dateAxis9.setAutoRangeMinimumSize(3.0d);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer14 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendTitle15.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean20 = rectangleAnchor16.equals((java.lang.Object) simpleTimePeriod19);
        java.util.Date date21 = simpleTimePeriod19.getStart();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = dateAxis9.dateToJava2D(date21, rectangle2D22, rectangleEdge23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot25.getRangeMarkers(3, layer27);
        java.util.List list29 = categoryPlot25.getAnnotations();
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double34 = dateAxis33.getFixedDimension();
        boolean boolean35 = dateAxis33.isAutoTickUnitSelection();
        categoryPlot25.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis33, true);
        dateAxis33.setRangeAboutValue((double) 0, (double) (short) 100);
        java.util.TimeZone timeZone41 = dateAxis33.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date21, timeZone41);
        java.lang.Class class43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double46 = dateAxis45.getFixedDimension();
        java.util.Date date47 = dateAxis45.getMinimumDate();
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date47, timeZone48);
        org.jfree.data.time.DateRange dateRange50 = new org.jfree.data.time.DateRange(date21, date47);
        java.lang.Number number51 = defaultBoxAndWhiskerCategoryDataset0.getMinRegularValue((java.lang.Comparable) month5, (java.lang.Comparable) date47);
        java.lang.Number number54 = defaultBoxAndWhiskerCategoryDataset0.getQ3Value((java.lang.Comparable) (-1L), (java.lang.Comparable) 30.0d);
        try {
            java.lang.Number number57 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue(128, 128);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 128, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNull(number51);
        org.junit.Assert.assertNull(number54);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) -1);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot0.getDomainMarkers(layer8);
        categoryPlot0.setRangeCrosshairValue(0.35d);
        java.awt.Paint paint12 = categoryPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray17);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset18, false);
        double double22 = range21.getCentralValue();
        org.jfree.data.Range range24 = org.jfree.data.Range.shift(range21, Double.POSITIVE_INFINITY);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange(range21);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 300.0d + "'", number19.equals(300.0d));
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 49.5d + "'", double22 == 49.5d);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = projectInfo0.getLogo();
        projectInfo0.setName("({0}, {1}) = {3} - {4}");
        java.lang.String str4 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.axis.NumberAxis numberAxis2 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str9 = textTitle8.getText();
        java.awt.Font font10 = textTitle8.getFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis2, (double) 12, 300.0d, (double) 10.0f, 0.25d, font10);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str14 = textTitle13.getText();
        textTitle13.setMargin((double) 100.0f, (double) 11, (double) 0, 0.0d);
        java.lang.Object obj20 = textTitle13.clone();
        java.lang.Object obj21 = textTitle13.clone();
        java.awt.Paint paint22 = textTitle13.getPaint();
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("org.jfree.data.UnknownKeyException: hi!", font10, paint22);
        boolean boolean24 = basicProjectInfo0.equals((java.lang.Object) textFragment23);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 11);
        java.lang.String str3 = rectangleConstraint2.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toFixedWidth((double) (-6553600));
        java.lang.String str7 = rectangleConstraint4.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint4.toUnconstrainedHeight();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]" + "'", str3.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=11.0]" + "'", str7.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=11.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint8);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke8 = ganttRenderer0.getSeriesStroke(0);
        java.lang.Boolean boolean10 = ganttRenderer0.getSeriesCreateEntities((int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot11.getRangeMarkers(3, layer13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot11.setRangeGridlinePaint((java.awt.Paint) color15);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot11.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint20, stroke21);
        categoryPlot11.setRangeCrosshairStroke(stroke21);
        boolean boolean24 = ganttRenderer0.hasListener((java.util.EventListener) categoryPlot11);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = null;
        categoryPlot11.datasetChanged(datasetChangeEvent25);
        double double27 = categoryPlot11.getAnchorValue();
        int int28 = categoryPlot11.getDatasetCount();
        java.util.List list29 = categoryPlot11.getAnnotations();
        java.util.Collection collection30 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list29);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(collection30);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray2, numberArray3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot8.setRadiusGridlineStroke(stroke9);
        boolean boolean11 = defaultIntervalCategoryDataset4.hasListener((java.util.EventListener) polarPlot8);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) defaultIntervalCategoryDataset4, (java.lang.Comparable) 10.0f);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = null;
        defaultIntervalCategoryDataset4.seriesChanged(seriesChangeEvent14);
        try {
            java.lang.Comparable comparable17 = defaultIntervalCategoryDataset4.getRowKey((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke3 = stackedBarRenderer3D0.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot4);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getRangeMarkers(3, layer11);
        java.util.List list13 = categoryPlot9.getAnnotations();
        categoryPlot9.clearRangeAxes();
        boolean boolean15 = categoryPlot4.equals((java.lang.Object) categoryPlot9);
        org.jfree.chart.axis.AxisSpace axisSpace16 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot4.setFixedDomainAxisSpace(axisSpace16);
        org.jfree.chart.util.SortOrder sortOrder18 = categoryPlot4.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(sortOrder18);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot1);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart5);
        org.jfree.chart.title.LegendTitle legendTitle8 = jFreeChart5.getLegend((int) '#');
        boolean boolean9 = jFreeChart5.getAntiAlias();
        java.lang.Object obj10 = jFreeChart5.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double13 = rectangleInsets11.trimHeight((double) 1.0f);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D15 = new org.jfree.chart.plot.PiePlot3D(pieDataset14);
        boolean boolean16 = rectangleInsets11.equals((java.lang.Object) pieDataset14);
        java.awt.Font font18 = null;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer21 = null;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot(xYDataset19, valueAxis20, polarItemRenderer21);
        polarPlot22.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str27 = textTitle26.getText();
        java.awt.Font font28 = textTitle26.getFont();
        polarPlot22.setAngleLabelFont(font28);
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("", font18, (org.jfree.chart.plot.Plot) polarPlot22, true);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str35 = textTitle34.getText();
        java.awt.Font font36 = textTitle34.getFont();
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str40 = textTitle39.getText();
        java.awt.geom.Rectangle2D rectangle2D41 = textTitle39.getBounds();
        textTitle34.draw(graphics2D37, rectangle2D41);
        java.awt.geom.Point2D point2D43 = null;
        org.jfree.chart.plot.PlotState plotState44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        polarPlot22.draw(graphics2D32, rectangle2D41, point2D43, plotState44, plotRenderingInfo45);
        java.awt.geom.Rectangle2D rectangle2D47 = rectangleInsets11.createInsetRectangle(rectangle2D41);
        java.lang.Number[] numberArray56 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray61 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray66 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray67 = new java.lang.Number[][] { numberArray56, numberArray61, numberArray66 };
        org.jfree.data.category.CategoryDataset categoryDataset68 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray67);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity71 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D47, "hi!", "({0}, {1}) = {2}", categoryDataset68, (java.lang.Comparable) 0.0f, (java.lang.Comparable) 0);
        org.jfree.data.general.PieDataset pieDataset73 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset68, 3);
        double double74 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset73);
        try {
            jFreeChart5.setTextAntiAlias((java.lang.Object) double74);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 30.0 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendTitle8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(numberArray66);
        org.junit.Assert.assertNotNull(numberArray67);
        org.junit.Assert.assertNotNull(categoryDataset68);
        org.junit.Assert.assertNotNull(pieDataset73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 30.0d + "'", double74 == 30.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint1, stroke2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int5 = color4.getBlue();
        valueMarker3.setLabelPaint((java.awt.Paint) color4);
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str11 = textTitle10.getText();
        java.awt.geom.Rectangle2D rectangle2D12 = textTitle10.getBounds();
        java.awt.geom.AffineTransform affineTransform13 = null;
        java.awt.RenderingHints renderingHints14 = null;
        java.awt.PaintContext paintContext15 = color4.createContext(colorModel7, rectangle8, rectangle2D12, affineTransform13, renderingHints14);
        try {
            org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle8, "AxisLocation.TOP_OR_LEFT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 128 + "'", int5 == 128);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(paintContext15);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str3 = textTitle2.getText();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint6 = null;
        textTitle5.setBackgroundPaint(paint6);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle9.setTextAlignment(horizontalAlignment10);
        textTitle5.setTextAlignment(horizontalAlignment10);
        textTitle2.setHorizontalAlignment(horizontalAlignment10);
        blockContainer0.add((org.jfree.chart.block.Block) textTitle2);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot15.getRangeMarkers(3, layer17);
        java.util.List list19 = categoryPlot15.getAnnotations();
        categoryPlot15.clearRangeAxes();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        categoryPlot15.setDrawingSupplier(drawingSupplier21);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer23 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean25 = ganttRenderer23.equals((java.lang.Object) '#');
        double double26 = ganttRenderer23.getItemLabelAnchorOffset();
        ganttRenderer23.setSeriesItemLabelsVisible((int) (short) 0, true);
        int int30 = categoryPlot15.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) ganttRenderer23);
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        java.lang.String str32 = axisLocation31.toString();
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot(xYDataset34, valueAxis35, polarItemRenderer36);
        polarPlot37.removeCornerTextItem("");
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = polarPlot37.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation33, plotOrientation40);
        org.jfree.chart.plot.PlotOrientation plotOrientation42 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation33, plotOrientation42);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation31, plotOrientation42);
        categoryPlot15.setDomainAxisLocation(axisLocation31, true);
        boolean boolean47 = textTitle2.equals((java.lang.Object) true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str32.equals("AxisLocation.TOP_OR_LEFT"));
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(plotOrientation40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(plotOrientation42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        boolean boolean3 = defaultBoxAndWhiskerCategoryDataset0.equals((java.lang.Object) color1);
        java.util.List list4 = defaultBoxAndWhiskerCategoryDataset0.getColumnKeys();
        defaultBoxAndWhiskerCategoryDataset0.validateObject();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot7.getRangeMarkers(3, layer9);
        java.util.List list11 = categoryPlot7.getAnnotations();
        java.awt.Paint paint12 = categoryPlot7.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double16 = dateAxis15.getFixedDimension();
        boolean boolean17 = dateAxis15.isAutoTickUnitSelection();
        categoryPlot7.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = dateAxis15.getTickUnit();
        org.jfree.chart.entity.EntityCollection entityCollection21 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo(entityCollection21);
        int int23 = dateTickUnit20.compareTo((java.lang.Object) entityCollection21);
        java.lang.Number number24 = defaultBoxAndWhiskerCategoryDataset0.getMedianValue((java.lang.Comparable) 5.0d, (java.lang.Comparable) dateTickUnit20);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNull(number24);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot2.getRangeMarkers(3, layer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot2.setRangeGridlinePaint((java.awt.Paint) color6);
        ganttRenderer0.setSeriesOutlinePaint((int) (byte) 1, (java.awt.Paint) color6);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        org.jfree.data.gantt.Task task4 = new org.jfree.data.gantt.Task("java.awt.Color[r=128,g=128,b=255]", (org.jfree.data.time.TimePeriod) simpleTimePeriod3);
        int int5 = task4.getSubtaskCount();
        task4.setPercentComplete((java.lang.Double) 49.5d);
        java.lang.Double double8 = task4.getPercentComplete();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 49.5d + "'", double8.equals(49.5d));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray2, numberArray3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot8.setRadiusGridlineStroke(stroke9);
        boolean boolean11 = defaultIntervalCategoryDataset4.hasListener((java.util.EventListener) polarPlot8);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) defaultIntervalCategoryDataset4, (java.lang.Comparable) 10.0f);
        try {
            int int14 = defaultIntervalCategoryDataset4.getColumnCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleEdge.TOP", graphics2D1, (float) 4, (float) 0, textAnchor4, (-1.0d), (float) 1, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str1 = chartChangeEventType0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = chartChangeEventType0.equals(obj2);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str1.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint1, stroke2);
        java.awt.Paint paint4 = valueMarker3.getLabelPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.lang.Class<?> wildcardClass7 = stackedBarRenderer3D6.getClass();
        java.lang.Class class8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double11 = dateAxis10.getFixedDimension();
        java.util.Date date12 = dateAxis10.getMinimumDate();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date12, timeZone13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot15.getRangeMarkers(3, layer17);
        java.util.List list19 = categoryPlot15.getAnnotations();
        java.awt.Paint paint20 = categoryPlot15.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double24 = dateAxis23.getFixedDimension();
        boolean boolean25 = dateAxis23.isAutoTickUnitSelection();
        categoryPlot15.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis23, true);
        dateAxis23.setRangeAboutValue((double) 0, (double) (short) 100);
        java.util.TimeZone timeZone31 = dateAxis23.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date12, timeZone31);
        java.io.InputStream inputStream33 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleEdge.TOP", (java.lang.Class) wildcardClass7);
        java.lang.ClassLoader classLoader34 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass7);
        try {
            java.util.EventListener[] eventListenerArray35 = valueMarker3.getListeners((java.lang.Class) wildcardClass7);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.chart.renderer.category.StackedBarRenderer3D; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(inputStream33);
        org.junit.Assert.assertNotNull(classLoader34);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot2.getRangeMarkers(3, layer4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot2.setRangeGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot2.getRangeAxisForDataset((int) (short) -1);
        java.awt.Font font10 = categoryPlot2.getNoDataMessageFont();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean13 = stackedBarRenderer3D11.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke14 = stackedBarRenderer3D11.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D11.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot15);
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot15.getColumnRenderingOrder();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        boolean boolean22 = sortOrder20.equals((java.lang.Object) color21);
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("", font10, (java.awt.Paint) color21);
        boolean boolean24 = gradientPaintTransformType0.equals((java.lang.Object) textFragment23);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers(3, layer10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot8.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint17, stroke18);
        categoryPlot8.setRangeCrosshairStroke(stroke18);
        categoryPlot0.setOutlineStroke(stroke18);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot0.zoomRangeAxes((double) 2958465, (double) 0.5f, plotRenderingInfo26, point2D27);
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot0.getDomainAxisLocation(0);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.Paint paint2 = null;
        textTitle1.setBackgroundPaint(paint2);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle5.setTextAlignment(horizontalAlignment6);
        textTitle1.setTextAlignment(horizontalAlignment6);
        java.awt.Font font9 = textTitle1.getFont();
        java.lang.String str10 = textTitle1.getText();
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getShadowYOffset();
        piePlot3D1.setStartAngle(2.0d);
        double double5 = piePlot3D1.getMaximumLabelWidth();
        java.awt.Paint paint6 = piePlot3D1.getLabelShadowPaint();
        double double7 = piePlot3D1.getMaximumLabelWidth();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number4 = taskSeriesCollection0.getPercentComplete((int) (byte) 10, (int) '4', 128);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        ganttRenderer0.setIncludeBaseInRange(true);
        int int9 = ganttRenderer0.getPassCount();
        ganttRenderer0.setMaximumBarWidth(0.0d);
        boolean boolean13 = ganttRenderer0.isSeriesVisible((int) '4');
        java.awt.Paint paint14 = ganttRenderer0.getIncompletePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double3 = dateAxis2.getFixedDimension();
        java.util.Date date4 = dateAxis2.getMinimumDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.lang.Class<?> wildcardClass7 = stackedBarRenderer3D6.getClass();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double10 = dateAxis9.getFixedDimension();
        java.util.Date date11 = dateAxis9.getMaximumDate();
        dateAxis9.setAutoRangeMinimumSize(3.0d);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer14 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendTitle15.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean20 = rectangleAnchor16.equals((java.lang.Object) simpleTimePeriod19);
        java.util.Date date21 = simpleTimePeriod19.getStart();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = dateAxis9.dateToJava2D(date21, rectangle2D22, rectangleEdge23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot25.getRangeMarkers(3, layer27);
        java.util.List list29 = categoryPlot25.getAnnotations();
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double34 = dateAxis33.getFixedDimension();
        boolean boolean35 = dateAxis33.isAutoTickUnitSelection();
        categoryPlot25.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis33, true);
        dateAxis33.setRangeAboutValue((double) 0, (double) (short) 100);
        java.util.TimeZone timeZone41 = dateAxis33.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date21, timeZone41);
        java.lang.Class class43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double46 = dateAxis45.getFixedDimension();
        java.util.Date date47 = dateAxis45.getMinimumDate();
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date47, timeZone48);
        org.jfree.data.time.DateRange dateRange50 = new org.jfree.data.time.DateRange(date21, date47);
        java.lang.Number number51 = defaultBoxAndWhiskerCategoryDataset0.getMinRegularValue((java.lang.Comparable) month5, (java.lang.Comparable) date47);
        try {
            java.lang.Comparable comparable53 = defaultBoxAndWhiskerCategoryDataset0.getRowKey((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNull(number51);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray17 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] { numberArray7, numberArray12, numberArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray18);
        java.lang.Number number20 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset19, false);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset19);
        double double24 = range23.getLength();
        org.jfree.data.KeyedObject keyedObject25 = new org.jfree.data.KeyedObject((java.lang.Comparable) 5, (java.lang.Object) double24);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.lang.Class<?> wildcardClass27 = stackedBarRenderer3D26.getClass();
        keyedObject25.setObject((java.lang.Object) stackedBarRenderer3D26);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator31 = stackedBarRenderer3D26.getToolTipGenerator(128, 2019);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 300.0d + "'", number20.equals(300.0d));
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 303.0d + "'", double24 == 303.0d);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(categoryToolTipGenerator31);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint2 = ganttRenderer0.getSeriesFillPaint((int) ' ');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = ganttRenderer0.getSeriesNegativeItemLabelPosition(10);
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition4.getRotationAnchor();
        java.lang.String str6 = textAnchor5.toString();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextAnchor.CENTER" + "'", str6.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 128);
        categoryMarker1.setDrawAsLine(true);
        try {
            categoryMarker1.setAlpha((float) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        taskSeries1.fireSeriesChanged();
        taskSeries1.setKey((java.lang.Comparable) Double.POSITIVE_INFINITY);
        java.lang.Object obj5 = taskSeries1.clone();
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        boolean boolean2 = ganttRenderer0.equals((java.lang.Object) '#');
        ganttRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = ganttRenderer0.getGradientPaintTransformer();
        ganttRenderer0.setSeriesCreateEntities((int) (byte) 0, (java.lang.Boolean) false, false);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str14 = textTitle13.getText();
        java.awt.Font font15 = textTitle13.getFont();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str19 = textTitle18.getText();
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle18.getBounds();
        textTitle13.draw(graphics2D16, rectangle2D20);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer22 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = legendTitle23.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean28 = rectangleAnchor24.equals((java.lang.Object) simpleTimePeriod27);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D20, rectangleAnchor24, 4.0d, (double) 100L);
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str34 = textTitle33.getText();
        java.awt.Font font35 = textTitle33.getFont();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str39 = textTitle38.getText();
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle38.getBounds();
        textTitle33.draw(graphics2D36, rectangle2D40);
        boolean boolean42 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D20, rectangle2D40);
        ganttRenderer0.setBaseShape((java.awt.Shape) rectangle2D40, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date6 = spreadsheetDate5.toDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(128, serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean14 = spreadsheetDate1.isInRange(serialDate7, serialDate13);
        java.lang.Object obj15 = null;
        try {
            int int16 = spreadsheetDate1.compareTo(obj15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.5f, (float) 7);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint1 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean3 = stackedBarRenderer3D1.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke4 = stackedBarRenderer3D1.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot5);
        org.jfree.chart.util.SortOrder sortOrder10 = categoryPlot5.getColumnRenderingOrder();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        boolean boolean12 = sortOrder10.equals((java.lang.Object) color11);
        defaultKeyedValues0.sortByKeys(sortOrder10);
        defaultKeyedValues0.addValue((java.lang.Comparable) 12, (double) (short) 100);
        try {
            defaultKeyedValues0.insertValue(6, (java.lang.Comparable) ' ', (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.PlotState plotState0 = new org.jfree.chart.plot.PlotState();
        java.util.Map map1 = plotState0.getSharedAxisStates();
        java.util.Map map2 = plotState0.getSharedAxisStates();
        org.junit.Assert.assertNotNull(map1);
        org.junit.Assert.assertNotNull(map2);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint1 = lineBorder0.getPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot2.getRangeMarkers(3, layer4);
        java.util.List list6 = categoryPlot2.getAnnotations();
        java.awt.Paint paint7 = categoryPlot2.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double11 = dateAxis10.getFixedDimension();
        boolean boolean12 = dateAxis10.isAutoTickUnitSelection();
        categoryPlot2.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis10, true);
        boolean boolean15 = dateAxis10.isVerticalTickLabels();
        java.awt.Shape shape16 = dateAxis10.getRightArrow();
        boolean boolean17 = lineBorder0.equals((java.lang.Object) shape16);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtLeft();
        java.util.List list2 = axisCollection0.getAxesAtLeft();
        java.util.List list3 = axisCollection0.getAxesAtTop();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        org.jfree.data.gantt.Task task2 = null;
        taskSeries1.remove(task2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        taskSeries1.removePropertyChangeListener(propertyChangeListener4);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) 1.0f);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        boolean boolean5 = rectangleInsets0.equals((java.lang.Object) pieDataset3);
        java.awt.Font font7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        polarPlot11.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str16 = textTitle15.getText();
        java.awt.Font font17 = textTitle15.getFont();
        polarPlot11.setAngleLabelFont(font17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", font7, (org.jfree.chart.plot.Plot) polarPlot11, true);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str24 = textTitle23.getText();
        java.awt.Font font25 = textTitle23.getFont();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str29 = textTitle28.getText();
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle28.getBounds();
        textTitle23.draw(graphics2D26, rectangle2D30);
        java.awt.geom.Point2D point2D32 = null;
        org.jfree.chart.plot.PlotState plotState33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        polarPlot11.draw(graphics2D21, rectangle2D30, point2D32, plotState33, plotRenderingInfo34);
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets0.createInsetRectangle(rectangle2D30);
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray45, numberArray50, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray56);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity60 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D36, "hi!", "({0}, {1}) = {2}", categoryDataset57, (java.lang.Comparable) 0.0f, (java.lang.Comparable) 0);
        org.jfree.data.general.PieDataset pieDataset62 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset57, 3);
        org.jfree.chart.plot.RingPlot ringPlot63 = new org.jfree.chart.plot.RingPlot(pieDataset62);
        java.awt.Stroke stroke64 = ringPlot63.getSeparatorStroke();
        double double65 = ringPlot63.getInnerSeparatorExtension();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertNotNull(pieDataset62);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.2d + "'", double65 == 0.2d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        java.util.Date date3 = dateAxis1.getMaximumDate();
        dateAxis1.setAutoRangeMinimumSize(3.0d);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer6 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendTitle7.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean12 = rectangleAnchor8.equals((java.lang.Object) simpleTimePeriod11);
        java.util.Date date13 = simpleTimePeriod11.getStart();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = dateAxis1.dateToJava2D(date13, rectangle2D14, rectangleEdge15);
        java.awt.Shape shape17 = dateAxis1.getLeftArrow();
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str20 = textTitle19.getText();
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle19.getBounds();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D21, (double) (short) 10, 100.0f, (float) (short) -1);
        dateAxis1.setLeftArrow((java.awt.Shape) rectangle2D21);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke3 = stackedBarRenderer3D0.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot4);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        java.util.List list10 = categoryPlot4.getCategoriesForAxis(categoryAxis9);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot4.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(sortOrder11);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxisForDataset((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot8.getRangeMarkers(3, layer10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot8.getRangeAxisForDataset((int) (short) -1);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint17, stroke18);
        categoryPlot8.setRangeCrosshairStroke(stroke18);
        categoryPlot0.setOutlineStroke(stroke18);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot0.zoomRangeAxes((double) 2958465, (double) 0.5f, plotRenderingInfo26, point2D27);
        categoryPlot0.clearDomainMarkers();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double3 = dateAxis2.getFixedDimension();
        java.util.Date date4 = dateAxis2.getMinimumDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.lang.Class<?> wildcardClass7 = stackedBarRenderer3D6.getClass();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double10 = dateAxis9.getFixedDimension();
        java.util.Date date11 = dateAxis9.getMaximumDate();
        dateAxis9.setAutoRangeMinimumSize(3.0d);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer14 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendTitle15.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean20 = rectangleAnchor16.equals((java.lang.Object) simpleTimePeriod19);
        java.util.Date date21 = simpleTimePeriod19.getStart();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = dateAxis9.dateToJava2D(date21, rectangle2D22, rectangleEdge23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot25.getRangeMarkers(3, layer27);
        java.util.List list29 = categoryPlot25.getAnnotations();
        java.awt.Paint paint30 = categoryPlot25.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double34 = dateAxis33.getFixedDimension();
        boolean boolean35 = dateAxis33.isAutoTickUnitSelection();
        categoryPlot25.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis33, true);
        dateAxis33.setRangeAboutValue((double) 0, (double) (short) 100);
        java.util.TimeZone timeZone41 = dateAxis33.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date21, timeZone41);
        java.lang.Class class43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double46 = dateAxis45.getFixedDimension();
        java.util.Date date47 = dateAxis45.getMinimumDate();
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date47, timeZone48);
        org.jfree.data.time.DateRange dateRange50 = new org.jfree.data.time.DateRange(date21, date47);
        java.lang.Number number51 = defaultBoxAndWhiskerCategoryDataset0.getMinRegularValue((java.lang.Comparable) month5, (java.lang.Comparable) date47);
        java.lang.Number number54 = defaultBoxAndWhiskerCategoryDataset0.getQ3Value((java.lang.Comparable) (-1L), (java.lang.Comparable) 30.0d);
        try {
            java.lang.Number number57 = defaultBoxAndWhiskerCategoryDataset0.getMedianValue((int) (short) -1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNull(number51);
        org.junit.Assert.assertNull(number54);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color4);
        org.jfree.data.category.CategoryDataset categoryDataset7 = categoryPlot0.getDataset(128);
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(categoryDataset7);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Object obj1 = null;
        boolean boolean2 = boxAndWhiskerRenderer0.equals(obj1);
        java.awt.Paint paint4 = null;
        boxAndWhiskerRenderer0.setSeriesPaint((int) (short) 100, paint4, true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boxAndWhiskerRenderer0.setSeriesFillPaint(3, (java.awt.Paint) color8, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        try {
            boxAndWhiskerRenderer0.setSeriesPositiveItemLabelPosition((int) (short) -1, itemLabelPosition12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(true);
        int int4 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) 86400000L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("PlotOrientation.HORIZONTAL");
        numberAxis3D1.configure();
        numberAxis3D1.setAutoRangeMinimumSize(300.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) 1.0f);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        boolean boolean5 = rectangleInsets0.equals((java.lang.Object) pieDataset3);
        java.awt.Font font7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot(xYDataset8, valueAxis9, polarItemRenderer10);
        polarPlot11.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str16 = textTitle15.getText();
        java.awt.Font font17 = textTitle15.getFont();
        polarPlot11.setAngleLabelFont(font17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", font7, (org.jfree.chart.plot.Plot) polarPlot11, true);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str24 = textTitle23.getText();
        java.awt.Font font25 = textTitle23.getFont();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str29 = textTitle28.getText();
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle28.getBounds();
        textTitle23.draw(graphics2D26, rectangle2D30);
        java.awt.geom.Point2D point2D32 = null;
        org.jfree.chart.plot.PlotState plotState33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        polarPlot11.draw(graphics2D21, rectangle2D30, point2D32, plotState33, plotRenderingInfo34);
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets0.createInsetRectangle(rectangle2D30);
        java.lang.Number[] numberArray45 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray50 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray45, numberArray50, numberArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray56);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity60 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D36, "hi!", "({0}, {1}) = {2}", categoryDataset57, (java.lang.Comparable) 0.0f, (java.lang.Comparable) 0);
        categoryItemEntity60.setRowKey((java.lang.Comparable) 0.25d);
        org.jfree.chart.entity.EntityCollection entityCollection63 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo64 = new org.jfree.chart.ChartRenderingInfo(entityCollection63);
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str67 = textTitle66.getText();
        java.awt.geom.Rectangle2D rectangle2D68 = textTitle66.getBounds();
        chartRenderingInfo64.setChartArea(rectangle2D68);
        boolean boolean70 = categoryItemEntity60.equals((java.lang.Object) rectangle2D68);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "" + "'", str67.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        java.lang.String[] strArray1 = new java.lang.String[] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray1, numberArray2, numberArray3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset5, valueAxis6, polarItemRenderer7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot8.setRadiusGridlineStroke(stroke9);
        boolean boolean11 = defaultIntervalCategoryDataset4.hasListener((java.util.EventListener) polarPlot8);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) defaultIntervalCategoryDataset4, (java.lang.Comparable) 10.0f);
        legendItemBlockContainer13.setURLText("ChartEntity: tooltip = ClassContext");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date6 = spreadsheetDate5.toDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(128, serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean14 = spreadsheetDate1.isInRange(serialDate7, serialDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date17 = spreadsheetDate16.toDate();
        int int18 = spreadsheetDate16.getMonth();
        boolean boolean19 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.Font font9 = textTitle7.getFont();
        polarPlot3.setAngleLabelFont(font9);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = polarPlot3.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        polarPlot3.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        polarPlot3.setDataset(xYDataset14);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(plotOrientation11);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke3 = stackedBarRenderer3D0.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot4);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot9.getRangeMarkers(3, layer11);
        java.util.List list13 = categoryPlot9.getAnnotations();
        categoryPlot9.clearRangeAxes();
        boolean boolean15 = categoryPlot4.equals((java.lang.Object) categoryPlot9);
        categoryPlot4.configureDomainAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot4.setRenderer(0, categoryItemRenderer18, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean2 = lineAndShapeRenderer0.equals((java.lang.Object) 12);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesShapesVisible((-1));
        java.lang.Object obj5 = lineAndShapeRenderer0.clone();
        boolean boolean6 = lineAndShapeRenderer0.getUseFillPaint();
        lineAndShapeRenderer0.setSeriesCreateEntities(1, (java.lang.Boolean) false, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.Number[][] numberArray1 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot(xYDataset4, valueAxis5, polarItemRenderer6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot7.setRadiusGridlineStroke(stroke8);
        boolean boolean10 = defaultIntervalCategoryDataset3.hasListener((java.util.EventListener) polarPlot7);
        try {
            boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAutoTickUnitSelection();
        org.jfree.data.Range range4 = dateAxis1.getDefaultAutoRange();
        dateAxis1.setAutoTickUnitSelection(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double9 = dateAxis8.getFixedDimension();
        boolean boolean10 = dateAxis8.isAutoTickUnitSelection();
        categoryPlot0.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis8, true);
        dateAxis8.setRangeAboutValue((double) (short) 10, (double) 86400000L);
        dateAxis8.setNegativeArrowVisible(false);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        categoryPlot0.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset6, valueAxis7, polarItemRenderer8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot9.setRadiusGridlineStroke(stroke10);
        categoryPlot0.setDomainGridlineStroke(stroke10);
        boolean boolean13 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.setRangeCrosshairVisible(false);
        try {
            categoryPlot0.zoom((double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.Number[][] numberArray1 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset3 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray1, numberArray2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = defaultIntervalCategoryDataset3.getGroup();
        boolean boolean6 = datasetGroup4.equals((java.lang.Object) (byte) 1);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(datasetGroup4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 10L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape1, "AxisLocation.TOP_OR_LEFT", "AxisLocation.TOP_OR_LEFT");
        tickLabelEntity4.setURLText("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str7 = tickLabelEntity4.getToolTipText();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str7.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getShadowYOffset();
        piePlot3D1.setStartAngle(2.0d);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot3D1.getLabelDistributor();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        java.util.List list4 = categoryPlot0.getAnnotations();
        categoryPlot0.clearRangeAxes();
        categoryPlot0.clearRangeAxes();
        int int7 = categoryPlot0.getWeight();
        int int8 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot1);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart5);
        java.awt.RenderingHints renderingHints7 = null;
        try {
            jFreeChart5.setRenderingHints(renderingHints7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double3 = dateAxis2.getFixedDimension();
        java.util.Date date4 = dateAxis2.getMinimumDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.gantt.Task task6 = new org.jfree.data.gantt.Task("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.time.TimePeriod) month5);
        java.lang.Double double7 = task6.getPercentComplete();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(double7);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double7 = dateAxis6.getFixedDimension();
        boolean boolean8 = dateAxis6.isAxisLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot10);
        categoryPlot9.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart14);
        java.awt.Font font16 = categoryPlot9.getNoDataMessageFont();
        dateAxis6.setLabelFont(font16);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D0, (double) (short) 0, (double) ' ', 300.0d, (double) (short) 100, font16);
        numberAxis3D0.setAutoRangeIncludesZero(false);
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str30 = textTitle29.getText();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle29.getBounds();
        chartRenderingInfo27.setChartArea(rectangle2D31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "({0}, {1}) = {2}", "", "", (java.awt.Shape) rectangle2D31, (java.awt.Paint) color33);
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str37 = textTitle36.getText();
        java.awt.geom.Rectangle2D rectangle2D38 = textTitle36.getBounds();
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D38, (double) (short) 10, 100.0f, (float) (short) -1);
        boolean boolean43 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D31, rectangle2D38);
        org.jfree.chart.axis.AxisState axisState44 = new org.jfree.chart.axis.AxisState();
        axisState44.cursorRight((double) 10);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer48 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer48);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = legendTitle49.getLegendItemGraphicLocation();
        java.awt.Paint paint51 = legendTitle49.getBackgroundPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = legendTitle49.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle49.setLegendItemGraphicEdge(rectangleEdge53);
        double double55 = legendTitle49.getHeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = org.jfree.chart.util.RectangleEdge.TOP;
        legendTitle49.setLegendItemGraphicEdge(rectangleEdge56);
        axisState44.moveCursor((double) (byte) 10, rectangleEdge56);
        double double59 = numberAxis3D0.valueToJava2D((double) 86400000L, rectangle2D31, rectangleEdge56);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNull(paint51);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = rendererState1.getEntityCollection();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = rendererState1.getInfo();
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertNull(plotRenderingInfo3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer0.getType();
        java.lang.Object obj3 = standardGradientPaintTransformer0.clone();
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        defaultKeyedValues2D1.clear();
        int int3 = defaultKeyedValues2D1.getColumnCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot6.getRangeMarkers(3, layer8);
        java.util.List list10 = categoryPlot6.getAnnotations();
        java.awt.Paint paint11 = categoryPlot6.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double15 = dateAxis14.getFixedDimension();
        boolean boolean16 = dateAxis14.isAutoTickUnitSelection();
        categoryPlot6.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis14, true);
        polarPlot3.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis14);
        java.awt.Paint paint20 = dateAxis14.getLabelPaint();
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("ChartEntity: tooltip = ClassContext", "java.awt.Color[r=128,g=128,b=255]");
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setCircular(false);
        boolean boolean4 = piePlot3D1.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        java.awt.Paint paint3 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer6 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.lang.Object obj7 = null;
        boolean boolean8 = boxAndWhiskerRenderer6.equals(obj7);
        java.awt.Paint paint10 = null;
        boxAndWhiskerRenderer6.setSeriesPaint((int) (short) 100, paint10, true);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_YELLOW;
        boxAndWhiskerRenderer6.setSeriesFillPaint(3, (java.awt.Paint) color14, false);
        legendTitle1.setItemPaint((java.awt.Paint) color14);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(true);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double6 = dateAxis5.getFixedDimension();
        java.util.Date date7 = dateAxis5.getMaximumDate();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.lang.Class<?> wildcardClass10 = stackedBarRenderer3D9.getClass();
        java.lang.Class class11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double14 = dateAxis13.getFixedDimension();
        java.util.Date date15 = dateAxis13.getMinimumDate();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date15, timeZone16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot18.getRangeMarkers(3, layer20);
        java.util.List list22 = categoryPlot18.getAnnotations();
        java.awt.Paint paint23 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double27 = dateAxis26.getFixedDimension();
        boolean boolean28 = dateAxis26.isAutoTickUnitSelection();
        categoryPlot18.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis26, true);
        dateAxis26.setRangeAboutValue((double) 0, (double) (short) 100);
        java.util.TimeZone timeZone34 = dateAxis26.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date15, timeZone34);
        java.io.InputStream inputStream36 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleEdge.TOP", (java.lang.Class) wildcardClass10);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double39 = dateAxis38.getFixedDimension();
        java.util.Date date40 = dateAxis38.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double43 = dateAxis42.getFixedDimension();
        boolean boolean44 = dateAxis42.isAxisLineVisible();
        java.lang.String str45 = dateAxis42.getLabelURL();
        dateAxis42.setTickMarksVisible(true);
        java.util.TimeZone timeZone48 = dateAxis42.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date40, timeZone48);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date7, timeZone48);
        java.lang.Number number51 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) 0L, (java.lang.Comparable) date7);
        try {
            java.lang.Comparable comparable53 = defaultStatisticalCategoryDataset0.getRowKey(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(inputStream36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNull(number51);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint1, stroke2);
        java.awt.Paint paint4 = valueMarker3.getLabelPaint();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int6 = color5.getTransparency();
        valueMarker3.setLabelPaint((java.awt.Paint) color5);
        java.awt.Stroke stroke8 = valueMarker3.getStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.clear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date8 = spreadsheetDate7.toDate();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays(128, serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date14 = spreadsheetDate13.toDate();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate3.isInRange(serialDate9, serialDate15);
        int int17 = spreadsheetDate3.getYYYY();
        defaultKeyedValues0.setValue((java.lang.Comparable) int17, (double) 15);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        java.awt.Paint paint2 = dateAxis1.getTickLabelPaint();
        double double3 = dateAxis1.getUpperMargin();
        double double4 = dateAxis1.getAutoRangeMinimumSize();
        org.jfree.chart.event.AxisChangeListener axisChangeListener5 = null;
        dateAxis1.addChangeListener(axisChangeListener5);
        dateAxis1.configure();
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = dateAxis1.getStandardTickUnits();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertNotNull(tickUnitSource8);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke3 = stackedBarRenderer3D0.getBaseStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = stackedBarRenderer3D0.getItemLabelGenerator((int) (short) -1, 0);
        java.awt.Paint paint7 = stackedBarRenderer3D0.getBaseItemLabelPaint();
        stackedBarRenderer3D0.setAutoPopulateSeriesFillPaint(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getRangeMarkers(3, layer2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot0.setDomainAxis(categoryAxis5);
        try {
            categoryPlot0.zoom(2.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        java.lang.String str4 = dateAxis1.getLabelURL();
        dateAxis1.setTickMarksVisible(true);
        java.lang.String[] strArray7 = new java.lang.String[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset10 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray7, numberArray8, numberArray9);
        org.jfree.data.general.DatasetGroup datasetGroup12 = new org.jfree.data.general.DatasetGroup("hi!");
        defaultIntervalCategoryDataset10.setGroup(datasetGroup12);
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str16 = textTitle15.getText();
        java.awt.Font font17 = textTitle15.getFont();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str21 = textTitle20.getText();
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle20.getBounds();
        textTitle15.draw(graphics2D18, rectangle2D22);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer24 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = legendTitle25.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean30 = rectangleAnchor26.equals((java.lang.Object) simpleTimePeriod29);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D22, rectangleAnchor26, 4.0d, (double) 100L);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str36 = textTitle35.getText();
        java.awt.Font font37 = textTitle35.getFont();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str41 = textTitle40.getText();
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle40.getBounds();
        textTitle35.draw(graphics2D38, rectangle2D42);
        boolean boolean44 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D22, rectangle2D42);
        boolean boolean45 = datasetGroup12.equals((java.lang.Object) rectangle2D42);
        dateAxis1.setLeftArrow((java.awt.Shape) rectangle2D42);
        double double47 = dateAxis1.getLowerMargin();
        org.jfree.chart.plot.Plot plot48 = dateAxis1.getPlot();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.05d + "'", double47 == 0.05d);
        org.junit.Assert.assertNull(plot48);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.equals((java.lang.Object) (short) 10);
        stackedBarRenderer3D0.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        boolean boolean8 = stackedBarRenderer3D0.isItemLabelVisible(3, 0);
        double double9 = stackedBarRenderer3D0.getMinimumBarLength();
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (-1), 100L, (byte) 100, 10.0d };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray16, numberArray21, numberArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", numberArray27);
        java.lang.Number number29 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset28);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset28, false);
        org.jfree.data.Range range32 = stackedBarRenderer3D0.findRangeBounds(categoryDataset28);
        java.lang.Number number33 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset28);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 300.0d + "'", number29.equals(300.0d));
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (-1.0d) + "'", number33.equals((-1.0d)));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot(xYDataset2, valueAxis3, polarItemRenderer4);
        polarPlot5.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str10 = textTitle9.getText();
        java.awt.Font font11 = textTitle9.getFont();
        polarPlot5.setAngleLabelFont(font11);
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("ThreadContext", font11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=128,g=128,b=255]", font11, (java.awt.Paint) color14);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(textBlock15);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean2 = stackedBarRenderer3D0.isSeriesVisibleInLegend(11);
        stackedBarRenderer3D0.setBaseCreateEntities(false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator9 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]", "ClassContext");
        stackedBarRenderer3D0.setSeriesURLGenerator((int) 'a', (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator9);
        java.lang.Boolean boolean12 = stackedBarRenderer3D0.getSeriesCreateEntities(12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        textTitle1.setPadding(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 2.0f, (double) 2958465);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate4.getNearestDayOfWeek(4);
        boolean boolean7 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str8 = textTitle7.getText();
        java.awt.Font font9 = textTitle7.getFont();
        polarPlot3.setAngleLabelFont(font9);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = polarPlot3.getOrientation();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setRangeCrosshairValue((double) (byte) 100, false);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot13);
        categoryPlot12.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart17);
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart17.getLegend((int) '#');
        boolean boolean21 = jFreeChart17.getAntiAlias();
        java.lang.Object obj22 = jFreeChart17.clone();
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent25 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) polarPlot3, jFreeChart17, (int) (byte) 1, (int) (byte) 1);
        int int26 = jFreeChart17.getSubtitleCount();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNull(legendTitle20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.text.DateFormat dateFormat6 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = new org.jfree.chart.axis.DateTickUnit(0, 12, 1, (int) (short) 1, dateFormat6);
        defaultCategoryDataset0.setValue(303.0d, (java.lang.Comparable) dateTickUnit7, (java.lang.Comparable) 8);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        java.lang.Object obj1 = null;
        boolean boolean2 = flowArrangement0.equals(obj1);
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray5 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray3, numberArray4, numberArray5);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer7 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle8.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean13 = rectangleAnchor9.equals((java.lang.Object) simpleTimePeriod12);
        java.util.Date date14 = simpleTimePeriod12.getStart();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) defaultIntervalCategoryDataset6, (java.lang.Comparable) simpleTimePeriod12);
        org.jfree.chart.block.Arrangement arrangement16 = legendItemBlockContainer15.getArrangement();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(arrangement16);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean3 = lineRenderer3D0.getItemShapeVisible((int) ' ', (int) ' ');
        java.awt.Paint paint4 = lineRenderer3D0.getWallPaint();
        double double5 = lineRenderer3D0.getYOffset();
        lineRenderer3D0.setYOffset((double) 4);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean11 = stackedBarRenderer3D9.isSeriesVisibleInLegend(11);
        java.awt.Stroke stroke12 = stackedBarRenderer3D9.getBaseStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setRangeCrosshairValue((double) (byte) 100, false);
        stackedBarRenderer3D9.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot13);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot18.getRangeMarkers(3, layer20);
        java.util.List list22 = categoryPlot18.getAnnotations();
        categoryPlot18.clearRangeAxes();
        boolean boolean24 = categoryPlot13.equals((java.lang.Object) categoryPlot18);
        categoryPlot13.configureDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double28 = dateAxis27.getFixedDimension();
        double double29 = dateAxis27.getLowerBound();
        java.awt.Paint paint30 = dateAxis27.getTickLabelPaint();
        dateAxis27.setVerticalTickLabels(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = categoryPlot33.getRangeMarkers(3, layer35);
        java.util.List list37 = categoryPlot33.getAnnotations();
        java.awt.Paint paint38 = categoryPlot33.getOutlinePaint();
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke41 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint40, stroke41);
        java.awt.Paint paint43 = valueMarker42.getLabelPaint();
        categoryPlot33.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker42);
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str47 = textTitle46.getText();
        java.awt.Font font48 = textTitle46.getFont();
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str52 = textTitle51.getText();
        java.awt.geom.Rectangle2D rectangle2D53 = textTitle51.getBounds();
        textTitle46.draw(graphics2D49, rectangle2D53);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer55 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer55);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = legendTitle56.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean61 = rectangleAnchor57.equals((java.lang.Object) simpleTimePeriod60);
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D53, rectangleAnchor57, 4.0d, (double) 100L);
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str67 = textTitle66.getText();
        java.awt.Font font68 = textTitle66.getFont();
        java.awt.Graphics2D graphics2D69 = null;
        org.jfree.chart.title.TextTitle textTitle71 = new org.jfree.chart.title.TextTitle("");
        java.lang.String str72 = textTitle71.getText();
        java.awt.geom.Rectangle2D rectangle2D73 = textTitle71.getBounds();
        textTitle66.draw(graphics2D69, rectangle2D73);
        boolean boolean75 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D53, rectangle2D73);
        lineRenderer3D0.drawRangeMarker(graphics2D8, categoryPlot13, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.chart.plot.Marker) valueMarker42, rectangle2D73);
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = dateAxis27.getLabelInsets();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "" + "'", str67.equals(""));
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "" + "'", str72.equals(""));
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(rectangleInsets77);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EXPAND" + "'", str1.equals("EXPAND"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setCircular(false);
        piePlot3D1.setIgnoreZeroValues(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        piePlot3D1.notifyListeners(plotChangeEvent6);
        piePlot3D1.setOutlineVisible(true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) -1, paint1, stroke2);
        java.awt.Paint paint4 = valueMarker3.getLabelPaint();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int6 = color5.getTransparency();
        valueMarker3.setLabelPaint((java.awt.Paint) color5);
        valueMarker3.setAlpha(0.0f);
        double double10 = valueMarker3.getValue();
        double double11 = valueMarker3.getValue();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean6 = rectangleAnchor2.equals((java.lang.Object) simpleTimePeriod5);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType8 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor7, categoryLabelWidthType8, (float) (-6553600));
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer11 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) ganttRenderer11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendTitle12.getLegendItemGraphicLocation();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 'a');
        boolean boolean17 = rectangleAnchor13.equals((java.lang.Object) simpleTimePeriod16);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType19 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor13, textBlockAnchor18, categoryLabelWidthType19, (float) (-6553600));
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType24 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition26 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor18, textAnchor22, 8.64E7d, categoryLabelWidthType24, 0.0f);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean29 = lineAndShapeRenderer27.equals((java.lang.Object) 12);
        java.lang.Boolean boolean31 = lineAndShapeRenderer27.getSeriesShapesVisible((-1));
        java.lang.Object obj32 = lineAndShapeRenderer27.clone();
        boolean boolean33 = textBlockAnchor18.equals(obj32);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelWidthType8);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(categoryLabelWidthType19);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(categoryLabelWidthType24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(boolean31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double2 = dateAxis1.getFixedDimension();
        java.util.Date date3 = dateAxis1.getMaximumDate();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.lang.Class<?> wildcardClass6 = stackedBarRenderer3D5.getClass();
        java.lang.Class class7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double10 = dateAxis9.getFixedDimension();
        java.util.Date date11 = dateAxis9.getMinimumDate();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date11, timeZone12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot14.getRangeMarkers(3, layer16);
        java.util.List list18 = categoryPlot14.getAnnotations();
        java.awt.Paint paint19 = categoryPlot14.getOutlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double23 = dateAxis22.getFixedDimension();
        boolean boolean24 = dateAxis22.isAutoTickUnitSelection();
        categoryPlot14.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis22, true);
        dateAxis22.setRangeAboutValue((double) 0, (double) (short) 100);
        java.util.TimeZone timeZone30 = dateAxis22.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date11, timeZone30);
        java.io.InputStream inputStream32 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleEdge.TOP", (java.lang.Class) wildcardClass6);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double35 = dateAxis34.getFixedDimension();
        java.util.Date date36 = dateAxis34.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=11.0]");
        double double39 = dateAxis38.getFixedDimension();
        boolean boolean40 = dateAxis38.isAxisLineVisible();
        java.lang.String str41 = dateAxis38.getLabelURL();
        dateAxis38.setTickMarksVisible(true);
        java.util.TimeZone timeZone44 = dateAxis38.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date36, timeZone44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date3, timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year46.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year46.previous();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNull(inputStream32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
    }
}

