import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        int int6 = week2.getWeek();
        java.util.Date date7 = week2.getStart();
        java.util.Date date8 = week2.getEnd();
        java.util.Date date9 = week2.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        java.lang.String str6 = week2.toString();
        java.util.Date date7 = week2.getEnd();
        long long8 = week2.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        java.lang.String str31 = timePeriodFormatException15.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.String str33 = timePeriodFormatException10.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray47 = timePeriodFormatException46.getSuppressed();
        timePeriodFormatException42.addSuppressed((java.lang.Throwable) timePeriodFormatException46);
        java.lang.Throwable[] throwableArray49 = timePeriodFormatException42.getSuppressed();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        java.lang.Throwable[] throwableArray51 = timePeriodFormatException42.getSuppressed();
        java.lang.Throwable[] throwableArray52 = timePeriodFormatException42.getSuppressed();
        int int53 = week2.compareTo((java.lang.Object) throwableArray52);
        long long54 = week2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 8, -1" + "'", str6.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62194924800000L) + "'", long8 == (-62194924800000L));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str33.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-62194622400001L) + "'", long54 == (-62194622400001L));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        long long11 = regularTimePeriod10.getMiddleMillisecond();
        java.util.Date date12 = regularTimePeriod10.getEnd();
        boolean boolean13 = week2.equals((java.lang.Object) regularTimePeriod10);
        long long14 = week2.getSerialIndex();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException18.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException40);
        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException40);
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        int int45 = week2.compareTo((java.lang.Object) timePeriodFormatException18);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168616000001L) + "'", long5 == (-62168616000001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62168313600001L) + "'", long6 == (-62168313600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61820251200001L) + "'", long11 == (-61820251200001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test04");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 12);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getFirstMillisecond();
//        int int5 = week2.compareTo((java.lang.Object) long4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, (int) (byte) 10);
//        java.util.Date date9 = week8.getStart();
//        int int10 = week2.compareTo((java.lang.Object) date9);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(8, (-1));
//        java.util.Date date14 = week13.getStart();
//        java.lang.Class<?> wildcardClass15 = date14.getClass();
//        int int16 = week2.compareTo((java.lang.Object) date14);
//        int int17 = week2.getYearValue();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
//    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date9 = week8.getStart();
        int int10 = week2.compareTo((java.lang.Object) date9);
        java.util.Date date11 = week2.getStart();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        java.util.Date date16 = week14.getEnd();
        java.lang.String str17 = week14.toString();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year20 = week19.getYear();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(10, year20);
        java.lang.Class<?> wildcardClass22 = week21.getClass();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long26 = week25.getFirstMillisecond();
        java.util.Date date27 = week25.getStart();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date27, timeZone28);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long33 = week32.getMiddleMillisecond();
        int int34 = week32.getWeek();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long38 = week37.getFirstMillisecond();
        java.util.Date date39 = week37.getStart();
        boolean boolean40 = week32.equals((java.lang.Object) date39);
        java.lang.Class class41 = null;
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.next();
        java.util.Date date46 = week44.getStart();
        java.lang.Class class47 = null;
        java.util.Date date48 = null;
        java.lang.Class class49 = null;
        java.util.Date date50 = null;
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date50, timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date48, timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date46, timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date39, timeZone51);
        boolean boolean56 = week14.equals((java.lang.Object) timeZone51);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date11, timeZone51);
        long long58 = week57.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168616000001L) + "'", long5 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week -1, 0" + "'", str17.equals("Week -1, 0"));
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61157692800000L) + "'", long26 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-61791825600001L) + "'", long33 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-61157692800000L) + "'", long38 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62073964800000L) + "'", long58 == (-62073964800000L));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2019, 32);
        int int3 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date3 = week2.getEnd();
        java.lang.Class class4 = null;
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date3, timeZone6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException12.getSuppressed();
        int int15 = week8.compareTo((java.lang.Object) throwableArray14);
        java.lang.Object obj16 = null;
        boolean boolean17 = week8.equals(obj16);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str17 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException40);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException48.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        java.lang.Throwable[] throwableArray54 = timePeriodFormatException40.getSuppressed();
        java.lang.Throwable[] throwableArray55 = timePeriodFormatException40.getSuppressed();
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException40);
        java.lang.Throwable[] throwableArray57 = timePeriodFormatException30.getSuppressed();
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray54);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertNotNull(throwableArray57);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        java.lang.String str6 = week2.toString();
        java.util.Date date7 = week2.getEnd();
        long long8 = week2.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        java.lang.String str31 = timePeriodFormatException15.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.String str33 = timePeriodFormatException10.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray47 = timePeriodFormatException46.getSuppressed();
        timePeriodFormatException42.addSuppressed((java.lang.Throwable) timePeriodFormatException46);
        java.lang.Throwable[] throwableArray49 = timePeriodFormatException42.getSuppressed();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        java.lang.Throwable[] throwableArray51 = timePeriodFormatException42.getSuppressed();
        java.lang.Throwable[] throwableArray52 = timePeriodFormatException42.getSuppressed();
        int int53 = week2.compareTo((java.lang.Object) throwableArray52);
        java.util.Calendar calendar54 = null;
        try {
            long long55 = week2.getLastMillisecond(calendar54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 8, -1" + "'", str6.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62194924800000L) + "'", long8 == (-62194924800000L));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str33.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
    }

//    @Test
//    public void test11() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test11");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        long long5 = week3.getMiddleMillisecond();
//        int int6 = week3.getYearValue();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) ' ', year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 10, year7);
//        java.util.Date date11 = week10.getStart();
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date11);
//    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(8, (-1));
        java.util.Date date8 = week7.getStart();
        java.lang.Class<?> wildcardClass9 = date8.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        boolean boolean11 = week2.equals((java.lang.Object) class10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.Object obj15 = null;
        boolean boolean16 = week14.equals(obj15);
        int int17 = week14.getYearValue();
        java.util.Date date18 = week14.getStart();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.previous();
        long long23 = week21.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass24 = week21.getClass();
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date29 = week28.getEnd();
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date29, timeZone30);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.next();
        int int36 = week34.getWeek();
        long long37 = week34.getLastMillisecond();
        java.util.Date date38 = week34.getStart();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date38);
        int int40 = week39.getWeek();
        java.util.Date date41 = week39.getEnd();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.next();
        java.lang.Class<?> wildcardClass46 = regularTimePeriod45.getClass();
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week49.next();
        java.util.Date date51 = week49.getEnd();
        java.lang.Class class52 = null;
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week55.next();
        java.util.Date date57 = week55.getStart();
        java.lang.Class class58 = null;
        java.util.Date date59 = null;
        java.lang.Class class60 = null;
        java.util.Date date61 = null;
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class60, date61, timeZone62);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date59, timeZone62);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date57, timeZone62);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date51, timeZone62);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date41, timeZone62);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date18, timeZone62);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 32 + "'", int17 == 32);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62194622400001L) + "'", long23 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-62168313600001L) + "'", long37 == (-62168313600001L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 51 + "'", int40 == 51);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNull(regularTimePeriod68);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        java.lang.Object obj5 = null;
        int int6 = week2.compareTo(obj5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, 53);
        long long10 = week9.getFirstMillisecond();
        long long11 = week9.getSerialIndex();
        boolean boolean12 = week2.equals((java.lang.Object) week9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week2.previous();
        try {
            org.jfree.data.time.Year year14 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (32) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 1, 32" + "'", str3.equals("Week 1, 32"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-60495436800000L) + "'", long10 == (-60495436800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2809L + "'", long11 == 2809L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        long long8 = week7.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62073662400001L) + "'", long8 == (-62073662400001L));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

//    @Test
//    public void test16() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test16");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(53, year2);
//        long long4 = week3.getSerialIndex();
//        int int5 = week3.getWeek();
//        java.util.Date date6 = week3.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        java.lang.Class<?> wildcardClass11 = regularTimePeriod10.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(0, (int) (byte) 0);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year18 = week17.getYear();
//        long long19 = week17.getMiddleMillisecond();
//        int int20 = week17.getYearValue();
//        org.jfree.data.time.Year year21 = week17.getYear();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (short) -1, year21);
//        int int23 = week15.compareTo((java.lang.Object) (short) -1);
//        int int24 = week15.getWeek();
//        java.util.Date date25 = week15.getStart();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) -1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
//        java.lang.Class<?> wildcardClass30 = regularTimePeriod29.getClass();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.next();
//        java.util.Date date35 = week33.getEnd();
//        java.lang.Class class36 = null;
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
//        java.util.Date date41 = week39.getStart();
//        java.lang.Class class42 = null;
//        java.util.Date date43 = null;
//        java.lang.Class class44 = null;
//        java.util.Date date45 = null;
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date43, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date41, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date35, timeZone46);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) (short) -1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week53.next();
//        java.lang.Class<?> wildcardClass55 = regularTimePeriod54.getClass();
//        java.util.Date date56 = regularTimePeriod54.getStart();
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = week59.next();
//        java.util.Date date61 = week59.getEnd();
//        java.lang.Class class62 = null;
//        java.util.Date date63 = null;
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date63, timeZone64);
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date61, timeZone64);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date56, timeZone64);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date25, timeZone64);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date6, timeZone64);
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(100, (int) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = week72.next();
//        boolean boolean74 = week69.equals((java.lang.Object) regularTimePeriod73);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107060L + "'", long4 == 107060L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 53 + "'", int5 == 53);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560365999999L + "'", long19 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        long long11 = regularTimePeriod10.getMiddleMillisecond();
        java.util.Date date12 = regularTimePeriod10.getEnd();
        boolean boolean13 = week2.equals((java.lang.Object) regularTimePeriod10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.next();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = week2.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168616000001L) + "'", long5 == (-62168616000001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62168313600001L) + "'", long6 == (-62168313600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61820251200001L) + "'", long11 == (-61820251200001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 53);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getLastMillisecond();
        long long6 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-60495436800000L) + "'", long3 == (-60495436800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60494832000001L) + "'", long5 == (-60494832000001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-60494832000001L) + "'", long6 == (-60494832000001L));
    }

//    @Test
//    public void test19() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test19");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        long long5 = week3.getMiddleMillisecond();
//        int int6 = week3.getYearValue();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) -1, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (byte) 0, year7);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//    }

//    @Test
//    public void test20() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test20");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) 0);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getMiddleMillisecond();
//        int int7 = week4.getYearValue();
//        org.jfree.data.time.Year year8 = week4.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, year8);
//        int int10 = week2.compareTo((java.lang.Object) (short) -1);
//        int int11 = week2.getWeek();
//        java.util.Date date12 = week2.getStart();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.next();
//        java.util.Date date18 = week16.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.lang.Class class21 = null;
//        java.util.Date date22 = null;
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date18, timeZone23);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date12, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.next();
//        int int29 = week27.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week27.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week27.next();
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//    }

//    @Test
//    public void test21() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test21");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) 0);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getMiddleMillisecond();
//        int int7 = week4.getYearValue();
//        org.jfree.data.time.Year year8 = week4.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, year8);
//        int int10 = week2.compareTo((java.lang.Object) (short) -1);
//        int int11 = week2.getWeek();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
//        java.util.Date date16 = week14.getStart();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
//        java.util.Date date18 = week17.getStart();
//        boolean boolean19 = week2.equals((java.lang.Object) date18);
//        java.util.Calendar calendar20 = null;
//        try {
//            week2.peg(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

//    @Test
//    public void test22() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test22");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getMiddleMillisecond();
//        int int3 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(8, (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        long long8 = week6.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        java.util.Date date10 = week6.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week6.next();
//        try {
//            int int12 = week0.compareTo((java.lang.Object) regularTimePeriod11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62194622400001L) + "'", long8 == (-62194622400001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test24() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test24");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getMiddleMillisecond();
//        int int3 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(8, (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        long long8 = week6.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) -1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
//        int int15 = week13.getWeek();
//        long long16 = week13.getLastMillisecond();
//        int int17 = week13.getWeek();
//        java.util.Date date18 = week13.getStart();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) -1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.next();
//        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.next();
//        java.util.Date date28 = week26.getEnd();
//        java.lang.Class class29 = null;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.next();
//        java.util.Date date34 = week32.getStart();
//        java.lang.Class class35 = null;
//        java.util.Date date36 = null;
//        java.lang.Class class37 = null;
//        java.util.Date date38 = null;
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date38, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date34, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date28, timeZone39);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) -1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.next();
//        java.lang.Class<?> wildcardClass48 = regularTimePeriod47.getClass();
//        java.util.Date date49 = regularTimePeriod47.getStart();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week52.next();
//        java.util.Date date54 = week52.getEnd();
//        java.lang.Class class55 = null;
//        java.util.Date date56 = null;
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date56, timeZone57);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date54, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date49, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date18, timeZone57);
//        boolean boolean62 = week0.equals((java.lang.Object) wildcardClass9);
//        java.lang.Class class63 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = week66.next();
//        java.util.Date date68 = week66.getStart();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date68);
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date68);
//        java.util.TimeZone timeZone71 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date68, timeZone71);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62194622400001L) + "'", long8 == (-62194622400001L));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62168313600001L) + "'", long16 == (-62168313600001L));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(class63);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNull(regularTimePeriod72);
//    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 0);
        int int3 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

//    @Test
//    public void test26() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test26");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getMiddleMillisecond();
//        int int3 = week0.getWeek();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getLastMillisecond();
//        long long6 = week0.getSerialIndex();
//        int int7 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        java.lang.String str5 = week2.toString();
        try {
            org.jfree.data.time.Year year6 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week -1, 0" + "'", str5.equals("Week -1, 0"));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.lang.Class<?> wildcardClass9 = regularTimePeriod8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
        java.util.Date date14 = week12.getEnd();
        java.lang.Class class15 = null;
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
        java.util.Date date20 = week18.getStart();
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone25);
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone34);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date14, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week37.previous();
        boolean boolean40 = week2.equals((java.lang.Object) regularTimePeriod39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week2.next();
        java.util.Calendar calendar42 = null;
        try {
            long long43 = regularTimePeriod41.getMiddleMillisecond(calendar42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        int int11 = week9.getWeek();
        long long12 = week9.getLastMillisecond();
        java.util.Date date13 = week9.getStart();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
        int int15 = week14.getWeek();
        java.util.Date date16 = week14.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        java.lang.Class<?> wildcardClass39 = timePeriodFormatException36.getClass();
        java.lang.Throwable[] throwableArray40 = timePeriodFormatException36.getSuppressed();
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        java.lang.Class<?> wildcardClass42 = timePeriodFormatException36.getClass();
        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass42);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.next();
        java.util.Date date48 = week46.getEnd();
        java.lang.Class class49 = null;
        java.util.Date date50 = null;
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date50, timeZone51);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date48, timeZone51);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date48);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = week57.next();
        java.util.Date date59 = week57.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = week57.previous();
        java.lang.Class<?> wildcardClass61 = week57.getClass();
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date65 = week64.getStart();
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date65);
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long70 = week69.getSerialIndex();
        java.util.Date date71 = week69.getEnd();
        java.lang.Class class72 = null;
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = week75.next();
        java.util.Date date77 = week75.getStart();
        java.lang.Class class78 = null;
        java.util.Date date79 = null;
        java.lang.Class class80 = null;
        java.util.Date date81 = null;
        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class80, date81, timeZone82);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance(class78, date79, timeZone82);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class72, date77, timeZone82);
        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date71, timeZone82);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date65, timeZone82);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date48, timeZone82);
        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(date16, timeZone82);
        java.util.Locale locale90 = null;
        try {
            org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date6, timeZone82, locale90);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62168313600001L) + "'", long12 == (-62168313600001L));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 51 + "'", int15 == 51);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(class43);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 630L + "'", long70 == 630L);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNull(regularTimePeriod83);
        org.junit.Assert.assertNull(regularTimePeriod84);
        org.junit.Assert.assertNull(regularTimePeriod85);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertNull(regularTimePeriod88);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year6 = week5.getYear();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(53, year6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(0, year6);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 0, year6);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(12, year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
        org.jfree.data.time.Year year12 = week10.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) ' ', year12);
        long long14 = week13.getLastMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        java.lang.Class<?> wildcardClass26 = timePeriodFormatException23.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException39.addSuppressed((java.lang.Throwable) timePeriodFormatException41);
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException45.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException52 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException50.addSuppressed((java.lang.Throwable) timePeriodFormatException52);
        timePeriodFormatException47.addSuppressed((java.lang.Throwable) timePeriodFormatException52);
        timePeriodFormatException39.addSuppressed((java.lang.Throwable) timePeriodFormatException52);
        java.lang.Throwable[] throwableArray56 = timePeriodFormatException39.getSuppressed();
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        boolean boolean58 = week13.equals((java.lang.Object) timePeriodFormatException39);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1565506799999L + "'", long14 == 1565506799999L);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException19.getSuppressed();
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException36.addSuppressed((java.lang.Throwable) timePeriodFormatException38);
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        java.lang.String str41 = timePeriodFormatException25.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException48.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray55 = timePeriodFormatException54.getSuppressed();
        timePeriodFormatException50.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        java.lang.String str59 = timePeriodFormatException19.toString();
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str41.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str59.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test32() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test32");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getMiddleMillisecond();
//        int int3 = week0.getWeek();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getLastMillisecond();
//        long long6 = week0.getSerialIndex();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        java.util.Date date11 = week9.getEnd();
//        java.lang.String str12 = week9.toString();
//        long long13 = week9.getFirstMillisecond();
//        try {
//            int int14 = week0.compareTo((java.lang.Object) week9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week -1, 0" + "'", str12.equals("Week -1, 0"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62168918400000L) + "'", long13 == (-62168918400000L));
//    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 1, 32");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        java.lang.Throwable[] throwableArray28 = timePeriodFormatException20.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.junit.Assert.assertNotNull(throwableArray28);
    }

//    @Test
//    public void test35() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test35");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        long long4 = week2.getMiddleMillisecond();
//        int int5 = week2.getYearValue();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(51, year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(8, year6);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, 35);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (35) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        java.lang.String str6 = week2.toString();
        java.lang.String str7 = week2.toString();
        int int8 = week2.getYearValue();
        int int9 = week2.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week -1, 0" + "'", str6.equals("Week -1, 0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week -1, 0" + "'", str7.equals("Week -1, 0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(53, year7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year7);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (byte) 0, year7);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(12, year7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
        org.jfree.data.time.Year year13 = week11.getYear();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) ' ', year13);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 100, year13);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        long long6 = week2.getMiddleMillisecond();
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
        java.util.Date date12 = week10.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week10.previous();
        java.lang.Class<?> wildcardClass14 = week10.getClass();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date18 = week17.getStart();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date18);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long23 = week22.getSerialIndex();
        java.util.Date date24 = week22.getEnd();
        java.lang.Class class25 = null;
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
        java.util.Date date30 = week28.getStart();
        java.lang.Class class31 = null;
        java.util.Date date32 = null;
        java.lang.Class class33 = null;
        java.util.Date date34 = null;
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date30, timeZone35);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date24, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date18, timeZone35);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date7, timeZone35);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62168616000001L) + "'", long6 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 630L + "'", long23 == 630L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.lang.Class<?> wildcardClass9 = regularTimePeriod8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
        java.util.Date date14 = week12.getEnd();
        java.lang.Class class15 = null;
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
        java.util.Date date20 = week18.getStart();
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone25);
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone34);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date14, timeZone34);
        int int38 = week2.compareTo((java.lang.Object) date14);
        int int39 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week2.previous();
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long44 = week43.getFirstMillisecond();
        long long45 = week43.getLastMillisecond();
        long long46 = week43.getMiddleMillisecond();
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date50 = week49.getStart();
        int int51 = week43.compareTo((java.lang.Object) date50);
        java.util.Date date52 = week43.getStart();
        long long53 = week43.getFirstMillisecond();
        long long54 = week43.getLastMillisecond();
        int int55 = week2.compareTo((java.lang.Object) long54);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException57 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException59 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException57.addSuppressed((java.lang.Throwable) timePeriodFormatException59);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException62 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException64 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException62.addSuppressed((java.lang.Throwable) timePeriodFormatException64);
        timePeriodFormatException57.addSuppressed((java.lang.Throwable) timePeriodFormatException64);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException68 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException70 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException68.addSuppressed((java.lang.Throwable) timePeriodFormatException70);
        timePeriodFormatException57.addSuppressed((java.lang.Throwable) timePeriodFormatException68);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException74 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException76 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException74.addSuppressed((java.lang.Throwable) timePeriodFormatException76);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException79 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException81 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException79.addSuppressed((java.lang.Throwable) timePeriodFormatException81);
        timePeriodFormatException76.addSuppressed((java.lang.Throwable) timePeriodFormatException81);
        timePeriodFormatException68.addSuppressed((java.lang.Throwable) timePeriodFormatException81);
        boolean boolean85 = week2.equals((java.lang.Object) timePeriodFormatException68);
        java.lang.Throwable[] throwableArray86 = timePeriodFormatException68.getSuppressed();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-62168918400000L) + "'", long44 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-62168313600001L) + "'", long45 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-62168616000001L) + "'", long46 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-62168918400000L) + "'", long53 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-62168313600001L) + "'", long54 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(throwableArray86);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (short) 1);
        long long3 = week2.getSerialIndex();
        java.lang.String str4 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.lang.Object obj6 = null;
        boolean boolean7 = week2.equals(obj6);
        try {
            org.jfree.data.time.Year year8 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 54L + "'", long3 == 54L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 1, 1" + "'", str4.equals("Week 1, 1"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException21.getSuppressed();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.junit.Assert.assertNotNull(throwableArray23);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getMiddleMillisecond();
        int int4 = week2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61791825600001L) + "'", long3 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

//    @Test
//    public void test44() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test44");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, 7);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        long long7 = week5.getMiddleMillisecond();
//        int int8 = week5.getYearValue();
//        org.jfree.data.time.Year year9 = week5.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(7, year9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(100, year9);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(53, year14);
//        long long16 = week15.getSerialIndex();
//        boolean boolean17 = week11.equals((java.lang.Object) week15);
//        int int18 = week2.compareTo((java.lang.Object) week11);
//        long long19 = week11.getSerialIndex();
//        int int20 = week11.getWeek();
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107060L + "'", long16 == 107060L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-2012) + "'", int18 == (-2012));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 107107L + "'", long19 == 107107L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: Week 1, 32");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, (int) (short) -1);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (short) 10);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 12);
        long long3 = week2.getLastMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61789104000001L) + "'", long3 == (-61789104000001L));
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        long long6 = week5.getSerialIndex();
        long long7 = week5.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 565L + "'", long6 == 565L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61830835200001L) + "'", long7 == (-61830835200001L));
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        java.lang.String str6 = week2.toString();
        java.util.Date date7 = week2.getEnd();
        long long8 = week2.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        java.lang.String str31 = timePeriodFormatException15.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.String str33 = timePeriodFormatException10.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray47 = timePeriodFormatException46.getSuppressed();
        timePeriodFormatException42.addSuppressed((java.lang.Throwable) timePeriodFormatException46);
        java.lang.Throwable[] throwableArray49 = timePeriodFormatException42.getSuppressed();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        java.lang.Throwable[] throwableArray51 = timePeriodFormatException42.getSuppressed();
        java.lang.Throwable[] throwableArray52 = timePeriodFormatException42.getSuppressed();
        int int53 = week2.compareTo((java.lang.Object) throwableArray52);
        java.util.Calendar calendar54 = null;
        try {
            week2.peg(calendar54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 8, -1" + "'", str6.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62194924800000L) + "'", long8 == (-62194924800000L));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str33.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        java.lang.Class<?> wildcardClass5 = regularTimePeriod4.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
        java.util.Date date10 = week8.getEnd();
        java.lang.Class class11 = null;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        java.util.Date date16 = week14.getStart();
        java.lang.Class class17 = null;
        java.util.Date date18 = null;
        java.lang.Class class19 = null;
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date16, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone21);
        java.lang.Class<?> wildcardClass26 = date10.getClass();
        java.lang.Class class27 = null;
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date31 = week30.getEnd();
        java.lang.Class class32 = null;
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.next();
        java.util.Date date37 = week35.getStart();
        java.lang.Class class38 = null;
        java.util.Date date39 = null;
        java.lang.Class class40 = null;
        java.util.Date date41 = null;
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date41, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date39, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date37, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date31, timeZone42);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date10, timeZone42);
        java.util.Locale locale48 = null;
        try {
            org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date0, timeZone42, locale48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNull(regularTimePeriod46);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        long long7 = week2.getSerialIndex();
        long long8 = week2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 565L + "'", long7 == 565L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61831137600001L) + "'", long8 == (-61831137600001L));
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        int int8 = week7.getWeek();
        long long9 = week7.getMiddleMillisecond();
        long long10 = week7.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 51 + "'", int8 == 51);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62073662400001L) + "'", long9 == (-62073662400001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62073662400001L) + "'", long10 == (-62073662400001L));
    }

//    @Test
//    public void test54() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test54");
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getMiddleMillisecond();
//        int int7 = week4.getYearValue();
//        org.jfree.data.time.Year year8 = week4.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(7, year8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(100, year8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', year8);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(32, year8);
//        long long13 = week12.getSerialIndex();
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107039L + "'", long13 == 107039L);
//    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        long long6 = week2.getMiddleMillisecond();
        java.lang.String str7 = week2.toString();
        java.lang.String str8 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62168616000001L) + "'", long6 == (-62168616000001L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week -1, 0" + "'", str7.equals("Week -1, 0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week -1, 0" + "'", str8.equals("Week -1, 0"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date10 = week9.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
        java.util.TimeZone timeZone14 = null;
        java.util.Locale locale15 = null;
        try {
            org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date10, timeZone14, locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getStart();
        java.lang.String str7 = week2.toString();
        int int8 = week2.getYearValue();
        java.util.Date date9 = week2.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.lang.Class class12 = null;
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone14);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date9, timeZone14);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week -1, 0" + "'", str7.equals("Week -1, 0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

//    @Test
//    public void test58() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test58");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        long long3 = week1.getMiddleMillisecond();
//        int int4 = week1.getYearValue();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(7, year5);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week6.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test59");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        long long10 = week8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.previous();
        java.util.Date date12 = week8.getEnd();
        boolean boolean13 = week2.equals((java.lang.Object) week8);
        java.lang.String str14 = week2.toString();
        long long15 = week2.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62194622400001L) + "'", long10 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 8, -1" + "'", str14.equals("Week 8, -1"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-45L) + "'", long15 == (-45L));
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test60");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date10 = week9.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(class16);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test61");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date3 = week2.getEnd();
        java.lang.Class class4 = null;
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date3, timeZone6);
        long long9 = week8.getLastMillisecond();
        java.util.Date date10 = week8.getStart();
        java.util.TimeZone timeZone11 = null;
        java.util.Locale locale12 = null;
        try {
            org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10, timeZone11, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61157088000001L) + "'", long9 == (-61157088000001L));
        org.junit.Assert.assertNotNull(date10);
    }

//    @Test
//    public void test62() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test62");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) 0);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getMiddleMillisecond();
//        int int7 = week4.getYearValue();
//        org.jfree.data.time.Year year8 = week4.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, year8);
//        int int10 = week2.compareTo((java.lang.Object) (short) -1);
//        int int11 = week2.getWeek();
//        java.util.Date date12 = week2.getStart();
//        try {
//            org.jfree.data.time.Year year13 = week2.getYear();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(date12);
//    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test63");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) 0);
        java.lang.Object obj3 = null;
        int int4 = week2.compareTo(obj3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test64");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        long long9 = regularTimePeriod8.getMiddleMillisecond();
        java.util.Date date10 = regularTimePeriod8.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getEnd();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date15, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone18);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date10);
        java.lang.Class class23 = null;
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date27 = week26.getEnd();
        java.lang.Class class28 = null;
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.next();
        java.util.Date date33 = week31.getStart();
        java.lang.Class class34 = null;
        java.util.Date date35 = null;
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date35, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date33, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date27, timeZone38);
        java.util.Locale locale43 = null;
        try {
            org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date10, timeZone38, locale43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61820251200001L) + "'", long9 == (-61820251200001L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNull(regularTimePeriod42);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test65");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        long long11 = regularTimePeriod10.getMiddleMillisecond();
        java.util.Date date12 = regularTimePeriod10.getEnd();
        boolean boolean13 = week2.equals((java.lang.Object) regularTimePeriod10);
        long long14 = week2.getSerialIndex();
        java.lang.String str15 = week2.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168616000001L) + "'", long5 == (-62168616000001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62168313600001L) + "'", long6 == (-62168313600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61820251200001L) + "'", long11 == (-61820251200001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week -1, 0" + "'", str15.equals("Week -1, 0"));
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test66");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getStart();
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test67");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        java.lang.String str6 = week2.toString();
        java.util.Date date7 = week2.getEnd();
        long long8 = week2.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        java.lang.String str31 = timePeriodFormatException15.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.String str33 = timePeriodFormatException10.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray47 = timePeriodFormatException46.getSuppressed();
        timePeriodFormatException42.addSuppressed((java.lang.Throwable) timePeriodFormatException46);
        java.lang.Throwable[] throwableArray49 = timePeriodFormatException42.getSuppressed();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        java.lang.Throwable[] throwableArray51 = timePeriodFormatException42.getSuppressed();
        java.lang.Throwable[] throwableArray52 = timePeriodFormatException42.getSuppressed();
        int int53 = week2.compareTo((java.lang.Object) throwableArray52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 8, -1" + "'", str6.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62194924800000L) + "'", long8 == (-62194924800000L));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str33.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test68");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 100, 2019");
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test69");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date9 = week8.getStart();
        int int10 = week2.compareTo((java.lang.Object) date9);
        java.util.Date date11 = week2.getStart();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        java.util.Date date16 = week14.getEnd();
        java.lang.String str17 = week14.toString();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year20 = week19.getYear();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(10, year20);
        java.lang.Class<?> wildcardClass22 = week21.getClass();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long26 = week25.getFirstMillisecond();
        java.util.Date date27 = week25.getStart();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date27, timeZone28);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long33 = week32.getMiddleMillisecond();
        int int34 = week32.getWeek();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long38 = week37.getFirstMillisecond();
        java.util.Date date39 = week37.getStart();
        boolean boolean40 = week32.equals((java.lang.Object) date39);
        java.lang.Class class41 = null;
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.next();
        java.util.Date date46 = week44.getStart();
        java.lang.Class class47 = null;
        java.util.Date date48 = null;
        java.lang.Class class49 = null;
        java.util.Date date50 = null;
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date50, timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date48, timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date46, timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date39, timeZone51);
        boolean boolean56 = week14.equals((java.lang.Object) timeZone51);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date11, timeZone51);
        int int58 = week57.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168616000001L) + "'", long5 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week -1, 0" + "'", str17.equals("Week -1, 0"));
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61157692800000L) + "'", long26 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-61791825600001L) + "'", long33 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-61157692800000L) + "'", long38 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2 + "'", int58 == 2);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test70");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        int int6 = week2.getWeek();
        java.util.Date date7 = week2.getStart();
        java.util.Date date8 = week2.getEnd();
        java.util.Calendar calendar9 = null;
        try {
            week2.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test71");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException3.getSuppressed();
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException3.getClass();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        long long12 = week10.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week10.previous();
        java.util.Date date14 = week10.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week10.next();
        int int16 = week10.getYearValue();
        java.util.Date date17 = week10.getStart();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.previous();
        long long23 = week21.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass24 = week21.getClass();
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
        int int30 = week28.getWeek();
        long long31 = week28.getLastMillisecond();
        int int32 = week28.getWeek();
        java.util.Date date33 = week28.getStart();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week36.next();
        java.lang.Class<?> wildcardClass38 = regularTimePeriod37.getClass();
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
        java.util.Date date43 = week41.getEnd();
        java.lang.Class class44 = null;
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week47.next();
        java.util.Date date49 = week47.getStart();
        java.lang.Class class50 = null;
        java.util.Date date51 = null;
        java.lang.Class class52 = null;
        java.util.Date date53 = null;
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date53, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date51, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date49, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date43, timeZone54);
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = week61.next();
        java.lang.Class<?> wildcardClass63 = regularTimePeriod62.getClass();
        java.util.Date date64 = regularTimePeriod62.getStart();
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week67.next();
        java.util.Date date69 = week67.getEnd();
        java.lang.Class class70 = null;
        java.util.Date date71 = null;
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance(class70, date71, timeZone72);
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date69, timeZone72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date64, timeZone72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date33, timeZone72);
        java.lang.Class<?> wildcardClass77 = timeZone72.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date17, timeZone72);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62194622400001L) + "'", long12 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62194622400001L) + "'", long23 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-62168313600001L) + "'", long31 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNull(regularTimePeriod78);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test72");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test73");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test74");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 0);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test75");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(53, year2);
        long long4 = week3.getSerialIndex();
        java.lang.Object obj5 = null;
        boolean boolean6 = week3.equals(obj5);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107060L + "'", long4 == 107060L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test76");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62194320000001L) + "'", long3 == (-62194320000001L));
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test77");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getMiddleMillisecond();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61791825600001L) + "'", long3 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test78");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        int int9 = week7.getWeek();
        long long10 = week7.getLastMillisecond();
        java.util.Date date11 = week7.getStart();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        java.lang.Class<?> wildcardClass16 = regularTimePeriod15.getClass();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
        java.util.Date date21 = week19.getEnd();
        java.lang.Class class22 = null;
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.next();
        java.util.Date date27 = week25.getStart();
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date27, timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date11, timeZone32);
        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize(class38);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62168313600001L) + "'", long10 == (-62168313600001L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertNotNull(class39);
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test79");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(35, 2);
    }

//    @Test
//    public void test80() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test80");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        long long4 = week2.getMiddleMillisecond();
//        int int5 = week2.getYearValue();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) ' ', year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(0, year6);
//        java.lang.String str9 = week8.toString();
//        java.util.Date date10 = week8.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
//        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
//        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
//        java.lang.Class<?> wildcardClass33 = timePeriodFormatException30.getClass();
//        java.lang.Throwable[] throwableArray34 = timePeriodFormatException30.getSuppressed();
//        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
//        java.lang.Class<?> wildcardClass36 = timePeriodFormatException30.getClass();
//        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.next();
//        java.util.Date date42 = week40.getEnd();
//        java.lang.Class class43 = null;
//        java.util.Date date44 = null;
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date44, timeZone45);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date42, timeZone45);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date42);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week51.next();
//        java.util.Date date53 = week51.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week51.previous();
//        java.lang.Class<?> wildcardClass55 = week51.getClass();
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(100, (int) (byte) 10);
//        java.util.Date date59 = week58.getStart();
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date59);
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(100, (int) (byte) 10);
//        long long64 = week63.getSerialIndex();
//        java.util.Date date65 = week63.getEnd();
//        java.lang.Class class66 = null;
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = week69.next();
//        java.util.Date date71 = week69.getStart();
//        java.lang.Class class72 = null;
//        java.util.Date date73 = null;
//        java.lang.Class class74 = null;
//        java.util.Date date75 = null;
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class74, date75, timeZone76);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class72, date73, timeZone76);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date71, timeZone76);
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date65, timeZone76);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date59, timeZone76);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date42, timeZone76);
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date10, timeZone76);
//        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
//        java.util.Date date87 = week86.getEnd();
//        java.lang.Class class88 = null;
//        java.util.Date date89 = null;
//        java.util.TimeZone timeZone90 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance(class88, date89, timeZone90);
//        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(date87, timeZone90);
//        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date10, timeZone90);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 0, 2019" + "'", str9.equals("Week 0, 2019"));
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(throwableArray34);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 630L + "'", long64 == 630L);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//        org.junit.Assert.assertNull(regularTimePeriod78);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(date87);
//        org.junit.Assert.assertNotNull(timeZone90);
//        org.junit.Assert.assertNull(regularTimePeriod91);
//    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test81");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) ' ', 6);
        int int3 = week2.getYearValue();
        long long4 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61959052800001L) + "'", long4 == (-61959052800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test82");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getLastMillisecond();
        int int5 = week2.getWeek();
        int int6 = week2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61830835200001L) + "'", long4 == (-61830835200001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test83() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test83");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        java.util.Date date3 = week2.getStart();
        java.lang.Class<?> wildcardClass4 = date3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        long long10 = week8.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass11 = week8.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long16 = week15.getFirstMillisecond();
        long long17 = week15.getLastMillisecond();
        java.util.Date date18 = week15.getStart();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.next();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.next();
        java.util.Date date28 = week26.getEnd();
        java.lang.Class class29 = null;
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.next();
        java.util.Date date34 = week32.getStart();
        java.lang.Class class35 = null;
        java.util.Date date36 = null;
        java.lang.Class class37 = null;
        java.util.Date date38 = null;
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date38, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date34, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date28, timeZone39);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.next();
        java.lang.Class<?> wildcardClass48 = regularTimePeriod47.getClass();
        java.util.Date date49 = regularTimePeriod47.getStart();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week52.next();
        java.util.Date date54 = week52.getEnd();
        java.lang.Class class55 = null;
        java.util.Date date56 = null;
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date56, timeZone57);
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date54, timeZone57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date49, timeZone57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date18, timeZone57);
        java.util.TimeZone timeZone62 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date18, timeZone62);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62194622400001L) + "'", long10 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62168918400000L) + "'", long16 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62168313600001L) + "'", long17 == (-62168313600001L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNull(regularTimePeriod63);
    }

    @Test
    public void test84() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test84");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 2019);
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546156799999L + "'", long3 == 1546156799999L);
    }

    @Test
    public void test85() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test85");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        int int8 = week2.getWeek();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(1, (int) (short) 1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        java.lang.Class<?> wildcardClass34 = timePeriodFormatException31.getClass();
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException31.getSuppressed();
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        int int37 = week11.compareTo((java.lang.Object) timePeriodFormatException31);
        java.lang.String str38 = week11.toString();
        try {
            int int39 = week2.compareTo((java.lang.Object) week11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Week 1, 1" + "'", str38.equals("Week 1, 1"));
    }

    @Test
    public void test86() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test86");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getSerialIndex();
        int int4 = week2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 630L + "'", long3 == 630L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test87() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test87");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        int int6 = week5.getYearValue();
        long long7 = week5.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException11.getSuppressed();
        boolean boolean20 = week5.equals((java.lang.Object) timePeriodFormatException11);
        long long21 = week5.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61831137600001L) + "'", long7 == (-61831137600001L));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61830835200001L) + "'", long21 == (-61830835200001L));
    }

    @Test
    public void test88() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test88");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getStart();
        java.lang.String str7 = week2.toString();
        long long8 = week2.getLastMillisecond();
        long long9 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        long long14 = week12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week12.previous();
        java.util.Date date16 = week12.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week12.next();
        int int18 = week12.getWeek();
        try {
            int int19 = week2.compareTo((java.lang.Object) week12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week -1, 0" + "'", str7.equals("Week -1, 0"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62168313600001L) + "'", long8 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62168918400000L) + "'", long9 == (-62168918400000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62194622400001L) + "'", long14 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
    }

    @Test
    public void test89() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test89");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61792128000000L) + "'", long5 == (-61792128000000L));
    }

    @Test
    public void test90() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test90");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str17 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException40);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException48.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        java.lang.Throwable[] throwableArray54 = timePeriodFormatException40.getSuppressed();
        java.lang.Throwable[] throwableArray55 = timePeriodFormatException40.getSuppressed();
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException40);
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = week59.next();
        java.util.Date date61 = week59.getStart();
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date61);
        int int63 = week62.getYearValue();
        long long64 = week62.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException66 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException68 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException66.addSuppressed((java.lang.Throwable) timePeriodFormatException68);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException71 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException73 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException71.addSuppressed((java.lang.Throwable) timePeriodFormatException73);
        timePeriodFormatException68.addSuppressed((java.lang.Throwable) timePeriodFormatException73);
        java.lang.Throwable[] throwableArray76 = timePeriodFormatException68.getSuppressed();
        boolean boolean77 = week62.equals((java.lang.Object) timePeriodFormatException68);
        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException68);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray54);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-61831137600001L) + "'", long64 == (-61831137600001L));
        org.junit.Assert.assertNotNull(throwableArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }
}

