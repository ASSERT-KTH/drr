import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Week week1 = new org.jfree.data.time.Week(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.Week.LAST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = week0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61791825600001L) + "'", long3 == (-61791825600001L));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.Week.FIRST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test033");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            week0.peg(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        boolean boolean5 = week2.equals((java.lang.Object) (short) 1);
        try {
            org.jfree.data.time.Year year6 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 1, 32");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = week0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (short) 1);
        int int3 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        int int6 = week2.getWeek();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            week0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone29);
        java.util.Locale locale32 = null;
        try {
            org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date9, timeZone29, locale32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod31);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = week0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 630L + "'", long3 == 630L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = regularTimePeriod5.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test046");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getMiddleMillisecond();
//        int int3 = week0.getYearValue();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getMiddleMillisecond();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(year4);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = regularTimePeriod3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.next();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        java.util.Date date30 = regularTimePeriod28.getStart();
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.next();
        java.util.Date date35 = week33.getEnd();
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date35, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date30, timeZone38);
        long long42 = regularTimePeriod41.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-62073057600001L) + "'", long42 == (-62073057600001L));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (short) 1);
        java.lang.String str3 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 1, 1" + "'", str3.equals("Week 1, 1"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (byte) 10);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = week2.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62194320000001L) + "'", long6 == (-62194320000001L));
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getMiddleMillisecond();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        int int5 = week0.getWeek();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getMiddleMillisecond();
        long long4 = week2.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61791825600001L) + "'", long3 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 630L + "'", long4 == 630L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 35, 10");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 2);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.String str3 = week2.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 1, 32" + "'", str3.equals("Week 1, 32"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        long long3 = week1.getMiddleMillisecond();
//        int int4 = week1.getYearValue();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) -1, year5);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week6.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (short) 1);
        java.util.Date date3 = week2.getStart();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date3 = week2.getEnd();
        java.lang.Class class4 = null;
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date3, timeZone6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException12.getSuppressed();
        int int15 = week8.compareTo((java.lang.Object) throwableArray14);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = week8.getMiddleMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable throwable11 = null;
        try {
            timePeriodFormatException8.addSuppressed(throwable11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getMiddleMillisecond();
        int int4 = week2.getWeek();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61791825600001L) + "'", long3 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week -1, 0");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (short) 1);
        long long3 = week2.getSerialIndex();
        java.lang.String str4 = week2.toString();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 54L + "'", long3 == 54L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 1, 1" + "'", str4.equals("Week 1, 1"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 1, 1");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class<?> wildcardClass5 = date4.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        java.lang.String str5 = week2.toString();
        try {
            org.jfree.data.time.Year year6 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week -1, 0" + "'", str5.equals("Week -1, 0"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 12);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61789104000001L) + "'", long3 == (-61789104000001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61789406400001L) + "'", long4 == (-61789406400001L));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 8, -1");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (short) 1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.lang.Class<?> wildcardClass9 = regularTimePeriod8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
        java.util.Date date14 = week12.getEnd();
        java.lang.Class class15 = null;
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
        java.util.Date date20 = week18.getStart();
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone25);
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone34);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date14, timeZone34);
        int int38 = week2.compareTo((java.lang.Object) date14);
        try {
            org.jfree.data.time.Year year39 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (32) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getMiddleMillisecond();
        long long4 = week2.getSerialIndex();
        try {
            org.jfree.data.time.Year year5 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61791825600001L) + "'", long3 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 630L + "'", long4 == 630L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61830835200001L) + "'", long4 == (-61830835200001L));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone29);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date9, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(1, (int) (short) 1);
        java.util.Date date37 = week36.getStart();
        try {
            int int38 = week32.compareTo((java.lang.Object) week36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date37);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException6.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone29);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date9, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.next();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week36.next();
        java.lang.Class<?> wildcardClass38 = regularTimePeriod37.getClass();
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
        java.util.Date date43 = week41.getEnd();
        java.lang.Class class44 = null;
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week47.next();
        java.util.Date date49 = week47.getStart();
        java.lang.Class class50 = null;
        java.util.Date date51 = null;
        java.lang.Class class52 = null;
        java.util.Date date53 = null;
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date53, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date51, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date49, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date43, timeZone54);
        boolean boolean59 = week32.equals((java.lang.Object) timeZone54);
        java.util.Calendar calendar60 = null;
        try {
            week32.peg(calendar60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        int int5 = week2.getYearValue();
        java.util.Date date6 = week2.getEnd();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.lang.String str4 = week2.toString();
        long long5 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 1, 32" + "'", str4.equals("Week 1, 32"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61157692800000L) + "'", long5 == (-61157692800000L));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        java.util.Date date3 = week2.getStart();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getMiddleMillisecond();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61791825600001L) + "'", long3 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 630L + "'", long4 == 630L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61831137600001L) + "'", long4 == (-61831137600001L));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.String str18 = timePeriodFormatException8.toString();
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        int int6 = week5.getYearValue();
        long long7 = week5.getMiddleMillisecond();
        java.util.Date date8 = week5.getStart();
        java.util.Calendar calendar9 = null;
        try {
            week5.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61831137600001L) + "'", long7 == (-61831137600001L));
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getSerialIndex();
        java.lang.Object obj5 = null;
        boolean boolean6 = week2.equals(obj5);
        try {
            org.jfree.data.time.Year year7 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (32) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1697L + "'", long4 == 1697L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        long long5 = regularTimePeriod3.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168011200001L) + "'", long5 == (-62168011200001L));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1697L + "'", long4 == 1697L);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        long long4 = week2.getMiddleMillisecond();
//        int int5 = week2.getYearValue();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(7, year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(5, year6);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date10 = week9.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone11);
        try {
            java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.lang.String str4 = week2.toString();
        boolean boolean6 = week2.equals((java.lang.Object) 7);
        long long7 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 1, 32" + "'", str4.equals("Week 1, 32"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61157088000001L) + "'", long7 == (-61157088000001L));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 12);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week -1, 2");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        int int6 = week2.getWeek();
        java.util.Date date7 = week2.getStart();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getMiddleMillisecond();
        long long4 = week2.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61791825600001L) + "'", long3 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61792128000000L) + "'", long4 == (-61792128000000L));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        long long8 = week6.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass9 = week6.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        int int15 = week13.getWeek();
        long long16 = week13.getLastMillisecond();
        int int17 = week13.getWeek();
        java.util.Date date18 = week13.getStart();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.next();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.next();
        java.util.Date date28 = week26.getEnd();
        java.lang.Class class29 = null;
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.next();
        java.util.Date date34 = week32.getStart();
        java.lang.Class class35 = null;
        java.util.Date date36 = null;
        java.lang.Class class37 = null;
        java.util.Date date38 = null;
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date38, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date34, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date28, timeZone39);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.next();
        java.lang.Class<?> wildcardClass48 = regularTimePeriod47.getClass();
        java.util.Date date49 = regularTimePeriod47.getStart();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week52.next();
        java.util.Date date54 = week52.getEnd();
        java.lang.Class class55 = null;
        java.util.Date date56 = null;
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date56, timeZone57);
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date54, timeZone57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date49, timeZone57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date18, timeZone57);
        java.util.Locale locale62 = null;
        try {
            org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date3, timeZone57, locale62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62194622400001L) + "'", long8 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62168313600001L) + "'", long16 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        int int6 = week2.getWeek();
        java.util.Calendar calendar7 = null;
        try {
            week2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getStart();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        long long7 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long11 = week10.getFirstMillisecond();
        long long12 = week10.getSerialIndex();
        java.lang.Object obj13 = null;
        boolean boolean14 = week10.equals(obj13);
        try {
            int int15 = week2.compareTo((java.lang.Object) week10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (32) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61831440000000L) + "'", long7 == (-61831440000000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61157692800000L) + "'", long11 == (-61157692800000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1697L + "'", long12 == 1697L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        java.lang.String str5 = week2.toString();
        java.util.Date date6 = week2.getEnd();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week -1, 0" + "'", str5.equals("Week -1, 0"));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getLastMillisecond();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        try {
            int int9 = week2.compareTo((java.lang.Object) week7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61791523200001L) + "'", long4 == (-61791523200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        long long10 = week8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.previous();
        java.util.Date date12 = week8.getEnd();
        boolean boolean13 = week2.equals((java.lang.Object) week8);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = week8.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62194622400001L) + "'", long10 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        int int6 = week5.getYearValue();
        long long7 = week5.getMiddleMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week5.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61831137600001L) + "'", long7 == (-61831137600001L));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (4) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        try {
            org.jfree.data.time.Year year5 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        int int6 = week5.getYearValue();
        long long7 = week5.getMiddleMillisecond();
        java.util.Date date8 = week5.getStart();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.next();
        long long18 = regularTimePeriod17.getMiddleMillisecond();
        java.util.Date date19 = regularTimePeriod17.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
        java.util.Date date24 = week22.getEnd();
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date24, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date19, timeZone27);
        java.util.Locale locale31 = null;
        try {
            org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date8, timeZone27, locale31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61831137600001L) + "'", long7 == (-61831137600001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61820251200001L) + "'", long18 == (-61820251200001L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date3 = week2.getEnd();
        java.lang.Class class4 = null;
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date3, timeZone6);
        int int9 = week8.getYearValue();
        int int10 = week8.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException12.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 0, 0" + "'", str3.equals("Week 0, 0"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62167708800001L) + "'", long4 == (-62167708800001L));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone29);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date9, timeZone29);
        java.lang.Class class33 = null;
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date37 = week36.getEnd();
        java.lang.Class class38 = null;
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
        java.util.Date date43 = week41.getStart();
        java.lang.Class class44 = null;
        java.util.Date date45 = null;
        java.lang.Class class46 = null;
        java.util.Date date47 = null;
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date47, timeZone48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date43, timeZone48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date37, timeZone48);
        java.util.Locale locale53 = null;
        try {
            org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date9, timeZone48, locale53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNull(regularTimePeriod52);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        long long7 = regularTimePeriod6.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62194017600001L) + "'", long7 == (-62194017600001L));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date3 = week2.getEnd();
        java.lang.Class class4 = null;
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date3, timeZone6);
        int int9 = week8.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        int int5 = week2.getYearValue();
        int int6 = week2.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Calendar calendar5 = null;
        try {
            week4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date3 = week2.getStart();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168616000001L) + "'", long5 == (-62168616000001L));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 2);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getMiddleMillisecond();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        long long9 = week7.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass10 = week7.getClass();
        int int11 = week2.compareTo((java.lang.Object) wildcardClass10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        java.lang.Class<?> wildcardClass16 = regularTimePeriod15.getClass();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
        java.util.Date date21 = week19.getEnd();
        java.lang.Class class22 = null;
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.next();
        java.util.Date date27 = week25.getStart();
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date27, timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone32);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date21);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date21);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
        java.lang.Class<?> wildcardClass43 = regularTimePeriod42.getClass();
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.next();
        java.util.Date date48 = week46.getEnd();
        java.lang.Class class49 = null;
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week52.next();
        java.util.Date date54 = week52.getStart();
        java.lang.Class class55 = null;
        java.util.Date date56 = null;
        java.lang.Class class57 = null;
        java.util.Date date58 = null;
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date58, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date56, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date54, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date48, timeZone59);
        java.lang.Class class64 = null;
        java.util.Date date65 = null;
        java.lang.Class class66 = null;
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date65, timeZone68);
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date48, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = week71.next();
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = week75.next();
        java.lang.Class<?> wildcardClass77 = regularTimePeriod76.getClass();
        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = week80.next();
        java.util.Date date82 = week80.getEnd();
        java.lang.Class class83 = null;
        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = week86.next();
        java.util.Date date88 = week86.getStart();
        java.lang.Class class89 = null;
        java.util.Date date90 = null;
        java.lang.Class class91 = null;
        java.util.Date date92 = null;
        java.util.TimeZone timeZone93 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance(class91, date92, timeZone93);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance(class89, date90, timeZone93);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance(class83, date88, timeZone93);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date82, timeZone93);
        boolean boolean98 = week71.equals((java.lang.Object) timeZone93);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod99 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date21, timeZone93);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61791825600001L) + "'", long3 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62194622400001L) + "'", long9 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(timeZone93);
        org.junit.Assert.assertNull(regularTimePeriod94);
        org.junit.Assert.assertNull(regularTimePeriod95);
        org.junit.Assert.assertNull(regularTimePeriod96);
        org.junit.Assert.assertNotNull(regularTimePeriod97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod99);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        int int8 = week2.getWeek();
        int int9 = week2.getWeek();
        int int11 = week2.compareTo((java.lang.Object) 100);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date3 = week2.getEnd();
        java.lang.Class class4 = null;
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date3, timeZone6);
        int int9 = week8.getYearValue();
        java.lang.Class<?> wildcardClass10 = week8.getClass();
        java.util.Calendar calendar11 = null;
        try {
            week8.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 2);
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week -1, 2" + "'", str3.equals("Week -1, 2"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getLastMillisecond();
        int int5 = week2.getWeek();
        java.lang.String str6 = week2.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61830835200001L) + "'", long4 == (-61830835200001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 35, 10" + "'", str6.equals("Week 35, 10"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        try {
            org.jfree.data.time.Year year8 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
        long long10 = regularTimePeriod9.getMiddleMillisecond();
        boolean boolean11 = week5.equals((java.lang.Object) regularTimePeriod9);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = week5.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61820251200001L) + "'", long10 == (-61820251200001L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        java.util.Date date4 = year2.getStart();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (short) 1);
        long long3 = week2.getSerialIndex();
        java.lang.String str4 = week2.toString();
        try {
            org.jfree.data.time.Year year5 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 54L + "'", long3 == 54L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 1, 1" + "'", str4.equals("Week 1, 1"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        long long5 = week3.getMiddleMillisecond();
//        int int6 = week3.getYearValue();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(7, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', year7);
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week10.getFirstMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getMiddleMillisecond();
//        int int3 = week0.getYearValue();
//        long long4 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getEnd();
        long long7 = week2.getFirstMillisecond();
        java.lang.String str8 = week2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62194924800000L) + "'", long7 == (-62194924800000L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 8, -1" + "'", str8.equals("Week 8, -1"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone29);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date9, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week32.previous();
        java.lang.Object obj35 = null;
        int int36 = week32.compareTo(obj35);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        java.util.Date date5 = week2.getStart();
        java.lang.Class class6 = null;
        java.util.Date date7 = null;
        java.lang.Class class8 = null;
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date9, timeZone10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone10);
        java.util.Locale locale13 = null;
        try {
            org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date5, timeZone10, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) 0);
        int int3 = week2.getYearValue();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        java.util.Date date3 = week2.getStart();
        java.lang.Class<?> wildcardClass4 = date3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.lang.Class<?> wildcardClass9 = regularTimePeriod8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
        java.util.Date date14 = week12.getEnd();
        java.lang.Class class15 = null;
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
        java.util.Date date20 = week18.getStart();
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone25);
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone34);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date14, timeZone34);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date14);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
        java.lang.Class<?> wildcardClass43 = regularTimePeriod42.getClass();
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.next();
        java.util.Date date48 = week46.getEnd();
        java.lang.Class class49 = null;
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week52.next();
        java.util.Date date54 = week52.getStart();
        java.lang.Class class55 = null;
        java.util.Date date56 = null;
        java.lang.Class class57 = null;
        java.util.Date date58 = null;
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date58, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date56, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date54, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date48, timeZone59);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = week66.next();
        java.lang.Class<?> wildcardClass68 = regularTimePeriod67.getClass();
        java.util.Date date69 = regularTimePeriod67.getStart();
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = week72.next();
        java.util.Date date74 = week72.getEnd();
        java.lang.Class class75 = null;
        java.util.Date date76 = null;
        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class75, date76, timeZone77);
        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date74, timeZone77);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date69, timeZone77);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date14, timeZone77);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertNull(regularTimePeriod81);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Class<?> wildcardClass14 = timePeriodFormatException11.getClass();
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str17 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (short) 1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException19.getSuppressed();
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException41.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        java.lang.Throwable[] throwableArray45 = timePeriodFormatException43.getSuppressed();
        timePeriodFormatException37.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray45);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        long long10 = week8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.previous();
        java.util.Date date12 = week8.getEnd();
        boolean boolean13 = week2.equals((java.lang.Object) week8);
        long long14 = week8.getFirstMillisecond();
        java.lang.String str15 = week8.toString();
        long long16 = week8.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62194622400001L) + "'", long10 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62194924800000L) + "'", long14 == (-62194924800000L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 8, -1" + "'", str15.equals("Week 8, -1"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62194320000001L) + "'", long16 == (-62194320000001L));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getMiddleMillisecond();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        long long9 = week7.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass10 = week7.getClass();
        int int11 = week2.compareTo((java.lang.Object) wildcardClass10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        java.util.Date date16 = week14.getStart();
        java.util.Date date17 = week14.getStart();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date17, timeZone18);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date17);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61791825600001L) + "'", long3 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62194622400001L) + "'", long9 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getMiddleMillisecond();
//        int int3 = week0.getWeek();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 12);
        java.lang.String str3 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 0, 12" + "'", str3.equals("Week 0, 12"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        int int7 = week2.getYearValue();
        java.lang.String str8 = week2.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168616000001L) + "'", long5 == (-62168616000001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62168313600001L) + "'", long6 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week -1, 0" + "'", str8.equals("Week -1, 0"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        int int7 = week2.getYearValue();
        int int8 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168616000001L) + "'", long5 == (-62168616000001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62168313600001L) + "'", long6 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        java.lang.String str6 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        java.lang.String str3 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 35, 10" + "'", str3.equals("Week 35, 10"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(53, year2);
        long long4 = week3.getSerialIndex();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.lang.Class<?> wildcardClass9 = regularTimePeriod8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
        java.util.Date date14 = week12.getEnd();
        java.lang.Class class15 = null;
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
        java.util.Date date20 = week18.getStart();
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone25);
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone34);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date14, timeZone34);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date14);
        try {
            int int39 = week3.compareTo((java.lang.Object) week38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107060L + "'", long4 == 107060L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod36);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        int int6 = week2.getWeek();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61791523200001L) + "'", long4 == (-61791523200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getMiddleMillisecond();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getFirstMillisecond();
        boolean boolean7 = week2.equals((java.lang.Object) 100L);
        long long8 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61791825600001L) + "'", long3 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 630L + "'", long4 == 630L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61792128000000L) + "'", long5 == (-61792128000000L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61792128000000L) + "'", long8 == (-61792128000000L));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week -1, 0");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.Class<?> wildcardClass16 = timePeriodFormatException13.getClass();
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException13.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        try {
            org.jfree.data.time.Year year10 = week9.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getMiddleMillisecond();
        int int4 = week2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61791825600001L) + "'", long3 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        int int5 = week2.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        long long11 = regularTimePeriod10.getMiddleMillisecond();
        java.util.Date date12 = regularTimePeriod10.getEnd();
        boolean boolean13 = week2.equals((java.lang.Object) regularTimePeriod10);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = regularTimePeriod10.getMiddleMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168616000001L) + "'", long5 == (-62168616000001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62168313600001L) + "'", long6 == (-62168313600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61820251200001L) + "'", long11 == (-61820251200001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 12);
        long long3 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61789406400001L) + "'", long3 == (-61789406400001L));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        java.lang.String str5 = week2.toString();
        java.util.Date date6 = week2.getStart();
        long long7 = week2.getLastMillisecond();
        long long8 = week2.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week -1, 0" + "'", str5.equals("Week -1, 0"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62168313600001L) + "'", long7 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getMiddleMillisecond();
//        int int3 = week0.getWeek();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getLastMillisecond();
        int int5 = week2.getWeek();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61791523200001L) + "'", long4 == (-61791523200001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        int int5 = week2.getWeek();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date9);
        try {
            org.jfree.data.time.Year year27 = week26.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        java.util.Date date5 = week3.getStart();
        java.lang.Class class6 = null;
        java.util.Date date7 = null;
        java.lang.Class class8 = null;
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date9, timeZone10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone10);
        java.util.TimeZone timeZone14 = null;
        java.util.Locale locale15 = null;
        try {
            org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date5, timeZone14, locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException3.getSuppressed();
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException3.getClass();
        java.lang.String str8 = timePeriodFormatException3.toString();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str17 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException46.addSuppressed((java.lang.Throwable) timePeriodFormatException48);
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException46);
        java.lang.String str51 = timePeriodFormatException35.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException53 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException55 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException53.addSuppressed((java.lang.Throwable) timePeriodFormatException55);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException58 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException60 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException58.addSuppressed((java.lang.Throwable) timePeriodFormatException60);
        timePeriodFormatException53.addSuppressed((java.lang.Throwable) timePeriodFormatException60);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException64 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray65 = timePeriodFormatException64.getSuppressed();
        timePeriodFormatException60.addSuppressed((java.lang.Throwable) timePeriodFormatException64);
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException64);
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str51.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray65);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 53);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getSerialIndex();
        try {
            org.jfree.data.time.Year year5 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (53) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-60495436800000L) + "'", long3 == (-60495436800000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2809L + "'", long4 == 2809L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 1, 32");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        int int6 = week5.getYearValue();
        long long7 = week5.getMiddleMillisecond();
        java.util.Date date8 = week5.getStart();
        java.lang.String str9 = week5.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61831137600001L) + "'", long7 == (-61831137600001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 35, 10" + "'", str9.equals("Week 35, 10"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        long long5 = week2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61831440000000L) + "'", long5 == (-61831440000000L));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.Date date6 = week5.getStart();
        java.util.Date date7 = week5.getEnd();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week5.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date9 = week8.getStart();
        int int10 = week2.compareTo((java.lang.Object) date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week2.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168616000001L) + "'", long5 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getLastMillisecond();
        int int5 = week2.getWeek();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61830835200001L) + "'", long4 == (-61830835200001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        java.lang.Class<?> wildcardClass5 = regularTimePeriod4.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
        java.util.Date date10 = week8.getEnd();
        java.lang.Class class11 = null;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        java.util.Date date16 = week14.getStart();
        java.lang.Class class17 = null;
        java.util.Date date18 = null;
        java.lang.Class class19 = null;
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date16, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone21);
        java.lang.Class class26 = null;
        java.util.Date date27 = null;
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date27, timeZone30);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date10, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.next();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.next();
        java.lang.Class<?> wildcardClass39 = regularTimePeriod38.getClass();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.next();
        java.util.Date date44 = week42.getEnd();
        java.lang.Class class45 = null;
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.next();
        java.util.Date date50 = week48.getStart();
        java.lang.Class class51 = null;
        java.util.Date date52 = null;
        java.lang.Class class53 = null;
        java.util.Date date54 = null;
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date54, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date52, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date50, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date44, timeZone55);
        boolean boolean60 = week33.equals((java.lang.Object) timeZone55);
        java.util.Locale locale61 = null;
        try {
            org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date0, timeZone55, locale61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        int int6 = week2.getWeek();
        java.util.Date date7 = week2.getStart();
        java.util.Date date8 = week2.getEnd();
        long long9 = week2.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62168313600001L) + "'", long9 == (-62168313600001L));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        java.util.Date date5 = week2.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        java.lang.String str6 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 35, 10");
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(8, (-1));
        java.util.Date date14 = week13.getStart();
        java.lang.Class<?> wildcardClass15 = date14.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        java.util.Date date17 = null;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.previous();
        long long22 = week20.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass23 = week20.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date28 = week27.getEnd();
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date28, timeZone29);
        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.next();
        java.lang.Class<?> wildcardClass36 = regularTimePeriod35.getClass();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
        java.util.Date date41 = week39.getEnd();
        java.lang.Class class42 = null;
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.next();
        java.util.Date date47 = week45.getStart();
        java.lang.Class class48 = null;
        java.util.Date date49 = null;
        java.lang.Class class50 = null;
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date51, timeZone52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date49, timeZone52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date47, timeZone52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date41, timeZone52);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date41);
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date41);
        java.lang.Class class59 = null;
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = week62.next();
        java.util.Date date64 = week62.getStart();
        java.lang.Class class65 = null;
        java.util.Date date66 = null;
        java.lang.Class class67 = null;
        java.util.Date date68 = null;
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class67, date68, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date66, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date64, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date41, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date17, timeZone69);
        java.util.Locale locale75 = null;
        try {
            org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date4, timeZone69, locale75);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62194622400001L) + "'", long22 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNull(regularTimePeriod74);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        long long9 = regularTimePeriod8.getMiddleMillisecond();
        java.util.Date date10 = regularTimePeriod8.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getEnd();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date15, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone18);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long25 = week24.getFirstMillisecond();
        long long26 = week24.getLastMillisecond();
        long long27 = week24.getMiddleMillisecond();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date31 = week30.getStart();
        int int32 = week24.compareTo((java.lang.Object) date31);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
        long long37 = week35.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass38 = week35.getClass();
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.next();
        int int44 = week42.getWeek();
        long long45 = week42.getLastMillisecond();
        int int46 = week42.getWeek();
        java.util.Date date47 = week42.getStart();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = week50.next();
        java.lang.Class<?> wildcardClass52 = regularTimePeriod51.getClass();
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week55.next();
        java.util.Date date57 = week55.getEnd();
        java.lang.Class class58 = null;
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = week61.next();
        java.util.Date date63 = week61.getStart();
        java.lang.Class class64 = null;
        java.util.Date date65 = null;
        java.lang.Class class66 = null;
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date65, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date63, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date57, timeZone68);
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = week75.next();
        java.lang.Class<?> wildcardClass77 = regularTimePeriod76.getClass();
        java.util.Date date78 = regularTimePeriod76.getStart();
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = week81.next();
        java.util.Date date83 = week81.getEnd();
        java.lang.Class class84 = null;
        java.util.Date date85 = null;
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class84, date85, timeZone86);
        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date83, timeZone86);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date78, timeZone86);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date47, timeZone86);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date31, timeZone86);
        java.util.Calendar calendar92 = null;
        try {
            long long93 = regularTimePeriod91.getMiddleMillisecond(calendar92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61820251200001L) + "'", long9 == (-61820251200001L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-62168918400000L) + "'", long25 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-62168313600001L) + "'", long26 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62168616000001L) + "'", long27 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-62194622400001L) + "'", long37 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-62168313600001L) + "'", long45 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNull(regularTimePeriod87);
        org.junit.Assert.assertNotNull(regularTimePeriod89);
        org.junit.Assert.assertNotNull(regularTimePeriod90);
        org.junit.Assert.assertNotNull(regularTimePeriod91);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        long long4 = week2.getMiddleMillisecond();
//        int int5 = week2.getYearValue();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(7, year6);
//        int int9 = week8.getWeek();
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Class<?> wildcardClass14 = timePeriodFormatException11.getClass();
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException11.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable throwable17 = null;
        try {
            timePeriodFormatException11.addSuppressed(throwable17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone29);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date9, timeZone29);
        java.lang.String str33 = week32.toString();
        long long34 = week32.getFirstMillisecond();
        java.util.Calendar calendar35 = null;
        try {
            long long36 = week32.getMiddleMillisecond(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Week 35, 10" + "'", str33.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-61831440000000L) + "'", long34 == (-61831440000000L));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.Date date6 = week5.getStart();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        java.lang.Class<?> wildcardClass11 = regularTimePeriod10.getClass();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        java.util.Date date16 = week14.getEnd();
        java.lang.Class class17 = null;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.next();
        java.util.Date date22 = week20.getStart();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date22, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date16, timeZone27);
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.lang.Class class34 = null;
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date35, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone36);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date16, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week43.next();
        java.lang.Class<?> wildcardClass45 = regularTimePeriod44.getClass();
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.next();
        java.util.Date date50 = week48.getEnd();
        java.lang.Class class51 = null;
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.next();
        java.util.Date date56 = week54.getStart();
        java.lang.Class class57 = null;
        java.util.Date date58 = null;
        java.lang.Class class59 = null;
        java.util.Date date60 = null;
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date60, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date58, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date56, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date50, timeZone61);
        boolean boolean66 = week39.equals((java.lang.Object) timeZone61);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date6, timeZone61);
        long long68 = week67.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 565L + "'", long68 == 565L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.lang.Class<?> wildcardClass9 = regularTimePeriod8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
        java.util.Date date14 = week12.getEnd();
        java.lang.Class class15 = null;
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
        java.util.Date date20 = week18.getStart();
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone25);
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone34);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date14, timeZone34);
        int int38 = week2.compareTo((java.lang.Object) date14);
        java.util.Calendar calendar39 = null;
        try {
            long long40 = week2.getFirstMillisecond(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getEnd();
        long long7 = week2.getFirstMillisecond();
        try {
            org.jfree.data.time.Year year8 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62194924800000L) + "'", long7 == (-62194924800000L));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getMiddleMillisecond();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getFirstMillisecond();
        int int6 = week2.getYearValue();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61791825600001L) + "'", long3 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 630L + "'", long4 == 630L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61792128000000L) + "'", long5 == (-61792128000000L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(53, year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(4, year4);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException3.getSuppressed();
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException3.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        int int8 = week7.getWeek();
        java.util.Date date9 = week7.getEnd();
        int int10 = week7.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 51 + "'", int8 == 51);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 51 + "'", int10 == 51);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date3 = week2.getEnd();
        java.lang.Class class4 = null;
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date3, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        long long10 = week8.getLastMillisecond();
        long long11 = week8.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61157088000001L) + "'", long10 == (-61157088000001L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61157088000001L) + "'", long11 == (-61157088000001L));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        long long7 = week2.getFirstMillisecond();
        int int8 = week2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62194924800000L) + "'", long7 == (-62194924800000L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        long long10 = week8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.previous();
        java.util.Date date12 = week8.getEnd();
        boolean boolean13 = week2.equals((java.lang.Object) week8);
        long long14 = week8.getMiddleMillisecond();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = week8.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62194622400001L) + "'", long10 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62194622400001L) + "'", long14 == (-62194622400001L));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, 35);
        int int3 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date9);
        long long27 = week26.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 565L + "'", long27 == 565L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        long long10 = week8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.previous();
        java.util.Date date12 = week8.getEnd();
        boolean boolean13 = week2.equals((java.lang.Object) week8);
        long long14 = week8.getFirstMillisecond();
        java.util.Calendar calendar15 = null;
        try {
            week8.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62194622400001L) + "'", long10 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62194924800000L) + "'", long14 == (-62194924800000L));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        int int11 = week9.getWeek();
        long long12 = week9.getLastMillisecond();
        int int13 = week9.getWeek();
        java.util.Date date14 = week9.getStart();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
        java.util.Date date24 = week22.getEnd();
        java.lang.Class class25 = null;
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
        java.util.Date date30 = week28.getStart();
        java.lang.Class class31 = null;
        java.util.Date date32 = null;
        java.lang.Class class33 = null;
        java.util.Date date34 = null;
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date30, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date24, timeZone35);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.next();
        java.lang.Class<?> wildcardClass44 = regularTimePeriod43.getClass();
        java.util.Date date45 = regularTimePeriod43.getStart();
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.next();
        java.util.Date date50 = week48.getEnd();
        java.lang.Class class51 = null;
        java.util.Date date52 = null;
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date52, timeZone53);
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date50, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date45, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date14, timeZone53);
        java.lang.Class<?> wildcardClass58 = date14.getClass();
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = week61.next();
        java.util.Date date63 = week61.getEnd();
        java.lang.Class class64 = null;
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date68 = week67.getEnd();
        java.lang.Class class69 = null;
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = week72.next();
        java.util.Date date74 = week72.getStart();
        java.lang.Class class75 = null;
        java.util.Date date76 = null;
        java.lang.Class class77 = null;
        java.util.Date date78 = null;
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class77, date78, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class75, date76, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class69, date74, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date68, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date63, timeZone79);
        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = week87.previous();
        long long89 = week87.getMiddleMillisecond();
        java.lang.String str90 = week87.toString();
        java.lang.String str91 = week87.toString();
        java.util.Date date92 = week87.getEnd();
        java.util.TimeZone timeZone93 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date92, timeZone93);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62168313600001L) + "'", long12 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNull(regularTimePeriod81);
        org.junit.Assert.assertNull(regularTimePeriod82);
        org.junit.Assert.assertNull(regularTimePeriod83);
        org.junit.Assert.assertNull(regularTimePeriod84);
        org.junit.Assert.assertNotNull(regularTimePeriod88);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + (-62194622400001L) + "'", long89 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "Week 8, -1" + "'", str90.equals("Week 8, -1"));
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "Week 8, -1" + "'", str91.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(date92);
        org.junit.Assert.assertNull(regularTimePeriod94);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.lang.String str4 = week2.toString();
        boolean boolean6 = week2.equals((java.lang.Object) 7);
        int int7 = week2.getWeek();
        long long8 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 1, 32" + "'", str4.equals("Week 1, 32"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61157692800000L) + "'", long8 == (-61157692800000L));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Throwable throwable23 = null;
        try {
            timePeriodFormatException3.addSuppressed(throwable23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        int int3 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.Date date6 = week5.getStart();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        java.lang.Class<?> wildcardClass11 = regularTimePeriod10.getClass();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        java.util.Date date16 = week14.getEnd();
        java.lang.Class class17 = null;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.next();
        java.util.Date date22 = week20.getStart();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date22, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date16, timeZone27);
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.lang.Class class34 = null;
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date35, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone36);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date16, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week43.next();
        java.lang.Class<?> wildcardClass45 = regularTimePeriod44.getClass();
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.next();
        java.util.Date date50 = week48.getEnd();
        java.lang.Class class51 = null;
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.next();
        java.util.Date date56 = week54.getStart();
        java.lang.Class class57 = null;
        java.util.Date date58 = null;
        java.lang.Class class59 = null;
        java.util.Date date60 = null;
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date60, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date58, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date56, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date50, timeZone61);
        boolean boolean66 = week39.equals((java.lang.Object) timeZone61);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date6, timeZone61);
        java.util.Calendar calendar68 = null;
        try {
            long long69 = week67.getLastMillisecond(calendar68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        int int6 = week2.getWeek();
        java.util.Date date7 = week2.getStart();
        long long8 = week2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62168616000001L) + "'", long8 == (-62168616000001L));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.String str22 = timePeriodFormatException6.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str24 = timePeriodFormatException1.toString();
        java.lang.String str25 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getSerialIndex();
        long long4 = week2.getLastMillisecond();
        java.util.Date date5 = week2.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 630L + "'", long3 == 630L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61791523200001L) + "'", long4 == (-61791523200001L));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        int int6 = week5.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (short) 1);
        long long3 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62136259200000L) + "'", long3 == (-62136259200000L));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date9);
        java.lang.Class<?> wildcardClass26 = week25.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = week2.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        long long5 = week2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61831440000000L) + "'", long5 == (-61831440000000L));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        long long9 = regularTimePeriod8.getMiddleMillisecond();
        java.util.Date date10 = regularTimePeriod8.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getEnd();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date15, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone18);
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61820251200001L) + "'", long9 == (-61820251200001L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(class22);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        java.lang.String str29 = timePeriodFormatException12.toString();
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str29.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        long long3 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getMiddleMillisecond();
//        int int3 = week0.getWeek();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date9 = week8.getStart();
        int int10 = week2.compareTo((java.lang.Object) date9);
        java.util.Date date11 = week2.getStart();
        long long12 = week2.getFirstMillisecond();
        java.lang.Object obj13 = null;
        int int14 = week2.compareTo(obj13);
        long long15 = week2.getMiddleMillisecond();
        java.util.Calendar calendar16 = null;
        try {
            week2.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168616000001L) + "'", long5 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62168918400000L) + "'", long12 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62168616000001L) + "'", long15 == (-62168616000001L));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
        java.lang.Class<?> wildcardClass8 = regularTimePeriod7.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
        java.util.Date date13 = week11.getEnd();
        java.lang.Class class14 = null;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
        java.util.Date date19 = week17.getStart();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        java.lang.Class class22 = null;
        java.util.Date date23 = null;
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date23, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date19, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone24);
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.lang.Class class31 = null;
        java.util.Date date32 = null;
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone33);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date13, timeZone33);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date13);
        boolean boolean38 = week2.equals((java.lang.Object) week37);
        java.util.Calendar calendar39 = null;
        try {
            long long40 = week2.getFirstMillisecond(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getMiddleMillisecond();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        java.lang.String str6 = week0.toString();
//        long long7 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        java.util.Date date12 = week10.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week10.previous();
//        try {
//            int int14 = week0.compareTo((java.lang.Object) week10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 0, 12");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 0, 12" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 0, 12"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        long long10 = week8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.previous();
        java.util.Date date12 = week8.getEnd();
        boolean boolean13 = week2.equals((java.lang.Object) week8);
        long long14 = week8.getFirstMillisecond();
        long long15 = week8.getLastMillisecond();
        int int16 = week8.getYearValue();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = week8.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62194622400001L) + "'", long10 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62194924800000L) + "'", long14 == (-62194924800000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62194320000001L) + "'", long15 == (-62194320000001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        java.lang.String str5 = week2.toString();
        long long6 = week2.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            week2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week -1, 0" + "'", str5.equals("Week -1, 0"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62168313600001L) + "'", long6 == (-62168313600001L));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(10, year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(32, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(5, year4);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week7.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, (int) (short) 0);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        long long3 = week1.getMiddleMillisecond();
//        int int4 = week1.getYearValue();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) ' ', year5);
//        int int7 = week6.getWeek();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
        java.lang.Class<?> wildcardClass8 = regularTimePeriod7.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
        java.util.Date date13 = week11.getEnd();
        java.lang.Class class14 = null;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
        java.util.Date date19 = week17.getStart();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        java.lang.Class class22 = null;
        java.util.Date date23 = null;
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date23, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date19, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone24);
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.lang.Class class31 = null;
        java.util.Date date32 = null;
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone33);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date13, timeZone33);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date13);
        boolean boolean38 = week2.equals((java.lang.Object) week37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week2.previous();
        try {
            org.jfree.data.time.Year year40 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        long long9 = week7.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass10 = week7.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date15 = week14.getEnd();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date15, timeZone16);
        boolean boolean18 = week2.equals((java.lang.Object) wildcardClass10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week2.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62194622400001L) + "'", long9 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        java.util.Date date6 = week2.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) 0);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getMiddleMillisecond();
//        int int7 = week4.getYearValue();
//        org.jfree.data.time.Year year8 = week4.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, year8);
//        int int10 = week2.compareTo((java.lang.Object) (short) -1);
//        int int11 = week2.getWeek();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
//        java.util.Date date16 = week14.getStart();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
//        java.util.Date date18 = week17.getStart();
//        boolean boolean19 = week2.equals((java.lang.Object) date18);
//        long long20 = week2.getSerialIndex();
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Class<?> wildcardClass11 = timePeriodFormatException8.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        java.lang.Class<?> wildcardClass34 = timePeriodFormatException31.getClass();
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException31.getSuppressed();
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        java.lang.Class<?> wildcardClass37 = timePeriodFormatException31.getClass();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(wildcardClass37);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(10, year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(32, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(5, year4);
        java.lang.String str8 = week7.toString();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 5, 2019" + "'", str8.equals("Week 5, 2019"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = regularTimePeriod5.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61831742400001L) + "'", long6 == (-61831742400001L));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone29);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date9, timeZone29);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date9);
        long long34 = week33.getSerialIndex();
        long long35 = week33.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 565L + "'", long34 == 565L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-61830835200001L) + "'", long35 == (-61830835200001L));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, 8);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.Object obj3 = null;
        boolean boolean4 = week2.equals(obj3);
        int int5 = week2.getYearValue();
        long long6 = week2.getMiddleMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61157390400001L) + "'", long6 == (-61157390400001L));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        long long7 = week2.getFirstMillisecond();
        long long8 = week2.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61831440000000L) + "'", long7 == (-61831440000000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61830835200001L) + "'", long8 == (-61830835200001L));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        java.lang.Object obj5 = null;
        int int6 = week2.compareTo(obj5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 1, 32" + "'", str3.equals("Week 1, 32"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        long long10 = week8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.previous();
        java.util.Date date12 = week8.getEnd();
        boolean boolean13 = week2.equals((java.lang.Object) week8);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = week2.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62194622400001L) + "'", long10 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        long long9 = regularTimePeriod8.getMiddleMillisecond();
        java.util.Date date10 = regularTimePeriod8.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getEnd();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date15, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone18);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date10);
        long long23 = week22.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61820251200001L) + "'", long9 == (-61820251200001L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61819948800001L) + "'", long23 == (-61819948800001L));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getLastMillisecond();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61791523200001L) + "'", long4 == (-61791523200001L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long9 = week8.getFirstMillisecond();
        boolean boolean11 = week8.equals((java.lang.Object) (short) 1);
        int int12 = week5.compareTo((java.lang.Object) (short) 1);
        try {
            org.jfree.data.time.Year year13 = week5.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62168918400000L) + "'", long9 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        long long4 = week2.getMiddleMillisecond();
//        int int5 = week2.getYearValue();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(7, year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) -1, year6);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) 0);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getMiddleMillisecond();
//        int int7 = week4.getYearValue();
//        org.jfree.data.time.Year year8 = week4.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, year8);
//        int int10 = week2.compareTo((java.lang.Object) (short) -1);
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week2.getMiddleMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, 35);
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61031289600001L) + "'", long3 == (-61031289600001L));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getMiddleMillisecond();
//        int int3 = week0.getYearValue();
//        int int4 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = week0.getMiddleMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(8, year3);
        java.util.Date date6 = year3.getStart();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.lang.Class<?> wildcardClass9 = regularTimePeriod8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
        java.util.Date date14 = week12.getEnd();
        java.lang.Class class15 = null;
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
        java.util.Date date20 = week18.getStart();
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone25);
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone34);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date14, timeZone34);
        int int38 = week2.compareTo((java.lang.Object) date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week2.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException8.getSuppressed();
        java.lang.String str19 = timePeriodFormatException8.toString();
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        long long5 = week3.getMiddleMillisecond();
//        int int6 = week3.getYearValue();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(7, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', year7);
//        java.util.Date date11 = year7.getStart();
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date11);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException19.getSuppressed();
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException19.getSuppressed();
        java.lang.String str25 = timePeriodFormatException19.toString();
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException19.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray26);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (short) 1);
        long long3 = week2.getSerialIndex();
        java.lang.String str4 = week2.toString();
        long long5 = week2.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 54L + "'", long3 == 54L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 1, 1" + "'", str4.equals("Week 1, 1"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62136259200000L) + "'", long5 == (-62136259200000L));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        try {
            org.jfree.data.time.Year year5 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 0, 12");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.lang.String str4 = week2.toString();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 1, 32" + "'", str4.equals("Week 1, 32"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(53, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year3);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week5.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        java.lang.Class<?> wildcardClass4 = week3.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week3.next();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 5, 2019");
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getEnd();
        java.lang.String str7 = week2.toString();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 8, -1" + "'", str7.equals("Week 8, -1"));
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(0, (int) (byte) 0);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        long long12 = week10.getMiddleMillisecond();
//        int int13 = week10.getYearValue();
//        org.jfree.data.time.Year year14 = week10.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) -1, year14);
//        int int16 = week8.compareTo((java.lang.Object) (short) -1);
//        int int17 = week8.getWeek();
//        java.util.Date date18 = week8.getStart();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) -1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.next();
//        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.next();
//        java.util.Date date28 = week26.getEnd();
//        java.lang.Class class29 = null;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.next();
//        java.util.Date date34 = week32.getStart();
//        java.lang.Class class35 = null;
//        java.util.Date date36 = null;
//        java.lang.Class class37 = null;
//        java.util.Date date38 = null;
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date38, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date34, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date28, timeZone39);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) -1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.next();
//        java.lang.Class<?> wildcardClass48 = regularTimePeriod47.getClass();
//        java.util.Date date49 = regularTimePeriod47.getStart();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week52.next();
//        java.util.Date date54 = week52.getEnd();
//        java.lang.Class class55 = null;
//        java.util.Date date56 = null;
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date56, timeZone57);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date54, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date49, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date18, timeZone57);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560365999999L + "'", long12 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str17 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException40);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        java.lang.Class<?> wildcardClass48 = timePeriodFormatException45.getClass();
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        java.lang.Throwable[] throwableArray50 = timePeriodFormatException45.getSuppressed();
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(throwableArray50);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.lang.Class<?> wildcardClass9 = regularTimePeriod8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
        java.util.Date date14 = week12.getEnd();
        java.lang.Class class15 = null;
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
        java.util.Date date20 = week18.getStart();
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone25);
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone34);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date14, timeZone34);
        int int38 = week2.compareTo((java.lang.Object) date14);
        java.util.Calendar calendar39 = null;
        try {
            long long40 = week2.getLastMillisecond(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        java.lang.String str6 = week2.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 8, -1" + "'", str6.equals("Week 8, -1"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        long long9 = regularTimePeriod8.getMiddleMillisecond();
        java.util.Date date10 = regularTimePeriod8.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getEnd();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date15, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone18);
        long long22 = regularTimePeriod21.getMiddleMillisecond();
        java.util.Date date23 = regularTimePeriod21.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61820251200001L) + "'", long9 == (-61820251200001L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61820251200001L) + "'", long22 == (-61820251200001L));
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        long long6 = week2.getMiddleMillisecond();
        java.lang.String str7 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62168616000001L) + "'", long6 == (-62168616000001L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week -1, 0" + "'", str7.equals("Week -1, 0"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        int int11 = week9.getWeek();
        long long12 = week9.getLastMillisecond();
        int int13 = week9.getWeek();
        java.util.Date date14 = week9.getStart();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
        java.util.Date date24 = week22.getEnd();
        java.lang.Class class25 = null;
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
        java.util.Date date30 = week28.getStart();
        java.lang.Class class31 = null;
        java.util.Date date32 = null;
        java.lang.Class class33 = null;
        java.util.Date date34 = null;
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date30, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date24, timeZone35);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.next();
        java.lang.Class<?> wildcardClass44 = regularTimePeriod43.getClass();
        java.util.Date date45 = regularTimePeriod43.getStart();
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.next();
        java.util.Date date50 = week48.getEnd();
        java.lang.Class class51 = null;
        java.util.Date date52 = null;
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date52, timeZone53);
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date50, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date45, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date14, timeZone53);
        java.lang.Class<?> wildcardClass58 = date14.getClass();
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = week61.next();
        java.util.Date date63 = week61.getEnd();
        java.lang.Class class64 = null;
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date68 = week67.getEnd();
        java.lang.Class class69 = null;
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = week72.next();
        java.util.Date date74 = week72.getStart();
        java.lang.Class class75 = null;
        java.util.Date date76 = null;
        java.lang.Class class77 = null;
        java.util.Date date78 = null;
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class77, date78, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class75, date76, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class69, date74, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date68, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date63, timeZone79);
        java.lang.Class class85 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass58);
        java.lang.Class class86 = org.jfree.data.time.RegularTimePeriod.downsize(class85);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62168313600001L) + "'", long12 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNull(regularTimePeriod81);
        org.junit.Assert.assertNull(regularTimePeriod82);
        org.junit.Assert.assertNull(regularTimePeriod83);
        org.junit.Assert.assertNull(regularTimePeriod84);
        org.junit.Assert.assertNotNull(class85);
        org.junit.Assert.assertNotNull(class86);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getMiddleMillisecond();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        long long9 = week7.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass10 = week7.getClass();
        int int11 = week2.compareTo((java.lang.Object) wildcardClass10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long15 = week14.getFirstMillisecond();
        boolean boolean16 = week2.equals((java.lang.Object) week14);
        java.lang.String str17 = week2.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61791825600001L) + "'", long3 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62194622400001L) + "'", long9 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61157692800000L) + "'", long15 == (-61157692800000L));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 100, 10" + "'", str17.equals("Week 100, 10"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        java.util.Date date3 = week2.getStart();
        long long4 = week2.getSerialIndex();
        int int5 = week2.getWeek();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-45L) + "'", long4 == (-45L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.lang.Class<?> wildcardClass5 = week4.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long9 = week8.getFirstMillisecond();
        java.util.Date date10 = week8.getStart();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone11);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long16 = week15.getMiddleMillisecond();
        int int17 = week15.getWeek();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long21 = week20.getFirstMillisecond();
        java.util.Date date22 = week20.getStart();
        boolean boolean23 = week15.equals((java.lang.Object) date22);
        java.lang.Class class24 = null;
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.next();
        java.util.Date date29 = week27.getStart();
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date29, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date22, timeZone34);
        try {
            org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date0, timeZone34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61157692800000L) + "'", long9 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61791825600001L) + "'", long16 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61157692800000L) + "'", long21 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(53, year5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 0, year5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 1, year5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) 0);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getMiddleMillisecond();
//        int int7 = week4.getYearValue();
//        org.jfree.data.time.Year year8 = week4.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, year8);
//        int int10 = week2.compareTo((java.lang.Object) (short) -1);
//        int int11 = week2.getWeek();
//        java.util.Date date12 = week2.getStart();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(8, (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.previous();
//        long long17 = week15.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass18 = week15.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (short) -1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
//        int int24 = week22.getWeek();
//        long long25 = week22.getLastMillisecond();
//        int int26 = week22.getWeek();
//        java.util.Date date27 = week22.getStart();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) (short) -1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.next();
//        java.lang.Class<?> wildcardClass32 = regularTimePeriod31.getClass();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.next();
//        java.util.Date date37 = week35.getEnd();
//        java.lang.Class class38 = null;
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
//        java.util.Date date43 = week41.getStart();
//        java.lang.Class class44 = null;
//        java.util.Date date45 = null;
//        java.lang.Class class46 = null;
//        java.util.Date date47 = null;
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date47, timeZone48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date43, timeZone48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date37, timeZone48);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week((int) (short) -1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week55.next();
//        java.lang.Class<?> wildcardClass57 = regularTimePeriod56.getClass();
//        java.util.Date date58 = regularTimePeriod56.getStart();
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = week61.next();
//        java.util.Date date63 = week61.getEnd();
//        java.lang.Class class64 = null;
//        java.util.Date date65 = null;
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date65, timeZone66);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date63, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date58, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date27, timeZone66);
//        java.lang.Class<?> wildcardClass71 = timeZone66.getClass();
//        java.util.Locale locale72 = null;
//        try {
//            org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date12, timeZone66, locale72);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62194622400001L) + "'", long17 == (-62194622400001L));
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-62168313600001L) + "'", long25 == (-62168313600001L));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(wildcardClass71);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date3 = week2.getEnd();
        java.lang.Class class4 = null;
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date3, timeZone6);
        java.util.Date date9 = week8.getStart();
        long long10 = week8.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1697L + "'", long10 == 1697L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 8);
        long long3 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 448L + "'", long3 == 448L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date9 = week8.getStart();
        int int10 = week2.compareTo((java.lang.Object) date9);
        java.util.Date date11 = week2.getStart();
        long long12 = week2.getFirstMillisecond();
        java.lang.Object obj13 = null;
        int int14 = week2.compareTo(obj13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week2.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168616000001L) + "'", long5 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62168918400000L) + "'", long12 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        int int8 = week7.getWeek();
        java.util.Date date9 = week7.getEnd();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week7.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 51 + "'", int8 == 51);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
        java.lang.Class<?> wildcardClass8 = regularTimePeriod7.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
        java.util.Date date13 = week11.getEnd();
        java.lang.Class class14 = null;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
        java.util.Date date19 = week17.getStart();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        java.lang.Class class22 = null;
        java.util.Date date23 = null;
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date23, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date19, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone24);
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.lang.Class class31 = null;
        java.util.Date date32 = null;
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone33);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date13, timeZone33);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date13);
        boolean boolean38 = week2.equals((java.lang.Object) week37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week2.previous();
        java.util.Calendar calendar40 = null;
        try {
            long long41 = week2.getMiddleMillisecond(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone29);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date9, timeZone29);
        java.lang.String str33 = week32.toString();
        int int34 = week32.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week32.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week32.previous();
        long long37 = week32.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Week 35, 10" + "'", str33.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 35 + "'", int34 == 35);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-61831440000000L) + "'", long37 == (-61831440000000L));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        long long3 = week1.getMiddleMillisecond();
//        int int4 = week1.getYearValue();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) -1, year5);
//        java.util.Date date7 = week6.getEnd();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date3 = week2.getStart();
        java.lang.String str4 = week2.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 100, 10" + "'", str4.equals("Week 100, 10"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.lang.String str4 = week2.toString();
        boolean boolean6 = week2.equals((java.lang.Object) 7);
        int int7 = week2.getWeek();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long11 = week10.getFirstMillisecond();
        java.util.Date date12 = week10.getStart();
        boolean boolean13 = week2.equals((java.lang.Object) date12);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = week2.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 1, 32" + "'", str4.equals("Week 1, 32"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61157692800000L) + "'", long11 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.Object obj3 = null;
        boolean boolean4 = week2.equals(obj3);
        int int5 = week2.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone29);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date9, timeZone29);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date36 = week35.getEnd();
        java.lang.Class class37 = null;
        java.util.Date date38 = null;
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date38, timeZone39);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date36, timeZone39);
        int int42 = week41.getYearValue();
        java.lang.Class<?> wildcardClass43 = week41.getClass();
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long47 = week46.getFirstMillisecond();
        long long48 = week46.getLastMillisecond();
        long long49 = week46.getMiddleMillisecond();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date53 = week52.getStart();
        int int54 = week46.compareTo((java.lang.Object) date53);
        java.util.Date date55 = week46.getStart();
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = week58.next();
        java.lang.Class<?> wildcardClass60 = regularTimePeriod59.getClass();
        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = week63.next();
        java.util.Date date65 = week63.getEnd();
        java.lang.Class class66 = null;
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = week69.next();
        java.util.Date date71 = week69.getStart();
        java.lang.Class class72 = null;
        java.util.Date date73 = null;
        java.lang.Class class74 = null;
        java.util.Date date75 = null;
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class74, date75, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class72, date73, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date71, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date65, timeZone76);
        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = week83.next();
        java.lang.Class<?> wildcardClass85 = regularTimePeriod84.getClass();
        java.util.Date date86 = regularTimePeriod84.getStart();
        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = week89.next();
        java.util.Date date91 = week89.getEnd();
        java.lang.Class class92 = null;
        java.util.Date date93 = null;
        java.util.TimeZone timeZone94 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance(class92, date93, timeZone94);
        org.jfree.data.time.Week week96 = new org.jfree.data.time.Week(date91, timeZone94);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date86, timeZone94);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod98 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date55, timeZone94);
        org.jfree.data.time.Week week99 = new org.jfree.data.time.Week(date9, timeZone94);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 32 + "'", int42 == 32);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-62168918400000L) + "'", long47 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-62168313600001L) + "'", long48 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-62168616000001L) + "'", long49 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(regularTimePeriod84);
        org.junit.Assert.assertNotNull(wildcardClass85);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertNotNull(regularTimePeriod90);
        org.junit.Assert.assertNotNull(date91);
        org.junit.Assert.assertNotNull(timeZone94);
        org.junit.Assert.assertNull(regularTimePeriod95);
        org.junit.Assert.assertNotNull(regularTimePeriod97);
        org.junit.Assert.assertNotNull(regularTimePeriod98);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = week2.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(53, year5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 0, year5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 1, year5);
        long long10 = week9.getLastMillisecond();
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546761599999L + "'", long10 == 1546761599999L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        java.lang.String str5 = week2.toString();
        java.util.Date date6 = week2.getEnd();
        long long7 = week2.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week -1, 0" + "'", str5.equals("Week -1, 0"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = regularTimePeriod3.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod3.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61830532800001L) + "'", long4 == (-61830532800001L));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getMiddleMillisecond();
        long long4 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61791825600001L) + "'", long3 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61791523200001L) + "'", long4 == (-61791523200001L));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) 0);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(1, (int) (short) 1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        java.lang.Class<?> wildcardClass28 = timePeriodFormatException25.getClass();
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException25.getSuppressed();
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        int int31 = week5.compareTo((java.lang.Object) timePeriodFormatException25);
        boolean boolean32 = week2.equals((java.lang.Object) week5);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getEnd();
        long long7 = week2.getFirstMillisecond();
        int int8 = week2.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62194924800000L) + "'", long7 == (-62194924800000L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        int int11 = week9.getWeek();
        long long12 = week9.getLastMillisecond();
        int int13 = week9.getWeek();
        java.util.Date date14 = week9.getStart();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
        java.util.Date date24 = week22.getEnd();
        java.lang.Class class25 = null;
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
        java.util.Date date30 = week28.getStart();
        java.lang.Class class31 = null;
        java.util.Date date32 = null;
        java.lang.Class class33 = null;
        java.util.Date date34 = null;
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date30, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date24, timeZone35);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.next();
        java.lang.Class<?> wildcardClass44 = regularTimePeriod43.getClass();
        java.util.Date date45 = regularTimePeriod43.getStart();
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.next();
        java.util.Date date50 = week48.getEnd();
        java.lang.Class class51 = null;
        java.util.Date date52 = null;
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date52, timeZone53);
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date50, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date45, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date14, timeZone53);
        long long58 = regularTimePeriod57.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62168313600001L) + "'", long12 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62073662400001L) + "'", long58 == (-62073662400001L));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(53, year5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 0, year5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(2019, year5);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, (int) (short) 1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        int int5 = week2.getWeek();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date10 = week9.getEnd();
        java.lang.Class class11 = null;
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date10, timeZone13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException19.getSuppressed();
        int int22 = week15.compareTo((java.lang.Object) throwableArray21);
        long long23 = week15.getLastMillisecond();
        boolean boolean24 = week2.equals((java.lang.Object) week15);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61157088000001L) + "'", long23 == (-61157088000001L));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone29);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date9, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week32.previous();
        java.util.Date date35 = week32.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(53, year5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 0, year5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, year5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        long long11 = week9.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1553108399999L + "'", long11 == 1553108399999L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getSerialIndex();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.lang.Class<?> wildcardClass9 = regularTimePeriod8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
        java.util.Date date14 = week12.getEnd();
        java.lang.Class class15 = null;
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
        java.util.Date date20 = week18.getStart();
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone25);
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone34);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date14, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.next();
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
        java.lang.Class<?> wildcardClass43 = regularTimePeriod42.getClass();
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.next();
        java.util.Date date48 = week46.getEnd();
        java.lang.Class class49 = null;
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week52.next();
        java.util.Date date54 = week52.getStart();
        java.lang.Class class55 = null;
        java.util.Date date56 = null;
        java.lang.Class class57 = null;
        java.util.Date date58 = null;
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date58, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date56, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date54, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date48, timeZone59);
        boolean boolean64 = week37.equals((java.lang.Object) timeZone59);
        java.util.Locale locale65 = null;
        try {
            org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date4, timeZone59, locale65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 630L + "'", long3 == 630L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        java.util.Date date6 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168616000001L) + "'", long5 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 9);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        long long4 = week2.getMiddleMillisecond();
//        int int5 = week2.getYearValue();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(7, year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(4, year6);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        java.lang.String str5 = week2.toString();
        java.util.Date date6 = week2.getStart();
        int int7 = week2.getWeek();
        try {
            org.jfree.data.time.Year year8 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week -1, 0" + "'", str5.equals("Week -1, 0"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        long long3 = week1.getMiddleMillisecond();
//        int int4 = week1.getYearValue();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(7, year5);
//        java.util.Calendar calendar7 = null;
//        try {
//            week6.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(53, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year3);
        java.lang.Class<?> wildcardClass6 = week5.getClass();
        org.jfree.data.time.Year year7 = week5.getYear();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(year7);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) 0);
        java.lang.Object obj3 = null;
        int int4 = week2.compareTo(obj3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = regularTimePeriod5.getStart();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Class<?> wildcardClass22 = timePeriodFormatException19.getClass();
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException19.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException19.getSuppressed();
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException19.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray26);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 12);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getFirstMillisecond();
//        int int5 = week2.compareTo((java.lang.Object) long4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, (int) (byte) 10);
//        java.util.Date date9 = week8.getStart();
//        int int10 = week2.compareTo((java.lang.Object) date9);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(8, (-1));
//        java.util.Date date14 = week13.getStart();
//        java.lang.Class<?> wildcardClass15 = date14.getClass();
//        int int16 = week2.compareTo((java.lang.Object) date14);
//        long long17 = week2.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61789708800000L) + "'", long17 == (-61789708800000L));
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        java.util.Date date5 = week2.getStart();
        try {
            org.jfree.data.time.Year year6 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone29);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date9, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week32.previous();
        java.util.Calendar calendar35 = null;
        try {
            long long36 = week32.getMiddleMillisecond(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = regularTimePeriod3.getMiddleMillisecond();
        long long5 = regularTimePeriod3.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass6 = regularTimePeriod3.getClass();
        java.util.Date date7 = regularTimePeriod3.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168011200001L) + "'", long4 == (-62168011200001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168011200001L) + "'", long5 == (-62168011200001L));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getMiddleMillisecond();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        long long9 = week7.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass10 = week7.getClass();
        int int11 = week2.compareTo((java.lang.Object) wildcardClass10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        java.util.Date date16 = week14.getStart();
        java.util.Date date17 = week14.getStart();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date17, timeZone18);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61791825600001L) + "'", long3 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62194622400001L) + "'", long9 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(class20);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        long long10 = week8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.previous();
        java.util.Date date12 = week8.getEnd();
        boolean boolean13 = week2.equals((java.lang.Object) week8);
        long long14 = week8.getFirstMillisecond();
        long long15 = week8.getLastMillisecond();
        int int16 = week8.getYearValue();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.next();
        java.util.Date date26 = week24.getEnd();
        java.lang.Class class27 = null;
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.next();
        java.util.Date date32 = week30.getStart();
        java.lang.Class class33 = null;
        java.util.Date date34 = null;
        java.lang.Class class35 = null;
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date32, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date26, timeZone37);
        java.lang.Class<?> wildcardClass42 = date26.getClass();
        int int43 = week8.compareTo((java.lang.Object) date26);
        try {
            org.jfree.data.time.Year year44 = week8.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62194622400001L) + "'", long10 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62194924800000L) + "'", long14 == (-62194924800000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62194320000001L) + "'", long15 == (-62194320000001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        long long10 = week8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.previous();
        java.util.Date date12 = week8.getEnd();
        boolean boolean13 = week2.equals((java.lang.Object) week8);
        long long14 = week8.getFirstMillisecond();
        long long15 = week8.getLastMillisecond();
        int int16 = week8.getYearValue();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.next();
        java.util.Date date26 = week24.getEnd();
        java.lang.Class class27 = null;
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.next();
        java.util.Date date32 = week30.getStart();
        java.lang.Class class33 = null;
        java.util.Date date34 = null;
        java.lang.Class class35 = null;
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date32, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date26, timeZone37);
        java.lang.Class<?> wildcardClass42 = date26.getClass();
        int int43 = week8.compareTo((java.lang.Object) date26);
        java.lang.Class<?> wildcardClass44 = date26.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62194622400001L) + "'", long10 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62194924800000L) + "'", long14 == (-62194924800000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62194320000001L) + "'", long15 == (-62194320000001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(wildcardClass44);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException12.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str15 = timePeriodFormatException8.toString();
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        java.lang.Class<?> wildcardClass25 = date9.getClass();
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertNotNull(class27);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        int int6 = week5.getYearValue();
        long long7 = week5.getMiddleMillisecond();
        java.lang.Object obj8 = null;
        int int9 = week5.compareTo(obj8);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61831137600001L) + "'", long7 == (-61831137600001L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.next();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        java.util.Date date30 = regularTimePeriod28.getStart();
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.next();
        java.util.Date date35 = week33.getEnd();
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date35, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date30, timeZone38);
        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(class42);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone29);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date9, timeZone29);
        java.lang.String str33 = week32.toString();
        int int34 = week32.getWeek();
        long long35 = week32.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Week 35, 10" + "'", str33.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 35 + "'", int34 == 35);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-61830835200001L) + "'", long35 == (-61830835200001L));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) "Week 1, 32");
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(53, year5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 0, year5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, year5);
        int int10 = week9.getYearValue();
        long long11 = week9.getFirstMillisecond();
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1552806000000L + "'", long11 == 1552806000000L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        long long9 = week7.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass10 = week7.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date15 = week14.getEnd();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date15, timeZone16);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.next();
        java.lang.Class<?> wildcardClass23 = regularTimePeriod22.getClass();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.next();
        java.util.Date date28 = week26.getEnd();
        java.lang.Class class29 = null;
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.next();
        java.util.Date date34 = week32.getStart();
        java.lang.Class class35 = null;
        java.util.Date date36 = null;
        java.lang.Class class37 = null;
        java.util.Date date38 = null;
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date38, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date34, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date28, timeZone39);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date28);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date28);
        java.lang.Class class46 = null;
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week49.next();
        java.util.Date date51 = week49.getStart();
        java.lang.Class class52 = null;
        java.util.Date date53 = null;
        java.lang.Class class54 = null;
        java.util.Date date55 = null;
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date55, timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date53, timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date51, timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date28, timeZone56);
        try {
            int int61 = week2.compareTo((java.lang.Object) regularTimePeriod60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62194622400001L) + "'", long9 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 0, 12");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        java.lang.String str4 = week2.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 35, 10" + "'", str4.equals("Week 35, 10"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date4);
        long long11 = week10.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61831137600001L) + "'", long11 == (-61831137600001L));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, (int) (byte) 1);
        int int3 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getLastMillisecond();
        int int5 = week2.getWeek();
        int int6 = week2.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61791523200001L) + "'", long4 == (-61791523200001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = week2.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(9, 0);
        long long3 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62162568000001L) + "'", long3 == (-62162568000001L));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, 51);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        long long3 = week1.getMiddleMillisecond();
//        int int4 = week1.getYearValue();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(7, year5);
//        java.lang.String str7 = week6.toString();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 7, 2019" + "'", str7.equals("Week 7, 2019"));
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        int int6 = week5.getYearValue();
        long long7 = week5.getMiddleMillisecond();
        java.util.Date date8 = week5.getStart();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long12 = week11.getFirstMillisecond();
        long long13 = week11.getLastMillisecond();
        long long14 = week11.getMiddleMillisecond();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date18 = week17.getStart();
        int int19 = week11.compareTo((java.lang.Object) date18);
        java.util.Date date20 = week11.getStart();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.next();
        java.util.Date date25 = week23.getEnd();
        java.lang.String str26 = week23.toString();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year29 = week28.getYear();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(10, year29);
        java.lang.Class<?> wildcardClass31 = week30.getClass();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long35 = week34.getFirstMillisecond();
        java.util.Date date36 = week34.getStart();
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date36, timeZone37);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long42 = week41.getMiddleMillisecond();
        int int43 = week41.getWeek();
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long47 = week46.getFirstMillisecond();
        java.util.Date date48 = week46.getStart();
        boolean boolean49 = week41.equals((java.lang.Object) date48);
        java.lang.Class class50 = null;
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week53.next();
        java.util.Date date55 = week53.getStart();
        java.lang.Class class56 = null;
        java.util.Date date57 = null;
        java.lang.Class class58 = null;
        java.util.Date date59 = null;
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date59, timeZone60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date57, timeZone60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date55, timeZone60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date48, timeZone60);
        boolean boolean65 = week23.equals((java.lang.Object) timeZone60);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date20, timeZone60);
        java.util.Locale locale67 = null;
        try {
            org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date8, timeZone60, locale67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61831137600001L) + "'", long7 == (-61831137600001L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62168918400000L) + "'", long12 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62168313600001L) + "'", long13 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62168616000001L) + "'", long14 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week -1, 0" + "'", str26.equals("Week -1, 0"));
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-61157692800000L) + "'", long35 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-61791825600001L) + "'", long42 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 100 + "'", int43 == 100);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61157692800000L) + "'", long47 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date9 = week8.getStart();
        int int10 = week2.compareTo((java.lang.Object) date9);
        java.util.Date date11 = week2.getStart();
        long long12 = week2.getFirstMillisecond();
        long long13 = week2.getLastMillisecond();
        int int14 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168616000001L) + "'", long5 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62168918400000L) + "'", long12 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62168313600001L) + "'", long13 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getMiddleMillisecond();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        long long9 = week7.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass10 = week7.getClass();
        int int11 = week2.compareTo((java.lang.Object) wildcardClass10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        java.util.Date date16 = week14.getStart();
        java.util.Date date17 = week14.getStart();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date17, timeZone18);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date23 = week22.getStart();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date23);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.previous();
        long long29 = week27.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass30 = week27.getClass();
        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.next();
        int int36 = week34.getWeek();
        long long37 = week34.getLastMillisecond();
        int int38 = week34.getWeek();
        java.util.Date date39 = week34.getStart();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.next();
        java.lang.Class<?> wildcardClass44 = regularTimePeriod43.getClass();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week47.next();
        java.util.Date date49 = week47.getEnd();
        java.lang.Class class50 = null;
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week53.next();
        java.util.Date date55 = week53.getStart();
        java.lang.Class class56 = null;
        java.util.Date date57 = null;
        java.lang.Class class58 = null;
        java.util.Date date59 = null;
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date59, timeZone60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date57, timeZone60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date55, timeZone60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date49, timeZone60);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week67.next();
        java.lang.Class<?> wildcardClass69 = regularTimePeriod68.getClass();
        java.util.Date date70 = regularTimePeriod68.getStart();
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = week73.next();
        java.util.Date date75 = week73.getEnd();
        java.lang.Class class76 = null;
        java.util.Date date77 = null;
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class76, date77, timeZone78);
        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date75, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date70, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date39, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date23, timeZone78);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61791825600001L) + "'", long3 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62194622400001L) + "'", long9 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-62194622400001L) + "'", long29 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-62168313600001L) + "'", long37 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(regularTimePeriod83);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.Date date6 = week5.getStart();
        int int7 = week5.getWeek();
        long long8 = week5.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 565L + "'", long8 == 565L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        int int9 = week7.getWeek();
        long long10 = week7.getLastMillisecond();
        java.util.Date date11 = week7.getStart();
        boolean boolean12 = week2.equals((java.lang.Object) date11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62168313600001L) + "'", long10 == (-62168313600001L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException12.getSuppressed();
        java.lang.String str30 = timePeriodFormatException12.toString();
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str30.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(53, year2);
        boolean boolean5 = week3.equals((java.lang.Object) 100);
        java.lang.Object obj6 = null;
        boolean boolean7 = week3.equals(obj6);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException19.getSuppressed();
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException19.getSuppressed();
        java.lang.String str25 = timePeriodFormatException19.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException37.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        java.lang.Throwable[] throwableArray47 = timePeriodFormatException45.getSuppressed();
        timePeriodFormatException39.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        java.lang.Throwable[] throwableArray50 = timePeriodFormatException45.getSuppressed();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        java.lang.Throwable throwable52 = null;
        try {
            timePeriodFormatException45.addSuppressed(throwable52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(throwableArray50);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        long long5 = week3.getMiddleMillisecond();
//        int int6 = week3.getYearValue();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) ' ', year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 10, year7);
//        int int11 = week10.getWeek();
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) 0);
        java.lang.Object obj3 = null;
        int int4 = week2.compareTo(obj3);
        long long5 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168011200001L) + "'", long5 == (-62168011200001L));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(53, year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (byte) 0, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getMiddleMillisecond();
//        int int3 = week0.getYearValue();
//        java.lang.String str4 = week0.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        java.lang.Throwable[] throwableArray34 = timePeriodFormatException20.getSuppressed();
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.junit.Assert.assertNotNull(throwableArray34);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getYearValue();
        long long5 = week2.getFirstMillisecond();
        java.util.Date date6 = week2.getEnd();
        java.util.Calendar calendar7 = null;
        try {
            week2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168918400000L) + "'", long5 == (-62168918400000L));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        int int8 = week2.getWeek();
        int int9 = week2.getWeek();
        java.lang.String str10 = week2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 8, -1" + "'", str10.equals("Week 8, -1"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 100, 10");
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date9 = week8.getStart();
        int int10 = week2.compareTo((java.lang.Object) date9);
        java.util.Date date11 = week2.getStart();
        long long12 = week2.getFirstMillisecond();
        java.lang.Object obj13 = null;
        int int14 = week2.compareTo(obj13);
        java.util.Date date15 = week2.getStart();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = week2.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168616000001L) + "'", long5 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62168918400000L) + "'", long12 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        long long5 = week3.getMiddleMillisecond();
//        int int6 = week3.getYearValue();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) -1, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 0, year7);
//        long long11 = week10.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1545854399999L + "'", long11 == 1545854399999L);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, (int) (byte) 1);
        java.util.Date date3 = week2.getEnd();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.Date date6 = week5.getStart();
        int int7 = week5.getWeek();
        long long8 = week5.getMiddleMillisecond();
        long long9 = week5.getMiddleMillisecond();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long13 = week12.getFirstMillisecond();
        long long14 = week12.getLastMillisecond();
        long long15 = week12.getMiddleMillisecond();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date19 = week18.getStart();
        int int20 = week12.compareTo((java.lang.Object) date19);
        java.util.Date date21 = week12.getStart();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.next();
        java.util.Date date26 = week24.getEnd();
        java.lang.String str27 = week24.toString();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year30 = week29.getYear();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(10, year30);
        java.lang.Class<?> wildcardClass32 = week31.getClass();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long36 = week35.getFirstMillisecond();
        java.util.Date date37 = week35.getStart();
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date37, timeZone38);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long43 = week42.getMiddleMillisecond();
        int int44 = week42.getWeek();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long48 = week47.getFirstMillisecond();
        java.util.Date date49 = week47.getStart();
        boolean boolean50 = week42.equals((java.lang.Object) date49);
        java.lang.Class class51 = null;
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.next();
        java.util.Date date56 = week54.getStart();
        java.lang.Class class57 = null;
        java.util.Date date58 = null;
        java.lang.Class class59 = null;
        java.util.Date date60 = null;
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date60, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date58, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date56, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date49, timeZone61);
        boolean boolean66 = week24.equals((java.lang.Object) timeZone61);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date21, timeZone61);
        boolean boolean68 = week5.equals((java.lang.Object) week67);
        java.util.Calendar calendar69 = null;
        try {
            long long70 = week5.getMiddleMillisecond(calendar69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61831137600001L) + "'", long8 == (-61831137600001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61831137600001L) + "'", long9 == (-61831137600001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62168918400000L) + "'", long13 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62168313600001L) + "'", long14 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62168616000001L) + "'", long15 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week -1, 0" + "'", str27.equals("Week -1, 0"));
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-61157692800000L) + "'", long36 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-61791825600001L) + "'", long43 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 100 + "'", int44 == 100);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61157692800000L) + "'", long48 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        int int6 = week5.getYearValue();
        long long7 = week5.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException11.getSuppressed();
        boolean boolean20 = week5.equals((java.lang.Object) timePeriodFormatException11);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.next();
        java.lang.Class<?> wildcardClass25 = regularTimePeriod24.getClass();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
        java.util.Date date30 = week28.getEnd();
        java.lang.Class class31 = null;
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.next();
        java.util.Date date36 = week34.getStart();
        java.lang.Class class37 = null;
        java.util.Date date38 = null;
        java.lang.Class class39 = null;
        java.util.Date date40 = null;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date38, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date36, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date30, timeZone41);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.next();
        java.lang.Class<?> wildcardClass50 = regularTimePeriod49.getClass();
        java.util.Date date51 = regularTimePeriod49.getStart();
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.next();
        java.util.Date date56 = week54.getEnd();
        java.lang.Class class57 = null;
        java.util.Date date58 = null;
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date58, timeZone59);
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date56, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date51, timeZone59);
        boolean boolean63 = week5.equals((java.lang.Object) date51);
        java.lang.Class<?> wildcardClass64 = week5.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61831137600001L) + "'", long7 == (-61831137600001L));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(wildcardClass64);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        long long7 = week2.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61830835200001L) + "'", long7 == (-61830835200001L));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) ' ', 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getFirstMillisecond();
        long long5 = week2.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61959657600000L) + "'", long4 == (-61959657600000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61959657600000L) + "'", long5 == (-61959657600000L));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.Date date6 = week5.getStart();
        java.util.Date date7 = week5.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
        try {
            org.jfree.data.time.Year year9 = week8.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 51);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        long long5 = week3.getMiddleMillisecond();
//        int int6 = week3.getYearValue();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) ' ', year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 10, year7);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(8, (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
//        long long15 = week13.getMiddleMillisecond();
//        int int16 = week13.getYearValue();
//        long long17 = week13.getLastMillisecond();
//        boolean boolean18 = week10.equals((java.lang.Object) week13);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62194622400001L) + "'", long15 == (-62194622400001L));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62194320000001L) + "'", long17 == (-62194320000001L));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
//        int int4 = week2.getWeek();
//        long long5 = week2.getLastMillisecond();
//        java.lang.String str6 = week2.toString();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year9 = week8.getYear();
//        long long10 = week8.getMiddleMillisecond();
//        int int11 = week8.getYearValue();
//        org.jfree.data.time.Year year12 = week8.getYear();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', year12);
//        boolean boolean14 = week2.equals((java.lang.Object) week13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week -1, 0" + "'", str6.equals("Week -1, 0"));
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560365999999L + "'", long10 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.Date date6 = week5.getStart();
        java.util.Date date7 = week5.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        long long3 = week1.getMiddleMillisecond();
//        int int4 = week1.getYearValue();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) ' ', year5);
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(year7);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 1, 32");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        java.lang.Object obj7 = null;
        int int8 = week6.compareTo(obj7);
        long long9 = week6.getSerialIndex();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week6.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 565L + "'", long9 == 565L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        java.lang.String str6 = week2.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week -1, 0" + "'", str6.equals("Week -1, 0"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        int int9 = week7.getWeek();
        long long10 = week7.getLastMillisecond();
        java.util.Date date11 = week7.getStart();
        boolean boolean12 = week2.equals((java.lang.Object) date11);
        int int13 = week2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62168313600001L) + "'", long10 == (-62168313600001L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(35, 32);
        int int3 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week -1, 2");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        int int6 = week2.getWeek();
        try {
            org.jfree.data.time.Year year7 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        java.lang.String str5 = week2.toString();
        java.util.Date date6 = week2.getStart();
        long long7 = week2.getLastMillisecond();
        long long8 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week -1, 0" + "'", str5.equals("Week -1, 0"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62168313600001L) + "'", long7 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62168313600001L) + "'", long8 == (-62168313600001L));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(class26);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.lang.Class<?> wildcardClass9 = regularTimePeriod8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
        java.util.Date date14 = week12.getEnd();
        java.lang.Class class15 = null;
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
        java.util.Date date20 = week18.getStart();
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone25);
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone34);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date14, timeZone34);
        int int38 = week2.compareTo((java.lang.Object) date14);
        int int39 = week2.getWeek();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.next();
        long long44 = week42.getLastMillisecond();
        int int45 = week42.getWeek();
        java.lang.String str46 = week42.toString();
        int int47 = week2.compareTo((java.lang.Object) str46);
        long long48 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-61830835200001L) + "'", long44 == (-61830835200001L));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 35 + "'", int45 == 35);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Week 35, 10" + "'", str46.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1697L + "'", long48 == 1697L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        int int5 = week2.getYearValue();
        long long6 = week2.getMiddleMillisecond();
        long long7 = week2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62194622400001L) + "'", long6 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62194924800000L) + "'", long7 == (-62194924800000L));
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        long long5 = week3.getMiddleMillisecond();
//        int int6 = week3.getYearValue();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(7, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', year7);
//        int int11 = week10.getYearValue();
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date3 = week2.getEnd();
        java.lang.Class class4 = null;
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date3, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        long long10 = week8.getLastMillisecond();
        long long11 = week8.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61157088000001L) + "'", long10 == (-61157088000001L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61157692800000L) + "'", long11 == (-61157692800000L));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        int int6 = week5.getYearValue();
        long long7 = week5.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        int int13 = week5.compareTo((java.lang.Object) timePeriodFormatException9);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61831137600001L) + "'", long7 == (-61831137600001L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.lang.Class<?> wildcardClass9 = regularTimePeriod8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
        java.util.Date date14 = week12.getEnd();
        java.lang.Class class15 = null;
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
        java.util.Date date20 = week18.getStart();
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone25);
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone34);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date14, timeZone34);
        int int38 = week2.compareTo((java.lang.Object) date14);
        int int39 = week2.getWeek();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.next();
        long long44 = week42.getLastMillisecond();
        int int45 = week42.getWeek();
        java.lang.String str46 = week42.toString();
        int int47 = week2.compareTo((java.lang.Object) str46);
        java.lang.String str48 = week2.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-61830835200001L) + "'", long44 == (-61830835200001L));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 35 + "'", int45 == 35);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Week 35, 10" + "'", str46.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Week 1, 32" + "'", str48.equals("Week 1, 32"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str17 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException40);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException48.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        java.lang.Throwable[] throwableArray54 = timePeriodFormatException40.getSuppressed();
        java.lang.Throwable[] throwableArray55 = timePeriodFormatException40.getSuppressed();
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException40);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException58 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException60 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException58.addSuppressed((java.lang.Throwable) timePeriodFormatException60);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException63 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException65 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException63.addSuppressed((java.lang.Throwable) timePeriodFormatException65);
        timePeriodFormatException58.addSuppressed((java.lang.Throwable) timePeriodFormatException65);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException69 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException71 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException69.addSuppressed((java.lang.Throwable) timePeriodFormatException71);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException74 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException76 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException74.addSuppressed((java.lang.Throwable) timePeriodFormatException76);
        timePeriodFormatException69.addSuppressed((java.lang.Throwable) timePeriodFormatException76);
        java.lang.Class<?> wildcardClass79 = timePeriodFormatException76.getClass();
        java.lang.Throwable[] throwableArray80 = timePeriodFormatException76.getSuppressed();
        timePeriodFormatException65.addSuppressed((java.lang.Throwable) timePeriodFormatException76);
        java.lang.Throwable[] throwableArray82 = timePeriodFormatException76.getSuppressed();
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException76);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray54);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertNotNull(wildcardClass79);
        org.junit.Assert.assertNotNull(throwableArray80);
        org.junit.Assert.assertNotNull(throwableArray82);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 0, 0");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 5);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        int int8 = week2.getWeek();
        int int9 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.previous();
        long long11 = week2.getLastMillisecond();
        long long12 = week2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62194320000001L) + "'", long11 == (-62194320000001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62194622400001L) + "'", long12 == (-62194622400001L));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.lang.Class<?> wildcardClass9 = regularTimePeriod8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
        java.util.Date date14 = week12.getEnd();
        java.lang.Class class15 = null;
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
        java.util.Date date20 = week18.getStart();
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone25);
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone34);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date14, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week37.previous();
        boolean boolean40 = week2.equals((java.lang.Object) regularTimePeriod39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week2.next();
        java.util.Calendar calendar42 = null;
        try {
            long long43 = week2.getMiddleMillisecond(calendar42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str17 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException40);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        java.lang.Class<?> wildcardClass48 = timePeriodFormatException45.getClass();
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        java.lang.String str50 = timePeriodFormatException35.toString();
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str50.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str17 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException46.addSuppressed((java.lang.Throwable) timePeriodFormatException48);
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException46);
        java.lang.String str51 = timePeriodFormatException35.toString();
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        java.lang.String str53 = timePeriodFormatException30.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException55 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException57 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException55.addSuppressed((java.lang.Throwable) timePeriodFormatException57);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException60 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException62 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException60.addSuppressed((java.lang.Throwable) timePeriodFormatException62);
        timePeriodFormatException55.addSuppressed((java.lang.Throwable) timePeriodFormatException62);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException66 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray67 = timePeriodFormatException66.getSuppressed();
        timePeriodFormatException62.addSuppressed((java.lang.Throwable) timePeriodFormatException66);
        java.lang.Throwable[] throwableArray69 = timePeriodFormatException62.getSuppressed();
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException62);
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException62);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException62);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str51.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str53.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(throwableArray69);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        long long4 = week2.getMiddleMillisecond();
//        int int5 = week2.getYearValue();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(7, year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, year6);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(53, year11);
//        long long13 = week12.getSerialIndex();
//        boolean boolean14 = week8.equals((java.lang.Object) week12);
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = week8.getFirstMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107060L + "'", long13 == 107060L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        java.lang.String str7 = week6.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 35, 10" + "'", str7.equals("Week 35, 10"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 2);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date3 = week2.getEnd();
        java.lang.Class class4 = null;
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date3, timeZone6);
        int int9 = week8.getYearValue();
        java.lang.Class<?> wildcardClass10 = week8.getClass();
        try {
            org.jfree.data.time.Year year11 = week8.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (32) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
        long long10 = regularTimePeriod9.getMiddleMillisecond();
        boolean boolean11 = week5.equals((java.lang.Object) regularTimePeriod9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week5.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61820251200001L) + "'", long10 == (-61820251200001L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(53, year2);
        long long4 = week3.getSerialIndex();
        int int5 = week3.getWeek();
        java.util.Date date6 = week3.getStart();
        java.util.Date date7 = week3.getStart();
        int int8 = week3.getYearValue();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107060L + "'", long4 == 107060L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 53 + "'", int5 == 53);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date4 = week3.getEnd();
        java.lang.Class class5 = null;
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
        java.util.Date date10 = week8.getStart();
        java.lang.Class class11 = null;
        java.util.Date date12 = null;
        java.lang.Class class13 = null;
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date10, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone15);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date23 = week22.getEnd();
        java.lang.Class class24 = null;
        java.util.Date date25 = null;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date23, timeZone26);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date4, timeZone26);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date4);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.Date date6 = week5.getStart();
        java.util.Date date7 = week5.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        long long12 = week10.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass13 = week10.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
        int int19 = week17.getWeek();
        long long20 = week17.getLastMillisecond();
        int int21 = week17.getWeek();
        java.util.Date date22 = week17.getStart();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.next();
        java.lang.Class<?> wildcardClass27 = regularTimePeriod26.getClass();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.next();
        java.util.Date date32 = week30.getEnd();
        java.lang.Class class33 = null;
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week36.next();
        java.util.Date date38 = week36.getStart();
        java.lang.Class class39 = null;
        java.util.Date date40 = null;
        java.lang.Class class41 = null;
        java.util.Date date42 = null;
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date42, timeZone43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date38, timeZone43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date32, timeZone43);
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = week50.next();
        java.lang.Class<?> wildcardClass52 = regularTimePeriod51.getClass();
        java.util.Date date53 = regularTimePeriod51.getStart();
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = week56.next();
        java.util.Date date58 = week56.getEnd();
        java.lang.Class class59 = null;
        java.util.Date date60 = null;
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date60, timeZone61);
        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date58, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date53, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date22, timeZone61);
        java.lang.Class<?> wildcardClass66 = timeZone61.getClass();
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = week69.next();
        java.util.Date date71 = regularTimePeriod70.getEnd();
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = week74.next();
        java.lang.Class<?> wildcardClass76 = regularTimePeriod75.getClass();
        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = week79.next();
        long long81 = regularTimePeriod80.getMiddleMillisecond();
        java.util.Date date82 = regularTimePeriod80.getEnd();
        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = week85.next();
        java.util.Date date87 = week85.getEnd();
        java.lang.Class class88 = null;
        java.util.Date date89 = null;
        java.util.TimeZone timeZone90 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance(class88, date89, timeZone90);
        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(date87, timeZone90);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass76, date82, timeZone90);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date71, timeZone90);
        org.jfree.data.time.Week week95 = new org.jfree.data.time.Week(date7, timeZone90);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62194622400001L) + "'", long12 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62168313600001L) + "'", long20 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-61820251200001L) + "'", long81 == (-61820251200001L));
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNotNull(regularTimePeriod86);
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertNotNull(timeZone90);
        org.junit.Assert.assertNull(regularTimePeriod91);
        org.junit.Assert.assertNotNull(regularTimePeriod93);
        org.junit.Assert.assertNull(regularTimePeriod94);
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) 0);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getMiddleMillisecond();
//        int int7 = week4.getYearValue();
//        org.jfree.data.time.Year year8 = week4.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, year8);
//        int int10 = week2.compareTo((java.lang.Object) (short) -1);
//        int int11 = week2.getWeek();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
//        java.util.Date date16 = week14.getStart();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
//        java.util.Date date18 = week17.getStart();
//        boolean boolean19 = week2.equals((java.lang.Object) date18);
//        java.lang.Class class20 = null;
//        java.util.Date date21 = null;
//        java.lang.Class class22 = null;
//        java.util.Date date23 = null;
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date23, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone24);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date18, timeZone24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.Date date6 = week5.getStart();
        java.util.Date date7 = week5.getEnd();
        java.lang.Class class8 = null;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
        java.util.Date date13 = week11.getStart();
        java.lang.Class class14 = null;
        java.util.Date date15 = null;
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date13, timeZone18);
        java.util.Locale locale22 = null;
        try {
            org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date7, timeZone18, locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod21);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long7 = week6.getFirstMillisecond();
        long long8 = week6.getSerialIndex();
        int int9 = week2.compareTo((java.lang.Object) long8);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61157692800000L) + "'", long7 == (-61157692800000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1697L + "'", long8 == 1697L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone29);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date9, timeZone29);
        java.lang.String str33 = week32.toString();
        long long34 = week32.getFirstMillisecond();
        java.lang.Object obj35 = null;
        boolean boolean36 = week32.equals(obj35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week32.next();
        java.util.Calendar calendar38 = null;
        try {
            long long39 = week32.getFirstMillisecond(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Week 35, 10" + "'", str33.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-61831440000000L) + "'", long34 == (-61831440000000L));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.lang.String str4 = week2.toString();
        int int5 = week2.getWeek();
        long long6 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 1, 32" + "'", str4.equals("Week 1, 32"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61157088000001L) + "'", long6 == (-61157088000001L));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        long long10 = week8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.previous();
        java.util.Date date12 = week8.getEnd();
        boolean boolean13 = week2.equals((java.lang.Object) week8);
        long long14 = week8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week8.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62194622400001L) + "'", long10 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62194924800000L) + "'", long14 == (-62194924800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        int int5 = week2.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        long long6 = week2.getMiddleMillisecond();
        java.util.Date date7 = week2.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
        java.util.Date date12 = week10.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week10.previous();
        java.lang.Class<?> wildcardClass14 = week10.getClass();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date18 = week17.getStart();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date18);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long23 = week22.getSerialIndex();
        java.util.Date date24 = week22.getEnd();
        java.lang.Class class25 = null;
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
        java.util.Date date30 = week28.getStart();
        java.lang.Class class31 = null;
        java.util.Date date32 = null;
        java.lang.Class class33 = null;
        java.util.Date date34 = null;
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date30, timeZone35);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date24, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date18, timeZone35);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date7, timeZone35);
        java.util.Date date42 = week41.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62168616000001L) + "'", long6 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 630L + "'", long23 == 630L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date42);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, (int) (short) 100);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        java.lang.String str6 = week2.toString();
        int int7 = week2.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week -1, 0" + "'", str6.equals("Week -1, 0"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long9 = week8.getFirstMillisecond();
        boolean boolean11 = week8.equals((java.lang.Object) (short) 1);
        int int12 = week5.compareTo((java.lang.Object) (short) 1);
        long long13 = week5.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62168918400000L) + "'", long9 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 565L + "'", long13 == 565L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) ' ');
        int int3 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
        java.util.Date date10 = week8.getEnd();
        java.lang.Class class11 = null;
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date10, timeZone13);
        java.util.Locale locale16 = null;
        try {
            org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date4, timeZone13, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.Date date6 = week5.getStart();
        int int7 = week5.getWeek();
        long long8 = week5.getMiddleMillisecond();
        long long9 = week5.getMiddleMillisecond();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long13 = week12.getFirstMillisecond();
        long long14 = week12.getLastMillisecond();
        long long15 = week12.getMiddleMillisecond();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date19 = week18.getStart();
        int int20 = week12.compareTo((java.lang.Object) date19);
        java.util.Date date21 = week12.getStart();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.next();
        java.util.Date date26 = week24.getEnd();
        java.lang.String str27 = week24.toString();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year30 = week29.getYear();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(10, year30);
        java.lang.Class<?> wildcardClass32 = week31.getClass();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long36 = week35.getFirstMillisecond();
        java.util.Date date37 = week35.getStart();
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date37, timeZone38);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long43 = week42.getMiddleMillisecond();
        int int44 = week42.getWeek();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long48 = week47.getFirstMillisecond();
        java.util.Date date49 = week47.getStart();
        boolean boolean50 = week42.equals((java.lang.Object) date49);
        java.lang.Class class51 = null;
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.next();
        java.util.Date date56 = week54.getStart();
        java.lang.Class class57 = null;
        java.util.Date date58 = null;
        java.lang.Class class59 = null;
        java.util.Date date60 = null;
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date60, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date58, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date56, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date49, timeZone61);
        boolean boolean66 = week24.equals((java.lang.Object) timeZone61);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date21, timeZone61);
        boolean boolean68 = week5.equals((java.lang.Object) week67);
        long long69 = week5.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61831137600001L) + "'", long8 == (-61831137600001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61831137600001L) + "'", long9 == (-61831137600001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62168918400000L) + "'", long13 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62168313600001L) + "'", long14 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62168616000001L) + "'", long15 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Week -1, 0" + "'", str27.equals("Week -1, 0"));
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-61157692800000L) + "'", long36 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-61791825600001L) + "'", long43 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 100 + "'", int44 == 100);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61157692800000L) + "'", long48 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-61831137600001L) + "'", long69 == (-61831137600001L));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(8, year3);
        long long6 = week5.getFirstMillisecond();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        long long11 = week9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week9.previous();
        try {
            int int13 = week5.compareTo((java.lang.Object) regularTimePeriod12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1550390400000L + "'", long6 == 1550390400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61791523200001L) + "'", long11 == (-61791523200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(11, (int) (byte) 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        int int8 = week2.getWeek();
        int int9 = week2.getYearValue();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week2.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        java.util.Date date11 = week10.getStart();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        java.lang.Class<?> wildcardClass16 = regularTimePeriod15.getClass();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
        java.util.Date date21 = week19.getEnd();
        java.lang.Class class22 = null;
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.next();
        java.util.Date date27 = week25.getStart();
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date27, timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone32);
        java.lang.Class class37 = null;
        java.util.Date date38 = null;
        java.lang.Class class39 = null;
        java.util.Date date40 = null;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date38, timeZone41);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date21, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.next();
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.next();
        java.lang.Class<?> wildcardClass50 = regularTimePeriod49.getClass();
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week53.next();
        java.util.Date date55 = week53.getEnd();
        java.lang.Class class56 = null;
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = week59.next();
        java.util.Date date61 = week59.getStart();
        java.lang.Class class62 = null;
        java.util.Date date63 = null;
        java.lang.Class class64 = null;
        java.util.Date date65 = null;
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date65, timeZone66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date63, timeZone66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date61, timeZone66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date55, timeZone66);
        boolean boolean71 = week44.equals((java.lang.Object) timeZone66);
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date11, timeZone66);
        java.util.Locale locale73 = null;
        try {
            org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date4, timeZone66, locale73);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        java.lang.String str2 = week0.toString();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        int int6 = week2.getWeek();
        java.util.Date date7 = week2.getStart();
        int int8 = week2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, (int) (byte) 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getSerialIndex();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.lang.String str6 = week2.toString();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long10 = week9.getFirstMillisecond();
        java.util.Date date11 = week9.getStart();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        java.lang.Class<?> wildcardClass16 = regularTimePeriod15.getClass();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
        java.util.Date date21 = week19.getEnd();
        java.lang.Class class22 = null;
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.next();
        java.util.Date date27 = week25.getStart();
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date27, timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone32);
        java.lang.Class class37 = null;
        java.util.Date date38 = null;
        java.lang.Class class39 = null;
        java.util.Date date40 = null;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date38, timeZone41);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date21, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week44.previous();
        boolean boolean47 = week9.equals((java.lang.Object) regularTimePeriod46);
        boolean boolean48 = week2.equals((java.lang.Object) week9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 630L + "'", long3 == 630L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 630L + "'", long4 == 630L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 100, 10" + "'", str6.equals("Week 100, 10"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61157692800000L) + "'", long10 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date28 = week27.getEnd();
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date28, timeZone31);
        int int34 = week33.getYearValue();
        java.lang.Class<?> wildcardClass35 = week33.getClass();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long39 = week38.getFirstMillisecond();
        long long40 = week38.getLastMillisecond();
        long long41 = week38.getMiddleMillisecond();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date45 = week44.getStart();
        int int46 = week38.compareTo((java.lang.Object) date45);
        java.util.Date date47 = week38.getStart();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = week50.next();
        java.lang.Class<?> wildcardClass52 = regularTimePeriod51.getClass();
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week55.next();
        java.util.Date date57 = week55.getEnd();
        java.lang.Class class58 = null;
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = week61.next();
        java.util.Date date63 = week61.getStart();
        java.lang.Class class64 = null;
        java.util.Date date65 = null;
        java.lang.Class class66 = null;
        java.util.Date date67 = null;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date67, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date65, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date63, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date57, timeZone68);
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = week75.next();
        java.lang.Class<?> wildcardClass77 = regularTimePeriod76.getClass();
        java.util.Date date78 = regularTimePeriod76.getStart();
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = week81.next();
        java.util.Date date83 = week81.getEnd();
        java.lang.Class class84 = null;
        java.util.Date date85 = null;
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class84, date85, timeZone86);
        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date83, timeZone86);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date78, timeZone86);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date47, timeZone86);
        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date9, timeZone86);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 32 + "'", int34 == 32);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-62168918400000L) + "'", long39 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62168313600001L) + "'", long40 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-62168616000001L) + "'", long41 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNull(regularTimePeriod87);
        org.junit.Assert.assertNotNull(regularTimePeriod89);
        org.junit.Assert.assertNotNull(regularTimePeriod90);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4);
        java.lang.Object obj7 = null;
        int int8 = week6.compareTo(obj7);
        int int9 = week6.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
        java.lang.Class<?> wildcardClass8 = regularTimePeriod7.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.next();
        java.util.Date date13 = week11.getEnd();
        java.lang.Class class14 = null;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
        java.util.Date date19 = week17.getStart();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        java.lang.Class class22 = null;
        java.util.Date date23 = null;
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date23, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date19, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone24);
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.lang.Class class31 = null;
        java.util.Date date32 = null;
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone33);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date13, timeZone33);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date13);
        boolean boolean38 = week2.equals((java.lang.Object) week37);
        java.util.Calendar calendar39 = null;
        try {
            long long40 = week37.getMiddleMillisecond(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        java.lang.String str5 = week2.toString();
        java.util.Date date6 = week2.getStart();
        int int7 = week2.getWeek();
        long long8 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week -1, 0" + "'", str5.equals("Week -1, 0"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62168616000001L) + "'", long8 == (-62168616000001L));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone29);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date9, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week32.previous();
        long long35 = week32.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-61830835200001L) + "'", long35 == (-61830835200001L));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        long long6 = week2.getMiddleMillisecond();
        java.util.Date date7 = week2.getStart();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62168616000001L) + "'", long6 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str17 = timePeriodFormatException12.toString();
        java.lang.String str18 = timePeriodFormatException12.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException20.getSuppressed();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
        org.junit.Assert.assertNotNull(throwableArray24);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 7);
        java.util.Date date3 = week2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException19.getSuppressed();
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException19.getSuppressed();
        java.lang.String str25 = timePeriodFormatException19.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException37.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        java.lang.Throwable[] throwableArray47 = timePeriodFormatException45.getSuppressed();
        timePeriodFormatException39.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        java.lang.Throwable[] throwableArray50 = timePeriodFormatException45.getSuppressed();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        java.lang.String str52 = timePeriodFormatException19.toString();
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str52.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        java.util.Date date6 = week5.getStart();
        int int7 = week5.getWeek();
        long long8 = week5.getMiddleMillisecond();
        long long9 = week5.getMiddleMillisecond();
        try {
            org.jfree.data.time.Year year10 = week5.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61831137600001L) + "'", long8 == (-61831137600001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61831137600001L) + "'", long9 == (-61831137600001L));
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        long long5 = week3.getMiddleMillisecond();
//        int int6 = week3.getYearValue();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) ' ', year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 10, year7);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
//        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray24 = timePeriodFormatException23.getSuppressed();
//        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
//        java.lang.Throwable[] throwableArray26 = timePeriodFormatException19.getSuppressed();
//        int int27 = week10.compareTo((java.lang.Object) throwableArray26);
//        java.util.Calendar calendar28 = null;
//        try {
//            long long29 = week10.getFirstMillisecond(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(throwableArray24);
//        org.junit.Assert.assertNotNull(throwableArray26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
//        long long3 = week2.getFirstMillisecond();
//        java.util.Date date4 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        java.lang.Class<?> wildcardClass9 = regularTimePeriod8.getClass();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
//        java.util.Date date14 = week12.getEnd();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        java.util.Date date20 = week18.getStart();
//        java.lang.Class class21 = null;
//        java.util.Date date22 = null;
//        java.lang.Class class23 = null;
//        java.util.Date date24 = null;
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone25);
//        java.lang.Class class30 = null;
//        java.util.Date date31 = null;
//        java.lang.Class class32 = null;
//        java.util.Date date33 = null;
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone34);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date14, timeZone34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week37.previous();
//        boolean boolean40 = week2.equals((java.lang.Object) regularTimePeriod39);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year43 = week42.getYear();
//        long long44 = week42.getMiddleMillisecond();
//        int int45 = week42.getYearValue();
//        org.jfree.data.time.Year year46 = week42.getYear();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) ' ', year46);
//        long long48 = week47.getLastMillisecond();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week51.next();
//        java.util.Date date53 = week51.getStart();
//        java.util.Date date54 = week51.getStart();
//        int int55 = week47.compareTo((java.lang.Object) date54);
//        boolean boolean56 = week2.equals((java.lang.Object) int55);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560365999999L + "'", long44 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
//        org.junit.Assert.assertNotNull(year46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1565506799999L + "'", long48 == 1565506799999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        int int5 = week2.getWeek();
        java.util.Date date6 = week2.getEnd();
        long long7 = week2.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62168313600001L) + "'", long7 == (-62168313600001L));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getStart();
        java.lang.String str7 = week2.toString();
        int int8 = week2.getYearValue();
        long long9 = week2.getMiddleMillisecond();
        int int10 = week2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week -1, 0" + "'", str7.equals("Week -1, 0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62168616000001L) + "'", long9 == (-62168616000001L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        java.lang.String str6 = week2.toString();
        java.lang.String str7 = week2.toString();
        int int8 = week2.getYearValue();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week -1, 0" + "'", str6.equals("Week -1, 0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week -1, 0" + "'", str7.equals("Week -1, 0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(32, year3);
        long long6 = week5.getSerialIndex();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107039L + "'", long6 == 107039L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        java.lang.Object obj5 = null;
        int int6 = week2.compareTo(obj5);
        long long7 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 1, 32" + "'", str3.equals("Week 1, 32"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1697L + "'", long7 == 1697L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        java.lang.String str5 = week2.toString();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        boolean boolean30 = week2.equals((java.lang.Object) timePeriodFormatException24);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 10);
        java.lang.Class<?> wildcardClass34 = week33.getClass();
        java.lang.String str35 = week33.toString();
        int int36 = week2.compareTo((java.lang.Object) str35);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week -1, 0" + "'", str5.equals("Week -1, 0"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 35, 10" + "'", str35.equals("Week 35, 10"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(53, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year3);
        java.lang.Class<?> wildcardClass6 = week5.getClass();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        java.lang.Class<?> wildcardClass11 = regularTimePeriod10.getClass();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        java.util.Date date16 = week14.getEnd();
        java.lang.Class class17 = null;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.next();
        java.util.Date date22 = week20.getStart();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date22, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date16, timeZone27);
        java.lang.Class<?> wildcardClass32 = date16.getClass();
        java.lang.Class class33 = null;
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date37 = week36.getEnd();
        java.lang.Class class38 = null;
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
        java.util.Date date43 = week41.getStart();
        java.lang.Class class44 = null;
        java.util.Date date45 = null;
        java.lang.Class class46 = null;
        java.util.Date date47 = null;
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date47, timeZone48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date43, timeZone48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date37, timeZone48);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date16, timeZone48);
        int int54 = week5.compareTo((java.lang.Object) timeZone48);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 1");
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 4);
        int int3 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        java.util.Date date5 = week3.getEnd();
        java.lang.Class class6 = null;
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone8);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5, timeZone8);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
        long long15 = week13.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass16 = week13.getClass();
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.next();
        int int22 = week20.getWeek();
        long long23 = week20.getLastMillisecond();
        int int24 = week20.getWeek();
        java.util.Date date25 = week20.getStart();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
        java.lang.Class<?> wildcardClass30 = regularTimePeriod29.getClass();
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.next();
        java.util.Date date35 = week33.getEnd();
        java.lang.Class class36 = null;
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.next();
        java.util.Date date41 = week39.getStart();
        java.lang.Class class42 = null;
        java.util.Date date43 = null;
        java.lang.Class class44 = null;
        java.util.Date date45 = null;
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date43, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date41, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date35, timeZone46);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week53.next();
        java.lang.Class<?> wildcardClass55 = regularTimePeriod54.getClass();
        java.util.Date date56 = regularTimePeriod54.getStart();
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = week59.next();
        java.util.Date date61 = week59.getEnd();
        java.lang.Class class62 = null;
        java.util.Date date63 = null;
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date63, timeZone64);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date61, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date56, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date25, timeZone64);
        java.lang.Class<?> wildcardClass69 = date25.getClass();
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = week72.next();
        java.util.Date date74 = week72.getEnd();
        java.lang.Class class75 = null;
        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date79 = week78.getEnd();
        java.lang.Class class80 = null;
        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = week83.next();
        java.util.Date date85 = week83.getStart();
        java.lang.Class class86 = null;
        java.util.Date date87 = null;
        java.lang.Class class88 = null;
        java.util.Date date89 = null;
        java.util.TimeZone timeZone90 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance(class88, date89, timeZone90);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance(class86, date87, timeZone90);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance(class80, date85, timeZone90);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance(class75, date79, timeZone90);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date74, timeZone90);
        org.jfree.data.time.Week week96 = new org.jfree.data.time.Week(date5, timeZone90);
        try {
            org.jfree.data.time.Week week97 = new org.jfree.data.time.Week(date0, timeZone90);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62194622400001L) + "'", long15 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62168313600001L) + "'", long23 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(regularTimePeriod84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeZone90);
        org.junit.Assert.assertNull(regularTimePeriod91);
        org.junit.Assert.assertNull(regularTimePeriod92);
        org.junit.Assert.assertNull(regularTimePeriod93);
        org.junit.Assert.assertNull(regularTimePeriod94);
        org.junit.Assert.assertNull(regularTimePeriod95);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.lang.String str4 = week2.toString();
        boolean boolean6 = week2.equals((java.lang.Object) 7);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 1, 32" + "'", str4.equals("Week 1, 32"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        int int5 = week2.getYearValue();
        java.util.Date date6 = week2.getEnd();
        java.util.Date date7 = week2.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) ' ', 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getFirstMillisecond();
        int int5 = week2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61959657600000L) + "'", long4 == (-61959657600000L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) 0);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getMiddleMillisecond();
//        int int7 = week4.getYearValue();
//        org.jfree.data.time.Year year8 = week4.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, year8);
//        int int10 = week2.compareTo((java.lang.Object) (short) -1);
//        long long11 = week2.getSerialIndex();
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        long long10 = week8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.previous();
        java.util.Date date12 = week8.getEnd();
        boolean boolean13 = week2.equals((java.lang.Object) week8);
        long long14 = week8.getFirstMillisecond();
        long long15 = week8.getLastMillisecond();
        int int16 = week8.getYearValue();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.next();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.next();
        java.util.Date date26 = week24.getEnd();
        java.lang.Class class27 = null;
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.next();
        java.util.Date date32 = week30.getStart();
        java.lang.Class class33 = null;
        java.util.Date date34 = null;
        java.lang.Class class35 = null;
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date32, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date26, timeZone37);
        java.lang.Class<?> wildcardClass42 = date26.getClass();
        int int43 = week8.compareTo((java.lang.Object) date26);
        java.util.Calendar calendar44 = null;
        try {
            long long45 = week8.getLastMillisecond(calendar44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62194622400001L) + "'", long10 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62194924800000L) + "'", long14 == (-62194924800000L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62194320000001L) + "'", long15 == (-62194320000001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        int int8 = week2.getWeek();
        long long9 = week2.getMiddleMillisecond();
        java.util.Date date10 = week2.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62194622400001L) + "'", long9 == (-62194622400001L));
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 0, 0" + "'", str3.equals("Week 0, 0"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168011200001L) + "'", long4 == (-62168011200001L));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        long long10 = week8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.previous();
        java.util.Date date12 = week8.getEnd();
        boolean boolean13 = week2.equals((java.lang.Object) week8);
        long long14 = week8.getFirstMillisecond();
        int int15 = week8.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 8, -1" + "'", str5.equals("Week 8, -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62194622400001L) + "'", long10 == (-62194622400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62194924800000L) + "'", long14 == (-62194924800000L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(53, year7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year7);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (byte) 0, year7);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (byte) 1, year7);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(11, year7);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(4, year7);
        java.lang.Class<?> wildcardClass14 = week13.getClass();
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getMiddleMillisecond();
//        long long3 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long10 = week9.getFirstMillisecond();
        long long11 = week9.getLastMillisecond();
        long long12 = week9.getMiddleMillisecond();
        long long13 = week9.getLastMillisecond();
        try {
            int int14 = week2.compareTo((java.lang.Object) week9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62168918400000L) + "'", long10 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62168313600001L) + "'", long11 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62168616000001L) + "'", long12 == (-62168616000001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62168313600001L) + "'", long13 == (-62168313600001L));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getFirstMillisecond();
        int int4 = week2.getWeek();
        long long5 = week2.getSerialIndex();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61792128000000L) + "'", long3 == (-61792128000000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 630L + "'", long5 == 630L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        int int5 = week2.getYearValue();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        int int11 = week9.getWeek();
        long long12 = week9.getLastMillisecond();
        long long13 = week9.getMiddleMillisecond();
        java.util.Date date14 = week9.getStart();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
        java.util.Date date19 = week17.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week17.previous();
        java.lang.Class<?> wildcardClass21 = week17.getClass();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date25 = week24.getStart();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long30 = week29.getSerialIndex();
        java.util.Date date31 = week29.getEnd();
        java.lang.Class class32 = null;
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.next();
        java.util.Date date37 = week35.getStart();
        java.lang.Class class38 = null;
        java.util.Date date39 = null;
        java.lang.Class class40 = null;
        java.util.Date date41 = null;
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date41, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date39, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date37, timeZone42);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date31, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date25, timeZone42);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date14, timeZone42);
        java.util.Locale locale49 = null;
        try {
            org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date6, timeZone42, locale49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62168313600001L) + "'", long12 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62168616000001L) + "'", long13 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 630L + "'", long30 == 630L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        java.lang.String str5 = week2.toString();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long10 = week9.getFirstMillisecond();
        long long11 = week9.getLastMillisecond();
        long long12 = week9.getMiddleMillisecond();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date16 = week15.getStart();
        int int17 = week9.compareTo((java.lang.Object) date16);
        java.util.Date date18 = week9.getStart();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.next();
        java.util.Date date23 = week21.getEnd();
        java.lang.String str24 = week21.toString();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year27 = week26.getYear();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(10, year27);
        java.lang.Class<?> wildcardClass29 = week28.getClass();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long33 = week32.getFirstMillisecond();
        java.util.Date date34 = week32.getStart();
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date34, timeZone35);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long40 = week39.getMiddleMillisecond();
        int int41 = week39.getWeek();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long45 = week44.getFirstMillisecond();
        java.util.Date date46 = week44.getStart();
        boolean boolean47 = week39.equals((java.lang.Object) date46);
        java.lang.Class class48 = null;
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week51.next();
        java.util.Date date53 = week51.getStart();
        java.lang.Class class54 = null;
        java.util.Date date55 = null;
        java.lang.Class class56 = null;
        java.util.Date date57 = null;
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date57, timeZone58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date55, timeZone58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date53, timeZone58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date46, timeZone58);
        boolean boolean63 = week21.equals((java.lang.Object) timeZone58);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date18, timeZone58);
        java.util.Locale locale65 = null;
        try {
            org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date6, timeZone58, locale65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week -1, 0" + "'", str5.equals("Week -1, 0"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62168918400000L) + "'", long10 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62168313600001L) + "'", long11 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62168616000001L) + "'", long12 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Week -1, 0" + "'", str24.equals("Week -1, 0"));
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-61157692800000L) + "'", long33 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-61791825600001L) + "'", long40 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 100 + "'", int41 == 100);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61157692800000L) + "'", long45 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        long long5 = week3.getMiddleMillisecond();
//        int int6 = week3.getYearValue();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(7, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) '#', year7);
//        java.lang.Class<?> wildcardClass11 = week10.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(100, (int) (byte) 10);
//        long long15 = week14.getSerialIndex();
//        int int16 = week10.compareTo((java.lang.Object) long15);
//        org.jfree.data.time.Year year17 = week10.getYear();
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 630L + "'", long15 == 630L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(year17);
//    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) 0);
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year5 = week4.getYear();
//        long long6 = week4.getMiddleMillisecond();
//        int int7 = week4.getYearValue();
//        org.jfree.data.time.Year year8 = week4.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, year8);
//        int int10 = week2.compareTo((java.lang.Object) (short) -1);
//        int int11 = week2.getWeek();
//        java.util.Date date12 = week2.getStart();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) '#', 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.next();
//        java.util.Date date18 = week16.getStart();
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.lang.Class class21 = null;
//        java.util.Date date22 = null;
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date18, timeZone23);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date12, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.next();
//        int int29 = week27.getYearValue();
//        long long30 = week27.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2 + "'", int29 == 2);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-62073360000000L) + "'", long30 == (-62073360000000L));
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        long long6 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        java.util.Date date11 = week9.getEnd();
        int int12 = week9.getWeek();
        java.util.Date date13 = week9.getEnd();
        boolean boolean14 = week2.equals((java.lang.Object) week9);
        java.util.Date date15 = week9.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62168616000001L) + "'", long6 == (-62168616000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date15);
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getMiddleMillisecond();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        java.lang.String str6 = week0.toString();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week0.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        long long3 = week2.getMiddleMillisecond();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        try {
            org.jfree.data.time.Year year6 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61791825600001L) + "'", long3 == (-61791825600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61791523200001L) + "'", long5 == (-61791523200001L));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str17 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException40);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException48.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        java.lang.Throwable[] throwableArray54 = timePeriodFormatException40.getSuppressed();
        java.lang.Throwable[] throwableArray55 = timePeriodFormatException40.getSuppressed();
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException40);
        java.lang.String str57 = timePeriodFormatException40.toString();
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray54);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str57.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        long long2 = week0.getMiddleMillisecond();
//        int int3 = week0.getWeek();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Date date5 = week0.getEnd();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560365999999L + "'", long2 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(53, year2);
        long long4 = week3.getSerialIndex();
        int int5 = week3.getWeek();
        java.util.Date date6 = week3.getStart();
        long long7 = week3.getSerialIndex();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107060L + "'", long4 == 107060L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 53 + "'", int5 == 53);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107060L + "'", long7 == 107060L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        long long11 = regularTimePeriod10.getMiddleMillisecond();
        java.util.Date date12 = regularTimePeriod10.getEnd();
        boolean boolean13 = week2.equals((java.lang.Object) regularTimePeriod10);
        long long14 = week2.getSerialIndex();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException18.getSuppressed();
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException18.getSuppressed();
        boolean boolean22 = week2.equals((java.lang.Object) timePeriodFormatException18);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = week2.getFirstMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168616000001L) + "'", long5 == (-62168616000001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62168313600001L) + "'", long6 == (-62168313600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61820251200001L) + "'", long11 == (-61820251200001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (short) 1);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        java.lang.Class<?> wildcardClass25 = timePeriodFormatException22.getClass();
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException22.getSuppressed();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        int int28 = week2.compareTo((java.lang.Object) timePeriodFormatException22);
        java.lang.String str29 = week2.toString();
        java.util.Calendar calendar30 = null;
        try {
            long long31 = week2.getFirstMillisecond(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Week 1, 1" + "'", str29.equals("Week 1, 1"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, 2);
        long long3 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 109L + "'", long3 == 109L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        java.lang.String str5 = week2.toString();
        java.util.Date date6 = week2.getStart();
        int int7 = week2.getWeek();
        int int8 = week2.getYearValue();
        java.lang.String str9 = week2.toString();
        long long10 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week -1, 0" + "'", str5.equals("Week -1, 0"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week -1, 0" + "'", str9.equals("Week -1, 0"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62168616000001L) + "'", long10 == (-62168616000001L));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.String str22 = timePeriodFormatException6.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException36.addSuppressed((java.lang.Throwable) timePeriodFormatException38);
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        java.lang.String str41 = timePeriodFormatException25.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException48.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray55 = timePeriodFormatException54.getSuppressed();
        timePeriodFormatException50.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str41.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray55);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone29);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date9, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.next();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week36.next();
        java.lang.Class<?> wildcardClass38 = regularTimePeriod37.getClass();
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
        java.util.Date date43 = week41.getEnd();
        java.lang.Class class44 = null;
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week47.next();
        java.util.Date date49 = week47.getStart();
        java.lang.Class class50 = null;
        java.util.Date date51 = null;
        java.lang.Class class52 = null;
        java.util.Date date53 = null;
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date53, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date51, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date49, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date43, timeZone54);
        boolean boolean59 = week32.equals((java.lang.Object) timeZone54);
        int int60 = week32.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str17 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException40);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException49 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException49.addSuppressed((java.lang.Throwable) timePeriodFormatException51);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException56 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException54.addSuppressed((java.lang.Throwable) timePeriodFormatException56);
        timePeriodFormatException49.addSuppressed((java.lang.Throwable) timePeriodFormatException56);
        java.lang.Class<?> wildcardClass59 = timePeriodFormatException56.getClass();
        java.lang.Throwable[] throwableArray60 = timePeriodFormatException56.getSuppressed();
        timePeriodFormatException45.addSuppressed((java.lang.Throwable) timePeriodFormatException56);
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException56);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(throwableArray60);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1697L + "'", long4 == 1697L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61157390400001L) + "'", long5 == (-61157390400001L));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        java.util.Date date9 = week8.getStart();
        int int10 = week2.compareTo((java.lang.Object) date9);
        java.util.Date date11 = week2.getStart();
        long long12 = week2.getFirstMillisecond();
        java.util.Calendar calendar13 = null;
        try {
            week2.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168616000001L) + "'", long5 == (-62168616000001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62168918400000L) + "'", long12 == (-62168918400000L));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        java.util.Date date15 = week13.getStart();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone20);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date9);
        long long27 = week26.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-61830835200001L) + "'", long27 == (-61830835200001L));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year6 = week5.getYear();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(53, year6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(0, year6);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 0, year6);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(12, year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
        org.jfree.data.time.Year year12 = week10.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(7, year12);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.lang.String str3 = week2.toString();
        int int4 = week2.getYearValue();
        java.lang.Object obj5 = null;
        int int6 = week2.compareTo(obj5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, 53);
        long long10 = week9.getFirstMillisecond();
        long long11 = week9.getSerialIndex();
        boolean boolean12 = week2.equals((java.lang.Object) week9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week9.previous();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 1, 32" + "'", str3.equals("Week 1, 32"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-60495436800000L) + "'", long10 == (-60495436800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2809L + "'", long11 == 2809L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date10 = week9.getEnd();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.next();
        java.lang.Class<?> wildcardClass18 = regularTimePeriod17.getClass();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.next();
        java.util.Date date23 = week21.getEnd();
        java.lang.Class class24 = null;
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.next();
        java.util.Date date29 = week27.getStart();
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date29, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date23, timeZone34);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date23);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date23);
        java.lang.Class class41 = null;
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.next();
        java.util.Date date46 = week44.getStart();
        java.lang.Class class47 = null;
        java.util.Date date48 = null;
        java.lang.Class class49 = null;
        java.util.Date date50 = null;
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date50, timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date48, timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date46, timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date23, timeZone51);
        java.lang.Class<?> wildcardClass56 = regularTimePeriod55.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62194622400001L) + "'", long4 == (-62194622400001L));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(wildcardClass56);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException10.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException31.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException37.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        java.lang.String str42 = timePeriodFormatException26.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException44.addSuppressed((java.lang.Throwable) timePeriodFormatException46);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException49 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException49.addSuppressed((java.lang.Throwable) timePeriodFormatException51);
        timePeriodFormatException44.addSuppressed((java.lang.Throwable) timePeriodFormatException51);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException55 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray56 = timePeriodFormatException55.getSuppressed();
        timePeriodFormatException51.addSuppressed((java.lang.Throwable) timePeriodFormatException55);
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException55);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException55);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException61 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException63 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException61.addSuppressed((java.lang.Throwable) timePeriodFormatException63);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException66 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException68 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException66.addSuppressed((java.lang.Throwable) timePeriodFormatException68);
        timePeriodFormatException61.addSuppressed((java.lang.Throwable) timePeriodFormatException68);
        java.lang.Class<?> wildcardClass71 = timePeriodFormatException68.getClass();
        java.lang.Throwable[] throwableArray72 = timePeriodFormatException68.getSuppressed();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException68);
        boolean boolean74 = week2.equals((java.lang.Object) timePeriodFormatException10);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str42.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNotNull(throwableArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(10, year5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(32, year5);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(5, year5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((-2012), year5);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, (int) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        long long11 = regularTimePeriod10.getMiddleMillisecond();
        java.util.Date date12 = regularTimePeriod10.getEnd();
        boolean boolean13 = week2.equals((java.lang.Object) regularTimePeriod10);
        long long14 = week2.getSerialIndex();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException18.getSuppressed();
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException18.getSuppressed();
        boolean boolean22 = week2.equals((java.lang.Object) timePeriodFormatException18);
        java.util.Date date23 = week2.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168918400000L) + "'", long3 == (-62168918400000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62168313600001L) + "'", long4 == (-62168313600001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168616000001L) + "'", long5 == (-62168616000001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62168313600001L) + "'", long6 == (-62168313600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61820251200001L) + "'", long11 == (-61820251200001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 12);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        long long4 = week3.getFirstMillisecond();
//        int int5 = week2.compareTo((java.lang.Object) long4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, (int) (byte) 10);
//        java.util.Date date9 = week8.getStart();
//        int int10 = week2.compareTo((java.lang.Object) date9);
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week2.getMiddleMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getStart();
        int int5 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(53, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (byte) 0, year3);
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        int int6 = week5.getYearValue();
        long long7 = week5.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException11.getSuppressed();
        boolean boolean20 = week5.equals((java.lang.Object) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 32");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        java.lang.String str39 = timePeriodFormatException34.toString();
        java.lang.String str40 = timePeriodFormatException34.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        java.lang.Throwable[] throwableArray42 = timePeriodFormatException34.getSuppressed();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61831137600001L) + "'", long7 == (-61831137600001L));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str39.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 32" + "'", str40.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 32"));
        org.junit.Assert.assertNotNull(throwableArray42);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 51);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (51) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        long long4 = week2.getMiddleMillisecond();
//        int int5 = week2.getYearValue();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(7, year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, year6);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(53, year11);
//        long long13 = week12.getSerialIndex();
//        boolean boolean14 = week8.equals((java.lang.Object) week12);
//        java.lang.String str15 = week8.toString();
//        java.util.Date date16 = week8.getStart();
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107060L + "'", long13 == 107060L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 100, 2019" + "'", str15.equals("Week 100, 2019"));
//        org.junit.Assert.assertNotNull(date16);
//    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        long long3 = week1.getMiddleMillisecond();
//        int int4 = week1.getYearValue();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) ' ', year5);
//        long long7 = week6.getLastMillisecond();
//        long long8 = week6.getSerialIndex();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1565506799999L + "'", long7 == 1565506799999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107039L + "'", long8 == 107039L);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getStart();
        java.lang.String str7 = week2.toString();
        long long8 = week2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62168313600001L) + "'", long5 == (-62168313600001L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week -1, 0" + "'", str7.equals("Week -1, 0"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62168616000001L) + "'", long8 == (-62168616000001L));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
        java.lang.Class<?> wildcardClass9 = regularTimePeriod8.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
        java.util.Date date14 = week12.getEnd();
        java.lang.Class class15 = null;
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
        java.util.Date date20 = week18.getStart();
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone25);
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone34);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date14, timeZone34);
        int int38 = week2.compareTo((java.lang.Object) date14);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) (byte) 1, (int) ' ');
        java.util.Date date42 = week41.getEnd();
        java.lang.Class class43 = null;
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date44, timeZone45);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date42, timeZone45);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date14, timeZone45);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61157692800000L) + "'", long3 == (-61157692800000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod46);
    }
}

