import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        java.awt.Font font4 = null;
        try {
            numberAxis1.setTickLabelFont(font4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.Stroke stroke1 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder3 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "hi!", (double) 1L, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Comparable comparable0 = null;
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick(comparable0, textBlock1, textBlockAnchor2, textAnchor3, 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.setCursor((double) (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (-1.0f), range1);
        org.jfree.data.Range range3 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toRangeHeight(range3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            statisticalBarRenderer0.drawDomainMarker(graphics2D5, categoryPlot6, categoryAxis7, categoryMarker8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint5 = statisticalBarRenderer0.getBaseOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        try {
            statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range2 = null;
        try {
            numberAxis1.setRange(range2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.resizeRange(10.0d, (double) 100.0f);
        double double9 = numberAxis1.getUpperMargin();
        java.awt.Shape shape10 = null;
        try {
            numberAxis1.setRightArrow(shape10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(shape0, shape1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setLabelToolTip("");
        java.lang.String str6 = numberAxis1.getLabelURL();
        numberAxis1.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.data.Range range10 = null;
        try {
            numberAxis1.setRangeWithMargins(range10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Stroke stroke5 = null;
        try {
            statisticalBarRenderer0.setBaseStroke(stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 100L, 0.0d, 10, (java.lang.Comparable) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("PlotOrientation.HORIZONTAL", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation8, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(itemLabelPosition5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = textTitle7.getPosition();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = textTitle10.getPosition();
        boolean boolean12 = textTitle7.equals((java.lang.Object) rectangleEdge11);
        try {
            double double13 = numberAxis1.valueToJava2D((double) (short) -1, rectangle2D5, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        axisState1.cursorRight((double) 10L);
        axisState1.setMax(3.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint5 = statisticalBarRenderer0.getBaseOutlinePaint();
        boolean boolean6 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(0, categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 'a');
        java.lang.Object obj2 = chartChangeEvent1.getSource();
        org.jfree.chart.JFreeChart jFreeChart3 = chartChangeEvent1.getChart();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 'a' + "'", obj2.equals('a'));
        org.junit.Assert.assertNull(jFreeChart3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = null;
        numberAxis2.setPlot(plot3);
        numberAxis2.setLabelToolTip("");
        boolean boolean7 = rectangleAnchor0.equals((java.lang.Object) "");
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = statisticalBarRenderer0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = statisticalBarRenderer0.getSeriesToolTipGenerator((int) (short) 0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        try {
            statisticalBarRenderer0.setSeriesURLGenerator((int) (short) -1, categoryURLGenerator5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getOptionalLibraries();
        basicProjectInfo5.setVersion("PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNotNull(libraryArray6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.resizeRange(10.0d, (double) 100.0f);
        numberAxis1.setAutoRangeIncludesZero(true);
        org.jfree.data.Range range11 = null;
        try {
            numberAxis1.setDefaultAutoRange(range11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) 0, (float) '4', (float) (byte) 1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        java.awt.Paint paint5 = statisticalBarRenderer0.getSeriesOutlinePaint((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        java.lang.String str1 = tickType0.toString();
        boolean boolean3 = tickType0.equals((java.lang.Object) '4');
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MINOR" + "'", str1.equals("MINOR"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.clone(shape0);
        org.junit.Assert.assertNull(shape1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setLabelToolTip("");
        java.awt.Paint paint6 = null;
        try {
            numberAxis1.setAxisLinePaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.data.general.DatasetGroup datasetGroup3 = new org.jfree.data.general.DatasetGroup();
        boolean boolean4 = itemLabelAnchor2.equals((java.lang.Object) datasetGroup3);
        columnArrangement0.add((org.jfree.chart.block.Block) blockContainer1, (java.lang.Object) boolean4);
        double double6 = blockContainer1.getContentYOffset();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("MINOR");
        try {
            blockContainer1.add((org.jfree.chart.block.Block) textTitle8, (java.lang.Object) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setLabelToolTip("");
        java.lang.String str6 = numberAxis1.getLabelURL();
        double double7 = numberAxis1.getLowerBound();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Shape shape0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.LEFT;
        try {
            java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, (double) '4', 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabel();
        numberAxis1.setPositiveArrowVisible(true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("MINOR", font2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = textTitle7.getPosition();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = textTitle10.getPosition();
        boolean boolean12 = textTitle7.equals((java.lang.Object) rectangleEdge11);
        boolean boolean13 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge11);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        try {
            org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=0.0]", font2, paint5, rectangleEdge11, horizontalAlignment14, verticalAlignment15, rectangleInsets16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = textTitle1.getPosition();
        textTitle1.setNotify(false);
        java.lang.String str5 = textTitle1.getToolTipText();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setLabelToolTip("");
        java.lang.String str6 = numberAxis1.getLabelURL();
        numberAxis1.setAutoTickUnitSelection(true);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setLabelToolTip("");
        java.lang.String str6 = numberAxis1.getLabelURL();
        numberAxis1.setRangeAboutValue((double) '4', (double) 3);
        numberAxis1.setLabelToolTip("PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        boolean boolean2 = unitType0.equals((java.lang.Object) itemLabelAnchor1);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleEdge.TOP", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 0.2d, 3.0d, (int) (byte) 10, (java.lang.Comparable) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 'a', (float) ' ', (-1.0d), 2.0f, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.data.general.DatasetGroup datasetGroup3 = new org.jfree.data.general.DatasetGroup();
        boolean boolean4 = itemLabelAnchor2.equals((java.lang.Object) datasetGroup3);
        columnArrangement0.add((org.jfree.chart.block.Block) blockContainer1, (java.lang.Object) boolean4);
        double double6 = blockContainer1.getContentYOffset();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.lang.Object obj9 = null;
        try {
            java.lang.Object obj10 = blockContainer1.draw(graphics2D7, rectangle2D8, obj9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("PlotOrientation.HORIZONTAL");
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, (java.awt.Paint) color2, 1.0f, 0, textMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.plot.Plot plot2 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", font1, plot2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.extendHeight((double) (byte) 1);
        double double4 = rectangleInsets0.getLeft();
        double double6 = rectangleInsets0.trimWidth(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-6.0d) + "'", double6 == (-6.0d));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke2 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setItemMargin((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Color color2 = java.awt.Color.getColor("MINOR", 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) (short) -1);
        numberAxis1.setAutoRangeStickyZero(false);
        org.jfree.data.Range range6 = null;
        try {
            numberAxis1.setDefaultAutoRange(range6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) (byte) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj1 = null;
        boolean boolean2 = borderArrangement0.equals(obj1);
        org.jfree.chart.block.BlockContainer blockContainer3 = null;
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = borderArrangement0.arrange(blockContainer3, graphics2D4, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        java.awt.Paint paint7 = statisticalBarRenderer0.lookupSeriesPaint(100);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        try {
            statisticalBarRenderer0.setSeriesItemLabelPaint((int) (byte) -1, (java.awt.Paint) color9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        axisState1.cursorRight((double) 10L);
        double double4 = axisState1.getMax();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("MINOR", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.Plot plot5 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", font2, plot5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = null;
        try {
            numberAxis0.setRangeWithMargins(range1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = textTitle1.getPosition();
        java.lang.String str3 = textTitle1.getText();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = org.jfree.chart.block.RectangleConstraint.NONE;
        java.lang.String str6 = rectangleConstraint5.toString();
        try {
            org.jfree.chart.util.Size2D size2D7 = textTitle1.arrange(graphics2D4, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MINOR" + "'", str3.equals("MINOR"));
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str6.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) (short) -1);
        boolean boolean4 = numberAxis1.isAutoTickUnitSelection();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = textTitle8.getPosition();
        try {
            double double10 = numberAxis1.lengthToJava2D((double) (byte) 1, rectangle2D6, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.trimWidth(3.0d);
        double double4 = rectangleInsets0.extendHeight((double) 2);
        double double6 = rectangleInsets0.calculateBottomOutset(0.05d);
        double double7 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double4 = statisticalBarRenderer3.getItemMargin();
        java.awt.Stroke stroke6 = statisticalBarRenderer3.getSeriesOutlineStroke(0);
        java.awt.Paint paint8 = statisticalBarRenderer3.getSeriesOutlinePaint((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = statisticalBarRenderer3.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor10 = itemLabelPosition9.getTextAnchor();
        try {
            org.jfree.chart.axis.NumberTick numberTick12 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-6.0d), "RectangleEdge.TOP", textAnchor2, textAnchor10, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = null;
        try {
            numberAxis0.setRangeWithMargins(range1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!", font2);
        boolean boolean4 = tickType0.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.lang.Object obj1 = null;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 10L, obj1);
        java.lang.Object obj3 = null;
        boolean boolean4 = keyedObject2.equals(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = projectInfo0.getLogo();
        org.junit.Assert.assertNull(image1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        boolean boolean4 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        boolean boolean5 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(100, categoryToolTipGenerator7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            statisticalBarRenderer0.drawDomainMarker(graphics2D9, categoryPlot10, categoryAxis11, categoryMarker12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.extendHeight((double) (byte) 1);
        double double4 = rectangleInsets0.getLeft();
        double double6 = rectangleInsets0.calculateLeftOutset(1.0E-8d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.lang.Object obj1 = blockContainer0.clone();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        try {
            java.lang.Object obj11 = blockContainer0.draw(graphics2D2, rectangle2D3, (java.lang.Object) colorModel5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "MINOR", (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.lang.Class class0 = null;
        try {
            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        axisState1.cursorRight((double) 10L);
        axisState1.setCursor(1.0d);
        java.util.List list6 = axisState1.getTicks();
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(false, false);
        double double7 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke9 = statisticalBarRenderer0.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = statisticalBarRenderer0.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color13 = java.awt.Color.cyan;
        statisticalBarRenderer0.setBaseFillPaint((java.awt.Paint) color13, false);
        java.awt.Shape shape16 = statisticalBarRenderer0.getBaseShape();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=0.0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.resizeRange(10.0d, (double) 100.0f);
        double double9 = numberAxis1.getUpperMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener10 = null;
        numberAxis1.removeChangeListener(axisChangeListener10);
        java.text.NumberFormat numberFormat12 = numberAxis1.getNumberFormatOverride();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = textTitle16.getPosition();
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = textTitle19.getPosition();
        boolean boolean21 = textTitle16.equals((java.lang.Object) rectangleEdge20);
        java.lang.String str22 = rectangleEdge20.toString();
        try {
            double double23 = numberAxis1.valueToJava2D(0.0d, rectangle2D14, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "RectangleEdge.TOP" + "'", str22.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = textTitle1.getPosition();
        java.lang.String str3 = textTitle1.getText();
        boolean boolean5 = textTitle1.equals((java.lang.Object) "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        double double6 = textTitle1.getContentXOffset();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MINOR" + "'", str3.equals("MINOR"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1L));
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) 10L, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("MINOR");
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("ThreadContext", graphics2D1, 0.0f, (float) 3, 0.0d, (float) (short) 0, 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, 4.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.lang.Object obj1 = null;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 10L, obj1);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double5 = numberAxis4.getUpperBound();
        numberAxis4.setTickLabelsVisible(true);
        keyedObject2.setObject((java.lang.Object) numberAxis4);
        java.lang.Object obj9 = keyedObject2.clone();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        boolean boolean7 = basicProjectInfo5.equals((java.lang.Object) rectangleAnchor6);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = statisticalBarRenderer8.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = statisticalBarRenderer8.getSeriesToolTipGenerator((int) (short) 0);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = statisticalBarRenderer8.getGradientPaintTransformer();
        boolean boolean13 = rectangleAnchor6.equals((java.lang.Object) gradientPaintTransformer12);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer9);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertNotNull(gradientPaintTransformer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        double double3 = numberAxis1.getUpperBound();
        boolean boolean4 = numberAxis1.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int1 = color0.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        boolean boolean4 = blockBorder2.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder2.getInsets();
        java.awt.Paint paint6 = blockBorder2.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setLabelURL("RectangleEdge.TOP");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 0, (float) 10);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        basicProjectInfo5.setVersion("hi!");
        java.lang.String str8 = basicProjectInfo5.getInfo();
        basicProjectInfo5.addOptionalLibrary("CategoryLabelWidthType.CATEGORY");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.resizeRange(10.0d, (double) 100.0f);
        numberAxis1.setAutoRangeIncludesZero(true);
        java.lang.String str11 = numberAxis1.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = numberAxis1.getTickLabelInsets();
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.resizeRange(10.0d, (double) 100.0f);
        org.jfree.data.Range range9 = null;
        try {
            numberAxis1.setRange(range9, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.extendHeight((double) (byte) 1);
        double double4 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            rectangleInsets0.trim(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("LengthConstraintType.FIXED", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'right' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        axisState1.cursorRight((double) 10L);
        axisState1.setCursor(1.0d);
        double double6 = axisState1.getCursor();
        double double7 = axisState1.getMax();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textBlock0.getLineAlignment();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        textBlock0.draw(graphics2D2, 0.0f, 10.0f, textBlockAnchor5);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateTopOutset(7.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!", font2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int5 = color4.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("CategoryLabelWidthType.CATEGORY", font2, (java.awt.Paint) color4);
        java.awt.Paint paint7 = labelBlock6.getPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int1 = color0.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        boolean boolean4 = blockBorder2.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder2.getInsets();
        double double7 = rectangleInsets5.calculateBottomInset(0.2d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bottom' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        java.util.List list6 = blockContainer5.getBlocks();
        blockContainer5.setMargin((double) '#', (double) (short) 0, (double) 100L, (double) (short) -1);
        java.lang.Object obj12 = blockContainer5.clone();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle3.getPosition();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = textTitle6.getPosition();
        boolean boolean8 = textTitle3.equals((java.lang.Object) rectangleEdge7);
        boolean boolean9 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge7);
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = axisSpace0.reserved(rectangle2D1, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setBottom(10.0d);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = axisSpace0.expand(rectangle2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.resizeRange(10.0d, (double) 100.0f);
        double double9 = numberAxis1.getUpperMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener10 = null;
        numberAxis1.removeChangeListener(axisChangeListener10);
        double double12 = numberAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot4 = null;
        numberAxis3.setPlot(plot4);
        numberAxis3.setLabelToolTip("");
        java.lang.String str8 = numberAxis3.getLabelURL();
        numberAxis3.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = statisticalBarRenderer12.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean17 = axisLocation15.equals((java.lang.Object) 2);
        categoryPlot14.setRangeAxisLocation(axisLocation15);
        categoryPlot14.configureRangeAxes();
        org.jfree.chart.plot.Marker marker20 = null;
        try {
            categoryPlot14.addRangeMarker(marker20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        java.awt.Paint paint5 = statisticalBarRenderer0.getSeriesOutlinePaint((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        boolean boolean9 = statisticalBarRenderer0.getItemVisible((int) (short) 100, (int) '4');
        statisticalBarRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        boolean boolean12 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        java.lang.String str1 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.FULL" + "'", str1.equals("RangeType.FULL"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getHorizontalAlignment();
        double double3 = textTitle1.getContentXOffset();
        java.awt.Paint paint4 = textTitle1.getPaint();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot4 = null;
        numberAxis3.setPlot(plot4);
        numberAxis3.setLabelToolTip("");
        java.lang.String str8 = numberAxis3.getLabelURL();
        numberAxis3.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = statisticalBarRenderer12.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean17 = axisLocation15.equals((java.lang.Object) 2);
        categoryPlot14.setRangeAxisLocation(axisLocation15);
        categoryPlot14.clearRangeAxes();
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        try {
            categoryPlot14.drawBackground(graphics2D20, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.trimWidth(3.0d);
        double double3 = rectangleInsets0.getLeft();
        double double5 = rectangleInsets0.calculateTopInset(100.0d);
        double double7 = rectangleInsets0.extendWidth((double) '#');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 37.0d + "'", double7 == 37.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("CategoryLabelWidthType.CATEGORY", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets1.getRight();
        double double4 = rectangleInsets1.extendHeight((double) (byte) 1);
        double double5 = rectangleInsets1.getLeft();
        boolean boolean6 = centerArrangement0.equals((java.lang.Object) double5);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer();
        java.lang.Object obj8 = blockContainer7.clone();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.Range range11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) 0.0f, range11);
        double double13 = rectangleConstraint12.getHeight();
        try {
            org.jfree.chart.util.Size2D size2D14 = centerArrangement0.arrange(blockContainer7, graphics2D9, rectangleConstraint12);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.0d + "'", double4 == 7.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint5 = statisticalBarRenderer0.getBaseOutlinePaint();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int8 = color7.getAlpha();
        float[] floatArray13 = new float[] { 0L, 0L, (short) 1, 1.0f };
        float[] floatArray14 = color7.getRGBColorComponents(floatArray13);
        statisticalBarRenderer0.setSeriesOutlinePaint((int) ' ', (java.awt.Paint) color7, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator17 = statisticalBarRenderer0.getLegendItemURLGenerator();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_BLUE;
        try {
            statisticalBarRenderer0.setSeriesOutlinePaint((-8355585), (java.awt.Paint) color20, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator17);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator18);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.awt.Paint paint0 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.width;
        double double2 = size2D0.width;
        size2D0.setHeight((double) 10.0f);
        java.lang.String str5 = size2D0.toString();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Size2D[width=0.0, height=10.0]" + "'", str5.equals("Size2D[width=0.0, height=10.0]"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, rectangleAnchor10, (double) (-1.0f), (double) (byte) 10);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int16 = color15.getAlpha();
        java.awt.Color color18 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.AffineTransform affineTransform22 = null;
        java.awt.RenderingHints renderingHints23 = null;
        java.awt.PaintContext paintContext24 = color18.createContext(colorModel19, rectangle20, rectangle2D21, affineTransform22, renderingHints23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ShapeList shapeList27 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape29, rectangleAnchor30, (double) (-1.0f), (double) (byte) 10);
        shapeList27.setShape(2, shape29);
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer36 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double37 = statisticalBarRenderer36.getItemMargin();
        java.awt.Stroke stroke39 = statisticalBarRenderer36.getSeriesOutlineStroke(0);
        statisticalBarRenderer36.setBaseSeriesVisibleInLegend(false, false);
        double double43 = statisticalBarRenderer36.getItemMargin();
        java.awt.Stroke stroke45 = statisticalBarRenderer36.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator48 = statisticalBarRenderer36.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color49 = java.awt.Color.cyan;
        statisticalBarRenderer36.setBaseFillPaint((java.awt.Paint) color49, false);
        org.jfree.chart.LegendItem legendItem52 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "", true, shape13, false, (java.awt.Paint) color15, true, (java.awt.Paint) color18, stroke25, true, shape29, stroke35, (java.awt.Paint) color49);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer53 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer54 = statisticalBarRenderer53.getGradientPaintTransformer();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer56 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double57 = statisticalBarRenderer56.getItemMargin();
        java.awt.Stroke stroke59 = statisticalBarRenderer56.getSeriesOutlineStroke(0);
        java.awt.Paint paint61 = statisticalBarRenderer56.getSeriesOutlinePaint((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition62 = statisticalBarRenderer56.getBasePositiveItemLabelPosition();
        statisticalBarRenderer53.setSeriesPositiveItemLabelPosition((int) '4', itemLabelPosition62, false);
        java.awt.Stroke stroke65 = statisticalBarRenderer53.getErrorIndicatorStroke();
        java.awt.Font font68 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle69 = new org.jfree.chart.title.TextTitle("hi!", font68);
        java.awt.Color color70 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int71 = color70.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock72 = new org.jfree.chart.block.LabelBlock("CategoryLabelWidthType.CATEGORY", font68, (java.awt.Paint) color70);
        try {
            org.jfree.chart.LegendItem legendItem73 = new org.jfree.chart.LegendItem(attributedString0, "RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=0.0]", "", "Size2D[width=0.0, height=10.0]", shape13, stroke65, (java.awt.Paint) color70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintContext24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.2d + "'", double37 == 0.2d);
        org.junit.Assert.assertNull(stroke39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.2d + "'", double43 == 0.2d);
        org.junit.Assert.assertNull(stroke45);
        org.junit.Assert.assertNull(categoryToolTipGenerator48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(gradientPaintTransformer54);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.2d + "'", double57 == 0.2d);
        org.junit.Assert.assertNull(stroke59);
        org.junit.Assert.assertNull(paint61);
        org.junit.Assert.assertNotNull(itemLabelPosition62);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 255 + "'", int71 == 255);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int3 = color2.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        boolean boolean6 = blockBorder4.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double8 = statisticalBarRenderer7.getItemMargin();
        java.awt.Stroke stroke10 = statisticalBarRenderer7.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = statisticalBarRenderer7.getLegendItemToolTipGenerator();
        java.awt.Paint paint12 = statisticalBarRenderer7.getBaseOutlinePaint();
        boolean boolean13 = statisticalBarRenderer7.getAutoPopulateSeriesOutlineStroke();
        boolean boolean14 = blockBorder4.equals((java.lang.Object) statisticalBarRenderer7);
        java.awt.Paint paint17 = statisticalBarRenderer7.getItemFillPaint((int) (short) 1, (int) (short) 0);
        statisticalBarRenderer0.setBaseItemLabelPaint(paint17);
        java.awt.Paint paint19 = null;
        try {
            statisticalBarRenderer0.setBaseOutlinePaint(paint19, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("7,6,5,8,3,10,0,8,-1,6,0,3,3,2,5,3,7,6,7,6", "7,6,5,8,3,10,0,8,-1,6,0,3,3,2,5,3,7,6,7,6", "RectangleEdge.TOP", "RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=0.0]");
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = null;
        numberAxis2.setPlot(plot3);
        numberAxis2.setNegativeArrowVisible(true);
        numberAxis2.resizeRange(10.0d, (double) 100.0f);
        double double10 = numberAxis2.getUpperMargin();
        java.awt.Font font11 = numberAxis2.getLabelFont();
        boolean boolean12 = gradientPaintTransformType0.equals((java.lang.Object) font11);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setLabelToolTip("");
        java.awt.Paint paint6 = numberAxis1.getTickLabelPaint();
        java.awt.Stroke stroke7 = numberAxis1.getTickMarkStroke();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double9 = statisticalBarRenderer8.getItemMargin();
        java.awt.Stroke stroke11 = statisticalBarRenderer8.getSeriesOutlineStroke(0);
        boolean boolean12 = statisticalBarRenderer8.getBaseItemLabelsVisible();
        java.awt.Stroke stroke15 = statisticalBarRenderer8.getItemOutlineStroke((int) (short) 0, 10);
        numberAxis1.setTickMarkStroke(stroke15);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, (double) (-1.0f), (double) (byte) 10);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int12 = color11.getAlpha();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ShapeList shapeList23 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, (double) (-1.0f), (double) (byte) 10);
        shapeList23.setShape(2, shape25);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double33 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke35 = statisticalBarRenderer32.getSeriesOutlineStroke(0);
        statisticalBarRenderer32.setBaseSeriesVisibleInLegend(false, false);
        double double39 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke41 = statisticalBarRenderer32.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = statisticalBarRenderer32.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color45 = java.awt.Color.cyan;
        statisticalBarRenderer32.setBaseFillPaint((java.awt.Paint) color45, false);
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "", true, shape9, false, (java.awt.Paint) color11, true, (java.awt.Paint) color14, stroke21, true, shape25, stroke31, (java.awt.Paint) color45);
        int int49 = legendItem48.getSeriesIndex();
        int int50 = legendItem48.getSeriesIndex();
        java.awt.Shape shape51 = legendItem48.getLine();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double53 = statisticalBarRenderer52.getItemMargin();
        java.awt.Stroke stroke55 = statisticalBarRenderer52.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = statisticalBarRenderer52.getLegendItemToolTipGenerator();
        java.awt.Paint paint57 = statisticalBarRenderer52.getBaseOutlinePaint();
        java.awt.Color color58 = java.awt.Color.darkGray;
        statisticalBarRenderer52.setBaseOutlinePaint((java.awt.Paint) color58, false);
        org.jfree.chart.title.LegendGraphic legendGraphic61 = new org.jfree.chart.title.LegendGraphic(shape51, (java.awt.Paint) color58);
        java.awt.Graphics2D graphics2D62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer64 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double65 = statisticalBarRenderer64.getItemMargin();
        java.awt.Stroke stroke67 = statisticalBarRenderer64.getSeriesOutlineStroke(0);
        statisticalBarRenderer64.setDrawBarOutline(true);
        java.awt.Paint paint71 = statisticalBarRenderer64.lookupSeriesOutlinePaint((int) (short) 100);
        try {
            java.lang.Object obj72 = legendGraphic61.draw(graphics2D62, rectangle2D63, (java.lang.Object) paint71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNull(stroke41);
        org.junit.Assert.assertNull(categoryToolTipGenerator44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.2d + "'", double53 == 0.2d);
        org.junit.Assert.assertNull(stroke55);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.2d + "'", double65 == 0.2d);
        org.junit.Assert.assertNull(stroke67);
        org.junit.Assert.assertNotNull(paint71);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 0, (float) 0, (float) 0L);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.trimWidth(3.0d);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint5 = statisticalBarRenderer0.getBaseOutlinePaint();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int8 = color7.getAlpha();
        float[] floatArray13 = new float[] { 0L, 0L, (short) 1, 1.0f };
        float[] floatArray14 = color7.getRGBColorComponents(floatArray13);
        statisticalBarRenderer0.setSeriesOutlinePaint((int) ' ', (java.awt.Paint) color7, false);
        boolean boolean17 = statisticalBarRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = null;
        statisticalBarRenderer0.setSeriesURLGenerator((int) 'a', categoryURLGenerator21, true);
        statisticalBarRenderer0.setSeriesVisible((int) (byte) 0, (java.lang.Boolean) false);
        java.awt.Stroke stroke29 = statisticalBarRenderer0.getItemStroke((int) (byte) 1, 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 100L, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement5);
        java.util.List list7 = blockContainer6.getBlocks();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockContainer6, jFreeChart8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint11.toFixedHeight((double) 100.0f);
        try {
            org.jfree.chart.util.Size2D size2D14 = centerArrangement0.arrange(blockContainer6, graphics2D10, rectangleConstraint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double2 = statisticalBarRenderer1.getItemMargin();
        java.awt.Stroke stroke4 = statisticalBarRenderer1.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = statisticalBarRenderer1.getLegendItemToolTipGenerator();
        java.awt.Paint paint6 = statisticalBarRenderer1.getBaseOutlinePaint();
        boolean boolean7 = sortOrder0.equals((java.lang.Object) statisticalBarRenderer1);
        org.jfree.data.Range range9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (-1.0f), range9);
        boolean boolean11 = sortOrder0.equals((java.lang.Object) (-1.0f));
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 2, (double) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition1, categoryLabelPosition2, categoryLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!", font2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int5 = color4.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("CategoryLabelWidthType.CATEGORY", font2, (java.awt.Paint) color4);
        java.awt.Paint paint7 = null;
        try {
            labelBlock6.setPaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot4 = null;
        numberAxis3.setPlot(plot4);
        numberAxis3.setLabelToolTip("");
        java.lang.String str8 = numberAxis3.getLabelURL();
        numberAxis3.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = statisticalBarRenderer12.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean17 = axisLocation15.equals((java.lang.Object) 2);
        categoryPlot14.setRangeAxisLocation(axisLocation15);
        categoryPlot14.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot14.getRenderer((int) '4');
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color24 = java.awt.Color.ORANGE;
        boolean boolean25 = layer23.equals((java.lang.Object) color24);
        try {
            categoryPlot14.addRangeMarker(marker22, layer23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, (double) (-1.0f), (double) (byte) 10);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int12 = color11.getAlpha();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ShapeList shapeList23 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, (double) (-1.0f), (double) (byte) 10);
        shapeList23.setShape(2, shape25);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double33 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke35 = statisticalBarRenderer32.getSeriesOutlineStroke(0);
        statisticalBarRenderer32.setBaseSeriesVisibleInLegend(false, false);
        double double39 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke41 = statisticalBarRenderer32.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = statisticalBarRenderer32.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color45 = java.awt.Color.cyan;
        statisticalBarRenderer32.setBaseFillPaint((java.awt.Paint) color45, false);
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "", true, shape9, false, (java.awt.Paint) color11, true, (java.awt.Paint) color14, stroke21, true, shape25, stroke31, (java.awt.Paint) color45);
        int int49 = legendItem48.getSeriesIndex();
        int int50 = legendItem48.getSeriesIndex();
        java.awt.Shape shape51 = legendItem48.getLine();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double53 = statisticalBarRenderer52.getItemMargin();
        java.awt.Stroke stroke55 = statisticalBarRenderer52.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = statisticalBarRenderer52.getLegendItemToolTipGenerator();
        java.awt.Paint paint57 = statisticalBarRenderer52.getBaseOutlinePaint();
        java.awt.Color color58 = java.awt.Color.darkGray;
        statisticalBarRenderer52.setBaseOutlinePaint((java.awt.Paint) color58, false);
        org.jfree.chart.title.LegendGraphic legendGraphic61 = new org.jfree.chart.title.LegendGraphic(shape51, (java.awt.Paint) color58);
        java.awt.Color color62 = java.awt.Color.yellow;
        legendGraphic61.setLinePaint((java.awt.Paint) color62);
        java.awt.Graphics2D graphics2D64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer66 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double67 = statisticalBarRenderer66.getItemMargin();
        java.awt.Stroke stroke69 = statisticalBarRenderer66.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator70 = statisticalBarRenderer66.getLegendItemToolTipGenerator();
        java.awt.Paint paint71 = statisticalBarRenderer66.getBaseOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle74 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = textTitle74.getPosition();
        org.jfree.chart.title.TextTitle textTitle77 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = textTitle77.getPosition();
        boolean boolean79 = textTitle74.equals((java.lang.Object) rectangleEdge78);
        java.awt.Color color80 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        textTitle74.setPaint((java.awt.Paint) color80);
        float[] floatArray82 = null;
        float[] floatArray83 = color80.getComponents(floatArray82);
        statisticalBarRenderer66.setSeriesFillPaint((int) (byte) 100, (java.awt.Paint) color80, true);
        boolean boolean86 = statisticalBarRenderer66.getBaseItemLabelsVisible();
        try {
            java.lang.Object obj87 = legendGraphic61.draw(graphics2D64, rectangle2D65, (java.lang.Object) boolean86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNull(stroke41);
        org.junit.Assert.assertNull(categoryToolTipGenerator44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.2d + "'", double53 == 0.2d);
        org.junit.Assert.assertNull(stroke55);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.2d + "'", double67 == 0.2d);
        org.junit.Assert.assertNull(stroke69);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator70);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(rectangleEdge75);
        org.junit.Assert.assertNotNull(rectangleEdge78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertNotNull(floatArray83);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double2 = statisticalBarRenderer1.getItemMargin();
        java.awt.Stroke stroke4 = statisticalBarRenderer1.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = statisticalBarRenderer1.getLegendItemToolTipGenerator();
        java.awt.Paint paint6 = statisticalBarRenderer1.getBaseOutlinePaint();
        boolean boolean7 = sortOrder0.equals((java.lang.Object) statisticalBarRenderer1);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot14 = null;
        numberAxis13.setPlot(plot14);
        numberAxis13.setLabelToolTip("");
        java.lang.String str18 = numberAxis13.getLabelURL();
        numberAxis13.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer23 = statisticalBarRenderer22.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean27 = axisLocation25.equals((java.lang.Object) 2);
        categoryPlot24.setRangeAxisLocation(axisLocation25);
        categoryPlot24.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot24.getRenderer((int) '4');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo33);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState35 = statisticalBarRenderer1.initialise(graphics2D8, rectangle2D9, categoryPlot24, (-8355585), plotRenderingInfo34);
        java.awt.geom.Point2D point2D36 = null;
        try {
            int int37 = plotRenderingInfo34.getSubplotIndex(point2D36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(gradientPaintTransformer23);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNotNull(categoryItemRendererState35);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, (double) (-1.0f), (double) (byte) 10);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int12 = color11.getAlpha();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ShapeList shapeList23 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, (double) (-1.0f), (double) (byte) 10);
        shapeList23.setShape(2, shape25);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double33 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke35 = statisticalBarRenderer32.getSeriesOutlineStroke(0);
        statisticalBarRenderer32.setBaseSeriesVisibleInLegend(false, false);
        double double39 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke41 = statisticalBarRenderer32.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = statisticalBarRenderer32.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color45 = java.awt.Color.cyan;
        statisticalBarRenderer32.setBaseFillPaint((java.awt.Paint) color45, false);
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "", true, shape9, false, (java.awt.Paint) color11, true, (java.awt.Paint) color14, stroke21, true, shape25, stroke31, (java.awt.Paint) color45);
        int int49 = legendItem48.getSeriesIndex();
        int int50 = legendItem48.getSeriesIndex();
        java.awt.Shape shape51 = legendItem48.getLine();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double53 = statisticalBarRenderer52.getItemMargin();
        java.awt.Stroke stroke55 = statisticalBarRenderer52.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = statisticalBarRenderer52.getLegendItemToolTipGenerator();
        java.awt.Paint paint57 = statisticalBarRenderer52.getBaseOutlinePaint();
        java.awt.Color color58 = java.awt.Color.darkGray;
        statisticalBarRenderer52.setBaseOutlinePaint((java.awt.Paint) color58, false);
        org.jfree.chart.title.LegendGraphic legendGraphic61 = new org.jfree.chart.title.LegendGraphic(shape51, (java.awt.Paint) color58);
        java.awt.Color color62 = java.awt.Color.yellow;
        legendGraphic61.setLinePaint((java.awt.Paint) color62);
        java.awt.Graphics2D graphics2D64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        try {
            legendGraphic61.draw(graphics2D64, rectangle2D65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNull(stroke41);
        org.junit.Assert.assertNull(categoryToolTipGenerator44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.2d + "'", double53 == 0.2d);
        org.junit.Assert.assertNull(stroke55);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(color62);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 'a');
        java.lang.String str2 = chartChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=a]" + "'", str2.equals("org.jfree.chart.event.ChartChangeEvent[source=a]"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int1 = color0.getAlpha();
        float[] floatArray6 = new float[] { 0L, 0L, (short) 1, 1.0f };
        float[] floatArray7 = color0.getRGBColorComponents(floatArray6);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart8, chartChangeEventType9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = chartChangeEvent10.getType();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNull(chartChangeEventType11);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor7, (double) (-1.0f), (double) (byte) 10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int13 = color12.getAlpha();
        java.awt.Color color15 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel16 = null;
        java.awt.Rectangle rectangle17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.geom.AffineTransform affineTransform19 = null;
        java.awt.RenderingHints renderingHints20 = null;
        java.awt.PaintContext paintContext21 = color15.createContext(colorModel16, rectangle17, rectangle2D18, affineTransform19, renderingHints20);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ShapeList shapeList24 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape26, rectangleAnchor27, (double) (-1.0f), (double) (byte) 10);
        shapeList24.setShape(2, shape26);
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double34 = statisticalBarRenderer33.getItemMargin();
        java.awt.Stroke stroke36 = statisticalBarRenderer33.getSeriesOutlineStroke(0);
        statisticalBarRenderer33.setBaseSeriesVisibleInLegend(false, false);
        double double40 = statisticalBarRenderer33.getItemMargin();
        java.awt.Stroke stroke42 = statisticalBarRenderer33.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator45 = statisticalBarRenderer33.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color46 = java.awt.Color.cyan;
        statisticalBarRenderer33.setBaseFillPaint((java.awt.Paint) color46, false);
        org.jfree.chart.LegendItem legendItem49 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "", true, shape10, false, (java.awt.Paint) color12, true, (java.awt.Paint) color15, stroke22, true, shape26, stroke32, (java.awt.Paint) color46);
        int int50 = legendItem49.getSeriesIndex();
        int int51 = legendItem49.getSeriesIndex();
        java.awt.Shape shape52 = legendItem49.getLine();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer53 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double54 = statisticalBarRenderer53.getItemMargin();
        java.awt.Stroke stroke56 = statisticalBarRenderer53.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator57 = statisticalBarRenderer53.getLegendItemToolTipGenerator();
        java.awt.Paint paint58 = statisticalBarRenderer53.getBaseOutlinePaint();
        java.awt.Color color59 = java.awt.Color.darkGray;
        statisticalBarRenderer53.setBaseOutlinePaint((java.awt.Paint) color59, false);
        org.jfree.chart.title.LegendGraphic legendGraphic62 = new org.jfree.chart.title.LegendGraphic(shape52, (java.awt.Paint) color59);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape52, (double) 0L, 2.0f, (float) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paintContext21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.2d + "'", double34 == 0.2d);
        org.junit.Assert.assertNull(stroke36);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.2d + "'", double40 == 0.2d);
        org.junit.Assert.assertNull(stroke42);
        org.junit.Assert.assertNull(categoryToolTipGenerator45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.2d + "'", double54 == 0.2d);
        org.junit.Assert.assertNull(stroke56);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(color59);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint5 = statisticalBarRenderer0.getBaseOutlinePaint();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int8 = color7.getAlpha();
        float[] floatArray13 = new float[] { 0L, 0L, (short) 1, 1.0f };
        float[] floatArray14 = color7.getRGBColorComponents(floatArray13);
        statisticalBarRenderer0.setSeriesOutlinePaint((int) ' ', (java.awt.Paint) color7, false);
        boolean boolean17 = statisticalBarRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = statisticalBarRenderer0.getBaseURLGenerator();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot24 = null;
        numberAxis23.setPlot(plot24);
        numberAxis23.setLabelToolTip("");
        java.lang.String str28 = numberAxis23.getLabelURL();
        numberAxis23.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer33 = statisticalBarRenderer32.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) numberAxis23, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean37 = axisLocation35.equals((java.lang.Object) 2);
        categoryPlot34.setRangeAxisLocation(axisLocation35);
        categoryPlot34.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = categoryPlot34.getRenderer((int) '4');
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        try {
            statisticalBarRenderer0.drawDomainGridline(graphics2D19, categoryPlot34, rectangle2D42, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categoryURLGenerator18);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(gradientPaintTransformer33);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(categoryItemRenderer41);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        try {
            java.lang.Number number3 = defaultStatisticalCategoryDataset0.getStdDevValue((int) (byte) 1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        double double4 = statisticalBarRenderer0.getBase();
        java.awt.Paint paint6 = null;
        statisticalBarRenderer0.setSeriesFillPaint((int) '#', paint6, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        statisticalBarRenderer0.setSeriesItemLabelsVisible((int) (short) 1, (java.lang.Boolean) false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = statisticalBarRenderer0.removeAnnotation(categoryAnnotation8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint5 = statisticalBarRenderer0.getBaseOutlinePaint();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int8 = color7.getAlpha();
        float[] floatArray13 = new float[] { 0L, 0L, (short) 1, 1.0f };
        float[] floatArray14 = color7.getRGBColorComponents(floatArray13);
        statisticalBarRenderer0.setSeriesOutlinePaint((int) ' ', (java.awt.Paint) color7, false);
        statisticalBarRenderer0.setBaseSeriesVisible(true);
        boolean boolean19 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        java.awt.Paint paint21 = null;
        statisticalBarRenderer0.setSeriesOutlinePaint((int) 'a', paint21);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.setHeight(1.0E-8d);
        java.lang.String str3 = size2D0.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Size2D[width=0.0, height=1.0E-8]" + "'", str3.equals("Size2D[width=0.0, height=1.0E-8]"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("RangeType.FULL", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) (short) -1);
        float float4 = numberAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        java.text.NumberFormat numberFormat4 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertNull(numberFormat4);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.resizeRange(10.0d, (double) 100.0f);
        double double9 = numberAxis1.getUpperMargin();
        boolean boolean10 = numberAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, (double) (-1.0f), (double) (byte) 10);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity7 = new org.jfree.chart.entity.TickLabelEntity(shape4, "hi!", "hi!");
        java.lang.String str8 = tickLabelEntity7.getShapeCoords();
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, rectangleAnchor10, (double) (-1.0f), (double) (byte) 10);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity16 = new org.jfree.chart.entity.TickLabelEntity(shape13, "hi!", "hi!");
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape13, "LengthConstraintType.FIXED");
        tickLabelEntity7.setArea(shape13);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "7,6,5,8,3,10,0,8,-1,6,0,3,3,2,5,3,7,6,7,6" + "'", str8.equals("7,6,5,8,3,10,0,8,-1,6,0,3,3,2,5,3,7,6,7,6"));
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=0.0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L), numberFormat1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setBottom(10.0d);
        org.jfree.chart.axis.AxisSpace axisSpace3 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.ensureAtLeast(axisSpace3);
        axisSpace3.setRight((double) 'a');
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        java.awt.Paint paint5 = statisticalBarRenderer0.getSeriesOutlinePaint((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        boolean boolean7 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int1 = color0.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        boolean boolean4 = blockBorder2.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double6 = statisticalBarRenderer5.getItemMargin();
        java.awt.Stroke stroke8 = statisticalBarRenderer5.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer5.getLegendItemToolTipGenerator();
        java.awt.Paint paint10 = statisticalBarRenderer5.getBaseOutlinePaint();
        boolean boolean11 = statisticalBarRenderer5.getAutoPopulateSeriesOutlineStroke();
        boolean boolean12 = blockBorder2.equals((java.lang.Object) statisticalBarRenderer5);
        java.awt.Paint paint15 = statisticalBarRenderer5.getItemLabelPaint((int) (byte) 100, (int) (byte) 100);
        boolean boolean18 = statisticalBarRenderer5.isItemLabelVisible(255, 19);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) (short) -1);
        boolean boolean4 = numberAxis1.isAutoTickUnitSelection();
        double double5 = numberAxis1.getFixedAutoRange();
        org.jfree.data.Range range6 = numberAxis1.getRange();
        try {
            org.jfree.data.Range range9 = org.jfree.data.Range.expand(range6, (double) (-8355585), (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (8355585.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        double double2 = axisState1.getCursor();
        axisState1.setMax(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("MINOR", font1, (java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = textFragment3.calculateDimensions(graphics2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets1.getRight();
        double double4 = rectangleInsets1.extendHeight((double) (byte) 1);
        double double5 = rectangleInsets1.getLeft();
        boolean boolean6 = centerArrangement0.equals((java.lang.Object) double5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot9 = null;
        numberAxis8.setPlot(plot9);
        numberAxis8.setNegativeArrowVisible(true);
        numberAxis8.resizeRange(10.0d, (double) 100.0f);
        boolean boolean16 = centerArrangement0.equals((java.lang.Object) 100.0f);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        boolean boolean18 = centerArrangement0.equals((java.lang.Object) color17);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.0d + "'", double4 == 7.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond((-1.0f));
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity5 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 1.0E-8d, shape2, "Size2D[width=0.0, height=1.0E-8]", "LengthConstraintType.FIXED");
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        boolean boolean5 = statisticalBarRenderer0.isDrawBarOutline();
        double double6 = statisticalBarRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0.0f, range1);
        org.jfree.chart.util.Size2D size2D3 = new org.jfree.chart.util.Size2D();
        double double4 = size2D3.width;
        double double5 = size2D3.width;
        try {
            org.jfree.chart.util.Size2D size2D6 = rectangleConstraint2.calculateConstrainedSize(size2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = statisticalBarRenderer0.getSeriesItemLabelGenerator((int) '4');
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertNull(itemLabelPosition12);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean3 = statisticalBarRenderer2.getAutoPopulateSeriesPaint();
        org.jfree.data.KeyedObject keyedObject4 = new org.jfree.data.KeyedObject((java.lang.Comparable) (byte) 100, (java.lang.Object) boolean3);
        boolean boolean5 = centerArrangement0.equals((java.lang.Object) keyedObject4);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = org.jfree.chart.block.RectangleConstraint.NONE;
        java.lang.String str9 = rectangleConstraint8.toString();
        try {
            org.jfree.chart.util.Size2D size2D10 = centerArrangement0.arrange(blockContainer6, graphics2D7, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str9.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot4 = null;
        numberAxis3.setPlot(plot4);
        numberAxis3.setLabelToolTip("");
        java.lang.String str8 = numberAxis3.getLabelURL();
        numberAxis3.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = statisticalBarRenderer12.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean17 = axisLocation15.equals((java.lang.Object) 2);
        categoryPlot14.setRangeAxisLocation(axisLocation15);
        categoryPlot14.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot14.getRenderer((int) '4');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot14.getDomainAxisForDataset(2);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertNull(categoryAxis24);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) (-8355585));
        org.jfree.data.general.DatasetGroup datasetGroup3 = null;
        try {
            defaultStatisticalCategoryDataset0.setGroup(datasetGroup3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double2 = statisticalBarRenderer1.getItemMargin();
        java.awt.Stroke stroke4 = statisticalBarRenderer1.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = statisticalBarRenderer1.getLegendItemToolTipGenerator();
        java.awt.Paint paint6 = statisticalBarRenderer1.getBaseOutlinePaint();
        boolean boolean7 = sortOrder0.equals((java.lang.Object) statisticalBarRenderer1);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot14 = null;
        numberAxis13.setPlot(plot14);
        numberAxis13.setLabelToolTip("");
        java.lang.String str18 = numberAxis13.getLabelURL();
        numberAxis13.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer23 = statisticalBarRenderer22.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean27 = axisLocation25.equals((java.lang.Object) 2);
        categoryPlot24.setRangeAxisLocation(axisLocation25);
        categoryPlot24.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot24.getRenderer((int) '4');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo33);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState35 = statisticalBarRenderer1.initialise(graphics2D8, rectangle2D9, categoryPlot24, (-8355585), plotRenderingInfo34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = categoryItemRendererState35.getInfo();
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = plotRenderingInfo36.getSubplotInfo(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(gradientPaintTransformer23);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNotNull(categoryItemRendererState35);
        org.junit.Assert.assertNotNull(plotRenderingInfo36);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateLeftOutset((double) 1);
        double double5 = rectangleInsets0.extendHeight((double) 10L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 16.0d + "'", double5 == 16.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) (short) -1);
        boolean boolean4 = numberAxis1.isAutoTickUnitSelection();
        java.lang.String str5 = numberAxis1.getLabelToolTip();
        java.lang.String str6 = numberAxis1.getLabel();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Size2D[width=0.0, height=10.0]");
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, (double) (-1.0f), (double) (byte) 10);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int12 = color11.getAlpha();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ShapeList shapeList23 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, (double) (-1.0f), (double) (byte) 10);
        shapeList23.setShape(2, shape25);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double33 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke35 = statisticalBarRenderer32.getSeriesOutlineStroke(0);
        statisticalBarRenderer32.setBaseSeriesVisibleInLegend(false, false);
        double double39 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke41 = statisticalBarRenderer32.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = statisticalBarRenderer32.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color45 = java.awt.Color.cyan;
        statisticalBarRenderer32.setBaseFillPaint((java.awt.Paint) color45, false);
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "", true, shape9, false, (java.awt.Paint) color11, true, (java.awt.Paint) color14, stroke21, true, shape25, stroke31, (java.awt.Paint) color45);
        int int49 = legendItem48.getSeriesIndex();
        boolean boolean50 = legendItem48.isLineVisible();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNull(stroke41);
        org.junit.Assert.assertNull(categoryToolTipGenerator44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        statisticalBarRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = statisticalBarRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double11 = statisticalBarRenderer10.getItemMargin();
        java.awt.Stroke stroke13 = statisticalBarRenderer10.getSeriesOutlineStroke(0);
        statisticalBarRenderer10.setBaseSeriesVisibleInLegend(false, false);
        double double17 = statisticalBarRenderer10.getItemMargin();
        java.awt.Stroke stroke19 = statisticalBarRenderer10.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = statisticalBarRenderer10.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Paint paint23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        statisticalBarRenderer10.setBaseItemLabelPaint(paint23, true);
        statisticalBarRenderer0.setSeriesOutlinePaint((int) (short) 100, paint23);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNull(stroke19);
        org.junit.Assert.assertNull(categoryToolTipGenerator22);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int1 = color0.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        boolean boolean4 = blockBorder2.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double6 = statisticalBarRenderer5.getItemMargin();
        java.awt.Stroke stroke8 = statisticalBarRenderer5.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer5.getLegendItemToolTipGenerator();
        java.awt.Paint paint10 = statisticalBarRenderer5.getBaseOutlinePaint();
        boolean boolean11 = statisticalBarRenderer5.getAutoPopulateSeriesOutlineStroke();
        boolean boolean12 = blockBorder2.equals((java.lang.Object) statisticalBarRenderer5);
        java.awt.Paint paint14 = statisticalBarRenderer5.lookupSeriesFillPaint(19);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor4, (double) (-1.0f), (double) (byte) 10);
        boolean boolean8 = axisLocation0.equals((java.lang.Object) shape3);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperBound();
        double double3 = numberAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        numberAxis1.removeChangeListener(axisChangeListener4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot10 = null;
        numberAxis9.setPlot(plot10);
        numberAxis9.setLabelToolTip("");
        java.lang.String str14 = numberAxis9.getLabelURL();
        numberAxis9.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = statisticalBarRenderer18.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean23 = axisLocation21.equals((java.lang.Object) 2);
        categoryPlot20.setRangeAxisLocation(axisLocation21);
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = categoryPlot20.getOrientation();
        org.jfree.chart.util.SortOrder sortOrder26 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot20.setColumnRenderingOrder(sortOrder26);
        boolean boolean28 = numberAxis1.hasListener((java.util.EventListener) categoryPlot20);
        numberAxis1.setFixedDimension((double) 15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer19);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertNotNull(sortOrder26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setLabelToolTip("");
        java.awt.Shape shape6 = numberAxis1.getLeftArrow();
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.data.Range range3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((double) 0.0f, range3);
        java.lang.String str5 = rectangleConstraint4.toString();
        try {
            org.jfree.chart.util.Size2D size2D6 = blockContainer0.arrange(graphics2D1, rectangleConstraint4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]" + "'", str5.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, (double) (-1.0f), (double) (byte) 10);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int12 = color11.getAlpha();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ShapeList shapeList23 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, (double) (-1.0f), (double) (byte) 10);
        shapeList23.setShape(2, shape25);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double33 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke35 = statisticalBarRenderer32.getSeriesOutlineStroke(0);
        statisticalBarRenderer32.setBaseSeriesVisibleInLegend(false, false);
        double double39 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke41 = statisticalBarRenderer32.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = statisticalBarRenderer32.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color45 = java.awt.Color.cyan;
        statisticalBarRenderer32.setBaseFillPaint((java.awt.Paint) color45, false);
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "", true, shape9, false, (java.awt.Paint) color11, true, (java.awt.Paint) color14, stroke21, true, shape25, stroke31, (java.awt.Paint) color45);
        int int49 = legendItem48.getSeriesIndex();
        java.awt.Shape shape50 = legendItem48.getShape();
        boolean boolean51 = legendItem48.isLineVisible();
        java.text.AttributedString attributedString52 = legendItem48.getAttributedLabel();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNull(stroke41);
        org.junit.Assert.assertNull(categoryToolTipGenerator44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNull(attributedString52);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int3 = color2.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        boolean boolean6 = blockBorder4.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double8 = statisticalBarRenderer7.getItemMargin();
        java.awt.Stroke stroke10 = statisticalBarRenderer7.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = statisticalBarRenderer7.getLegendItemToolTipGenerator();
        java.awt.Paint paint12 = statisticalBarRenderer7.getBaseOutlinePaint();
        boolean boolean13 = statisticalBarRenderer7.getAutoPopulateSeriesOutlineStroke();
        boolean boolean14 = blockBorder4.equals((java.lang.Object) statisticalBarRenderer7);
        java.awt.Paint paint17 = statisticalBarRenderer7.getItemFillPaint((int) (short) 1, (int) (short) 0);
        statisticalBarRenderer0.setBaseItemLabelPaint(paint17);
        statisticalBarRenderer0.setItemLabelAnchorOffset(3.0d);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation21, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        flowArrangement4.clear();
        flowArrangement4.clear();
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        java.awt.Paint paint5 = statisticalBarRenderer0.getSeriesOutlinePaint((int) (byte) 10);
        statisticalBarRenderer0.setSeriesCreateEntities(10, (java.lang.Boolean) false, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.validateObject();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot6 = null;
        numberAxis5.setPlot(plot6);
        numberAxis5.setLabelToolTip("");
        java.lang.String str10 = numberAxis5.getLabelURL();
        numberAxis5.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = statisticalBarRenderer14.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean19 = axisLocation17.equals((java.lang.Object) 2);
        categoryPlot16.setRangeAxisLocation(axisLocation17);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot16.getOrientation();
        java.lang.String str22 = categoryPlot16.getNoDataMessage();
        boolean boolean23 = defaultStatisticalCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.data.KeyToGroupMap keyToGroupMap24 = null;
        try {
            org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, keyToGroupMap24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getOptionalLibraries();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo12 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        basicProjectInfo5.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo12);
        java.lang.String str14 = basicProjectInfo5.getInfo();
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double2 = statisticalBarRenderer1.getItemMargin();
        java.awt.Stroke stroke4 = statisticalBarRenderer1.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = statisticalBarRenderer1.getLegendItemToolTipGenerator();
        java.awt.Paint paint6 = statisticalBarRenderer1.getBaseOutlinePaint();
        boolean boolean7 = sortOrder0.equals((java.lang.Object) statisticalBarRenderer1);
        java.lang.String str8 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "SortOrder.DESCENDING" + "'", str8.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.POSITIVE");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot9 = null;
        numberAxis8.setPlot(plot9);
        numberAxis8.setLabelToolTip("");
        java.lang.String str13 = numberAxis8.getLabelURL();
        numberAxis8.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = statisticalBarRenderer17.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean22 = axisLocation20.equals((java.lang.Object) 2);
        categoryPlot19.setRangeAxisLocation(axisLocation20);
        categoryPlot19.clearRangeAxes();
        boolean boolean25 = categoryPlot19.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getDomainAxisEdge();
        try {
            double double27 = categoryAxis1.getCategoryStart(100, 255, rectangle2D4, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(gradientPaintTransformer18);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.resizeRange(10.0d, (double) 100.0f);
        double double9 = numberAxis1.getUpperMargin();
        java.awt.Font font10 = numberAxis1.getLabelFont();
        double double11 = numberAxis1.getUpperBound();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 105.0d + "'", double11 == 105.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double2 = statisticalBarRenderer1.getItemMargin();
        java.awt.Stroke stroke4 = statisticalBarRenderer1.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = statisticalBarRenderer1.getLegendItemToolTipGenerator();
        java.awt.Paint paint6 = statisticalBarRenderer1.getBaseOutlinePaint();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int9 = color8.getAlpha();
        float[] floatArray14 = new float[] { 0L, 0L, (short) 1, 1.0f };
        float[] floatArray15 = color8.getRGBColorComponents(floatArray14);
        statisticalBarRenderer1.setSeriesOutlinePaint((int) ' ', (java.awt.Paint) color8, false);
        boolean boolean18 = statisticalBarRenderer1.getAutoPopulateSeriesOutlinePaint();
        java.awt.Stroke stroke20 = statisticalBarRenderer1.lookupSeriesOutlineStroke(3);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 19);
        statisticalBarRenderer1.setBaseShape(shape22, false);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape22, (double) 2.0f, (float) ' ', (float) 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setLabelToolTip("");
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(false, false);
        double double7 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke9 = statisticalBarRenderer0.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = statisticalBarRenderer0.getToolTipGenerator((int) '#', (int) (short) 0);
        org.jfree.chart.block.ColumnArrangement columnArrangement13 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor16 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.data.general.DatasetGroup datasetGroup17 = new org.jfree.data.general.DatasetGroup();
        boolean boolean18 = itemLabelAnchor16.equals((java.lang.Object) datasetGroup17);
        columnArrangement14.add((org.jfree.chart.block.Block) blockContainer15, (java.lang.Object) boolean18);
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0, (org.jfree.chart.block.Arrangement) columnArrangement13, (org.jfree.chart.block.Arrangement) columnArrangement14);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.data.Range range24 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) 0.0f, range24);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint25.toFixedWidth((double) 2);
        try {
            java.lang.Object obj28 = legendTitle20.draw(graphics2D21, rectangle2D22, (java.lang.Object) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(itemLabelAnchor16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtTop();
        org.jfree.chart.axis.Axis axis2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot7 = null;
        numberAxis6.setPlot(plot7);
        numberAxis6.setLabelToolTip("");
        java.lang.String str11 = numberAxis6.getLabelURL();
        numberAxis6.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer16 = statisticalBarRenderer15.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean20 = axisLocation18.equals((java.lang.Object) 2);
        categoryPlot17.setRangeAxisLocation(axisLocation18);
        categoryPlot17.clearRangeAxes();
        boolean boolean23 = categoryPlot17.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot17.getDomainAxisEdge();
        try {
            axisCollection0.add(axis2, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(gradientPaintTransformer16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        double double5 = statisticalBarRenderer0.getUpperClip();
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(true, true);
        statisticalBarRenderer0.setItemLabelAnchorOffset((double) 0.5f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        java.awt.Paint paint5 = statisticalBarRenderer0.getSeriesOutlinePaint((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        double double7 = statisticalBarRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, (double) (-1.0f), (double) (byte) 10);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int12 = color11.getAlpha();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ShapeList shapeList23 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, (double) (-1.0f), (double) (byte) 10);
        shapeList23.setShape(2, shape25);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double33 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke35 = statisticalBarRenderer32.getSeriesOutlineStroke(0);
        statisticalBarRenderer32.setBaseSeriesVisibleInLegend(false, false);
        double double39 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke41 = statisticalBarRenderer32.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = statisticalBarRenderer32.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color45 = java.awt.Color.cyan;
        statisticalBarRenderer32.setBaseFillPaint((java.awt.Paint) color45, false);
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "", true, shape9, false, (java.awt.Paint) color11, true, (java.awt.Paint) color14, stroke21, true, shape25, stroke31, (java.awt.Paint) color45);
        int int49 = legendItem48.getSeriesIndex();
        int int50 = legendItem48.getSeriesIndex();
        java.awt.Shape shape51 = legendItem48.getLine();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double53 = statisticalBarRenderer52.getItemMargin();
        java.awt.Stroke stroke55 = statisticalBarRenderer52.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = statisticalBarRenderer52.getLegendItemToolTipGenerator();
        java.awt.Paint paint57 = statisticalBarRenderer52.getBaseOutlinePaint();
        java.awt.Color color58 = java.awt.Color.darkGray;
        statisticalBarRenderer52.setBaseOutlinePaint((java.awt.Paint) color58, false);
        org.jfree.chart.title.LegendGraphic legendGraphic61 = new org.jfree.chart.title.LegendGraphic(shape51, (java.awt.Paint) color58);
        java.awt.Shape shape62 = legendGraphic61.getShape();
        java.awt.Graphics2D graphics2D63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        try {
            legendGraphic61.draw(graphics2D63, rectangle2D64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNull(stroke41);
        org.junit.Assert.assertNull(categoryToolTipGenerator44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.2d + "'", double53 == 0.2d);
        org.junit.Assert.assertNull(stroke55);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(shape62);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.validateObject();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot6 = null;
        numberAxis5.setPlot(plot6);
        numberAxis5.setLabelToolTip("");
        java.lang.String str10 = numberAxis5.getLabelURL();
        numberAxis5.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = statisticalBarRenderer14.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean19 = axisLocation17.equals((java.lang.Object) 2);
        categoryPlot16.setRangeAxisLocation(axisLocation17);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot16.getOrientation();
        java.lang.String str22 = categoryPlot16.getNoDataMessage();
        boolean boolean23 = defaultStatisticalCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Object obj25 = defaultStatisticalCategoryDataset0.clone();
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertEquals((double) number24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, (double) (-1.0f), (double) (byte) 10);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int12 = color11.getAlpha();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ShapeList shapeList23 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, (double) (-1.0f), (double) (byte) 10);
        shapeList23.setShape(2, shape25);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double33 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke35 = statisticalBarRenderer32.getSeriesOutlineStroke(0);
        statisticalBarRenderer32.setBaseSeriesVisibleInLegend(false, false);
        double double39 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke41 = statisticalBarRenderer32.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = statisticalBarRenderer32.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color45 = java.awt.Color.cyan;
        statisticalBarRenderer32.setBaseFillPaint((java.awt.Paint) color45, false);
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "", true, shape9, false, (java.awt.Paint) color11, true, (java.awt.Paint) color14, stroke21, true, shape25, stroke31, (java.awt.Paint) color45);
        int int49 = legendItem48.getSeriesIndex();
        int int50 = legendItem48.getSeriesIndex();
        java.awt.Shape shape51 = legendItem48.getLine();
        java.awt.Paint paint52 = legendItem48.getFillPaint();
        boolean boolean53 = legendItem48.isLineVisible();
        java.lang.String str54 = legendItem48.getURLText();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNull(stroke41);
        org.junit.Assert.assertNull(categoryToolTipGenerator44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot6 = null;
        numberAxis5.setPlot(plot6);
        numberAxis5.setLabelToolTip("");
        java.lang.String str10 = numberAxis5.getLabelURL();
        numberAxis5.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = statisticalBarRenderer14.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean19 = axisLocation17.equals((java.lang.Object) 2);
        categoryPlot16.setRangeAxisLocation(axisLocation17);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot16.getOrientation();
        org.jfree.chart.util.SortOrder sortOrder22 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot16.setColumnRenderingOrder(sortOrder22);
        boolean boolean24 = textFragment1.equals((java.lang.Object) sortOrder22);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            textFragment1.draw(graphics2D25, (float) 2, (float) 10L, textAnchor28, (float) '4', (float) 19, 52.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(textAnchor28);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double2 = statisticalBarRenderer1.getItemMargin();
        java.awt.Stroke stroke4 = statisticalBarRenderer1.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = statisticalBarRenderer1.getLegendItemToolTipGenerator();
        java.awt.Paint paint6 = statisticalBarRenderer1.getBaseOutlinePaint();
        boolean boolean7 = sortOrder0.equals((java.lang.Object) statisticalBarRenderer1);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot14 = null;
        numberAxis13.setPlot(plot14);
        numberAxis13.setLabelToolTip("");
        java.lang.String str18 = numberAxis13.getLabelURL();
        numberAxis13.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer23 = statisticalBarRenderer22.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean27 = axisLocation25.equals((java.lang.Object) 2);
        categoryPlot24.setRangeAxisLocation(axisLocation25);
        categoryPlot24.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot24.getRenderer((int) '4');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo33);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState35 = statisticalBarRenderer1.initialise(graphics2D8, rectangle2D9, categoryPlot24, (-8355585), plotRenderingInfo34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = categoryItemRendererState35.getInfo();
        categoryItemRendererState35.setBarWidth((double) 500);
        double double39 = categoryItemRendererState35.getBarWidth();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(gradientPaintTransformer23);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNotNull(categoryItemRendererState35);
        org.junit.Assert.assertNotNull(plotRenderingInfo36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 500.0d + "'", double39 == 500.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint5 = statisticalBarRenderer0.getBaseOutlinePaint();
        java.awt.Color color6 = java.awt.Color.darkGray;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color6, false);
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape15, rectangleAnchor16, (double) (-1.0f), (double) (byte) 10);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int22 = color21.getAlpha();
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel25 = null;
        java.awt.Rectangle rectangle26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.RenderingHints renderingHints29 = null;
        java.awt.PaintContext paintContext30 = color24.createContext(colorModel25, rectangle26, rectangle2D27, affineTransform28, renderingHints29);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ShapeList shapeList33 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape35, rectangleAnchor36, (double) (-1.0f), (double) (byte) 10);
        shapeList33.setShape(2, shape35);
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer42 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double43 = statisticalBarRenderer42.getItemMargin();
        java.awt.Stroke stroke45 = statisticalBarRenderer42.getSeriesOutlineStroke(0);
        statisticalBarRenderer42.setBaseSeriesVisibleInLegend(false, false);
        double double49 = statisticalBarRenderer42.getItemMargin();
        java.awt.Stroke stroke51 = statisticalBarRenderer42.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator54 = statisticalBarRenderer42.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color55 = java.awt.Color.cyan;
        statisticalBarRenderer42.setBaseFillPaint((java.awt.Paint) color55, false);
        org.jfree.chart.LegendItem legendItem58 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "", true, shape19, false, (java.awt.Paint) color21, true, (java.awt.Paint) color24, stroke31, true, shape35, stroke41, (java.awt.Paint) color55);
        int int59 = legendItem58.getSeriesIndex();
        int int60 = legendItem58.getSeriesIndex();
        java.awt.Shape shape61 = legendItem58.getLine();
        java.awt.Paint paint62 = legendItem58.getFillPaint();
        statisticalBarRenderer0.setSeriesPaint((int) '#', paint62, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.2d + "'", double43 == 0.2d);
        org.junit.Assert.assertNull(stroke45);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.2d + "'", double49 == 0.2d);
        org.junit.Assert.assertNull(stroke51);
        org.junit.Assert.assertNull(categoryToolTipGenerator54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(paint62);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = statisticalBarRenderer0.getGradientPaintTransformer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot7 = null;
        numberAxis6.setPlot(plot7);
        numberAxis6.setLabelToolTip("");
        java.lang.String str11 = numberAxis6.getLabelURL();
        numberAxis6.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer16 = statisticalBarRenderer15.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean20 = axisLocation18.equals((java.lang.Object) 2);
        categoryPlot17.setRangeAxisLocation(axisLocation18);
        categoryPlot17.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = categoryPlot17.getRenderer((int) '4');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = categoryPlot17.getDomainGridlinePosition();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot28 = null;
        numberAxis27.setPlot(plot28);
        numberAxis27.setNegativeArrowVisible(true);
        numberAxis27.resizeRange(10.0d, (double) 100.0f);
        double double35 = numberAxis27.getUpperMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener36 = null;
        numberAxis27.removeChangeListener(axisChangeListener36);
        java.text.NumberFormat numberFormat38 = numberAxis27.getNumberFormatOverride();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        statisticalBarRenderer0.drawRangeGridline(graphics2D2, categoryPlot17, (org.jfree.chart.axis.ValueAxis) numberAxis27, rectangle2D39, (double) '4');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo44);
        java.lang.Object obj46 = plotRenderingInfo45.clone();
        org.jfree.chart.renderer.RendererState rendererState47 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo45);
        categoryPlot17.handleClick((int) ' ', 255, plotRenderingInfo45);
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = null;
        try {
            categoryPlot17.addDomainMarker(categoryMarker49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(gradientPaintTransformer16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(categoryItemRenderer24);
        org.junit.Assert.assertNotNull(categoryAnchor25);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertNull(numberFormat38);
        org.junit.Assert.assertNotNull(obj46);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 3.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        flowArrangement4.clear();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment8, (double) 100L, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11);
        java.util.List list13 = blockContainer12.getBlocks();
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) blockContainer12, jFreeChart14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = null;
        try {
            org.jfree.chart.util.Size2D size2D18 = flowArrangement4.arrange(blockContainer12, graphics2D16, rectangleConstraint17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        boolean boolean4 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        boolean boolean5 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(100, categoryToolTipGenerator7);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(layer10);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0.0f, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth((double) 2);
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D();
        double double6 = size2D5.width;
        try {
            org.jfree.chart.util.Size2D size2D7 = rectangleConstraint4.calculateConstrainedSize(size2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        java.awt.Paint paint5 = statisticalBarRenderer0.getSeriesOutlinePaint((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint8 = statisticalBarRenderer0.lookupSeriesFillPaint((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("MINOR", font1, (java.awt.Paint) color2);
        java.lang.String str4 = textFragment3.getText();
        java.lang.String str5 = textFragment3.getText();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            float float8 = textFragment3.calculateBaselineOffset(graphics2D6, textAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "MINOR" + "'", str4.equals("MINOR"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "MINOR" + "'", str5.equals("MINOR"));
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double2 = statisticalBarRenderer1.getItemMargin();
        java.awt.Stroke stroke4 = statisticalBarRenderer1.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = statisticalBarRenderer1.getLegendItemToolTipGenerator();
        java.awt.Paint paint6 = statisticalBarRenderer1.getBaseOutlinePaint();
        boolean boolean7 = sortOrder0.equals((java.lang.Object) statisticalBarRenderer1);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot14 = null;
        numberAxis13.setPlot(plot14);
        numberAxis13.setLabelToolTip("");
        java.lang.String str18 = numberAxis13.getLabelURL();
        numberAxis13.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer23 = statisticalBarRenderer22.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean27 = axisLocation25.equals((java.lang.Object) 2);
        categoryPlot24.setRangeAxisLocation(axisLocation25);
        categoryPlot24.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot24.getRenderer((int) '4');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo33);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState35 = statisticalBarRenderer1.initialise(graphics2D8, rectangle2D9, categoryPlot24, (-8355585), plotRenderingInfo34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = categoryItemRendererState35.getInfo();
        categoryItemRendererState35.setBarWidth(105.0d);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(gradientPaintTransformer23);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNotNull(categoryItemRendererState35);
        org.junit.Assert.assertNotNull(plotRenderingInfo36);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = statisticalBarRenderer0.getSeriesItemLabelGenerator((int) '4');
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = textTitle13.getPosition();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = textTitle16.getPosition();
        boolean boolean18 = textTitle13.equals((java.lang.Object) rectangleEdge17);
        java.awt.Font font19 = textTitle13.getFont();
        statisticalBarRenderer0.setBaseItemLabelFont(font19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot26 = null;
        numberAxis25.setPlot(plot26);
        numberAxis25.setLabelToolTip("");
        java.lang.String str30 = numberAxis25.getLabelURL();
        numberAxis25.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer34 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer35 = statisticalBarRenderer34.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) numberAxis25, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean39 = axisLocation37.equals((java.lang.Object) 2);
        categoryPlot36.setRangeAxisLocation(axisLocation37);
        categoryPlot36.configureRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection42 = categoryPlot36.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        try {
            statisticalBarRenderer0.drawOutline(graphics2D21, categoryPlot36, rectangle2D43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(gradientPaintTransformer35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(legendItemCollection42);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateTopInset((double) 0L);
        double double5 = rectangleInsets0.extendWidth((double) 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 7.0d + "'", double5 == 7.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (-8355585), (double) 100, 0, (java.lang.Comparable) 500.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        try {
            java.awt.Color color1 = java.awt.Color.decode("Size2D[width=0.0, height=10.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Size2D[width=0.0, height=10.0]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, (double) 0, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 0);
        int int3 = objectList1.indexOf((java.lang.Object) "RectangleEdge.TOP");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double2 = statisticalBarRenderer1.getItemMargin();
        java.awt.Stroke stroke4 = statisticalBarRenderer1.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = statisticalBarRenderer1.getLegendItemToolTipGenerator();
        java.awt.Paint paint6 = statisticalBarRenderer1.getBaseOutlinePaint();
        boolean boolean7 = sortOrder0.equals((java.lang.Object) statisticalBarRenderer1);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot14 = null;
        numberAxis13.setPlot(plot14);
        numberAxis13.setLabelToolTip("");
        java.lang.String str18 = numberAxis13.getLabelURL();
        numberAxis13.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer23 = statisticalBarRenderer22.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean27 = axisLocation25.equals((java.lang.Object) 2);
        categoryPlot24.setRangeAxisLocation(axisLocation25);
        categoryPlot24.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot24.getRenderer((int) '4');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo33);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState35 = statisticalBarRenderer1.initialise(graphics2D8, rectangle2D9, categoryPlot24, (-8355585), plotRenderingInfo34);
        categoryItemRendererState35.setBarWidth((double) (-1));
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(gradientPaintTransformer23);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNotNull(categoryItemRendererState35);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        boolean boolean7 = statisticalBarRenderer0.isItemLabelVisible((int) (short) 100, (int) (short) 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation8, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(layer9);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double7 = statisticalBarRenderer6.getItemMargin();
        java.awt.Stroke stroke9 = statisticalBarRenderer6.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = statisticalBarRenderer6.getLegendItemToolTipGenerator();
        java.awt.Paint paint11 = statisticalBarRenderer6.getBaseOutlinePaint();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int14 = color13.getAlpha();
        float[] floatArray19 = new float[] { 0L, 0L, (short) 1, 1.0f };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        statisticalBarRenderer6.setSeriesOutlinePaint((int) ' ', (java.awt.Paint) color13, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = statisticalBarRenderer6.getLegendItemURLGenerator();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator24 = statisticalBarRenderer6.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator24);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 255 + "'", int14 == 255);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator23);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator24);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double2 = statisticalBarRenderer1.getItemMargin();
        java.awt.Stroke stroke4 = statisticalBarRenderer1.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = statisticalBarRenderer1.getLegendItemToolTipGenerator();
        statisticalBarRenderer1.setBaseSeriesVisibleInLegend(false);
        org.jfree.data.KeyedObject keyedObject8 = new org.jfree.data.KeyedObject((java.lang.Comparable) "Size2D[width=0.0, height=1.0E-8]", (java.lang.Object) statisticalBarRenderer1);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle10.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement15 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment11, verticalAlignment12, (double) (short) 10, (double) 1);
        keyedObject8.setObject((java.lang.Object) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int3 = color2.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        boolean boolean6 = blockBorder4.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double8 = statisticalBarRenderer7.getItemMargin();
        java.awt.Stroke stroke10 = statisticalBarRenderer7.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = statisticalBarRenderer7.getLegendItemToolTipGenerator();
        java.awt.Paint paint12 = statisticalBarRenderer7.getBaseOutlinePaint();
        boolean boolean13 = statisticalBarRenderer7.getAutoPopulateSeriesOutlineStroke();
        boolean boolean14 = blockBorder4.equals((java.lang.Object) statisticalBarRenderer7);
        java.awt.Paint paint17 = statisticalBarRenderer7.getItemFillPaint((int) (short) 1, (int) (short) 0);
        statisticalBarRenderer0.setBaseItemLabelPaint(paint17);
        statisticalBarRenderer0.setItemLabelAnchorOffset(3.0d);
        java.awt.Shape shape22 = statisticalBarRenderer0.getSeriesShape(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(shape22);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 2);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.lang.Object obj1 = null;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 10L, obj1);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double5 = numberAxis4.getUpperBound();
        numberAxis4.setTickLabelsVisible(true);
        keyedObject2.setObject((java.lang.Object) numberAxis4);
        java.lang.Object obj9 = keyedObject2.getObject();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) (short) -1);
        boolean boolean4 = numberAxis1.isAutoTickUnitSelection();
        double double5 = numberAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        java.util.List list6 = blockContainer5.getBlocks();
        try {
            java.util.Collection collection7 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list6);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint5 = statisticalBarRenderer0.getBaseOutlinePaint();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int8 = color7.getAlpha();
        float[] floatArray13 = new float[] { 0L, 0L, (short) 1, 1.0f };
        float[] floatArray14 = color7.getRGBColorComponents(floatArray13);
        statisticalBarRenderer0.setSeriesOutlinePaint((int) ' ', (java.awt.Paint) color7, false);
        statisticalBarRenderer0.setBaseSeriesVisible(true);
        boolean boolean19 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(itemLabelPosition20);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot4 = null;
        numberAxis3.setPlot(plot4);
        numberAxis3.setLabelToolTip("");
        java.lang.String str8 = numberAxis3.getLabelURL();
        numberAxis3.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = statisticalBarRenderer12.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean17 = axisLocation15.equals((java.lang.Object) 2);
        categoryPlot14.setRangeAxisLocation(axisLocation15);
        categoryPlot14.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot14.getRenderer((int) '4');
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation22 = null;
        try {
            boolean boolean23 = categoryPlot14.removeAnnotation(categoryAnnotation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categoryItemRenderer21);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, (double) (-1.0f), (double) (byte) 10);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int12 = color11.getAlpha();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ShapeList shapeList23 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, (double) (-1.0f), (double) (byte) 10);
        shapeList23.setShape(2, shape25);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double33 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke35 = statisticalBarRenderer32.getSeriesOutlineStroke(0);
        statisticalBarRenderer32.setBaseSeriesVisibleInLegend(false, false);
        double double39 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke41 = statisticalBarRenderer32.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = statisticalBarRenderer32.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color45 = java.awt.Color.cyan;
        statisticalBarRenderer32.setBaseFillPaint((java.awt.Paint) color45, false);
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "", true, shape9, false, (java.awt.Paint) color11, true, (java.awt.Paint) color14, stroke21, true, shape25, stroke31, (java.awt.Paint) color45);
        int int49 = legendItem48.getSeriesIndex();
        int int50 = legendItem48.getSeriesIndex();
        java.awt.Shape shape51 = legendItem48.getLine();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double53 = statisticalBarRenderer52.getItemMargin();
        java.awt.Stroke stroke55 = statisticalBarRenderer52.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = statisticalBarRenderer52.getLegendItemToolTipGenerator();
        java.awt.Paint paint57 = statisticalBarRenderer52.getBaseOutlinePaint();
        java.awt.Color color58 = java.awt.Color.darkGray;
        statisticalBarRenderer52.setBaseOutlinePaint((java.awt.Paint) color58, false);
        org.jfree.chart.title.LegendGraphic legendGraphic61 = new org.jfree.chart.title.LegendGraphic(shape51, (java.awt.Paint) color58);
        java.awt.Shape shape62 = legendGraphic61.getShape();
        java.awt.Stroke stroke63 = legendGraphic61.getOutlineStroke();
        boolean boolean64 = legendGraphic61.isLineVisible();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNull(stroke41);
        org.junit.Assert.assertNull(categoryToolTipGenerator44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.2d + "'", double53 == 0.2d);
        org.junit.Assert.assertNull(stroke55);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(shape62);
        org.junit.Assert.assertNull(stroke63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.validateObject();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 0);
        java.lang.Number number5 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) 10, (java.lang.Comparable) numberTickUnit4);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = statisticalBarRenderer0.getSeriesItemLabelGenerator((int) '4');
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setSeriesItemLabelsVisible(2, (java.lang.Boolean) false, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin((double) (short) -1);
        numberAxis1.setAutoRangeStickyZero(true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.FIXED;
        java.lang.String str6 = lengthConstraintType5.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((-1.0d), range1, lengthConstraintType2, 100.0d, range4, lengthConstraintType5);
        java.lang.String str8 = lengthConstraintType5.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "LengthConstraintType.FIXED" + "'", str6.equals("LengthConstraintType.FIXED"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "LengthConstraintType.FIXED" + "'", str8.equals("LengthConstraintType.FIXED"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("hi!", font3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int6 = color5.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("CategoryLabelWidthType.CATEGORY", font3, (java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font3);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("MINOR", font10, (java.awt.Paint) color11);
        textLine8.removeFragment(textFragment12);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!", font2);
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("7,6,5,8,3,10,0,8,-1,6,0,3,3,2,5,3,7,6,7,6", font2);
        labelBlock4.setMargin((double) 10L, 0.0d, 100.0d, (double) (-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double11 = statisticalBarRenderer10.getItemMargin();
        java.awt.Stroke stroke13 = statisticalBarRenderer10.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = statisticalBarRenderer10.getSeriesPositiveItemLabelPosition(3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = statisticalBarRenderer10.getDrawingSupplier();
        java.awt.Color color21 = java.awt.Color.getHSBColor(0.0f, (float) 10L, (float) 2);
        statisticalBarRenderer10.setSeriesPaint((int) (byte) 1, (java.awt.Paint) color21);
        labelBlock4.setPaint((java.awt.Paint) color21);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.data.Range range26 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint((double) 0.0f, range26);
        java.lang.String str28 = rectangleConstraint27.toString();
        try {
            org.jfree.chart.util.Size2D size2D29 = labelBlock4.arrange(graphics2D24, rectangleConstraint27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNull(drawingSupplier16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]" + "'", str28.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int1 = color0.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        boolean boolean4 = blockBorder2.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double6 = statisticalBarRenderer5.getItemMargin();
        java.awt.Stroke stroke8 = statisticalBarRenderer5.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer5.getLegendItemToolTipGenerator();
        java.awt.Paint paint10 = statisticalBarRenderer5.getBaseOutlinePaint();
        boolean boolean11 = statisticalBarRenderer5.getAutoPopulateSeriesOutlineStroke();
        boolean boolean12 = blockBorder2.equals((java.lang.Object) statisticalBarRenderer5);
        java.awt.Paint paint15 = statisticalBarRenderer5.getItemFillPaint((int) (short) 1, (int) (short) 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = statisticalBarRenderer5.getLegendItemURLGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer5.getPositiveItemLabelPosition((int) (byte) 0, (int) (byte) -1);
        statisticalBarRenderer5.setBaseSeriesVisibleInLegend(true, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double24 = statisticalBarRenderer23.getItemMargin();
        java.awt.Stroke stroke26 = statisticalBarRenderer23.getSeriesOutlineStroke(0);
        java.awt.Paint paint28 = statisticalBarRenderer23.getSeriesOutlinePaint((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = statisticalBarRenderer23.getBasePositiveItemLabelPosition();
        statisticalBarRenderer5.setPositiveItemLabelPositionFallback(itemLabelPosition29);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
        org.junit.Assert.assertNull(stroke26);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle2.getPosition();
        textTitle2.setNotify(false);
        boolean boolean6 = textTitle2.getExpandToFitSpace();
        double double7 = textTitle2.getHeight();
        java.awt.Paint paint8 = textTitle2.getPaint();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = textTitle10.getPosition();
        textTitle10.setNotify(false);
        boolean boolean14 = textTitle10.getExpandToFitSpace();
        double double15 = textTitle10.getHeight();
        java.awt.Paint paint16 = textTitle10.getPaint();
        textTitle2.setBackgroundPaint(paint16);
        org.jfree.data.KeyedObject keyedObject18 = new org.jfree.data.KeyedObject((java.lang.Comparable) (byte) 1, (java.lang.Object) textTitle2);
        org.jfree.chart.event.TitleChangeListener titleChangeListener19 = null;
        textTitle2.addChangeListener(titleChangeListener19);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.validateObject();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) "");
        try {
            java.lang.Number number7 = defaultStatisticalCategoryDataset0.getValue((int) (short) 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) number2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(pieDataset4);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleAnchor.LEFT", graphics2D1, 0.5f, 0.0f, textAnchor4, (double) 'a', textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = textTitle1.getPosition();
        textTitle1.setNotify(false);
        boolean boolean5 = textTitle1.getExpandToFitSpace();
        double double6 = textTitle1.getHeight();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle1.setTextAlignment(horizontalAlignment7);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = statisticalBarRenderer0.getGradientPaintTransformer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot7 = null;
        numberAxis6.setPlot(plot7);
        numberAxis6.setLabelToolTip("");
        java.lang.String str11 = numberAxis6.getLabelURL();
        numberAxis6.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer16 = statisticalBarRenderer15.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean20 = axisLocation18.equals((java.lang.Object) 2);
        categoryPlot17.setRangeAxisLocation(axisLocation18);
        categoryPlot17.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = categoryPlot17.getRenderer((int) '4');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = categoryPlot17.getDomainGridlinePosition();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot28 = null;
        numberAxis27.setPlot(plot28);
        numberAxis27.setNegativeArrowVisible(true);
        numberAxis27.resizeRange(10.0d, (double) 100.0f);
        double double35 = numberAxis27.getUpperMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener36 = null;
        numberAxis27.removeChangeListener(axisChangeListener36);
        java.text.NumberFormat numberFormat38 = numberAxis27.getNumberFormatOverride();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        statisticalBarRenderer0.drawRangeGridline(graphics2D2, categoryPlot17, (org.jfree.chart.axis.ValueAxis) numberAxis27, rectangle2D39, (double) '4');
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset43 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset45 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset43, (java.lang.Comparable) (-8355585));
        categoryPlot17.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset43);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(gradientPaintTransformer16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(categoryItemRenderer24);
        org.junit.Assert.assertNotNull(categoryAnchor25);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertNull(numberFormat38);
        org.junit.Assert.assertNotNull(pieDataset45);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = statisticalBarRenderer0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = statisticalBarRenderer0.getSeriesToolTipGenerator((int) (short) 0);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int5 = color4.getTransparency();
        statisticalBarRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        statisticalBarRenderer0.setSeriesVisible(0, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Size2D[width=0.0, height=10.0]", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setLabelToolTip("");
        java.lang.String str6 = numberAxis1.getLabelURL();
        numberAxis1.setRangeAboutValue((double) '4', (double) 3);
        numberAxis1.setLowerMargin((double) 0.0f);
        org.jfree.data.Range range12 = numberAxis1.getRange();
        double double14 = range12.constrain((double) 100.0f);
        org.jfree.data.Range range16 = org.jfree.data.Range.expandToInclude(range12, 0.0d);
        boolean boolean19 = range12.intersects((double) 15, (double) 1L);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 53.5d + "'", double14 == 53.5d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot4 = null;
        numberAxis3.setPlot(plot4);
        numberAxis3.setLabelToolTip("");
        java.lang.String str8 = numberAxis3.getLabelURL();
        numberAxis3.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = statisticalBarRenderer12.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        statisticalBarRenderer12.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator17 = statisticalBarRenderer12.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator17);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.data.general.DatasetGroup datasetGroup3 = new org.jfree.data.general.DatasetGroup();
        boolean boolean4 = itemLabelAnchor2.equals((java.lang.Object) datasetGroup3);
        columnArrangement0.add((org.jfree.chart.block.Block) blockContainer1, (java.lang.Object) boolean4);
        double double6 = blockContainer1.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double9 = rectangleInsets7.trimWidth(3.0d);
        double double11 = rectangleInsets7.extendHeight((double) 2);
        blockContainer1.setPadding(rectangleInsets7);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 2, 100.0d, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) (short) 10, (java.lang.Number) 37.0d);
        java.lang.Number number3 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 37.0d + "'", number3.equals(37.0d));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets1.getRight();
        double double4 = rectangleInsets1.extendHeight((double) (byte) 1);
        double double5 = rectangleInsets1.getLeft();
        boolean boolean6 = centerArrangement0.equals((java.lang.Object) double5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot9 = null;
        numberAxis8.setPlot(plot9);
        numberAxis8.setNegativeArrowVisible(true);
        numberAxis8.resizeRange(10.0d, (double) 100.0f);
        boolean boolean16 = centerArrangement0.equals((java.lang.Object) 100.0f);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset17.validateObject();
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer21 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset17, (java.lang.Comparable) (short) 0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement26 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment22, verticalAlignment23, (double) 100L, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement26);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = null;
        try {
            org.jfree.chart.util.Size2D size2D30 = centerArrangement0.arrange(blockContainer27, graphics2D28, rectangleConstraint29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.0d + "'", double4 == 7.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) number19, Double.NaN, 0);
        org.junit.Assert.assertNotNull(verticalAlignment23);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.data.general.DatasetGroup datasetGroup3 = new org.jfree.data.general.DatasetGroup();
        boolean boolean4 = itemLabelAnchor2.equals((java.lang.Object) datasetGroup3);
        columnArrangement0.add((org.jfree.chart.block.Block) blockContainer1, (java.lang.Object) boolean4);
        org.jfree.chart.block.Arrangement arrangement6 = blockContainer1.getArrangement();
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(arrangement6);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int1 = color0.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        boolean boolean4 = blockBorder2.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder2.getInsets();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = textTitle7.getPosition();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = textTitle10.getPosition();
        boolean boolean12 = textTitle7.equals((java.lang.Object) rectangleEdge11);
        java.awt.Font font13 = textTitle7.getFont();
        boolean boolean14 = blockBorder2.equals((java.lang.Object) font13);
        java.awt.Paint paint15 = blockBorder2.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.validateObject();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number5 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) (short) 1, (java.lang.Comparable) (-1));
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double2 = statisticalBarRenderer1.getItemMargin();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int4 = color3.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        boolean boolean7 = blockBorder5.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double9 = statisticalBarRenderer8.getItemMargin();
        java.awt.Stroke stroke11 = statisticalBarRenderer8.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer8.getLegendItemToolTipGenerator();
        java.awt.Paint paint13 = statisticalBarRenderer8.getBaseOutlinePaint();
        boolean boolean14 = statisticalBarRenderer8.getAutoPopulateSeriesOutlineStroke();
        boolean boolean15 = blockBorder5.equals((java.lang.Object) statisticalBarRenderer8);
        java.awt.Paint paint18 = statisticalBarRenderer8.getItemFillPaint((int) (short) 1, (int) (short) 0);
        statisticalBarRenderer1.setBaseItemLabelPaint(paint18);
        boolean boolean20 = lineBorder0.equals((java.lang.Object) paint18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot4 = null;
        numberAxis3.setPlot(plot4);
        numberAxis3.setLabelToolTip("");
        java.lang.String str8 = numberAxis3.getLabelURL();
        numberAxis3.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = statisticalBarRenderer12.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean17 = axisLocation15.equals((java.lang.Object) 2);
        categoryPlot14.setRangeAxisLocation(axisLocation15);
        categoryPlot14.configureRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = categoryPlot14.getFixedLegendItems();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double22 = statisticalBarRenderer21.getItemMargin();
        java.awt.Stroke stroke24 = statisticalBarRenderer21.getSeriesOutlineStroke(0);
        statisticalBarRenderer21.setBaseSeriesVisibleInLegend(false, false);
        double double28 = statisticalBarRenderer21.getItemMargin();
        java.awt.Stroke stroke30 = statisticalBarRenderer21.getSeriesStroke((int) '#');
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double32 = statisticalBarRenderer31.getItemMargin();
        java.awt.Stroke stroke34 = statisticalBarRenderer31.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator35 = statisticalBarRenderer31.getLegendItemToolTipGenerator();
        double double36 = statisticalBarRenderer31.getUpperClip();
        double double37 = statisticalBarRenderer31.getBase();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer38 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double39 = statisticalBarRenderer38.getItemMargin();
        java.awt.Stroke stroke41 = statisticalBarRenderer38.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = statisticalBarRenderer38.getSeriesPositiveItemLabelPosition(3);
        statisticalBarRenderer31.setBaseNegativeItemLabelPosition(itemLabelPosition43);
        java.awt.Stroke stroke45 = statisticalBarRenderer31.getErrorIndicatorStroke();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer46 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer47 = statisticalBarRenderer46.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator49 = statisticalBarRenderer46.getSeriesToolTipGenerator((int) (short) 0);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int51 = color50.getTransparency();
        statisticalBarRenderer46.setBaseFillPaint((java.awt.Paint) color50);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer53 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double54 = statisticalBarRenderer53.getItemMargin();
        java.awt.Stroke stroke56 = statisticalBarRenderer53.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator57 = statisticalBarRenderer53.getLegendItemToolTipGenerator();
        java.awt.Paint paint58 = statisticalBarRenderer53.getBaseOutlinePaint();
        boolean boolean59 = statisticalBarRenderer53.getAutoPopulateSeriesOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = null;
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot64 = null;
        numberAxis63.setPlot(plot64);
        numberAxis63.setLabelToolTip("");
        java.lang.String str68 = numberAxis63.getLabelURL();
        numberAxis63.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer72 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer73 = statisticalBarRenderer72.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot(categoryDataset60, categoryAxis61, (org.jfree.chart.axis.ValueAxis) numberAxis63, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer72);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray75 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { statisticalBarRenderer21, statisticalBarRenderer31, statisticalBarRenderer46, statisticalBarRenderer53, statisticalBarRenderer72 };
        categoryPlot14.setRenderers(categoryItemRendererArray75);
        org.jfree.chart.plot.CategoryMarker categoryMarker77 = null;
        try {
            categoryPlot14.addDomainMarker(categoryMarker77);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(legendItemCollection20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.2d + "'", double22 == 0.2d);
        org.junit.Assert.assertNull(stroke24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.2d + "'", double28 == 0.2d);
        org.junit.Assert.assertNull(stroke30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.2d + "'", double32 == 0.2d);
        org.junit.Assert.assertNull(stroke34);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNull(stroke41);
        org.junit.Assert.assertNotNull(itemLabelPosition43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(gradientPaintTransformer47);
        org.junit.Assert.assertNull(categoryToolTipGenerator49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.2d + "'", double54 == 0.2d);
        org.junit.Assert.assertNull(stroke56);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNotNull(gradientPaintTransformer73);
        org.junit.Assert.assertNotNull(categoryItemRendererArray75);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = statisticalBarRenderer0.getSeriesItemLabelGenerator((int) '4');
        double double9 = statisticalBarRenderer0.getMinimumBarLength();
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textBlock0.getLineAlignment();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("hi!", font4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = textTitle7.getPosition();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int10 = color9.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color9);
        textTitle7.setPaint((java.awt.Paint) color9);
        textBlock0.addLine("hi!", font4, (java.awt.Paint) color9);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        try {
            textBlock0.draw(graphics2D14, (float) 255, (float) (short) -1, textBlockAnchor17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (short) 100);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorUp(0.0d);
        axisState0.cursorRight((double) '#');
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean2 = statisticalBarRenderer1.getAutoPopulateSeriesPaint();
        org.jfree.data.KeyedObject keyedObject3 = new org.jfree.data.KeyedObject((java.lang.Comparable) (byte) 100, (java.lang.Object) boolean2);
        java.lang.Object obj4 = keyedObject3.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getHorizontalAlignment();
        double double3 = textTitle1.getWidth();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot4 = null;
        numberAxis3.setPlot(plot4);
        numberAxis3.setLabelToolTip("");
        java.lang.String str8 = numberAxis3.getLabelURL();
        numberAxis3.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = statisticalBarRenderer12.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot14.setRangeGridlineStroke(stroke15);
        categoryPlot14.setAnchorValue(0.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot14.getRenderer((int) (byte) -1);
        categoryPlot14.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(categoryItemRenderer21);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0.0f, range1);
        java.lang.String str3 = rectangleConstraint2.toString();
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D();
        double double5 = size2D4.width;
        double double6 = size2D4.width;
        try {
            org.jfree.chart.util.Size2D size2D7 = rectangleConstraint2.calculateConstrainedSize(size2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]" + "'", str3.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double2 = statisticalBarRenderer1.getItemMargin();
        java.awt.Stroke stroke4 = statisticalBarRenderer1.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = statisticalBarRenderer1.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalBarRenderer1.getNegativeItemLabelPositionFallback();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("hi!", font11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int14 = color13.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("CategoryLabelWidthType.CATEGORY", font11, (java.awt.Paint) color13);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("", font11);
        statisticalBarRenderer1.setSeriesItemLabelFont((int) (short) 0, font11, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double20 = statisticalBarRenderer19.getItemMargin();
        java.awt.Stroke stroke22 = statisticalBarRenderer19.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = statisticalBarRenderer19.getSeriesPositiveItemLabelPosition(3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = statisticalBarRenderer19.getDrawingSupplier();
        java.awt.Color color30 = java.awt.Color.getHSBColor(0.0f, (float) 10L, (float) 2);
        statisticalBarRenderer19.setSeriesPaint((int) (byte) 1, (java.awt.Paint) color30);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer35 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double36 = statisticalBarRenderer35.getItemMargin();
        java.awt.Stroke stroke38 = statisticalBarRenderer35.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator39 = statisticalBarRenderer35.getLegendItemToolTipGenerator();
        double double40 = statisticalBarRenderer35.getUpperClip();
        double double41 = statisticalBarRenderer35.getBase();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer42 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double43 = statisticalBarRenderer42.getItemMargin();
        java.awt.Stroke stroke45 = statisticalBarRenderer42.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = statisticalBarRenderer42.getSeriesPositiveItemLabelPosition(3);
        statisticalBarRenderer35.setBaseNegativeItemLabelPosition(itemLabelPosition47);
        java.awt.Stroke stroke49 = statisticalBarRenderer35.getErrorIndicatorStroke();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator50 = statisticalBarRenderer35.getLegendItemLabelGenerator();
        java.awt.Font font51 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalBarRenderer35.setBaseItemLabelFont(font51);
        java.awt.Color color53 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int54 = color53.getAlpha();
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer57 = new org.jfree.chart.text.G2TextMeasurer(graphics2D56);
        org.jfree.chart.text.TextBlock textBlock58 = org.jfree.chart.text.TextUtilities.createTextBlock("", font51, (java.awt.Paint) color53, (float) (-8355585), (org.jfree.chart.text.TextMeasurer) g2TextMeasurer57);
        try {
            org.jfree.chart.text.TextBlock textBlock59 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font11, (java.awt.Paint) color30, 0.0f, (int) (byte) 100, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 255 + "'", int14 == 255);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.2d + "'", double20 == 0.2d);
        org.junit.Assert.assertNull(stroke22);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNull(drawingSupplier25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.2d + "'", double36 == 0.2d);
        org.junit.Assert.assertNull(stroke38);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.2d + "'", double43 == 0.2d);
        org.junit.Assert.assertNull(stroke45);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator50);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 255 + "'", int54 == 255);
        org.junit.Assert.assertNotNull(textBlock58);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        statisticalBarRenderer0.setDrawBarOutline(true);
        java.awt.Paint paint7 = statisticalBarRenderer0.lookupSeriesOutlinePaint((int) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = statisticalBarRenderer0.getSeriesNegativeItemLabelPosition(3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle2.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment3, verticalAlignment4, 0.0d, (double) 10L);
        boolean boolean8 = sortOrder0.equals((java.lang.Object) 10L);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 1.0f, range1);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double5 = numberAxis4.getUpperBound();
        double double6 = numberAxis4.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot9 = null;
        numberAxis8.setPlot(plot9);
        numberAxis8.setLabelToolTip("");
        java.lang.String str13 = numberAxis8.getLabelURL();
        numberAxis8.setRangeAboutValue((double) '4', (double) 3);
        numberAxis8.setLowerMargin((double) 0.0f);
        org.jfree.data.Range range19 = numberAxis8.getRange();
        double double21 = range19.constrain((double) 100.0f);
        numberAxis4.setDefaultAutoRange(range19);
        double double23 = range19.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint2.toRangeWidth(range19);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 53.5d + "'", double21 == 53.5d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 52.0d + "'", double23 == 52.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(false, false);
        double double7 = statisticalBarRenderer0.getItemMargin();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint12 = statisticalBarRenderer0.getItemPaint(2, (int) (short) 10);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double15 = statisticalBarRenderer14.getItemMargin();
        java.awt.Stroke stroke17 = statisticalBarRenderer14.getSeriesOutlineStroke(0);
        java.awt.Paint paint19 = statisticalBarRenderer14.getSeriesOutlinePaint((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = statisticalBarRenderer14.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor21 = itemLabelPosition20.getTextAnchor();
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(3, itemLabelPosition20);
        boolean boolean23 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2d + "'", double15 == 0.2d);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
        java.lang.String str2 = licences0.getLGPL();
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.extendHeight((double) (byte) 1);
        double double5 = rectangleInsets0.calculateBottomInset(0.0d);
        double double7 = rectangleInsets0.calculateBottomOutset(3.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        boolean boolean1 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = statisticalBarRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("hi!", font3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int6 = color5.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("CategoryLabelWidthType.CATEGORY", font3, (java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font3);
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation11 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 0.0f, (java.lang.Number) 100.0d);
        java.lang.Number number12 = meanAndStandardDeviation11.getMean();
        boolean boolean13 = textLine8.equals((java.lang.Object) number12);
        java.awt.Graphics2D graphics2D14 = null;
        try {
            org.jfree.chart.util.Size2D size2D15 = textLine8.calculateDimensions(graphics2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0f + "'", number12.equals(0.0f));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("MINOR", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        java.util.List list2 = projectInfo0.getContributors();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(list2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 100L, (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement5);
        java.util.List list7 = blockContainer6.getBlocks();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.Range range10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) (-1.0f), range10);
        try {
            org.jfree.chart.util.Size2D size2D12 = columnArrangement0.arrange(blockContainer6, graphics2D8, rectangleConstraint11);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, (double) (-1.0f), (double) (byte) 10);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int12 = color11.getAlpha();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ShapeList shapeList23 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, (double) (-1.0f), (double) (byte) 10);
        shapeList23.setShape(2, shape25);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double33 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke35 = statisticalBarRenderer32.getSeriesOutlineStroke(0);
        statisticalBarRenderer32.setBaseSeriesVisibleInLegend(false, false);
        double double39 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke41 = statisticalBarRenderer32.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = statisticalBarRenderer32.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color45 = java.awt.Color.cyan;
        statisticalBarRenderer32.setBaseFillPaint((java.awt.Paint) color45, false);
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "", true, shape9, false, (java.awt.Paint) color11, true, (java.awt.Paint) color14, stroke21, true, shape25, stroke31, (java.awt.Paint) color45);
        int int49 = legendItem48.getSeriesIndex();
        java.awt.Shape shape50 = legendItem48.getShape();
        legendItem48.setSeriesIndex((int) ' ');
        java.lang.String str53 = legendItem48.getLabel();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNull(stroke41);
        org.junit.Assert.assertNull(categoryToolTipGenerator44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str53.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, (double) (-1.0f), (double) (byte) 10);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int12 = color11.getAlpha();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ShapeList shapeList23 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, (double) (-1.0f), (double) (byte) 10);
        shapeList23.setShape(2, shape25);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double33 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke35 = statisticalBarRenderer32.getSeriesOutlineStroke(0);
        statisticalBarRenderer32.setBaseSeriesVisibleInLegend(false, false);
        double double39 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke41 = statisticalBarRenderer32.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = statisticalBarRenderer32.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color45 = java.awt.Color.cyan;
        statisticalBarRenderer32.setBaseFillPaint((java.awt.Paint) color45, false);
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "", true, shape9, false, (java.awt.Paint) color11, true, (java.awt.Paint) color14, stroke21, true, shape25, stroke31, (java.awt.Paint) color45);
        int int49 = legendItem48.getSeriesIndex();
        int int50 = legendItem48.getSeriesIndex();
        org.jfree.data.general.Dataset dataset51 = legendItem48.getDataset();
        java.lang.Object obj52 = null;
        boolean boolean53 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) dataset51, obj52);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNull(stroke41);
        org.junit.Assert.assertNull(categoryToolTipGenerator44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNull(dataset51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, (double) (-1.0f), (double) (byte) 10);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int12 = color11.getAlpha();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ShapeList shapeList23 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, (double) (-1.0f), (double) (byte) 10);
        shapeList23.setShape(2, shape25);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double33 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke35 = statisticalBarRenderer32.getSeriesOutlineStroke(0);
        statisticalBarRenderer32.setBaseSeriesVisibleInLegend(false, false);
        double double39 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke41 = statisticalBarRenderer32.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = statisticalBarRenderer32.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color45 = java.awt.Color.cyan;
        statisticalBarRenderer32.setBaseFillPaint((java.awt.Paint) color45, false);
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "", true, shape9, false, (java.awt.Paint) color11, true, (java.awt.Paint) color14, stroke21, true, shape25, stroke31, (java.awt.Paint) color45);
        int int49 = legendItem48.getSeriesIndex();
        int int50 = legendItem48.getSeriesIndex();
        java.awt.Shape shape51 = legendItem48.getLine();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double53 = statisticalBarRenderer52.getItemMargin();
        java.awt.Stroke stroke55 = statisticalBarRenderer52.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator56 = statisticalBarRenderer52.getLegendItemToolTipGenerator();
        java.awt.Paint paint57 = statisticalBarRenderer52.getBaseOutlinePaint();
        java.awt.Color color58 = java.awt.Color.darkGray;
        statisticalBarRenderer52.setBaseOutlinePaint((java.awt.Paint) color58, false);
        org.jfree.chart.title.LegendGraphic legendGraphic61 = new org.jfree.chart.title.LegendGraphic(shape51, (java.awt.Paint) color58);
        java.awt.Stroke stroke62 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        legendGraphic61.setLineStroke(stroke62);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer65 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double66 = statisticalBarRenderer65.getItemMargin();
        java.awt.Stroke stroke68 = statisticalBarRenderer65.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator69 = statisticalBarRenderer65.getLegendItemToolTipGenerator();
        double double70 = statisticalBarRenderer65.getUpperClip();
        double double71 = statisticalBarRenderer65.getBase();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer72 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double73 = statisticalBarRenderer72.getItemMargin();
        java.awt.Stroke stroke75 = statisticalBarRenderer72.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition77 = statisticalBarRenderer72.getSeriesPositiveItemLabelPosition(3);
        statisticalBarRenderer65.setBaseNegativeItemLabelPosition(itemLabelPosition77);
        java.awt.Stroke stroke79 = statisticalBarRenderer65.getErrorIndicatorStroke();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator80 = statisticalBarRenderer65.getLegendItemLabelGenerator();
        java.awt.Font font81 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalBarRenderer65.setBaseItemLabelFont(font81);
        java.awt.Color color83 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int84 = color83.getAlpha();
        java.awt.Graphics2D graphics2D86 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer87 = new org.jfree.chart.text.G2TextMeasurer(graphics2D86);
        org.jfree.chart.text.TextBlock textBlock88 = org.jfree.chart.text.TextUtilities.createTextBlock("", font81, (java.awt.Paint) color83, (float) (-8355585), (org.jfree.chart.text.TextMeasurer) g2TextMeasurer87);
        legendGraphic61.setLinePaint((java.awt.Paint) color83);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNull(stroke41);
        org.junit.Assert.assertNull(categoryToolTipGenerator44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.2d + "'", double53 == 0.2d);
        org.junit.Assert.assertNull(stroke55);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.2d + "'", double66 == 0.2d);
        org.junit.Assert.assertNull(stroke68);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.2d + "'", double73 == 0.2d);
        org.junit.Assert.assertNull(stroke75);
        org.junit.Assert.assertNotNull(itemLabelPosition77);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator80);
        org.junit.Assert.assertNotNull(font81);
        org.junit.Assert.assertNotNull(color83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 255 + "'", int84 == 255);
        org.junit.Assert.assertNotNull(textBlock88);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        boolean boolean2 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator3, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double7 = statisticalBarRenderer6.getItemMargin();
        java.awt.Stroke stroke9 = statisticalBarRenderer6.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = statisticalBarRenderer6.getLegendItemToolTipGenerator();
        java.awt.Paint paint11 = statisticalBarRenderer6.getBaseOutlinePaint();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int14 = color13.getAlpha();
        float[] floatArray19 = new float[] { 0L, 0L, (short) 1, 1.0f };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        statisticalBarRenderer6.setSeriesOutlinePaint((int) ' ', (java.awt.Paint) color13, false);
        boolean boolean23 = statisticalBarRenderer6.getAutoPopulateSeriesOutlinePaint();
        java.awt.Stroke stroke25 = statisticalBarRenderer6.lookupSeriesOutlineStroke(3);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator26 = statisticalBarRenderer6.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator26);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 255 + "'", int14 == 255);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator26);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 'a');
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        chartChangeEvent1.setType(chartChangeEventType2);
        org.jfree.chart.axis.AxisState axisState4 = new org.jfree.chart.axis.AxisState();
        axisState4.cursorUp(0.0d);
        axisState4.cursorRight(100.0d);
        axisState4.cursorLeft((double) (-1.0f));
        boolean boolean11 = chartChangeEventType2.equals((java.lang.Object) axisState4);
        java.lang.String str12 = chartChangeEventType2.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str12.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 10.0f, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot4 = null;
        numberAxis3.setPlot(plot4);
        numberAxis3.setLabelToolTip("");
        java.lang.String str8 = numberAxis3.getLabelURL();
        numberAxis3.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = statisticalBarRenderer12.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean17 = axisLocation15.equals((java.lang.Object) 2);
        categoryPlot14.setRangeAxisLocation(axisLocation15);
        categoryPlot14.clearRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot14.setRenderer((int) '#', categoryItemRenderer21);
        try {
            categoryPlot14.zoom((double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        java.lang.Object obj2 = keyedObjects0.getObject(comparable1);
        java.lang.Object obj3 = keyedObjects0.clone();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getSeriesPositiveItemLabelPosition(3);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesOutlinePaint((int) ' ', (java.awt.Paint) color7);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double10 = statisticalBarRenderer9.getItemMargin();
        java.awt.Stroke stroke12 = statisticalBarRenderer9.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = statisticalBarRenderer9.getLegendItemToolTipGenerator();
        java.awt.Paint paint14 = statisticalBarRenderer9.getBaseOutlinePaint();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = textTitle17.getPosition();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = textTitle20.getPosition();
        boolean boolean22 = textTitle17.equals((java.lang.Object) rectangleEdge21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        textTitle17.setPaint((java.awt.Paint) color23);
        float[] floatArray25 = null;
        float[] floatArray26 = color23.getComponents(floatArray25);
        statisticalBarRenderer9.setSeriesFillPaint((int) (byte) 100, (java.awt.Paint) color23, true);
        java.awt.Color color29 = java.awt.Color.darkGray;
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int31 = color30.getAlpha();
        float[] floatArray36 = new float[] { 0L, 0L, (short) 1, 1.0f };
        float[] floatArray37 = color30.getRGBColorComponents(floatArray36);
        float[] floatArray38 = color29.getRGBComponents(floatArray37);
        float[] floatArray39 = color23.getRGBComponents(floatArray37);
        float[] floatArray40 = color7.getComponents(floatArray39);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 255 + "'", int31 == 255);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Object obj1 = booleanList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setVersion("");
        org.jfree.chart.axis.AxisState axisState4 = new org.jfree.chart.axis.AxisState(0.0d);
        double double5 = axisState4.getMax();
        java.util.List list6 = axisState4.getTicks();
        projectInfo0.setContributors(list6);
        java.lang.String str8 = projectInfo0.getLicenceText();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint5 = statisticalBarRenderer0.getBaseOutlinePaint();
        java.awt.Color color6 = java.awt.Color.darkGray;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color6, false);
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        try {
            statisticalBarRenderer0.setSeriesOutlineStroke((-8355585), stroke10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint5 = statisticalBarRenderer0.getBaseOutlinePaint();
        boolean boolean6 = statisticalBarRenderer0.getBaseSeriesVisible();
        try {
            statisticalBarRenderer0.setSeriesCreateEntities((int) (byte) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) '4', jFreeChart1);
        java.lang.Object obj3 = chartChangeEvent2.getSource();
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + '4' + "'", obj3.equals('4'));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, (double) (-1.0f), (double) (byte) 10);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int12 = color11.getAlpha();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ShapeList shapeList23 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, (double) (-1.0f), (double) (byte) 10);
        shapeList23.setShape(2, shape25);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double33 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke35 = statisticalBarRenderer32.getSeriesOutlineStroke(0);
        statisticalBarRenderer32.setBaseSeriesVisibleInLegend(false, false);
        double double39 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke41 = statisticalBarRenderer32.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = statisticalBarRenderer32.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color45 = java.awt.Color.cyan;
        statisticalBarRenderer32.setBaseFillPaint((java.awt.Paint) color45, false);
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "", true, shape9, false, (java.awt.Paint) color11, true, (java.awt.Paint) color14, stroke21, true, shape25, stroke31, (java.awt.Paint) color45);
        java.awt.Shape shape49 = legendItem48.getLine();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNull(stroke41);
        org.junit.Assert.assertNull(categoryToolTipGenerator44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(shape49);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setLabelToolTip("");
        java.awt.Paint paint6 = numberAxis1.getTickLabelPaint();
        java.awt.Stroke stroke7 = numberAxis1.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double11 = numberAxis10.getUpperBound();
        double double12 = numberAxis10.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot15 = null;
        numberAxis14.setPlot(plot15);
        numberAxis14.setLabelToolTip("");
        java.lang.String str19 = numberAxis14.getLabelURL();
        numberAxis14.setRangeAboutValue((double) '4', (double) 3);
        numberAxis14.setLowerMargin((double) 0.0f);
        org.jfree.data.Range range25 = numberAxis14.getRange();
        double double27 = range25.constrain((double) 100.0f);
        numberAxis10.setDefaultAutoRange(range25);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType29 = org.jfree.chart.block.LengthConstraintType.FIXED;
        java.lang.String str30 = lengthConstraintType29.toString();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double34 = numberAxis33.getUpperBound();
        double double35 = numberAxis33.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot38 = null;
        numberAxis37.setPlot(plot38);
        numberAxis37.setLabelToolTip("");
        java.lang.String str42 = numberAxis37.getLabelURL();
        numberAxis37.setRangeAboutValue((double) '4', (double) 3);
        numberAxis37.setLowerMargin((double) 0.0f);
        org.jfree.data.Range range48 = numberAxis37.getRange();
        double double50 = range48.constrain((double) 100.0f);
        numberAxis33.setDefaultAutoRange(range48);
        boolean boolean53 = range48.equals((java.lang.Object) "ThreadContext");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType54 = org.jfree.chart.block.LengthConstraintType.FIXED;
        java.lang.String str55 = lengthConstraintType54.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint56 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range25, lengthConstraintType29, 16.0d, range48, lengthConstraintType54);
        numberAxis1.setDefaultAutoRange(range25);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 53.5d + "'", double27 == 53.5d);
        org.junit.Assert.assertNotNull(lengthConstraintType29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "LengthConstraintType.FIXED" + "'", str30.equals("LengthConstraintType.FIXED"));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 53.5d + "'", double50 == 53.5d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "LengthConstraintType.FIXED" + "'", str55.equals("LengthConstraintType.FIXED"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot4 = null;
        numberAxis3.setPlot(plot4);
        numberAxis3.setLabelToolTip("");
        java.lang.String str8 = numberAxis3.getLabelURL();
        numberAxis3.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = statisticalBarRenderer12.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot14.setRangeGridlineStroke(stroke15);
        categoryPlot14.setAnchorValue(0.0d, false);
        java.util.List list20 = categoryPlot14.getAnnotations();
        categoryPlot14.setForegroundAlpha((float) '4');
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("SortOrder.DESCENDING", (int) 'a', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.width;
        double double2 = size2D0.width;
        size2D0.setHeight((double) 10.0f);
        double double5 = size2D0.getWidth();
        double double6 = size2D0.getHeight();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Size2D[width=0.0, height=1.0E-8]", graphics2D1, 53.5d, (float) (short) 0, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int3 = color2.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        boolean boolean6 = blockBorder4.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double8 = statisticalBarRenderer7.getItemMargin();
        java.awt.Stroke stroke10 = statisticalBarRenderer7.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = statisticalBarRenderer7.getLegendItemToolTipGenerator();
        java.awt.Paint paint12 = statisticalBarRenderer7.getBaseOutlinePaint();
        boolean boolean13 = statisticalBarRenderer7.getAutoPopulateSeriesOutlineStroke();
        boolean boolean14 = blockBorder4.equals((java.lang.Object) statisticalBarRenderer7);
        java.awt.Paint paint17 = statisticalBarRenderer7.getItemFillPaint((int) (short) 1, (int) (short) 0);
        statisticalBarRenderer0.setBaseItemLabelPaint(paint17);
        double double19 = statisticalBarRenderer0.getUpperClip();
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalBarRenderer0.setSeriesOutlineStroke((int) (short) 1, stroke21);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot4 = null;
        numberAxis3.setPlot(plot4);
        numberAxis3.setLabelToolTip("");
        java.lang.String str8 = numberAxis3.getLabelURL();
        numberAxis3.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = statisticalBarRenderer12.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean17 = axisLocation15.equals((java.lang.Object) 2);
        categoryPlot14.setRangeAxisLocation(axisLocation15);
        categoryPlot14.clearRangeAxes();
        boolean boolean20 = categoryPlot14.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot14.getDomainAxisEdge();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int23 = color22.getAlpha();
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color22.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color22);
        java.lang.String str31 = categoryPlot14.getPlotType();
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot14.setRangeCrosshairStroke(stroke32);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 255 + "'", int23 == 255);
        org.junit.Assert.assertNotNull(paintContext29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Category Plot" + "'", str31.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.resizeRange(10.0d, (double) 100.0f);
        numberAxis1.setAutoRangeMinimumSize((double) 100L);
        java.awt.Paint paint11 = numberAxis1.getAxisLinePaint();
        boolean boolean12 = numberAxis1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-1), 0.0d, (double) (-1L), 0.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setLabelToolTip("");
        java.lang.String str6 = numberAxis1.getLabelURL();
        numberAxis1.setRangeAboutValue((double) '4', (double) 3);
        numberAxis1.setLowerMargin((double) 0.0f);
        org.jfree.data.Range range12 = numberAxis1.getRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = null;
        numberAxis1.setMarkerBand(markerAxisBand13);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.validateObject();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot6 = null;
        numberAxis5.setPlot(plot6);
        numberAxis5.setLabelToolTip("");
        java.lang.String str10 = numberAxis5.getLabelURL();
        numberAxis5.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = statisticalBarRenderer14.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean19 = axisLocation17.equals((java.lang.Object) 2);
        categoryPlot16.setRangeAxisLocation(axisLocation17);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot16.getOrientation();
        java.lang.String str22 = categoryPlot16.getNoDataMessage();
        boolean boolean23 = defaultStatisticalCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertEquals((double) number24, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0.0d + "'", number25.equals(0.0d));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        boolean boolean2 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(0, categoryURLGenerator4, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double9 = statisticalBarRenderer8.getItemMargin();
        java.awt.Stroke stroke11 = statisticalBarRenderer8.getSeriesOutlineStroke(0);
        java.awt.Paint paint13 = statisticalBarRenderer8.getSeriesOutlinePaint((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = statisticalBarRenderer8.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor15 = itemLabelPosition14.getTextAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor16 = itemLabelPosition14.getItemLabelAnchor();
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition(3, itemLabelPosition14, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(itemLabelAnchor16);
        org.junit.Assert.assertNull(itemLabelPosition19);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperBound();
        double double3 = numberAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        numberAxis1.removeChangeListener(axisChangeListener4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot10 = null;
        numberAxis9.setPlot(plot10);
        numberAxis9.setLabelToolTip("");
        java.lang.String str14 = numberAxis9.getLabelURL();
        numberAxis9.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = statisticalBarRenderer18.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean23 = axisLocation21.equals((java.lang.Object) 2);
        categoryPlot20.setRangeAxisLocation(axisLocation21);
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = categoryPlot20.getOrientation();
        org.jfree.chart.util.SortOrder sortOrder26 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot20.setColumnRenderingOrder(sortOrder26);
        boolean boolean28 = numberAxis1.hasListener((java.util.EventListener) categoryPlot20);
        java.lang.String str29 = numberAxis1.getLabel();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer19);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertNotNull(sortOrder26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperBound();
        double double3 = numberAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        numberAxis1.removeChangeListener(axisChangeListener4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis1.getLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = numberAxis1.getLabelInsets();
        java.awt.Shape shape8 = null;
        try {
            org.jfree.chart.entity.AxisLabelEntity axisLabelEntity11 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis1, shape8, "RangeType.POSITIVE", "LengthConstraintType.FIXED");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        boolean boolean12 = basicProjectInfo10.equals((java.lang.Object) rectangleAnchor11);
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, 105.0d, (double) (-8355585), rectangleAnchor11);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor14 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.data.general.DatasetGroup datasetGroup15 = new org.jfree.data.general.DatasetGroup();
        boolean boolean16 = itemLabelAnchor14.equals((java.lang.Object) datasetGroup15);
        java.lang.String str17 = datasetGroup15.getID();
        try {
            java.lang.Object obj18 = blockContainer0.draw(graphics2D1, rectangle2D13, (java.lang.Object) datasetGroup15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(itemLabelAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "NOID" + "'", str17.equals("NOID"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = keyedObjects0.getObject(255);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.resizeRange(10.0d, (double) 100.0f);
        numberAxis1.setAutoRangeIncludesZero(true);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int12 = color11.getAlpha();
        numberAxis1.setTickLabelPaint((java.awt.Paint) color11);
        double double14 = numberAxis1.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0E-8d + "'", double14 == 1.0E-8d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = statisticalBarRenderer0.getSeriesItemLabelGenerator((int) '4');
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        statisticalBarRenderer0.setSeriesURLGenerator((int) (short) 1, categoryURLGenerator13);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot4 = null;
        numberAxis3.setPlot(plot4);
        numberAxis3.setLabelToolTip("");
        java.lang.String str8 = numberAxis3.getLabelURL();
        numberAxis3.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = statisticalBarRenderer12.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot14.setRangeGridlineStroke(stroke15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot14.addChangeListener(plotChangeListener17);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot4 = null;
        numberAxis3.setPlot(plot4);
        numberAxis3.setLabelToolTip("");
        java.lang.String str8 = numberAxis3.getLabelURL();
        numberAxis3.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = statisticalBarRenderer12.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean17 = axisLocation15.equals((java.lang.Object) 2);
        categoryPlot14.setRangeAxisLocation(axisLocation15);
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = categoryPlot14.getOrientation();
        java.lang.String str20 = categoryPlot14.getNoDataMessage();
        categoryPlot14.clearDomainMarkers((int) (short) -1);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.lang.Object obj1 = null;
        boolean boolean2 = borderArrangement0.equals(obj1);
        borderArrangement0.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.POSITIVE");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        boolean boolean15 = basicProjectInfo13.equals((java.lang.Object) rectangleAnchor14);
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D5, 105.0d, (double) (-8355585), rectangleAnchor14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.SortOrder sortOrder18 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double20 = statisticalBarRenderer19.getItemMargin();
        java.awt.Stroke stroke22 = statisticalBarRenderer19.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = statisticalBarRenderer19.getLegendItemToolTipGenerator();
        java.awt.Paint paint24 = statisticalBarRenderer19.getBaseOutlinePaint();
        boolean boolean25 = sortOrder18.equals((java.lang.Object) statisticalBarRenderer19);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot32 = null;
        numberAxis31.setPlot(plot32);
        numberAxis31.setLabelToolTip("");
        java.lang.String str36 = numberAxis31.getLabelURL();
        numberAxis31.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer40 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer41 = statisticalBarRenderer40.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) numberAxis31, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer40);
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean45 = axisLocation43.equals((java.lang.Object) 2);
        categoryPlot42.setRangeAxisLocation(axisLocation43);
        categoryPlot42.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = categoryPlot42.getRenderer((int) '4');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo51 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo51);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState53 = statisticalBarRenderer19.initialise(graphics2D26, rectangle2D27, categoryPlot42, (-8355585), plotRenderingInfo52);
        categoryItemRendererState53.setBarWidth(0.0d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = categoryItemRendererState53.getInfo();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo57 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo57);
        java.lang.Object obj59 = plotRenderingInfo58.clone();
        org.jfree.chart.renderer.RendererState rendererState60 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo58);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState61 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo58);
        plotRenderingInfo56.addSubplotInfo(plotRenderingInfo58);
        try {
            org.jfree.chart.axis.AxisState axisState63 = categoryAxis1.draw(graphics2D2, (double) (short) 100, rectangle2D4, rectangle2D16, rectangleEdge17, plotRenderingInfo58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.2d + "'", double20 == 0.2d);
        org.junit.Assert.assertNull(stroke22);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(gradientPaintTransformer41);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(categoryItemRenderer49);
        org.junit.Assert.assertNotNull(categoryItemRendererState53);
        org.junit.Assert.assertNotNull(plotRenderingInfo56);
        org.junit.Assert.assertNotNull(obj59);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, (double) (-1.0f), (double) (byte) 10);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity7 = new org.jfree.chart.entity.TickLabelEntity(shape4, "hi!", "hi!");
        java.lang.String str8 = tickLabelEntity7.getShapeCoords();
        java.lang.String str9 = tickLabelEntity7.getShapeCoords();
        tickLabelEntity7.setToolTipText("");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "7,6,5,8,3,10,0,8,-1,6,0,3,3,2,5,3,7,6,7,6" + "'", str8.equals("7,6,5,8,3,10,0,8,-1,6,0,3,3,2,5,3,7,6,7,6"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "7,6,5,8,3,10,0,8,-1,6,0,3,3,2,5,3,7,6,7,6" + "'", str9.equals("7,6,5,8,3,10,0,8,-1,6,0,3,3,2,5,3,7,6,7,6"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        boolean boolean6 = numberAxis1.isAutoTickUnitSelection();
        double double7 = numberAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!", font2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int5 = color4.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("CategoryLabelWidthType.CATEGORY", font2, (java.awt.Paint) color4);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double8 = rectangleInsets7.getRight();
        labelBlock6.setMargin(rectangleInsets7);
        java.lang.Object obj10 = labelBlock6.clone();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        boolean boolean2 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(0, categoryURLGenerator4, true);
        statisticalBarRenderer0.setBaseSeriesVisible(true, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke3 = defaultDrawingSupplier2.getNextOutlineStroke();
        strokeList0.setStroke(3, stroke3);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double2 = statisticalBarRenderer1.getItemMargin();
        java.awt.Stroke stroke4 = statisticalBarRenderer1.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = statisticalBarRenderer1.getLegendItemToolTipGenerator();
        java.awt.Paint paint6 = statisticalBarRenderer1.getBaseOutlinePaint();
        boolean boolean7 = sortOrder0.equals((java.lang.Object) statisticalBarRenderer1);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot14 = null;
        numberAxis13.setPlot(plot14);
        numberAxis13.setLabelToolTip("");
        java.lang.String str18 = numberAxis13.getLabelURL();
        numberAxis13.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer23 = statisticalBarRenderer22.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean27 = axisLocation25.equals((java.lang.Object) 2);
        categoryPlot24.setRangeAxisLocation(axisLocation25);
        categoryPlot24.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot24.getRenderer((int) '4');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo33);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState35 = statisticalBarRenderer1.initialise(graphics2D8, rectangle2D9, categoryPlot24, (-8355585), plotRenderingInfo34);
        boolean boolean36 = categoryPlot24.isRangeZoomable();
        java.lang.Object obj37 = categoryPlot24.clone();
        org.jfree.data.category.CategoryDataset categoryDataset39 = categoryPlot24.getDataset(255);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(gradientPaintTransformer23);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNotNull(categoryItemRendererState35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNull(categoryDataset39);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        boolean boolean5 = statisticalBarRenderer0.isDrawBarOutline();
        statisticalBarRenderer0.setItemMargin(37.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, comparable1, 0.2d, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets1.getRight();
        boolean boolean3 = shapeList0.equals((java.lang.Object) rectangleInsets1);
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.data.general.DatasetGroup datasetGroup7 = new org.jfree.data.general.DatasetGroup();
        boolean boolean8 = itemLabelAnchor6.equals((java.lang.Object) datasetGroup7);
        columnArrangement4.add((org.jfree.chart.block.Block) blockContainer5, (java.lang.Object) boolean8);
        boolean boolean10 = shapeList0.equals((java.lang.Object) columnArrangement4);
        java.lang.Object obj11 = shapeList0.clone();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, (double) (-1.0f), (double) (byte) 10);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int12 = color11.getAlpha();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ShapeList shapeList23 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, (double) (-1.0f), (double) (byte) 10);
        shapeList23.setShape(2, shape25);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double33 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke35 = statisticalBarRenderer32.getSeriesOutlineStroke(0);
        statisticalBarRenderer32.setBaseSeriesVisibleInLegend(false, false);
        double double39 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke41 = statisticalBarRenderer32.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = statisticalBarRenderer32.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color45 = java.awt.Color.cyan;
        statisticalBarRenderer32.setBaseFillPaint((java.awt.Paint) color45, false);
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "", true, shape9, false, (java.awt.Paint) color11, true, (java.awt.Paint) color14, stroke21, true, shape25, stroke31, (java.awt.Paint) color45);
        org.jfree.chart.JFreeChart jFreeChart49 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent52 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) legendItem48, jFreeChart49, 1, (int) (short) 100);
        org.jfree.chart.JFreeChart jFreeChart53 = chartProgressEvent52.getChart();
        int int54 = chartProgressEvent52.getType();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNull(stroke41);
        org.junit.Assert.assertNull(categoryToolTipGenerator44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNull(jFreeChart53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setBottom(10.0d);
        org.jfree.chart.axis.AxisSpace axisSpace3 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.ensureAtLeast(axisSpace3);
        java.lang.Object obj5 = null;
        boolean boolean6 = axisSpace3.equals(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, (double) (-1.0f), (double) (byte) 10);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int12 = color11.getAlpha();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ShapeList shapeList23 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, (double) (-1.0f), (double) (byte) 10);
        shapeList23.setShape(2, shape25);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double33 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke35 = statisticalBarRenderer32.getSeriesOutlineStroke(0);
        statisticalBarRenderer32.setBaseSeriesVisibleInLegend(false, false);
        double double39 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke41 = statisticalBarRenderer32.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = statisticalBarRenderer32.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color45 = java.awt.Color.cyan;
        statisticalBarRenderer32.setBaseFillPaint((java.awt.Paint) color45, false);
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "", true, shape9, false, (java.awt.Paint) color11, true, (java.awt.Paint) color14, stroke21, true, shape25, stroke31, (java.awt.Paint) color45);
        int int49 = legendItem48.getSeriesIndex();
        int int50 = legendItem48.getSeriesIndex();
        java.awt.Shape shape51 = legendItem48.getLine();
        java.awt.Paint paint52 = legendItem48.getFillPaint();
        boolean boolean53 = legendItem48.isLineVisible();
        boolean boolean54 = legendItem48.isShapeFilled();
        legendItem48.setSeriesIndex(0);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNull(stroke41);
        org.junit.Assert.assertNull(categoryToolTipGenerator44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 10.0f);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!", font2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int5 = color4.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("CategoryLabelWidthType.CATEGORY", font2, (java.awt.Paint) color4);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.lang.Object obj10 = plotRenderingInfo9.clone();
        org.jfree.chart.renderer.RendererState rendererState11 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState12 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo9.getDataArea();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        boolean boolean16 = textBlockAnchor14.equals((java.lang.Object) "hi!");
        try {
            java.lang.Object obj17 = labelBlock6.draw(graphics2D7, rectangle2D13, (java.lang.Object) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        boolean boolean2 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 1, 3, 1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getSeriesPositiveItemLabelPosition(3);
        org.jfree.chart.util.ShapeList shapeList6 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double8 = rectangleInsets7.getRight();
        boolean boolean9 = shapeList6.equals((java.lang.Object) rectangleInsets7);
        boolean boolean10 = itemLabelPosition5.equals((java.lang.Object) rectangleInsets7);
        double double11 = rectangleInsets7.getRight();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int1 = color0.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        boolean boolean4 = blockBorder2.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double6 = statisticalBarRenderer5.getItemMargin();
        java.awt.Stroke stroke8 = statisticalBarRenderer5.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer5.getLegendItemToolTipGenerator();
        java.awt.Paint paint10 = statisticalBarRenderer5.getBaseOutlinePaint();
        boolean boolean11 = statisticalBarRenderer5.getAutoPopulateSeriesOutlineStroke();
        boolean boolean12 = blockBorder2.equals((java.lang.Object) statisticalBarRenderer5);
        java.awt.Paint paint15 = statisticalBarRenderer5.getItemFillPaint((int) (short) 1, (int) (short) 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = statisticalBarRenderer5.getLegendItemURLGenerator();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double19 = statisticalBarRenderer18.getItemMargin();
        java.awt.Stroke stroke21 = statisticalBarRenderer18.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = statisticalBarRenderer18.getSeriesPositiveItemLabelPosition(3);
        org.jfree.chart.util.ShapeList shapeList24 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double26 = rectangleInsets25.getRight();
        boolean boolean27 = shapeList24.equals((java.lang.Object) rectangleInsets25);
        boolean boolean28 = itemLabelPosition23.equals((java.lang.Object) rectangleInsets25);
        statisticalBarRenderer5.setSeriesNegativeItemLabelPosition(0, itemLabelPosition23);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        statisticalBarRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = statisticalBarRenderer0.getBaseToolTipGenerator();
        java.lang.Boolean boolean10 = statisticalBarRenderer0.getSeriesVisibleInLegend((int) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(boolean10);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint5 = statisticalBarRenderer0.getBaseOutlinePaint();
        boolean boolean6 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double9 = statisticalBarRenderer8.getItemMargin();
        java.awt.Stroke stroke11 = statisticalBarRenderer8.getSeriesOutlineStroke(0);
        java.awt.Paint paint13 = statisticalBarRenderer8.getSeriesOutlinePaint((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = statisticalBarRenderer8.getBasePositiveItemLabelPosition();
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 10, itemLabelPosition14, false);
        boolean boolean18 = statisticalBarRenderer0.isSeriesItemLabelsVisible((int) (short) 0);
        boolean boolean20 = statisticalBarRenderer0.isSeriesVisibleInLegend((int) (byte) 0);
        java.lang.Boolean boolean22 = statisticalBarRenderer0.getSeriesVisibleInLegend((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(boolean22);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(false, false);
        double double7 = statisticalBarRenderer0.getItemMargin();
        statisticalBarRenderer0.removeAnnotations();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = statisticalBarRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 15, (float) (short) 100, (double) (short) 0, 0.0f, (float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        double double5 = statisticalBarRenderer0.getUpperClip();
        double double6 = statisticalBarRenderer0.getBase();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double8 = statisticalBarRenderer7.getItemMargin();
        java.awt.Stroke stroke10 = statisticalBarRenderer7.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalBarRenderer7.getSeriesPositiveItemLabelPosition(3);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition12);
        java.lang.Object obj14 = null;
        boolean boolean15 = itemLabelPosition12.equals(obj14);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.trimWidth(3.0d);
        double double4 = rectangleInsets0.extendHeight((double) 2);
        double double6 = rectangleInsets0.calculateBottomOutset(0.05d);
        double double8 = rectangleInsets0.calculateLeftOutset((double) (byte) 10);
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets0.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(unitType9);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
        java.lang.Object obj2 = standardCategorySeriesLabelGenerator1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.POSITIVE");
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        java.util.List list2 = axisState1.getTicks();
        axisState1.setCursor(3.0d);
        axisState1.setMax((double) 10);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int3 = color2.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        boolean boolean6 = blockBorder4.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double8 = statisticalBarRenderer7.getItemMargin();
        java.awt.Stroke stroke10 = statisticalBarRenderer7.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = statisticalBarRenderer7.getLegendItemToolTipGenerator();
        java.awt.Paint paint12 = statisticalBarRenderer7.getBaseOutlinePaint();
        boolean boolean13 = statisticalBarRenderer7.getAutoPopulateSeriesOutlineStroke();
        boolean boolean14 = blockBorder4.equals((java.lang.Object) statisticalBarRenderer7);
        java.awt.Paint paint17 = statisticalBarRenderer7.getItemFillPaint((int) (short) 1, (int) (short) 0);
        statisticalBarRenderer0.setBaseItemLabelPaint(paint17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(itemLabelPosition19);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        statisticalBarRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        boolean boolean9 = statisticalBarRenderer0.isSeriesVisibleInLegend((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setLeft(1.0E-8d);
        org.jfree.chart.axis.AxisSpace axisSpace3 = new org.jfree.chart.axis.AxisSpace();
        axisSpace3.setBottom(10.0d);
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        axisSpace3.ensureAtLeast(axisSpace6);
        axisSpace0.ensureAtLeast(axisSpace3);
        double double9 = axisSpace0.getTop();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = textTitle1.getPosition();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int4 = color3.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        textTitle1.setPaint((java.awt.Paint) color3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = textTitle1.getVerticalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle1.getMargin();
        textTitle1.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.resizeRange(10.0d, (double) 100.0f);
        numberAxis1.setAutoRangeIncludesZero(true);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int12 = color11.getAlpha();
        numberAxis1.setTickLabelPaint((java.awt.Paint) color11);
        numberAxis1.resizeRange((-1.0d));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.resizeRange(10.0d, (double) 100.0f);
        double double9 = numberAxis1.getUpperMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener10 = null;
        numberAxis1.removeChangeListener(axisChangeListener10);
        java.text.NumberFormat numberFormat12 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setAutoRangeIncludesZero(true);
        java.awt.Paint paint15 = numberAxis1.getLabelPaint();
        numberAxis1.setLabel("Size2D[width=0.0, height=10.0]");
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot4 = null;
        numberAxis3.setPlot(plot4);
        numberAxis3.setLabelToolTip("");
        java.lang.String str8 = numberAxis3.getLabelURL();
        numberAxis3.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = statisticalBarRenderer12.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean17 = axisLocation15.equals((java.lang.Object) 2);
        categoryPlot14.setRangeAxisLocation(axisLocation15);
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = categoryPlot14.getOrientation();
        org.jfree.chart.util.SortOrder sortOrder20 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot14.setColumnRenderingOrder(sortOrder20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot26 = null;
        numberAxis25.setPlot(plot26);
        numberAxis25.setLabelToolTip("");
        java.lang.String str30 = numberAxis25.getLabelURL();
        numberAxis25.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer34 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer35 = statisticalBarRenderer34.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) numberAxis25, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean39 = axisLocation37.equals((java.lang.Object) 2);
        categoryPlot36.setRangeAxisLocation(axisLocation37);
        categoryPlot36.clearRangeAxes();
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection44 = categoryPlot36.getRangeMarkers((int) (short) -1, layer43);
        java.util.Collection collection45 = categoryPlot14.getRangeMarkers(layer43);
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.FOREGROUND;
        java.awt.Color color48 = java.awt.Color.ORANGE;
        boolean boolean49 = layer47.equals((java.lang.Object) color48);
        java.util.Collection collection50 = categoryPlot14.getRangeMarkers(100, layer47);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation51 = null;
        try {
            boolean boolean52 = categoryPlot14.removeAnnotation(categoryAnnotation51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(gradientPaintTransformer35);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(collection50);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (-1.0f), range1);
        java.lang.String str3 = rectangleConstraint2.toString();
        double double4 = rectangleConstraint2.getHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint2.getHeightConstraintType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=0.0]" + "'", str3.equals("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        java.awt.Shape shape11 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D5, 2.0f, 0.0f, textAnchor8, 53.5d, textAnchor10);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double14 = statisticalBarRenderer13.getItemMargin();
        java.awt.Stroke stroke16 = statisticalBarRenderer13.getSeriesOutlineStroke(0);
        java.awt.Paint paint18 = statisticalBarRenderer13.getSeriesOutlinePaint((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer13.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor20 = itemLabelPosition19.getTextAnchor();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Size2D[width=0.0, height=10.0]", graphics2D1, 0.0f, 0.0f, textAnchor8, 500.0d, textAnchor20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNull(shape11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2d + "'", double14 == 0.2d);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(textAnchor20);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot7 = null;
        numberAxis6.setPlot(plot7);
        numberAxis6.setLabelToolTip("");
        java.lang.String str11 = numberAxis6.getLabelURL();
        numberAxis6.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer16 = statisticalBarRenderer15.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer15);
        boolean boolean18 = categoryLabelWidthType2.equals((java.lang.Object) categoryDataset3);
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition20 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categoryAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(gradientPaintTransformer16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.POSITIVE");
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!", font5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int8 = color7.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("CategoryLabelWidthType.CATEGORY", font5, (java.awt.Paint) color7);
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 100L, font5);
        float float11 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 15);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range(100.0d, 53.5d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (53.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) -1, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int2 = color1.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color1);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot6 = null;
        numberAxis5.setPlot(plot6);
        numberAxis5.setLabelToolTip("");
        java.lang.String str10 = numberAxis5.getLabelURL();
        numberAxis5.setRangeAboutValue((double) '4', (double) 3);
        numberAxis5.setLowerMargin((double) 0.0f);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis5.setAxisLineStroke(stroke16);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, (java.awt.Paint) color1, stroke16);
        valueMarker18.setLabel("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.awt.Paint paint21 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        valueMarker18.setOutlinePaint(paint21);
        java.awt.Paint paint23 = valueMarker18.getLabelPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = statisticalBarRenderer0.getSeriesItemLabelGenerator((int) '4');
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = textTitle13.getPosition();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = textTitle16.getPosition();
        boolean boolean18 = textTitle13.equals((java.lang.Object) rectangleEdge17);
        java.awt.Font font19 = textTitle13.getFont();
        statisticalBarRenderer0.setBaseItemLabelFont(font19);
        java.awt.Stroke stroke22 = statisticalBarRenderer0.getSeriesStroke((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(stroke22);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int8 = color7.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color7);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot12 = null;
        numberAxis11.setPlot(plot12);
        numberAxis11.setLabelToolTip("");
        java.lang.String str16 = numberAxis11.getLabelURL();
        numberAxis11.setRangeAboutValue((double) '4', (double) 3);
        numberAxis11.setLowerMargin((double) 0.0f);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis11.setAxisLineStroke(stroke22);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, (java.awt.Paint) color7, stroke22);
        valueMarker24.setLabel("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.lang.Object obj27 = valueMarker24.clone();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener28 = null;
        valueMarker24.removeChangeListener(markerChangeListener28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double32 = rectangleInsets30.trimWidth(3.0d);
        double double33 = rectangleInsets30.getLeft();
        double double35 = rectangleInsets30.calculateTopInset(100.0d);
        valueMarker24.setLabelOffset(rectangleInsets30);
        double double38 = rectangleInsets30.calculateTopOutset((double) ' ');
        numberAxis1.setLabelInsets(rectangleInsets30);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint5 = statisticalBarRenderer0.getBaseOutlinePaint();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int8 = color7.getAlpha();
        float[] floatArray13 = new float[] { 0L, 0L, (short) 1, 1.0f };
        float[] floatArray14 = color7.getRGBColorComponents(floatArray13);
        statisticalBarRenderer0.setSeriesOutlinePaint((int) ' ', (java.awt.Paint) color7, false);
        statisticalBarRenderer0.setBaseSeriesVisible(true);
        boolean boolean19 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double22 = statisticalBarRenderer21.getItemMargin();
        java.awt.Stroke stroke24 = statisticalBarRenderer21.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator25 = statisticalBarRenderer21.getLegendItemToolTipGenerator();
        java.awt.Paint paint26 = statisticalBarRenderer21.getBaseOutlinePaint();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int29 = color28.getAlpha();
        float[] floatArray34 = new float[] { 0L, 0L, (short) 1, 1.0f };
        float[] floatArray35 = color28.getRGBColorComponents(floatArray34);
        statisticalBarRenderer21.setSeriesOutlinePaint((int) ' ', (java.awt.Paint) color28, false);
        boolean boolean38 = statisticalBarRenderer21.getAutoPopulateSeriesOutlinePaint();
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        statisticalBarRenderer21.setBaseItemLabelPaint((java.awt.Paint) color39);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = textTitle43.getPosition();
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = textTitle46.getPosition();
        boolean boolean48 = textTitle43.equals((java.lang.Object) rectangleEdge47);
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        textTitle43.setPaint((java.awt.Paint) color49);
        float[] floatArray51 = null;
        float[] floatArray52 = color49.getComponents(floatArray51);
        statisticalBarRenderer21.setSeriesFillPaint(0, (java.awt.Paint) color49);
        try {
            statisticalBarRenderer0.setSeriesOutlinePaint((-1), (java.awt.Paint) color49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.2d + "'", double22 == 0.2d);
        org.junit.Assert.assertNull(stroke24);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 255 + "'", int29 == 255);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(floatArray52);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.extendHeight((double) (byte) 1);
        double double5 = rectangleInsets0.calculateBottomInset(0.0d);
        double double7 = rectangleInsets0.extendWidth((double) 'a');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 103.0d + "'", double7 == 103.0d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets1.getRight();
        boolean boolean3 = shapeList0.equals((java.lang.Object) rectangleInsets1);
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.data.general.DatasetGroup datasetGroup7 = new org.jfree.data.general.DatasetGroup();
        boolean boolean8 = itemLabelAnchor6.equals((java.lang.Object) datasetGroup7);
        columnArrangement4.add((org.jfree.chart.block.Block) blockContainer5, (java.lang.Object) boolean8);
        boolean boolean10 = shapeList0.equals((java.lang.Object) columnArrangement4);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = textTitle12.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement17 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment13, verticalAlignment14, (double) (short) 10, (double) 1);
        boolean boolean18 = shapeList0.equals((java.lang.Object) verticalAlignment14);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.resizeRange(10.0d, (double) 100.0f);
        double double9 = numberAxis1.getUpperMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener10 = null;
        numberAxis1.removeChangeListener(axisChangeListener10);
        java.text.NumberFormat numberFormat12 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setAutoRangeIncludesZero(true);
        numberAxis1.setAutoTickUnitSelection(false, false);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.AxisState axisState20 = new org.jfree.chart.axis.AxisState(0.0d);
        java.util.List list21 = axisState20.getTicks();
        org.jfree.chart.util.Size2D size2D22 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo30 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        boolean boolean32 = basicProjectInfo30.equals((java.lang.Object) rectangleAnchor31);
        java.awt.geom.Rectangle2D rectangle2D33 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D22, 105.0d, (double) (-8355585), rectangleAnchor31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = textTitle35.getPosition();
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = textTitle38.getPosition();
        boolean boolean40 = textTitle35.equals((java.lang.Object) rectangleEdge39);
        java.lang.String str41 = rectangleEdge39.toString();
        double double42 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D33, rectangleEdge39);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = textTitle44.getPosition();
        try {
            java.util.List list46 = numberAxis1.refreshTicks(graphics2D18, axisState20, rectangle2D33, rectangleEdge45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "RectangleEdge.TOP" + "'", str41.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + (-8355585.0d) + "'", double42 == (-8355585.0d));
        org.junit.Assert.assertNotNull(rectangleEdge45);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 0);
        int int2 = numberTickUnit1.getMinorTickCount();
        java.lang.String str4 = numberTickUnit1.valueToString((double) (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.resizeRange(10.0d, (double) 100.0f);
        double double9 = numberAxis1.getUpperMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener10 = null;
        numberAxis1.removeChangeListener(axisChangeListener10);
        boolean boolean12 = numberAxis1.isAutoRange();
        org.jfree.data.RangeType rangeType13 = org.jfree.data.RangeType.POSITIVE;
        java.lang.String str14 = rangeType13.toString();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double17 = statisticalBarRenderer16.getItemMargin();
        java.awt.Stroke stroke19 = statisticalBarRenderer16.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = statisticalBarRenderer16.getLegendItemToolTipGenerator();
        double double21 = statisticalBarRenderer16.getUpperClip();
        double double22 = statisticalBarRenderer16.getBase();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double24 = statisticalBarRenderer23.getItemMargin();
        java.awt.Stroke stroke26 = statisticalBarRenderer23.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = statisticalBarRenderer23.getSeriesPositiveItemLabelPosition(3);
        statisticalBarRenderer16.setBaseNegativeItemLabelPosition(itemLabelPosition28);
        java.awt.Stroke stroke30 = statisticalBarRenderer16.getErrorIndicatorStroke();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator31 = statisticalBarRenderer16.getLegendItemLabelGenerator();
        java.awt.Font font32 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        statisticalBarRenderer16.setBaseItemLabelFont(font32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int35 = color34.getAlpha();
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer38 = new org.jfree.chart.text.G2TextMeasurer(graphics2D37);
        org.jfree.chart.text.TextBlock textBlock39 = org.jfree.chart.text.TextUtilities.createTextBlock("", font32, (java.awt.Paint) color34, (float) (-8355585), (org.jfree.chart.text.TextMeasurer) g2TextMeasurer38);
        boolean boolean40 = rangeType13.equals((java.lang.Object) color34);
        numberAxis1.setRangeType(rangeType13);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rangeType13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RangeType.POSITIVE" + "'", str14.equals("RangeType.POSITIVE"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNull(stroke19);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
        org.junit.Assert.assertNull(stroke26);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 255 + "'", int35 == 255);
        org.junit.Assert.assertNotNull(textBlock39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.resizeRange(10.0d, (double) 100.0f);
        numberAxis1.setAutoRangeIncludesZero(true);
        org.jfree.data.RangeType rangeType11 = numberAxis1.getRangeType();
        org.junit.Assert.assertNotNull(rangeType11);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("hi!", font10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int13 = color12.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("CategoryLabelWidthType.CATEGORY", font10, (java.awt.Paint) color12);
        org.jfree.chart.text.TextLine textLine15 = new org.jfree.chart.text.TextLine("", font10);
        statisticalBarRenderer0.setSeriesItemLabelFont((int) (short) 0, font10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = statisticalBarRenderer0.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorUp(0.0d);
        axisState0.cursorRight(100.0d);
        double double5 = axisState0.getMax();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.resizeRange(10.0d, (double) 100.0f);
        double double9 = numberAxis1.getUpperMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener10 = null;
        numberAxis1.removeChangeListener(axisChangeListener10);
        boolean boolean12 = numberAxis1.isAutoRange();
        numberAxis1.centerRange((double) 15);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = statisticalBarRenderer0.getGradientPaintTransformer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = statisticalBarRenderer0.getSeriesToolTipGenerator((int) (short) 0);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int5 = color4.getTransparency();
        statisticalBarRenderer0.setBaseFillPaint((java.awt.Paint) color4);
        java.awt.Paint paint7 = statisticalBarRenderer0.getBaseFillPaint();
        java.awt.Shape shape10 = statisticalBarRenderer0.getItemShape(1, (int) (short) -1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = statisticalBarRenderer0.getGradientPaintTransformer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot7 = null;
        numberAxis6.setPlot(plot7);
        numberAxis6.setLabelToolTip("");
        java.lang.String str11 = numberAxis6.getLabelURL();
        numberAxis6.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer16 = statisticalBarRenderer15.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean20 = axisLocation18.equals((java.lang.Object) 2);
        categoryPlot17.setRangeAxisLocation(axisLocation18);
        categoryPlot17.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = categoryPlot17.getRenderer((int) '4');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = categoryPlot17.getDomainGridlinePosition();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot28 = null;
        numberAxis27.setPlot(plot28);
        numberAxis27.setNegativeArrowVisible(true);
        numberAxis27.resizeRange(10.0d, (double) 100.0f);
        double double35 = numberAxis27.getUpperMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener36 = null;
        numberAxis27.removeChangeListener(axisChangeListener36);
        java.text.NumberFormat numberFormat38 = numberAxis27.getNumberFormatOverride();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        statisticalBarRenderer0.drawRangeGridline(graphics2D2, categoryPlot17, (org.jfree.chart.axis.ValueAxis) numberAxis27, rectangle2D39, (double) '4');
        org.jfree.chart.plot.Plot plot42 = categoryPlot17.getRootPlot();
        plot42.setBackgroundImageAlignment((int) (byte) 10);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(gradientPaintTransformer16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(categoryItemRenderer24);
        org.junit.Assert.assertNotNull(categoryAnchor25);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertNull(numberFormat38);
        org.junit.Assert.assertNotNull(plot42);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.validateObject();
        java.lang.Object obj2 = defaultStatisticalCategoryDataset0.clone();
        java.lang.Comparable comparable3 = null;
        java.lang.Number number5 = defaultStatisticalCategoryDataset0.getStdDevValue(comparable3, (java.lang.Comparable) "Category Plot");
        org.jfree.data.Range range7 = defaultStatisticalCategoryDataset0.getRangeBounds(true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = textTitle1.getPosition();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = textTitle4.getPosition();
        boolean boolean6 = textTitle1.equals((java.lang.Object) rectangleEdge5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        textTitle1.setPaint((java.awt.Paint) color7);
        java.awt.Paint paint9 = textTitle1.getBackgroundPaint();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = textTitle11.getPosition();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int14 = color13.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color13);
        textTitle11.setPaint((java.awt.Paint) color13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle11.getVerticalAlignment();
        org.jfree.chart.block.BlockFrame blockFrame18 = textTitle11.getFrame();
        textTitle11.setHeight((double) (byte) -1);
        java.lang.Object obj21 = textTitle11.clone();
        boolean boolean22 = textTitle1.equals((java.lang.Object) textTitle11);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 255 + "'", int14 == 255);
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertNotNull(blockFrame18);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 0);
        int int2 = numberTickUnit1.getMinorTickCount();
        double double3 = numberTickUnit1.getSize();
        java.lang.String str5 = numberTickUnit1.valueToString((double) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "35" + "'", str5.equals("35"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.validateObject();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range4 = defaultStatisticalCategoryDataset0.getRangeBounds(true);
        java.lang.Object obj5 = defaultStatisticalCategoryDataset0.clone();
        org.junit.Assert.assertEquals((double) number2, Double.NaN, 0);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int3 = color2.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        boolean boolean6 = blockBorder4.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double8 = statisticalBarRenderer7.getItemMargin();
        java.awt.Stroke stroke10 = statisticalBarRenderer7.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = statisticalBarRenderer7.getLegendItemToolTipGenerator();
        java.awt.Paint paint12 = statisticalBarRenderer7.getBaseOutlinePaint();
        boolean boolean13 = statisticalBarRenderer7.getAutoPopulateSeriesOutlineStroke();
        boolean boolean14 = blockBorder4.equals((java.lang.Object) statisticalBarRenderer7);
        java.awt.Paint paint17 = statisticalBarRenderer7.getItemFillPaint((int) (short) 1, (int) (short) 0);
        statisticalBarRenderer0.setBaseItemLabelPaint(paint17);
        statisticalBarRenderer0.setItemLabelAnchorOffset(3.0d);
        java.awt.Paint paint21 = statisticalBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        statisticalBarRenderer0.notifyListeners(rendererChangeEvent22);
        statisticalBarRenderer0.setSeriesItemLabelsVisible(3, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        java.awt.Paint paint5 = statisticalBarRenderer0.getSeriesOutlinePaint((int) (byte) 10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = statisticalBarRenderer0.getSeriesItemLabelGenerator((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
    }
}

