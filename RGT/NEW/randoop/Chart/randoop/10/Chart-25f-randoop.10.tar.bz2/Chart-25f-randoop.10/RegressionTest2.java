import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setLabelToolTip("");
        java.lang.String str6 = numberAxis1.getLabelURL();
        numberAxis1.setRangeAboutValue((double) '4', (double) 3);
        numberAxis1.setLowerMargin((double) 0.0f);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis1.setAxisLineStroke(stroke12);
        numberAxis1.setAutoRangeMinimumSize(500.0d);
        numberAxis1.zoomRange((double) 1, (double) (short) 10);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.validateObject();
        java.lang.Object obj2 = defaultStatisticalCategoryDataset0.clone();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (double) 19);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        java.lang.Object obj2 = keyedObjects0.getObject(comparable1);
        int int4 = keyedObjects0.getIndex((java.lang.Comparable) 100.0d);
        java.lang.Object obj5 = keyedObjects0.clone();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot4 = null;
        numberAxis3.setPlot(plot4);
        numberAxis3.setLabelToolTip("");
        java.lang.String str8 = numberAxis3.getLabelURL();
        numberAxis3.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = statisticalBarRenderer12.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer12);
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot14.setRangeGridlineStroke(stroke15);
        categoryPlot14.setAnchorValue(0.0d, false);
        java.util.List list20 = categoryPlot14.getAnnotations();
        org.jfree.chart.plot.Plot plot21 = categoryPlot14.getParent();
        java.lang.String str22 = categoryPlot14.getNoDataMessage();
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 'a');
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        chartChangeEvent1.setType(chartChangeEventType2);
        org.jfree.chart.axis.AxisState axisState4 = new org.jfree.chart.axis.AxisState();
        axisState4.cursorUp(0.0d);
        axisState4.cursorRight(100.0d);
        axisState4.cursorLeft((double) (-1.0f));
        boolean boolean11 = chartChangeEventType2.equals((java.lang.Object) axisState4);
        double double12 = axisState4.getCursor();
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 101.0d + "'", double12 == 101.0d);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = textTitle1.getPosition();
        java.lang.String str3 = textTitle1.getText();
        java.lang.Object obj4 = textTitle1.clone();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MINOR" + "'", str3.equals("MINOR"));
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        statisticalBarRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = statisticalBarRenderer0.getBaseToolTipGenerator();
        java.awt.Stroke stroke9 = statisticalBarRenderer0.getErrorIndicatorStroke();
        boolean boolean10 = statisticalBarRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint11 = statisticalBarRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot15 = null;
        numberAxis14.setPlot(plot15);
        numberAxis14.setNegativeArrowVisible(true);
        numberAxis14.resizeRange(10.0d, (double) 100.0f);
        double double22 = numberAxis14.getUpperMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener23 = null;
        numberAxis14.removeChangeListener(axisChangeListener23);
        java.text.NumberFormat numberFormat25 = numberAxis14.getNumberFormatOverride();
        numberAxis14.setAutoRangeIncludesZero(true);
        java.awt.Paint paint28 = numberAxis14.getLabelPaint();
        statisticalBarRenderer0.setSeriesItemLabelPaint(1, paint28, false);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer31 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        statisticalBarRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer31);
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNull(numberFormat25);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textBlock1.getLineAlignment();
        org.jfree.chart.text.TextLine textLine3 = textBlock1.getLastLine();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int5 = color4.getAlpha();
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color4);
        boolean boolean8 = blockBorder6.equals((java.lang.Object) (byte) -1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double10 = statisticalBarRenderer9.getItemMargin();
        java.awt.Stroke stroke12 = statisticalBarRenderer9.getSeriesOutlineStroke(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = statisticalBarRenderer9.getLegendItemToolTipGenerator();
        java.awt.Paint paint14 = statisticalBarRenderer9.getBaseOutlinePaint();
        boolean boolean15 = statisticalBarRenderer9.getAutoPopulateSeriesOutlineStroke();
        boolean boolean16 = blockBorder6.equals((java.lang.Object) statisticalBarRenderer9);
        java.awt.Paint paint19 = statisticalBarRenderer9.getItemFillPaint((int) (short) 1, (int) (short) 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = statisticalBarRenderer9.getLegendItemURLGenerator();
        statisticalBarRenderer9.setAutoPopulateSeriesOutlinePaint(false);
        boolean boolean23 = textBlock1.equals((java.lang.Object) false);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor27 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.awt.Shape shape31 = textBlock1.calculateBounds(graphics2D24, 0.0f, (float) (byte) 0, textBlockAnchor27, (float) 100, (float) 2, 4.0d);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor32 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor33 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.jfree.chart.text.TextAnchor textAnchor34 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str36 = rectangleAnchor35.toString();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor37 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor38 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType40 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.lang.String str41 = categoryLabelWidthType40.toString();
        java.lang.String str42 = categoryLabelWidthType40.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition44 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor35, textBlockAnchor37, textAnchor38, (double) (-1), categoryLabelWidthType40, 0.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor33, textAnchor34, textAnchor38, (double) 500);
        org.jfree.chart.axis.CategoryTick categoryTick48 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) "TextBlockAnchor.CENTER_RIGHT", textBlock1, textBlockAnchor32, textAnchor38, (-8355585.0d));
        double double49 = categoryTick48.getAngle();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNull(textLine3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(textBlockAnchor32);
        org.junit.Assert.assertNotNull(itemLabelAnchor33);
        org.junit.Assert.assertNotNull(textAnchor34);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "RectangleAnchor.LEFT" + "'", str36.equals("RectangleAnchor.LEFT"));
        org.junit.Assert.assertNotNull(textBlockAnchor37);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertNotNull(categoryLabelWidthType40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str41.equals("CategoryLabelWidthType.CATEGORY"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str42.equals("CategoryLabelWidthType.CATEGORY"));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + (-8355585.0d) + "'", double49 == (-8355585.0d));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = statisticalBarRenderer0.getGradientPaintTransformer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot7 = null;
        numberAxis6.setPlot(plot7);
        numberAxis6.setLabelToolTip("");
        java.lang.String str11 = numberAxis6.getLabelURL();
        numberAxis6.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer16 = statisticalBarRenderer15.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean20 = axisLocation18.equals((java.lang.Object) 2);
        categoryPlot17.setRangeAxisLocation(axisLocation18);
        categoryPlot17.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = categoryPlot17.getRenderer((int) '4');
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = categoryPlot17.getDomainGridlinePosition();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot28 = null;
        numberAxis27.setPlot(plot28);
        numberAxis27.setNegativeArrowVisible(true);
        numberAxis27.resizeRange(10.0d, (double) 100.0f);
        double double35 = numberAxis27.getUpperMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener36 = null;
        numberAxis27.removeChangeListener(axisChangeListener36);
        java.text.NumberFormat numberFormat38 = numberAxis27.getNumberFormatOverride();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        statisticalBarRenderer0.drawRangeGridline(graphics2D2, categoryPlot17, (org.jfree.chart.axis.ValueAxis) numberAxis27, rectangle2D39, (double) '4');
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo44);
        java.lang.Object obj46 = plotRenderingInfo45.clone();
        org.jfree.chart.renderer.RendererState rendererState47 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo45);
        categoryPlot17.handleClick((int) ' ', 255, plotRenderingInfo45);
        java.awt.geom.Rectangle2D rectangle2D49 = plotRenderingInfo45.getPlotArea();
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = plotRenderingInfo45.getSubplotInfo((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(gradientPaintTransformer16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(categoryItemRenderer24);
        org.junit.Assert.assertNotNull(categoryAnchor25);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertNull(numberFormat38);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNull(rectangle2D49);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets1.getRight();
        double double4 = rectangleInsets1.extendHeight((double) (byte) 1);
        double double5 = rectangleInsets1.getLeft();
        boolean boolean6 = centerArrangement0.equals((java.lang.Object) double5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot9 = null;
        numberAxis8.setPlot(plot9);
        numberAxis8.setNegativeArrowVisible(true);
        numberAxis8.resizeRange(10.0d, (double) 100.0f);
        boolean boolean16 = centerArrangement0.equals((java.lang.Object) 100.0f);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset17.validateObject();
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer21 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset17, (java.lang.Comparable) (short) 0);
        org.jfree.data.general.Dataset dataset22 = legendItemBlockContainer21.getDataset();
        org.jfree.data.general.Dataset dataset23 = legendItemBlockContainer21.getDataset();
        org.jfree.data.general.Dataset dataset24 = legendItemBlockContainer21.getDataset();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.0d + "'", double4 == 7.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) number19, Double.NaN, 0);
        org.junit.Assert.assertNotNull(dataset22);
        org.junit.Assert.assertNotNull(dataset23);
        org.junit.Assert.assertNotNull(dataset24);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = textTitle1.getPosition();
        boolean boolean3 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object[][] objArray1 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = null;
        numberAxis1.setPlot(plot2);
        numberAxis1.setNegativeArrowVisible(true);
        numberAxis1.resizeRange(10.0d, (double) 100.0f);
        double double9 = numberAxis1.getUpperMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener10 = null;
        numberAxis1.removeChangeListener(axisChangeListener10);
        java.text.NumberFormat numberFormat12 = numberAxis1.getNumberFormatOverride();
        java.awt.Shape shape13 = numberAxis1.getUpArrow();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNull(numberFormat12);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.POSITIVE");
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("hi!", font5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int8 = color7.getAlpha();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("CategoryLabelWidthType.CATEGORY", font5, (java.awt.Paint) color7);
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 100L, font5);
        float float11 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState14 = new org.jfree.chart.axis.AxisState(0.0d);
        axisState14.cursorRight((double) 10L);
        axisState14.setCursor(1.0d);
        java.util.List list19 = null;
        axisState14.setTicks(list19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.axis.AxisSpace axisSpace22 = new org.jfree.chart.axis.AxisSpace();
        axisSpace22.setLeft(1.0E-8d);
        org.jfree.chart.axis.AxisSpace axisSpace25 = new org.jfree.chart.axis.AxisSpace();
        axisSpace25.setBottom(10.0d);
        org.jfree.chart.axis.AxisSpace axisSpace28 = new org.jfree.chart.axis.AxisSpace();
        axisSpace25.ensureAtLeast(axisSpace28);
        axisSpace22.ensureAtLeast(axisSpace25);
        java.awt.Color color31 = java.awt.Color.RED;
        java.awt.image.ColorModel colorModel32 = null;
        java.awt.Rectangle rectangle33 = null;
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("MINOR");
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = textTitle35.getPosition();
        textTitle35.setNotify(false);
        boolean boolean39 = textTitle35.getExpandToFitSpace();
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo42 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo42.setVersion("");
        org.jfree.chart.axis.AxisState axisState46 = new org.jfree.chart.axis.AxisState(0.0d);
        double double47 = axisState46.getMax();
        java.util.List list48 = axisState46.getTicks();
        projectInfo42.setContributors(list48);
        java.lang.Object obj50 = textTitle35.draw(graphics2D40, rectangle2D41, (java.lang.Object) list48);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent51 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle35);
        org.jfree.chart.util.Size2D size2D52 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo60 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        boolean boolean62 = basicProjectInfo60.equals((java.lang.Object) rectangleAnchor61);
        java.awt.geom.Rectangle2D rectangle2D63 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D52, 105.0d, (double) (-8355585), rectangleAnchor61);
        textTitle35.setBounds(rectangle2D63);
        java.awt.geom.AffineTransform affineTransform65 = null;
        java.awt.RenderingHints renderingHints66 = null;
        java.awt.PaintContext paintContext67 = color31.createContext(colorModel32, rectangle33, rectangle2D63, affineTransform65, renderingHints66);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean69 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge68);
        java.awt.geom.Rectangle2D rectangle2D70 = axisSpace22.reserved(rectangle2D63, rectangleEdge68);
        try {
            java.util.List list71 = categoryAxis1.refreshTicks(graphics2D12, axisState14, rectangle2D21, rectangleEdge68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNull(obj50);
        org.junit.Assert.assertNotNull(rectangleAnchor61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(paintContext67);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(rectangle2D70);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        java.util.List list2 = axisState1.getTicks();
        axisState1.setCursor(3.0d);
        axisState1.setMax((-6.0d));
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 500);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("CategoryLabelWidthType.CATEGORY", "NOID", "", "SortOrder.DESCENDING", shape5, (java.awt.Paint) color6);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer8 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendItem7.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer8);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        java.lang.Object obj1 = null;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 10L, obj1);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double5 = numberAxis4.getUpperBound();
        numberAxis4.setTickLabelsVisible(true);
        keyedObject2.setObject((java.lang.Object) numberAxis4);
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, rectangleAnchor10, (double) (-1.0f), (double) (byte) 10);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity16 = new org.jfree.chart.entity.TickLabelEntity(shape13, "hi!", "hi!");
        numberAxis4.setRightArrow(shape13);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = null;
        numberAxis4.setMarkerBand(markerAxisBand18);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor6, (double) (-1.0f), (double) (byte) 10);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int12 = color11.getAlpha();
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.util.ShapeList shapeList23 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor26, (double) (-1.0f), (double) (byte) 10);
        shapeList23.setShape(2, shape25);
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer32 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double33 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke35 = statisticalBarRenderer32.getSeriesOutlineStroke(0);
        statisticalBarRenderer32.setBaseSeriesVisibleInLegend(false, false);
        double double39 = statisticalBarRenderer32.getItemMargin();
        java.awt.Stroke stroke41 = statisticalBarRenderer32.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = statisticalBarRenderer32.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Color color45 = java.awt.Color.cyan;
        statisticalBarRenderer32.setBaseFillPaint((java.awt.Paint) color45, false);
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "ThreadContext", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "", true, shape9, false, (java.awt.Paint) color11, true, (java.awt.Paint) color14, stroke21, true, shape25, stroke31, (java.awt.Paint) color45);
        org.jfree.chart.JFreeChart jFreeChart49 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent52 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) legendItem48, jFreeChart49, 1, (int) (short) 100);
        org.jfree.chart.JFreeChart jFreeChart53 = chartProgressEvent52.getChart();
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = null;
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.Plot plot59 = null;
        numberAxis58.setPlot(plot59);
        numberAxis58.setLabelToolTip("");
        java.lang.String str63 = numberAxis58.getLabelURL();
        numberAxis58.setRangeAboutValue((double) '4', (double) 3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer67 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer68 = statisticalBarRenderer67.getGradientPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis56, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer67);
        org.jfree.chart.axis.AxisLocation axisLocation70 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        boolean boolean72 = axisLocation70.equals((java.lang.Object) 2);
        categoryPlot69.setRangeAxisLocation(axisLocation70);
        categoryPlot69.configureRangeAxes();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier75 = categoryPlot69.getDrawingSupplier();
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = categoryPlot69.getDomainAxisEdge();
        org.jfree.chart.JFreeChart jFreeChart77 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot69);
        org.jfree.chart.event.ChartProgressListener chartProgressListener78 = null;
        jFreeChart77.addProgressListener(chartProgressListener78);
        org.jfree.chart.plot.Plot plot80 = jFreeChart77.getPlot();
        chartProgressEvent52.setChart(jFreeChart77);
        org.jfree.chart.title.TextTitle textTitle83 = new org.jfree.chart.title.TextTitle("");
        jFreeChart77.removeSubtitle((org.jfree.chart.title.Title) textTitle83);
        org.jfree.chart.util.RectangleInsets rectangleInsets85 = textTitle83.getPadding();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNull(stroke35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNull(stroke41);
        org.junit.Assert.assertNull(categoryToolTipGenerator44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNull(jFreeChart53);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(gradientPaintTransformer68);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(drawingSupplier75);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertNotNull(plot80);
        org.junit.Assert.assertNotNull(rectangleInsets85);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke3 = statisticalBarRenderer0.getSeriesOutlineStroke(0);
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(false, false);
        double double7 = statisticalBarRenderer0.getItemMargin();
        java.awt.Stroke stroke9 = statisticalBarRenderer0.getSeriesStroke((int) '#');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = statisticalBarRenderer0.getToolTipGenerator((int) '#', (int) (short) 0);
        java.awt.Paint paint15 = statisticalBarRenderer0.getItemOutlinePaint(0, (-16711681));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNull(categoryToolTipGenerator12);
        org.junit.Assert.assertNotNull(paint15);
    }
}

