import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 100, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number2 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number2);
        int int5 = timeSeriesDataItem3.compareTo((java.lang.Object) '4');
        int int6 = month0.compareTo((java.lang.Object) '4');
        long long7 = month0.getLastMillisecond();
        java.lang.Class class8 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date10);
        int int15 = month0.compareTo((java.lang.Object) date10);
        int int16 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getMonth();
//        int int13 = day11.getMonth();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190909677L + "'", long7 == 1560190909677L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
        timeSeries7.setKey((java.lang.Comparable) 1560190859422L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number17 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, number17);
        int int20 = timeSeriesDataItem18.compareTo((java.lang.Object) '4');
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        long long22 = month21.getSerialIndex();
        boolean boolean24 = month21.equals((java.lang.Object) 10);
        long long25 = month21.getFirstMillisecond();
        org.jfree.data.time.Year year26 = month21.getYear();
        int int27 = timeSeriesDataItem18.compareTo((java.lang.Object) year26);
        try {
            timeSeries7.add(timeSeriesDataItem18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 24234L + "'", long22 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1559372400000L + "'", long25 == 1559372400000L);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        timeSeries7.fireSeriesChanged();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
//        long long27 = day26.getFirstMillisecond();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number30);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem31, "June 2019", "June 2019", class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries36.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (byte) -1);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) year50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) year50);
//        long long55 = day26.getFirstMillisecond();
//        java.util.Calendar calendar56 = null;
//        try {
//            day26.peg(calendar56);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190909796L + "'", long22 == 1560190909796L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560150000000L + "'", long55 == 1560150000000L);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        boolean boolean23 = timeSeries17.isEmpty();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.previous();
        boolean boolean28 = year24.equals((java.lang.Object) 1560190852108L);
        int int30 = year24.compareTo((java.lang.Object) 1560190855204L);
        java.util.Date date31 = year24.getStart();
        timeSeries17.setKey((java.lang.Comparable) date31);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1560190857476L);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1560190857476]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=1560190857476]"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("September");
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        java.lang.Number number8 = timeSeriesDataItem2.getValue();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        long long10 = month9.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number12 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, number12);
//        java.lang.Object obj14 = timeSeriesDataItem13.clone();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem13, "June 2019", "June 2019", class17);
//        timeSeries18.removeAgedItems(true);
//        timeSeries18.setKey((java.lang.Comparable) (byte) -1);
//        boolean boolean23 = month9.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month9.next();
//        int int25 = timeSeriesDataItem2.compareTo((java.lang.Object) month9);
//        int int27 = month9.compareTo((java.lang.Object) 1560190860518L);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date30 = fixedMillisecond29.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date30);
//        boolean boolean33 = fixedMillisecond31.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond31.getFirstMillisecond(calendar34);
//        java.util.Date date36 = fixedMillisecond31.getTime();
//        java.util.TimeZone timeZone37 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date36, timeZone37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date36);
//        long long40 = day39.getFirstMillisecond();
//        java.lang.Class class41 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date43 = fixedMillisecond42.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(date43);
//        boolean boolean46 = fixedMillisecond44.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar47 = null;
//        long long48 = fixedMillisecond44.getFirstMillisecond(calendar47);
//        java.util.Date date49 = fixedMillisecond44.getTime();
//        java.util.TimeZone timeZone50 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date49, timeZone50);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date49);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date49);
//        boolean boolean54 = day39.equals((java.lang.Object) year53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year53.previous();
//        boolean boolean56 = month9.equals((java.lang.Object) regularTimePeriod55);
//        long long57 = month9.getLastMillisecond();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24234L + "'", long10 == 24234L);
//        org.junit.Assert.assertNotNull(obj14);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560190910611L + "'", long35 == 1560190910611L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560150000000L + "'", long40 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560190910612L + "'", long48 == 1560190910612L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1561964399999L + "'", long57 == 1561964399999L);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.String str2 = month0.toString();
        int int3 = month0.getMonth();
        java.lang.Object obj4 = null;
        int int5 = month0.compareTo(obj4);
        org.jfree.data.time.Year year6 = month0.getYear();
        java.lang.String str7 = year6.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        boolean boolean4 = year0.equals((java.lang.Object) 1560190852108L);
        long long5 = year0.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, number8);
//        timeSeriesDataItem9.setValue((java.lang.Number) (short) -1);
//        boolean boolean12 = fixedMillisecond0.equals((java.lang.Object) timeSeriesDataItem9);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "SerialDate.weekInMonthToString(): invalid code.", "Wed Dec 31 15:59:59 PST 1969", class15);
//        java.lang.String str17 = timeSeries16.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number19 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, number19);
//        java.lang.Object obj21 = timeSeriesDataItem20.clone();
//        java.lang.Class class24 = null;
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem20, "June 2019", "June 2019", class24);
//        timeSeries25.removeAgedItems(true);
//        timeSeries25.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries25.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number33 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, number33);
//        java.lang.Object obj35 = timeSeriesDataItem34.clone();
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem34, "June 2019", "June 2019", class38);
//        timeSeries39.removeAgedItems(true);
//        timeSeries39.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries39.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number47 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, number47);
//        java.util.Calendar calendar49 = null;
//        long long50 = fixedMillisecond46.getMiddleMillisecond(calendar49);
//        java.util.Calendar calendar51 = null;
//        long long52 = fixedMillisecond46.getMiddleMillisecond(calendar51);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (java.lang.Number) 8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number58 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57, number58);
//        java.util.Calendar calendar60 = null;
//        long long61 = fixedMillisecond57.getLastMillisecond(calendar60);
//        long long62 = fixedMillisecond57.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number64 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, number64);
//        java.util.Calendar calendar66 = null;
//        long long67 = fixedMillisecond63.getLastMillisecond(calendar66);
//        long long68 = fixedMillisecond63.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = fixedMillisecond57.previous();
//        java.lang.Class class71 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date73 = fixedMillisecond72.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond(date73);
//        boolean boolean76 = fixedMillisecond74.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar77 = null;
//        long long78 = fixedMillisecond74.getFirstMillisecond(calendar77);
//        java.util.Date date79 = fixedMillisecond74.getTime();
//        java.util.TimeZone timeZone80 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class71, date79, timeZone80);
//        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date79);
//        int int83 = day82.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries16.createCopy(regularTimePeriod70, (org.jfree.data.time.RegularTimePeriod) day82);
//        java.util.List list85 = timeSeries84.getItems();
//        java.lang.String str86 = timeSeries84.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190910912L + "'", long4 == 1560190910912L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190910912L + "'", long6 == 1560190910912L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560190910916L + "'", long50 == 1560190910916L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560190910916L + "'", long52 == 1560190910916L);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//        org.junit.Assert.assertNull(timeSeriesDataItem56);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560190910917L + "'", long61 == 1560190910917L);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560190910917L + "'", long62 == 1560190910917L);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1560190910918L + "'", long67 == 1560190910918L);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560190910918L + "'", long68 == 1560190910918L);
//        org.junit.Assert.assertNotNull(timeSeries69);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1560190910919L + "'", long78 == 1560190910919L);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 10 + "'", int83 == 10);
//        org.junit.Assert.assertNotNull(timeSeries84);
//        org.junit.Assert.assertNotNull(list85);
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str86.equals("SerialDate.weekInMonthToString(): invalid code."));
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.lang.Class<?> wildcardClass3 = year0.getClass();
        long long4 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries7.getTimePeriod((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection8);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1964, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate5);
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getNearestDayOfWeek(7);
//        boolean boolean11 = spreadsheetDate2.isAfter(serialDate10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date13 = fixedMillisecond12.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date13);
//        java.lang.String str16 = serialDate15.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int19 = spreadsheetDate18.getDayOfWeek();
//        boolean boolean20 = spreadsheetDate2.isInRange(serialDate15, (org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date22 = fixedMillisecond21.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(date22);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date22);
//        java.lang.String str25 = serialDate24.toString();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate24);
//        boolean boolean27 = spreadsheetDate2.isOnOrBefore(serialDate24);
//        try {
//            org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) '#', (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries7.getDescription();
        boolean boolean11 = timeSeries7.getNotify();
        java.lang.String str12 = timeSeries7.getDescription();
        timeSeries7.setDomainDescription("Wed Dec 31 15:59:59 PST 1969");
        java.lang.Class class15 = timeSeries7.getTimePeriodClass();
        timeSeries7.setMaximumItemAge(1560190883994L);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(class15);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        long long8 = timeSeries7.getMaximumItemAge();
        timeSeries7.setDomainDescription("17-May-1927");
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int30 = spreadsheetDate29.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate32.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean36 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, serialDate32, (int) ' ');
//        java.lang.String[] strArray37 = org.jfree.data.time.SerialDate.getMonths();
//        boolean boolean38 = spreadsheetDate1.equals((java.lang.Object) strArray37);
//        int int39 = spreadsheetDate1.getMonth();
//        int int40 = spreadsheetDate1.getMonth();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190911849L + "'", long9 == 1560190911849L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(strArray37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        java.util.Collection collection11 = timeSeries7.getTimePeriods();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
//        boolean boolean17 = fixedMillisecond15.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getFirstMillisecond(calendar18);
//        java.util.Date date20 = fixedMillisecond15.getTime();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date20, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20);
//        int int24 = day23.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 2);
//        java.lang.String str27 = timeSeries7.getDescription();
//        java.lang.String str28 = timeSeries7.getDescription();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560190912011L + "'", long19 == 1560190912011L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertNull(str28);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
//        java.lang.Object obj13 = timeSeriesDataItem12.clone();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries17.removeChangeListener(seriesChangeListener18);
//        java.util.Collection collection20 = timeSeries17.getTimePeriods();
//        java.lang.Comparable comparable21 = timeSeries17.getKey();
//        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries17.removeChangeListener(seriesChangeListener23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number26 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number26);
//        java.lang.Object obj28 = timeSeriesDataItem27.clone();
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem27, "June 2019", "June 2019", class31);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries32.removeChangeListener(seriesChangeListener33);
//        timeSeries32.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number38 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, number38);
//        java.lang.Object obj40 = timeSeriesDataItem39.clone();
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem39, "June 2019", "June 2019", class43);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener45 = null;
//        timeSeries44.removeChangeListener(seriesChangeListener45);
//        java.util.Collection collection47 = timeSeries44.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener48 = null;
//        timeSeries44.removeChangeListener(seriesChangeListener48);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        long long51 = year50.getFirstMillisecond();
//        int int52 = timeSeries44.getIndex((org.jfree.data.time.RegularTimePeriod) year50);
//        timeSeries44.setMaximumItemCount((int) '4');
//        timeSeries44.setMaximumItemCount(100);
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries32.addAndOrUpdate(timeSeries44);
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries17.addAndOrUpdate(timeSeries44);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
//        long long60 = year59.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = year59.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year59.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries17.getDataItem(regularTimePeriod62);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number65 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, number65);
//        java.util.Calendar calendar67 = null;
//        long long68 = fixedMillisecond64.getLastMillisecond(calendar67);
//        long long69 = fixedMillisecond64.getMiddleMillisecond();
//        try {
//            timeSeries17.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (double) 5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertNotNull(comparable21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertNotNull(obj40);
//        org.junit.Assert.assertNotNull(collection47);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1546329600000L + "'", long51 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1546329600000L + "'", long60 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560190912116L + "'", long68 == 1560190912116L);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560190912116L + "'", long69 == 1560190912116L);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        java.beans.PropertyChangeListener propertyChangeListener39 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener39);
//        java.beans.PropertyChangeListener propertyChangeListener41 = null;
//        timeSeries7.removePropertyChangeListener(propertyChangeListener41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number44 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, number44);
//        java.lang.Object obj46 = timeSeriesDataItem45.clone();
//        java.lang.Class class49 = null;
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem45, "June 2019", "June 2019", class49);
//        timeSeriesDataItem45.setValue((java.lang.Number) 1560190852108L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number54 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, number54);
//        java.lang.Object obj56 = timeSeriesDataItem55.clone();
//        java.lang.Class class59 = null;
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem55, "June 2019", "June 2019", class59);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener61 = null;
//        timeSeries60.removeChangeListener(seriesChangeListener61);
//        java.util.Collection collection63 = timeSeries60.getTimePeriods();
//        java.lang.Comparable comparable64 = timeSeries60.getKey();
//        boolean boolean65 = timeSeriesDataItem45.equals((java.lang.Object) timeSeries60);
//        try {
//            timeSeries7.add(timeSeriesDataItem45);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190912132L + "'", long32 == 1560190912132L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190912132L + "'", long34 == 1560190912132L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertNotNull(obj46);
//        org.junit.Assert.assertNotNull(obj56);
//        org.junit.Assert.assertNotNull(collection63);
//        org.junit.Assert.assertNotNull(comparable64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        java.lang.String str12 = timeSeries7.getDomainDescription();
        java.util.List list13 = timeSeries7.getItems();
        java.lang.String str14 = timeSeries7.getRangeDescription();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(comparable11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 1927, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getLastMillisecond(calendar6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getMiddleMillisecond(calendar8);
//        boolean boolean10 = fixedMillisecond0.equals((java.lang.Object) fixedMillisecond5);
//        long long11 = fixedMillisecond0.getSerialIndex();
//        long long12 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560190912204L + "'", long3 == 1560190912204L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190912204L + "'", long4 == 1560190912204L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190912205L + "'", long7 == 1560190912205L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190912205L + "'", long9 == 1560190912205L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560190912204L + "'", long11 == 1560190912204L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560190912204L + "'", long12 == 1560190912204L);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        timeSeries17.removeAgedItems(false);
        timeSeries17.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code.");
        timeSeries17.setRangeDescription("org.jfree.data.general.SeriesException: June 2019");
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number40 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, number40);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond39.getLastMillisecond(calendar42);
//        long long44 = fixedMillisecond39.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number46 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, number46);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond45.getLastMillisecond(calendar48);
//        long long50 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
//        long long52 = fixedMillisecond45.getMiddleMillisecond();
//        java.lang.Object obj53 = null;
//        int int54 = fixedMillisecond45.compareTo(obj53);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190912267L + "'", long32 == 1560190912267L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190912267L + "'", long34 == 1560190912267L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560190912268L + "'", long43 == 1560190912268L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560190912268L + "'", long44 == 1560190912268L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560190912269L + "'", long49 == 1560190912269L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560190912269L + "'", long50 == 1560190912269L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560190912269L + "'", long52 == 1560190912269L);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond14.getMiddleMillisecond(calendar17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond14.getMiddleMillisecond(calendar19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1546329600000L);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.previous();
//        java.lang.Number number26 = timeSeries7.getValue(regularTimePeriod25);
//        timeSeries7.setRangeDescription("June 2019");
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560190912375L + "'", long18 == 1560190912375L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190912375L + "'", long20 == 1560190912375L);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1.5463296E12d + "'", number26.equals(1.5463296E12d));
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries7.setMaximumItemCount((int) '4');
        java.lang.Class class18 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, number20);
        java.lang.Object obj22 = timeSeriesDataItem21.clone();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem21, "June 2019", "June 2019", class25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries26.removeChangeListener(seriesChangeListener27);
        java.util.Collection collection29 = timeSeries26.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries26.removeChangeListener(seriesChangeListener30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getFirstMillisecond();
        int int34 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date36 = fixedMillisecond35.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (double) (byte) -1);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year40.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year40.previous();
        boolean boolean43 = fixedMillisecond37.equals((java.lang.Object) year40);
        boolean boolean44 = timeSeries7.equals((java.lang.Object) fixedMillisecond37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = null;
        try {
            timeSeries7.update(regularTimePeriod45, (java.lang.Number) 1560190859036L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number13 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number13);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "June 2019", "June 2019", class18);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        java.util.Collection collection22 = timeSeries19.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries19.removeChangeListener(seriesChangeListener23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        int int27 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
        timeSeries19.setMaximumItemCount((int) '4');
        timeSeries19.setMaximumItemCount(100);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries7.addAndOrUpdate(timeSeries19);
        java.lang.String str33 = timeSeries7.getRangeDescription();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        long long35 = month34.getSerialIndex();
        boolean boolean37 = month34.equals((java.lang.Object) 10);
        long long38 = month34.getFirstMillisecond();
        int int39 = month34.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month34.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number45 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, number45);
        java.lang.Object obj47 = timeSeriesDataItem46.clone();
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem46, "June 2019", "June 2019", class50);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener52 = null;
        timeSeries51.removeChangeListener(seriesChangeListener52);
        java.util.Collection collection54 = timeSeries51.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries51.removeChangeListener(seriesChangeListener55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        long long58 = year57.getFirstMillisecond();
        int int59 = timeSeries51.getIndex((org.jfree.data.time.RegularTimePeriod) year57);
        timeSeries51.setMaximumItemCount((int) '4');
        timeSeries51.setMaximumItemCount(100);
        int int64 = timeSeries51.getMaximumItemCount();
        java.lang.Class<?> wildcardClass65 = timeSeries51.getClass();
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2147483647, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass65);
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month34, (java.lang.Class) wildcardClass65);
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries7.addAndOrUpdate(timeSeries67);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = timeSeries67.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 24234L + "'", long35 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1559372400000L + "'", long38 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1546329600000L + "'", long58 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 100 + "'", int64 == 100);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(timeSeries68);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, number8);
//        timeSeriesDataItem9.setValue((java.lang.Number) (short) -1);
//        boolean boolean12 = fixedMillisecond0.equals((java.lang.Object) timeSeriesDataItem9);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "SerialDate.weekInMonthToString(): invalid code.", "Wed Dec 31 15:59:59 PST 1969", class15);
//        timeSeries16.clear();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190912479L + "'", long4 == 1560190912479L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190912479L + "'", long6 == 1560190912479L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Wed Dec 31 15:59:59 PST 1969");
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond14.getMiddleMillisecond(calendar17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond14.getMiddleMillisecond(calendar19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1546329600000L);
//        long long23 = fixedMillisecond14.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond14.previous();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560190912512L + "'", long18 == 1560190912512L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190912512L + "'", long20 == 1560190912512L);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190912512L + "'", long23 == 1560190912512L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        timeSeries7.delete(regularTimePeriod15);
        int int17 = timeSeries7.getMaximumItemCount();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        java.util.Collection collection11 = timeSeries7.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries21.removeChangeListener(seriesChangeListener22);
//        timeSeries21.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number27 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, number27);
//        java.lang.Object obj29 = timeSeriesDataItem28.clone();
//        java.lang.Class class32 = null;
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem28, "June 2019", "June 2019", class32);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
//        timeSeries33.removeChangeListener(seriesChangeListener34);
//        java.util.Collection collection36 = timeSeries33.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries33.removeChangeListener(seriesChangeListener37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
//        long long40 = year39.getFirstMillisecond();
//        int int41 = timeSeries33.getIndex((org.jfree.data.time.RegularTimePeriod) year39);
//        timeSeries33.setMaximumItemCount((int) '4');
//        timeSeries33.setMaximumItemCount(100);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries21.addAndOrUpdate(timeSeries33);
//        int int47 = timeSeries46.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date49 = fixedMillisecond48.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(date49);
//        long long51 = fixedMillisecond50.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (double) 1560190879376L);
//        java.util.Calendar calendar54 = null;
//        fixedMillisecond50.peg(calendar54);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertNotNull(obj29);
//        org.junit.Assert.assertNotNull(collection36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1546329600000L + "'", long40 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560190912671L + "'", long51 == 1560190912671L);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertNull(timeSeriesDataItem56);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("10-January-1900");
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries17.addChangeListener(seriesChangeListener23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number26 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number26);
        java.lang.Object obj28 = timeSeriesDataItem27.clone();
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem27, "June 2019", "June 2019", class31);
        timeSeriesDataItem27.setValue((java.lang.Number) 1560190852108L);
        try {
            timeSeries17.add(timeSeriesDataItem27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100, (int) (byte) 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries7.getDataItem((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection8);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        int int14 = day11.compareTo((java.lang.Object) 1560190851150L);
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day11.equals(obj15);
//        org.jfree.data.time.SerialDate serialDate17 = day11.getSerialDate();
//        long long18 = day11.getSerialIndex();
//        java.util.Calendar calendar19 = null;
//        try {
//            day11.peg(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190913649L + "'", long7 == 1560190913649L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        try {
            org.jfree.data.time.TimeSeries timeSeries10 = timeSeries7.createCopy(1900, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2147483647) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560190899486L, class1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date17 = fixedMillisecond16.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) (byte) -1);
        java.util.Collection collection21 = timeSeries7.getTimePeriods();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(collection21);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeries7.removeAgedItems(true);
        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
        timeSeries7.setRangeDescription("2019");
        long long14 = timeSeries7.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number16 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, number16);
        java.lang.Object obj18 = timeSeriesDataItem17.clone();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem17, "June 2019", "June 2019", class21);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries22.removeChangeListener(seriesChangeListener23);
        java.util.Collection collection25 = timeSeries22.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries22.removeChangeListener(seriesChangeListener26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        long long29 = year28.getFirstMillisecond();
        int int30 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) year28);
        int int31 = year28.getYear();
        java.lang.Class<?> wildcardClass32 = year28.getClass();
        long long33 = year28.getFirstMillisecond();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year28, (double) 1560190876701L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) '#');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray25 = seriesException24.getSuppressed();
        int int26 = timeSeriesDataItem2.compareTo((java.lang.Object) seriesException24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("SerialDate.weekInMonthToString(): invalid code.");
        seriesException24.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        java.lang.String str30 = timePeriodFormatException28.toString();
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException28.getSuppressed();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code." + "'", str30.equals("org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code."));
        org.junit.Assert.assertNotNull(throwableArray31);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getFirstMillisecond();
//        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number17 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, number17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond16.getMiddleMillisecond(calendar19);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond16.getMiddleMillisecond(calendar21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number24 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, number24);
//        timeSeriesDataItem25.setValue((java.lang.Number) (short) -1);
//        boolean boolean28 = fixedMillisecond16.equals((java.lang.Object) timeSeriesDataItem25);
//        try {
//            timeSeries7.add(timeSeriesDataItem25);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190914068L + "'", long20 == 1560190914068L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190914068L + "'", long22 == 1560190914068L);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560190855309L);
        int int5 = timeSeriesDataItem3.compareTo((java.lang.Object) 1560190865047L);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        try {
            int int3 = spreadsheetDate1.compareTo((java.lang.Object) 1560190895288L);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 0, 2958465);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, number4);
        java.lang.Object obj6 = timeSeriesDataItem5.clone();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem5, "June 2019", "June 2019", class9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.removeChangeListener(seriesChangeListener11);
        java.util.Collection collection13 = timeSeries10.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries10.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getFirstMillisecond();
        int int18 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        int int19 = year16.getYear();
        java.lang.Class<?> wildcardClass20 = year16.getClass();
        boolean boolean21 = year0.equals((java.lang.Object) year16);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number13 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number13);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "June 2019", "June 2019", class18);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        java.util.Collection collection22 = timeSeries19.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries19.removeChangeListener(seriesChangeListener23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        int int27 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
        timeSeries19.setMaximumItemCount((int) '4');
        timeSeries19.setMaximumItemCount(100);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries7.addAndOrUpdate(timeSeries19);
        java.lang.String str33 = timeSeries7.getRangeDescription();
        timeSeries7.setDomainDescription("May");
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number37 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, number37);
        java.lang.Object obj39 = timeSeriesDataItem38.clone();
        java.lang.Class class42 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem38, "June 2019", "June 2019", class42);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener44 = null;
        timeSeries43.removeChangeListener(seriesChangeListener44);
        java.util.Collection collection46 = timeSeries43.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener47 = null;
        timeSeries43.removeChangeListener(seriesChangeListener47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        long long50 = year49.getFirstMillisecond();
        int int51 = timeSeries43.getIndex((org.jfree.data.time.RegularTimePeriod) year49);
        int int52 = year49.getYear();
        java.lang.Class<?> wildcardClass53 = year49.getClass();
        long long54 = year49.getFirstMillisecond();
        java.lang.Number number55 = null;
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year49, number55, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(collection46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1546329600000L + "'", long50 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1546329600000L + "'", long54 == 1546329600000L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, number3);
        java.lang.Object obj5 = timeSeriesDataItem4.clone();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem4, "June 2019", "June 2019", class8);
        timeSeries9.removeAgedItems(true);
        timeSeries9.setKey((java.lang.Comparable) (byte) -1);
        boolean boolean14 = month0.equals((java.lang.Object) (byte) -1);
        int int15 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1964, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries7.setMaximumItemCount((int) '4');
        timeSeries7.setMaximumItemCount(100);
        int int20 = timeSeries7.getMaximumItemCount();
        timeSeries7.removeAgedItems(false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        boolean boolean13 = timeSeries7.isEmpty();
        java.util.List list14 = timeSeries7.getItems();
        boolean boolean15 = timeSeries7.isEmpty();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        java.lang.String str7 = fixedMillisecond0.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 4);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190914339L + "'", long4 == 1560190914339L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190914339L + "'", long6 == 1560190914339L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Mon Jun 10 11:21:54 PDT 2019" + "'", str7.equals("Mon Jun 10 11:21:54 PDT 2019"));
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560190855309L);
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1560190855309L);
//        java.util.Date date10 = fixedMillisecond6.getTime();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date13 = fixedMillisecond12.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date10, timeZone15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date4, timeZone15);
//        long long19 = day18.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43626L + "'", long19 == 43626L);
//    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate30);
//        org.jfree.data.time.SerialDate serialDate33 = serialDate31.getFollowingDayOfWeek(3);
//        boolean boolean34 = spreadsheetDate1.isOn(serialDate31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int37 = spreadsheetDate36.getMonth();
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate40);
//        org.jfree.data.time.SerialDate serialDate43 = serialDate41.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate45 = serialDate43.getNearestDayOfWeek(7);
//        boolean boolean46 = spreadsheetDate36.isBefore(serialDate43);
//        boolean boolean47 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate36);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class50 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date52 = fixedMillisecond51.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(date52);
//        boolean boolean55 = fixedMillisecond53.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar56 = null;
//        long long57 = fixedMillisecond53.getFirstMillisecond(calendar56);
//        java.util.Date date58 = fixedMillisecond53.getTime();
//        java.util.TimeZone timeZone59 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date58, timeZone59);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date58);
//        int int62 = day61.getDayOfMonth();
//        int int64 = day61.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate65 = day61.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate68);
//        org.jfree.data.time.SerialDate serialDate71 = serialDate69.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate73 = serialDate71.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate74 = serialDate65.getEndOfCurrentMonth(serialDate71);
//        boolean boolean75 = spreadsheetDate49.isOnOrBefore(serialDate74);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int78 = spreadsheetDate77.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate80.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean84 = spreadsheetDate49.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate77, serialDate80, (int) ' ');
//        int int85 = spreadsheetDate49.getMonth();
//        int int86 = spreadsheetDate36.compare((org.jfree.data.time.SerialDate) spreadsheetDate49);
//        java.util.Date date87 = spreadsheetDate49.toDate();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190914664L + "'", long9 == 1560190914664L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5 + "'", int37 == 5);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560190914669L + "'", long57 == 1560190914669L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 10 + "'", int62 == 10);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertNotNull(serialDate71);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 3 + "'", int78 == 3);
//        org.junit.Assert.assertNotNull(serialDate80);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 9992 + "'", int86 == 9992);
//        org.junit.Assert.assertNotNull(date87);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
//        boolean boolean11 = fixedMillisecond9.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond9.getFirstMillisecond(calendar12);
//        java.util.Date date14 = fixedMillisecond9.getTime();
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date14, timeZone15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14);
//        int int18 = day17.getDayOfMonth();
//        int int20 = day17.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate21 = day17.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate24);
//        org.jfree.data.time.SerialDate serialDate27 = serialDate25.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate29 = serialDate27.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate30 = serialDate21.getEndOfCurrentMonth(serialDate27);
//        boolean boolean31 = spreadsheetDate5.isOnOrBefore(serialDate30);
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate35);
//        org.jfree.data.time.SerialDate serialDate38 = serialDate36.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate40 = serialDate38.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate38);
//        serialDate41.setDescription("org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean45 = spreadsheetDate2.isInRange(serialDate30, serialDate41, (int) (short) 10);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560190915380L + "'", long13 == 1560190915380L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        long long12 = day11.getFirstMillisecond();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        boolean boolean18 = fixedMillisecond16.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond16.getFirstMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond16.getTime();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date21);
//        boolean boolean26 = day11.equals((java.lang.Object) year25);
//        long long27 = day11.getSerialIndex();
//        java.util.Calendar calendar28 = null;
//        try {
//            day11.peg(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190915592L + "'", long7 == 1560190915592L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190915594L + "'", long20 == 1560190915594L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        long long2 = month0.getLastMillisecond();
        long long3 = month0.getMiddleMillisecond();
        int int4 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560190915636L + "'", long3 == 1560190915636L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190915636L + "'", long4 == 1560190915636L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        long long4 = month3.getLastMillisecond();
        int int5 = month3.getMonth();
        int int6 = month3.getYearValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 1560190855309L);
        java.util.Date date5 = fixedMillisecond1.getTime();
        java.lang.Class class6 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date8, timeZone10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone10);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date5);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeries7.removeAgedItems(true);
        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
        timeSeries7.setRangeDescription("2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number15 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
        java.lang.Object obj17 = timeSeriesDataItem16.clone();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.removeChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries21.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries21.removeChangeListener(seriesChangeListener25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getFirstMillisecond();
        int int29 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) year27);
        timeSeries21.setMaximumItemCount((int) '4');
        timeSeries21.setMaximumItemCount(100);
        int int34 = timeSeries21.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries7.addAndOrUpdate(timeSeries21);
        timeSeries7.setMaximumItemCount(2);
        int int38 = timeSeries7.getMaximumItemCount();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        boolean boolean4 = fixedMillisecond2.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond2.getFirstMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond2.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) 1560190857893L);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond2.getMiddleMillisecond(calendar10);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190916339L + "'", long6 == 1560190916339L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560190916339L + "'", long11 == 1560190916339L);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate4);
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(7);
//        boolean boolean10 = spreadsheetDate1.isAfter(serialDate9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.lang.String str15 = serialDate14.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int18 = spreadsheetDate17.getDayOfWeek();
//        boolean boolean19 = spreadsheetDate1.isInRange(serialDate14, (org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int20 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int23 = spreadsheetDate22.getMonth();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate26);
//        org.jfree.data.time.SerialDate serialDate29 = serialDate27.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate29.getNearestDayOfWeek(7);
//        boolean boolean32 = spreadsheetDate22.isBefore(serialDate29);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class35 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        boolean boolean40 = fixedMillisecond38.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond38.getFirstMillisecond(calendar41);
//        java.util.Date date43 = fixedMillisecond38.getTime();
//        java.util.TimeZone timeZone44 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date43, timeZone44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date43);
//        int int47 = day46.getDayOfMonth();
//        int int49 = day46.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate50 = day46.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate53);
//        org.jfree.data.time.SerialDate serialDate56 = serialDate54.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate58 = serialDate56.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate59 = serialDate50.getEndOfCurrentMonth(serialDate56);
//        boolean boolean60 = spreadsheetDate34.isOnOrBefore(serialDate59);
//        int int61 = spreadsheetDate34.getDayOfWeek();
//        boolean boolean62 = spreadsheetDate1.isInRange(serialDate29, (org.jfree.data.time.SerialDate) spreadsheetDate34);
//        int int63 = spreadsheetDate1.getYYYY();
//        try {
//            org.jfree.data.time.SerialDate serialDate65 = spreadsheetDate1.getFollowingDayOfWeek((-458));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 7 + "'", int20 == 7);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560190916383L + "'", long42 == 1560190916383L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 7 + "'", int61 == 7);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1900 + "'", int63 == 1900);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Overwritten values from: -1");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: June 2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: June 2019");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray5 = seriesException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        int int2 = month0.getYearValue();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        long long6 = year5.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
//        java.lang.Object obj13 = timeSeriesDataItem12.clone();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries17.removeChangeListener(seriesChangeListener18);
//        java.util.Collection collection20 = timeSeries17.getTimePeriods();
//        java.lang.Comparable comparable21 = timeSeries17.getKey();
//        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
//        java.lang.Class class23 = timeSeries17.getTimePeriodClass();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number28 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, number28);
//        java.lang.Object obj30 = timeSeriesDataItem29.clone();
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem29, "June 2019", "June 2019", class33);
//        timeSeries34.removeAgedItems(true);
//        timeSeries34.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries34.setRangeDescription("2019");
//        timeSeries34.fireSeriesChanged();
//        java.lang.Class class42 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date44 = fixedMillisecond43.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(date44);
//        boolean boolean47 = fixedMillisecond45.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond45.getFirstMillisecond(calendar48);
//        java.util.Date date50 = fixedMillisecond45.getTime();
//        java.util.TimeZone timeZone51 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date50, timeZone51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date50);
//        long long54 = day53.getFirstMillisecond();
//        java.util.Date date55 = day53.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number57 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, number57);
//        java.lang.Object obj59 = timeSeriesDataItem58.clone();
//        java.lang.Class class62 = null;
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem58, "June 2019", "June 2019", class62);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener64 = null;
//        timeSeries63.removeChangeListener(seriesChangeListener64);
//        java.util.Collection collection66 = timeSeries63.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener67 = null;
//        timeSeries63.removeChangeListener(seriesChangeListener67);
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
//        long long70 = year69.getFirstMillisecond();
//        int int71 = timeSeries63.getIndex((org.jfree.data.time.RegularTimePeriod) year69);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date73 = fixedMillisecond72.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond(date73);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries63.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond74, (double) (byte) -1);
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = year77.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = year77.previous();
//        boolean boolean80 = fixedMillisecond74.equals((java.lang.Object) year77);
//        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day53, (org.jfree.data.time.RegularTimePeriod) year77);
//        org.jfree.data.time.Month month82 = new org.jfree.data.time.Month();
//        long long83 = month82.getSerialIndex();
//        boolean boolean85 = month82.equals((java.lang.Object) 10);
//        long long86 = month82.getFirstMillisecond();
//        int int87 = month82.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = month82.previous();
//        timeSeries34.setKey((java.lang.Comparable) regularTimePeriod88);
//        java.beans.PropertyChangeListener propertyChangeListener90 = null;
//        timeSeries34.addPropertyChangeListener(propertyChangeListener90);
//        boolean boolean92 = year24.equals((java.lang.Object) propertyChangeListener90);
//        java.lang.Number number93 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) year24);
//        int int95 = year24.compareTo((java.lang.Object) 1560190911849L);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertNotNull(comparable21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNull(class23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(obj30);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560190916573L + "'", long49 == 1560190916573L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560150000000L + "'", long54 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(obj59);
//        org.junit.Assert.assertNotNull(collection66);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1546329600000L + "'", long70 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNull(timeSeriesDataItem76);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(timeSeries81);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 24234L + "'", long83 == 24234L);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 1559372400000L + "'", long86 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 6 + "'", int87 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
//        org.junit.Assert.assertNull(number93);
//        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1 + "'", int95 == 1);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(11);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate5);
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(3);
        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getNearestDayOfWeek(7);
        boolean boolean11 = spreadsheetDate1.isBefore(serialDate8);
        org.jfree.data.time.SerialDate serialDate12 = null;
        try {
            boolean boolean13 = spreadsheetDate1.isAfter(serialDate12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560190855309L);
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        long long5 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getLastMillisecond(calendar6);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560190917147L + "'", long5 == 1560190917147L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190917147L + "'", long7 == 1560190917147L);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        int int12 = timeSeries7.getMaximumItemCount();
        int int13 = timeSeries7.getItemCount();
        java.lang.Class class14 = timeSeries7.getTimePeriodClass();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(class14);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2);
        java.util.Date date8 = month7.getStart();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        long long4 = month3.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month3.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(1963);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.previous();
        boolean boolean6 = year2.equals((java.lang.Object) 1560190852108L);
        long long7 = year2.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, year2);
        java.lang.Object obj9 = null;
        boolean boolean10 = year2.equals(obj9);
        try {
            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 0, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        long long12 = day11.getFirstMillisecond();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        boolean boolean18 = fixedMillisecond16.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond16.getFirstMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond16.getTime();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date21);
//        boolean boolean26 = day11.equals((java.lang.Object) year25);
//        long long27 = year25.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190917307L + "'", long7 == 1560190917307L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190917309L + "'", long20 == 1560190917309L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        java.lang.Class class9 = timeSeries7.getTimePeriodClass();
        timeSeries7.setMaximumItemAge(1560236399999L);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNull(class9);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
//        boolean boolean8 = fixedMillisecond0.equals((java.lang.Object) year4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year4.next();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
//        boolean boolean17 = fixedMillisecond15.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getFirstMillisecond(calendar18);
//        java.util.Date date20 = fixedMillisecond15.getTime();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date20, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20);
//        int int24 = day23.getDayOfMonth();
//        int int26 = day23.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate27 = day23.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate30);
//        org.jfree.data.time.SerialDate serialDate33 = serialDate31.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate35 = serialDate33.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate36 = serialDate27.getEndOfCurrentMonth(serialDate33);
//        boolean boolean37 = spreadsheetDate11.isOnOrBefore(serialDate36);
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate40);
//        org.jfree.data.time.SerialDate serialDate43 = serialDate41.getFollowingDayOfWeek(3);
//        boolean boolean44 = spreadsheetDate11.isOn(serialDate41);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int47 = spreadsheetDate46.getMonth();
//        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate50);
//        org.jfree.data.time.SerialDate serialDate53 = serialDate51.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate55 = serialDate53.getNearestDayOfWeek(7);
//        boolean boolean56 = spreadsheetDate46.isBefore(serialDate53);
//        boolean boolean57 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate46);
//        int int58 = year4.compareTo((java.lang.Object) spreadsheetDate46);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560190917409L + "'", long3 == 1560190917409L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560190917411L + "'", long19 == 1560190917411L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 5 + "'", int47 == 5);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str5 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries7.getDataItem(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.next();
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
//        boolean boolean12 = fixedMillisecond10.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond10.getFirstMillisecond(calendar13);
//        java.util.Date date15 = fixedMillisecond10.getTime();
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date15, timeZone16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date15);
//        long long20 = year19.getFirstMillisecond();
//        java.util.Date date21 = year19.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date23 = fixedMillisecond22.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date27 = fixedMillisecond26.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date27);
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date27, timeZone29);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number32 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, number32);
//        java.lang.Object obj34 = timeSeriesDataItem33.clone();
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem33, "June 2019", "June 2019", class37);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries38.removeChangeListener(seriesChangeListener39);
//        java.util.Collection collection41 = timeSeries38.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener42 = null;
//        timeSeries38.removeChangeListener(seriesChangeListener42);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
//        long long45 = year44.getFirstMillisecond();
//        int int46 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) year44);
//        timeSeries38.setMaximumItemCount((int) '4');
//        timeSeries38.setMaximumItemCount(100);
//        int int51 = timeSeries38.getMaximumItemCount();
//        java.lang.Class<?> wildcardClass52 = timeSeries38.getClass();
//        java.lang.Class class53 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date55 = fixedMillisecond54.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond(date55);
//        boolean boolean58 = fixedMillisecond56.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar59 = null;
//        long long60 = fixedMillisecond56.getFirstMillisecond(calendar59);
//        java.util.Date date61 = fixedMillisecond56.getTime();
//        java.util.TimeZone timeZone62 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date61, timeZone62);
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date61, timeZone64);
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date27, timeZone64);
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date23, timeZone64);
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date21, timeZone64);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date6, timeZone64);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190918127L + "'", long4 == 1560190918127L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560190918127L + "'", long14 == 1560190918127L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertNotNull(collection41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560190918154L + "'", long60 == 1560190918154L);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries17.removeChangeListener(seriesChangeListener23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number26 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number26);
        java.lang.Object obj28 = timeSeriesDataItem27.clone();
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem27, "June 2019", "June 2019", class31);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries32.removeChangeListener(seriesChangeListener33);
        timeSeries32.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number38 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, number38);
        java.lang.Object obj40 = timeSeriesDataItem39.clone();
        java.lang.Class class43 = null;
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem39, "June 2019", "June 2019", class43);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener45 = null;
        timeSeries44.removeChangeListener(seriesChangeListener45);
        java.util.Collection collection47 = timeSeries44.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener48 = null;
        timeSeries44.removeChangeListener(seriesChangeListener48);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getFirstMillisecond();
        int int52 = timeSeries44.getIndex((org.jfree.data.time.RegularTimePeriod) year50);
        timeSeries44.setMaximumItemCount((int) '4');
        timeSeries44.setMaximumItemCount(100);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries32.addAndOrUpdate(timeSeries44);
        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries17.addAndOrUpdate(timeSeries44);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year59.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = year59.previous();
        boolean boolean63 = year59.equals((java.lang.Object) 1560190852108L);
        int int65 = year59.compareTo((java.lang.Object) 1560190855204L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries44.getDataItem((org.jfree.data.time.RegularTimePeriod) year59);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1546329600000L + "'", long51 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertNotNull(timeSeries58);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(4, 0, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        long long9 = year7.getSerialIndex();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("");
        int int12 = year7.compareTo((java.lang.Object) seriesException11);
        boolean boolean13 = year5.equals((java.lang.Object) seriesException11);
        java.lang.Throwable[] throwableArray14 = seriesException11.getSuppressed();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        java.util.TimeZone timeZone4 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date2);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getFirstMillisecond(calendar7);
//        long long9 = fixedMillisecond6.getSerialIndex();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond6.getLastMillisecond(calendar10);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560190919895L + "'", long8 == 1560190919895L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190919895L + "'", long9 == 1560190919895L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560190919895L + "'", long11 == 1560190919895L);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        boolean boolean14 = day11.equals((java.lang.Object) 1560190856010L);
//        long long15 = day11.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190919910L + "'", long7 == 1560190919910L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560150000000L + "'", long15 == 1560150000000L);
//    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8);
//        long long13 = year12.getFirstMillisecond();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = year12.getMiddleMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190919977L + "'", long7 == 1560190919977L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        java.lang.Class<?> wildcardClass11 = date8.getClass();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8);
//        long long13 = year12.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190920501L + "'", long7 == 1560190920501L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number14 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, number14);
//        java.lang.Object obj16 = timeSeriesDataItem15.clone();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem15, "June 2019", "June 2019", class19);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries20.removeChangeListener(seriesChangeListener21);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries20.removeChangeListener(seriesChangeListener23);
//        timeSeries20.clear();
//        boolean boolean26 = day11.equals((java.lang.Object) timeSeries20);
//        int int27 = day11.getMonth();
//        java.util.Calendar calendar28 = null;
//        try {
//            long long29 = day11.getLastMillisecond(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190920803L + "'", long7 == 1560190920803L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int3 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
//        boolean boolean11 = fixedMillisecond9.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond9.getFirstMillisecond(calendar12);
//        java.util.Date date14 = fixedMillisecond9.getTime();
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date14, timeZone15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14);
//        int int18 = day17.getDayOfMonth();
//        int int20 = day17.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate21 = day17.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate24);
//        org.jfree.data.time.SerialDate serialDate27 = serialDate25.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate29 = serialDate27.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate30 = serialDate21.getEndOfCurrentMonth(serialDate27);
//        boolean boolean31 = spreadsheetDate5.isOnOrBefore(serialDate30);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int34 = spreadsheetDate33.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate36.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean40 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate33, serialDate36, (int) ' ');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int43 = spreadsheetDate42.getDayOfWeek();
//        boolean boolean44 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate42);
//        boolean boolean45 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate42);
//        try {
//            org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-459), (org.jfree.data.time.SerialDate) spreadsheetDate42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560190920819L + "'", long13 == 1560190920819L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 3 + "'", int34 == 3);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 3 + "'", int43 == 3);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        int int4 = timeSeriesDataItem2.compareTo((java.lang.Object) '4');
        java.lang.Object obj5 = timeSeriesDataItem2.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(obj5);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        java.util.TimeZone timeZone4 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date2);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getFirstMillisecond(calendar7);
//        long long9 = fixedMillisecond6.getLastMillisecond();
//        long long10 = fixedMillisecond6.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560190920866L + "'", long8 == 1560190920866L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190920866L + "'", long9 == 1560190920866L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560190920866L + "'", long10 == 1560190920866L);
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        java.lang.String str7 = fixedMillisecond0.toString();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond0.getLastMillisecond(calendar8);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190920879L + "'", long4 == 1560190920879L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190920879L + "'", long6 == 1560190920879L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Mon Jun 10 11:22:00 PDT 2019" + "'", str7.equals("Mon Jun 10 11:22:00 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190920879L + "'", long9 == 1560190920879L);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
        timeSeries7.setKey((java.lang.Comparable) 1560190859422L);
        java.lang.Class class16 = timeSeries7.getTimePeriodClass();
        try {
            org.jfree.data.time.TimeSeries timeSeries19 = timeSeries7.createCopy(31, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertNull(class16);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate30);
//        org.jfree.data.time.SerialDate serialDate33 = serialDate31.getFollowingDayOfWeek(3);
//        boolean boolean34 = spreadsheetDate1.isOn(serialDate31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int37 = spreadsheetDate36.getMonth();
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate40);
//        org.jfree.data.time.SerialDate serialDate43 = serialDate41.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate45 = serialDate43.getNearestDayOfWeek(7);
//        boolean boolean46 = spreadsheetDate36.isBefore(serialDate43);
//        boolean boolean47 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number49 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, number49);
//        java.lang.Object obj51 = timeSeriesDataItem50.clone();
//        java.lang.Class class54 = null;
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem50, "June 2019", "June 2019", class54);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener56 = null;
//        timeSeries55.removeChangeListener(seriesChangeListener56);
//        java.util.Collection collection58 = timeSeries55.getTimePeriods();
//        java.lang.Comparable comparable59 = timeSeries55.getKey();
//        java.lang.String str60 = timeSeries55.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar62 = null;
//        long long63 = fixedMillisecond61.getLastMillisecond(calendar62);
//        timeSeries55.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
//        boolean boolean65 = spreadsheetDate36.equals((java.lang.Object) fixedMillisecond61);
//        int int66 = spreadsheetDate36.getYYYY();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190920902L + "'", long9 == 1560190920902L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5 + "'", int37 == 5);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(obj51);
//        org.junit.Assert.assertNotNull(collection58);
//        org.junit.Assert.assertNotNull(comparable59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "June 2019" + "'", str60.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560190920908L + "'", long63 == 1560190920908L);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1927 + "'", int66 == 1927);
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        long long12 = day11.getFirstMillisecond();
//        int int13 = day11.getYear();
//        int int14 = day11.getDayOfMonth();
//        int int15 = day11.getMonth();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190921188L + "'", long7 == 1560190921188L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        int int12 = timeSeries7.getMaximumItemCount();
        java.lang.String str13 = timeSeries7.getRangeDescription();
        long long14 = timeSeries7.getMaximumItemAge();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        long long12 = timeSeries7.getMaximumItemAge();
        java.util.List list13 = timeSeries7.getItems();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        timeSeries7.fireSeriesChanged();
        java.lang.String str10 = timeSeries7.getDescription();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        boolean boolean23 = timeSeries17.isEmpty();
        long long24 = timeSeries17.getMaximumItemAge();
        timeSeries17.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries17.createCopy(0, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries17.getDataItem(regularTimePeriod29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries28);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 17 + "'", int3 == 17);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeries7.removeAgedItems(true);
        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
        timeSeries7.setRangeDescription("2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number15 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
        java.lang.Object obj17 = timeSeriesDataItem16.clone();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.removeChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries21.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries21.removeChangeListener(seriesChangeListener25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getFirstMillisecond();
        int int29 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) year27);
        timeSeries21.setMaximumItemCount((int) '4');
        timeSeries21.setMaximumItemCount(100);
        int int34 = timeSeries21.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries7.addAndOrUpdate(timeSeries21);
        java.lang.Object obj36 = timeSeries35.clone();
        java.lang.Comparable comparable37 = timeSeries35.getKey();
        timeSeries35.fireSeriesChanged();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + "Overwritten values from: -1" + "'", comparable37.equals("Overwritten values from: -1"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries17.addChangeListener(seriesChangeListener23);
        java.lang.String str25 = timeSeries17.getRangeDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries17.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number14 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, number14);
//        java.lang.Object obj16 = timeSeriesDataItem15.clone();
//        int int17 = day11.compareTo(obj16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day11.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day11.previous();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190922308L + "'", long7 == 1560190922308L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        int int12 = timeSeries7.getMaximumItemCount();
        int int13 = timeSeries7.getItemCount();
        timeSeries7.removeAgedItems(true);
        java.util.List list16 = timeSeries7.getItems();
        timeSeries7.removeAgedItems(false);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener19);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeries7.removeAgedItems(true);
        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
        timeSeries7.setRangeDescription("2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number15 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
        java.lang.Object obj17 = timeSeriesDataItem16.clone();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.removeChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries21.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries21.removeChangeListener(seriesChangeListener25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getFirstMillisecond();
        int int29 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) year27);
        timeSeries21.setMaximumItemCount((int) '4');
        timeSeries21.setMaximumItemCount(100);
        int int34 = timeSeries21.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries7.addAndOrUpdate(timeSeries21);
        java.lang.Object obj36 = timeSeries35.clone();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = timeSeries35.getTimePeriod((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertNotNull(obj36);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate3);
//        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getFollowingDayOfWeek(3);
//        java.lang.Class class7 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date9, timeZone11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date9);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date9);
//        long long16 = day15.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number18 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, number18);
//        java.lang.Object obj20 = timeSeriesDataItem19.clone();
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem19, "June 2019", "June 2019", class23);
//        timeSeries24.removeAgedItems(true);
//        timeSeries24.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries24.setRangeDescription("hi!");
//        int int31 = day15.compareTo((java.lang.Object) timeSeries24);
//        org.jfree.data.time.SerialDate serialDate32 = day15.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate33 = serialDate6.getEndOfCurrentMonth(serialDate32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths((int) (short) 1, serialDate33);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560150000000L + "'", long16 == 1560150000000L);
//        org.junit.Assert.assertNotNull(obj20);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate34);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        int int14 = day11.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate15 = day11.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate18);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate24 = serialDate15.getEndOfCurrentMonth(serialDate21);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date27 = fixedMillisecond26.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date27);
//        boolean boolean30 = fixedMillisecond28.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getFirstMillisecond(calendar31);
//        java.util.Date date33 = fixedMillisecond28.getTime();
//        java.util.TimeZone timeZone34 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date33, timeZone34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date33);
//        int int37 = day36.getDayOfMonth();
//        int int39 = day36.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate40 = day36.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate43);
//        org.jfree.data.time.SerialDate serialDate46 = serialDate44.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate48 = serialDate46.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate49 = serialDate40.getEndOfCurrentMonth(serialDate46);
//        org.jfree.data.time.SerialDate serialDate50 = serialDate21.getEndOfCurrentMonth(serialDate40);
//        java.lang.String str51 = serialDate21.getDescription();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190922928L + "'", long7 == 1560190922928L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190922931L + "'", long32 == 1560190922931L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNull(str51);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(5, 9, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond14.getMiddleMillisecond(calendar17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond14.getMiddleMillisecond(calendar19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1546329600000L);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener23);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560190923135L + "'", long18 == 1560190923135L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190923135L + "'", long20 == 1560190923135L);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.lang.String str3 = year0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate4);
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(7);
//        boolean boolean10 = spreadsheetDate1.isAfter(serialDate9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.lang.String str15 = serialDate14.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int18 = spreadsheetDate17.getDayOfWeek();
//        boolean boolean19 = spreadsheetDate1.isInRange(serialDate14, (org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int20 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int23 = spreadsheetDate22.getMonth();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate26);
//        org.jfree.data.time.SerialDate serialDate29 = serialDate27.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate29.getNearestDayOfWeek(7);
//        boolean boolean32 = spreadsheetDate22.isBefore(serialDate29);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class35 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        boolean boolean40 = fixedMillisecond38.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond38.getFirstMillisecond(calendar41);
//        java.util.Date date43 = fixedMillisecond38.getTime();
//        java.util.TimeZone timeZone44 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date43, timeZone44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date43);
//        int int47 = day46.getDayOfMonth();
//        int int49 = day46.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate50 = day46.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate53);
//        org.jfree.data.time.SerialDate serialDate56 = serialDate54.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate58 = serialDate56.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate59 = serialDate50.getEndOfCurrentMonth(serialDate56);
//        boolean boolean60 = spreadsheetDate34.isOnOrBefore(serialDate59);
//        int int61 = spreadsheetDate34.getDayOfWeek();
//        boolean boolean62 = spreadsheetDate1.isInRange(serialDate29, (org.jfree.data.time.SerialDate) spreadsheetDate34);
//        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate65);
//        org.jfree.data.time.SerialDate serialDate68 = serialDate66.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate70 = serialDate66.getFollowingDayOfWeek(7);
//        int int71 = spreadsheetDate34.compare(serialDate70);
//        int int72 = spreadsheetDate34.getDayOfMonth();
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 7 + "'", int20 == 7);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560190923684L + "'", long42 == 1560190923684L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 7 + "'", int61 == 7);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-304346) + "'", int71 == (-304346));
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 6 + "'", int72 == 6);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-458));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        timeSeries7.fireSeriesChanged();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
//        long long27 = day26.getFirstMillisecond();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number30);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem31, "June 2019", "June 2019", class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries36.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (byte) -1);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) year50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) year50);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number56 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, number56);
//        java.lang.Object obj58 = timeSeriesDataItem57.clone();
//        java.lang.Class class61 = null;
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem57, "June 2019", "June 2019", class61);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener63 = null;
//        timeSeries62.removeChangeListener(seriesChangeListener63);
//        java.lang.String str65 = timeSeries62.getDescription();
//        boolean boolean66 = timeSeries62.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number68 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67, number68);
//        java.util.Calendar calendar70 = null;
//        long long71 = fixedMillisecond67.getLastMillisecond(calendar70);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries62.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67);
//        timeSeries62.setKey((java.lang.Comparable) false);
//        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries54.addAndOrUpdate(timeSeries62);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number77 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond76, number77);
//        java.lang.Object obj79 = timeSeriesDataItem78.clone();
//        java.lang.Class class82 = null;
//        org.jfree.data.time.TimeSeries timeSeries83 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem78, "June 2019", "June 2019", class82);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener84 = null;
//        timeSeries83.removeChangeListener(seriesChangeListener84);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener86 = null;
//        timeSeries83.removeChangeListener(seriesChangeListener86);
//        org.jfree.data.time.TimeSeries timeSeries88 = timeSeries75.addAndOrUpdate(timeSeries83);
//        long long89 = timeSeries75.getMaximumItemAge();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190924051L + "'", long22 == 1560190924051L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(obj58);
//        org.junit.Assert.assertNull(str65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560190924056L + "'", long71 == 1560190924056L);
//        org.junit.Assert.assertNull(timeSeriesDataItem72);
//        org.junit.Assert.assertNotNull(timeSeries75);
//        org.junit.Assert.assertNotNull(obj79);
//        org.junit.Assert.assertNotNull(timeSeries88);
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 9223372036854775807L + "'", long89 == 9223372036854775807L);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getSerialIndex();
        java.lang.Number number16 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month14);
        java.lang.Object obj17 = timeSeries7.clone();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        boolean boolean5 = year1.equals((java.lang.Object) 1560190852108L);
        long long6 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(10, year1);
        java.lang.Object obj8 = null;
        boolean boolean9 = year1.equals(obj8);
        long long10 = year1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1560190859036L);
        java.lang.Object obj4 = seriesChangeEvent3.getSource();
        java.lang.Object obj5 = seriesChangeEvent3.getSource();
        boolean boolean6 = timeSeries1.equals((java.lang.Object) seriesChangeEvent3);
        java.lang.String str7 = seriesChangeEvent3.toString();
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 1560190859036L + "'", obj4.equals(1560190859036L));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + 1560190859036L + "'", obj5.equals(1560190859036L));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1560190859036]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=1560190859036]"));
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number13 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number13);
//        java.lang.Object obj15 = timeSeriesDataItem14.clone();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "June 2019", "June 2019", class18);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries19.removeChangeListener(seriesChangeListener20);
//        java.util.Collection collection22 = timeSeries19.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries19.removeChangeListener(seriesChangeListener23);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        long long26 = year25.getFirstMillisecond();
//        int int27 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
//        timeSeries19.setMaximumItemCount((int) '4');
//        timeSeries19.setMaximumItemCount(100);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries7.addAndOrUpdate(timeSeries19);
//        int int33 = timeSeries32.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date35);
//        long long37 = fixedMillisecond36.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 1560190879376L);
//        timeSeries32.setDescription("org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str42 = timeSeries32.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener43 = null;
//        timeSeries32.removePropertyChangeListener(propertyChangeListener43);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj15);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560190924610L + "'", long37 == 1560190924610L);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Value" + "'", str42.equals("Value"));
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        long long9 = year7.getSerialIndex();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("");
        int int12 = year7.compareTo((java.lang.Object) seriesException11);
        boolean boolean13 = year5.equals((java.lang.Object) seriesException11);
        long long14 = year5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Number number3 = timeSeriesDataItem2.getValue();
        java.lang.Object obj4 = timeSeriesDataItem2.clone();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(obj4);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        long long12 = day11.getFirstMillisecond();
//        int int13 = day11.getYear();
//        long long14 = day11.getSerialIndex();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190924723L + "'", long7 == 1560190924723L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43626L + "'", long14 == 43626L);
//    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate4);
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(7);
//        boolean boolean10 = spreadsheetDate1.isAfter(serialDate9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.lang.String str15 = serialDate14.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int18 = spreadsheetDate17.getDayOfWeek();
//        boolean boolean19 = spreadsheetDate1.isInRange(serialDate14, (org.jfree.data.time.SerialDate) spreadsheetDate17);
//        java.lang.String str20 = spreadsheetDate17.getDescription();
//        java.lang.Class class21 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date23 = fixedMillisecond22.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        boolean boolean26 = fixedMillisecond24.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond24.getFirstMillisecond(calendar27);
//        java.util.Date date29 = fixedMillisecond24.getTime();
//        java.util.TimeZone timeZone30 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date29, timeZone30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date29);
//        int int33 = day32.getDayOfMonth();
//        int int35 = day32.compareTo((java.lang.Object) 1560190851150L);
//        java.lang.Object obj36 = null;
//        boolean boolean37 = day32.equals(obj36);
//        org.jfree.data.time.SerialDate serialDate38 = day32.getSerialDate();
//        long long39 = day32.getSerialIndex();
//        java.lang.Class class40 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date42 = fixedMillisecond41.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date42, timeZone44);
//        java.lang.Class<?> wildcardClass46 = date42.getClass();
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long39, (java.lang.Class) wildcardClass46);
//        timeSeries47.setDescription("");
//        try {
//            int int50 = spreadsheetDate17.compareTo((java.lang.Object) timeSeries47);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560190924767L + "'", long28 == 1560190924767L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 43626L + "'", long39 == 43626L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone4);
//        java.lang.Class<?> wildcardClass6 = date2.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
//        java.lang.Object obj13 = timeSeriesDataItem12.clone();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries17.removeChangeListener(seriesChangeListener18);
//        java.util.Collection collection20 = timeSeries17.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries17.removeChangeListener(seriesChangeListener21);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getFirstMillisecond();
//        int int25 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
//        timeSeries17.setMaximumItemCount((int) '4');
//        timeSeries17.setMaximumItemCount(100);
//        int int30 = timeSeries17.getMaximumItemCount();
//        java.lang.Class<?> wildcardClass31 = timeSeries17.getClass();
//        java.lang.Class class32 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date34 = fixedMillisecond33.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date34);
//        boolean boolean37 = fixedMillisecond35.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond35.getFirstMillisecond(calendar38);
//        java.util.Date date40 = fixedMillisecond35.getTime();
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date40, timeZone41);
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date40, timeZone43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date40);
//        java.lang.Class class46 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date48 = fixedMillisecond47.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond(date48);
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date48, timeZone50);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date40, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date8, timeZone50);
//        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560190924787L + "'", long39 == 1560190924787L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(class54);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.lang.Comparable comparable0 = null;
        java.lang.Class class1 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date3, timeZone5);
        java.lang.Class<?> wildcardClass7 = date3.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize(class8);
        try {
            org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries(comparable0, class9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class9);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        java.lang.String str28 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate33);
//        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate38 = serialDate36.getNearestDayOfWeek(7);
//        boolean boolean39 = spreadsheetDate30.isAfter(serialDate38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date41 = fixedMillisecond40.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(date41);
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date41);
//        java.lang.String str44 = serialDate43.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int47 = spreadsheetDate46.getDayOfWeek();
//        boolean boolean48 = spreadsheetDate30.isInRange(serialDate43, (org.jfree.data.time.SerialDate) spreadsheetDate46);
//        int int49 = spreadsheetDate30.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int52 = spreadsheetDate51.getMonth();
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate55);
//        org.jfree.data.time.SerialDate serialDate58 = serialDate56.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate60 = serialDate58.getNearestDayOfWeek(7);
//        boolean boolean61 = spreadsheetDate51.isBefore(serialDate58);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class64 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date66 = fixedMillisecond65.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond(date66);
//        boolean boolean69 = fixedMillisecond67.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar70 = null;
//        long long71 = fixedMillisecond67.getFirstMillisecond(calendar70);
//        java.util.Date date72 = fixedMillisecond67.getTime();
//        java.util.TimeZone timeZone73 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date72, timeZone73);
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date72);
//        int int76 = day75.getDayOfMonth();
//        int int78 = day75.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate79 = day75.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate82);
//        org.jfree.data.time.SerialDate serialDate85 = serialDate83.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate87 = serialDate85.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate88 = serialDate79.getEndOfCurrentMonth(serialDate85);
//        boolean boolean89 = spreadsheetDate63.isOnOrBefore(serialDate88);
//        int int90 = spreadsheetDate63.getDayOfWeek();
//        boolean boolean91 = spreadsheetDate30.isInRange(serialDate58, (org.jfree.data.time.SerialDate) spreadsheetDate63);
//        boolean boolean92 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        int int93 = spreadsheetDate30.getMonth();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190925175L + "'", long9 == 1560190925175L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "10-June-2019" + "'", str44.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 3 + "'", int47 == 3);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 7 + "'", int49 == 7);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 5 + "'", int52 == 5);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560190925204L + "'", long71 == 1560190925204L);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 10 + "'", int76 == 10);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
//        org.junit.Assert.assertNotNull(serialDate79);
//        org.junit.Assert.assertNotNull(serialDate82);
//        org.junit.Assert.assertNotNull(serialDate83);
//        org.junit.Assert.assertNotNull(serialDate85);
//        org.junit.Assert.assertNotNull(serialDate87);
//        org.junit.Assert.assertNotNull(serialDate88);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 7 + "'", int90 == 7);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
//        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1 + "'", int93 == 1);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int3 = spreadsheetDate2.getDayOfWeek();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, number5);
//        java.lang.Object obj7 = timeSeriesDataItem6.clone();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6, "June 2019", "June 2019", class10);
//        timeSeries11.removeAgedItems(true);
//        timeSeries11.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries11.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number19 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, number19);
//        java.lang.Object obj21 = timeSeriesDataItem20.clone();
//        java.lang.Class class24 = null;
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem20, "June 2019", "June 2019", class24);
//        timeSeries25.removeAgedItems(true);
//        timeSeries25.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries25.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number33 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, number33);
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond32.getMiddleMillisecond(calendar35);
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond32.getMiddleMillisecond(calendar37);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number44 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, number44);
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond43.getLastMillisecond(calendar46);
//        long long48 = fixedMillisecond43.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number50 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49, number50);
//        java.util.Calendar calendar52 = null;
//        long long53 = fixedMillisecond49.getLastMillisecond(calendar52);
//        long long54 = fixedMillisecond49.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
//        long long56 = fixedMillisecond49.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(9999);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date60 = fixedMillisecond59.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond(date60);
//        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(date60);
//        java.lang.String str63 = serialDate62.toString();
//        boolean boolean64 = spreadsheetDate58.equals((java.lang.Object) serialDate62);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(serialDate62);
//        int int66 = fixedMillisecond49.compareTo((java.lang.Object) serialDate62);
//        boolean boolean67 = spreadsheetDate2.isAfter(serialDate62);
//        boolean boolean69 = spreadsheetDate2.equals((java.lang.Object) 1560190881452L);
//        java.lang.String str70 = spreadsheetDate2.toString();
//        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.addDays(9992, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560190925748L + "'", long36 == 1560190925748L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560190925748L + "'", long38 == 1560190925748L);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560190925749L + "'", long47 == 1560190925749L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560190925749L + "'", long48 == 1560190925749L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560190925750L + "'", long53 == 1560190925750L);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560190925750L + "'", long54 == 1560190925750L);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560190925750L + "'", long56 == 1560190925750L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "10-June-2019" + "'", str63.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "17-May-1927" + "'", str70.equals("17-May-1927"));
//        org.junit.Assert.assertNotNull(serialDate71);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate30);
//        org.jfree.data.time.SerialDate serialDate33 = serialDate31.getFollowingDayOfWeek(3);
//        boolean boolean34 = spreadsheetDate1.isOn(serialDate31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int37 = spreadsheetDate36.getMonth();
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate40);
//        org.jfree.data.time.SerialDate serialDate43 = serialDate41.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate45 = serialDate43.getNearestDayOfWeek(7);
//        boolean boolean46 = spreadsheetDate36.isBefore(serialDate43);
//        boolean boolean47 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate36);
//        try {
//            int int49 = spreadsheetDate36.compareTo((java.lang.Object) 1560190890910L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190926045L + "'", long9 == 1560190926045L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5 + "'", int37 == 5);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.previous();
//        java.lang.Class<?> wildcardClass6 = fixedMillisecond0.getClass();
//        long long7 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560190926063L + "'", long2 == 1560190926063L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190926063L + "'", long4 == 1560190926063L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190926063L + "'", long7 == 1560190926063L);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        long long12 = day11.getFirstMillisecond();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        boolean boolean18 = fixedMillisecond16.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond16.getFirstMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond16.getTime();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date21);
//        boolean boolean26 = day11.equals((java.lang.Object) year25);
//        long long27 = day11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day11.previous();
//        long long29 = day11.getSerialIndex();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190926075L + "'", long7 == 1560190926075L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190926076L + "'", long20 == 1560190926076L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43626L + "'", long29 == 43626L);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        long long39 = fixedMillisecond28.getMiddleMillisecond();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond28.getMiddleMillisecond(calendar40);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190926165L + "'", long32 == 1560190926165L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190926165L + "'", long34 == 1560190926165L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560190926165L + "'", long39 == 1560190926165L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560190926165L + "'", long41 == 1560190926165L);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1560190895288L);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8);
//        long long13 = year12.getFirstMillisecond();
//        java.util.Date date14 = year12.getEnd();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        java.lang.Class<?> wildcardClass26 = date23.getClass();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date23);
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date23, timeZone28);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date14, timeZone28);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date14);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190926222L + "'", long7 == 1560190926222L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190926225L + "'", long22 == 1560190926225L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(timeZone28);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        long long6 = month0.getFirstMillisecond();
        int int7 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate4);
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(7);
//        boolean boolean10 = spreadsheetDate1.isAfter(serialDate9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.lang.String str15 = serialDate14.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int18 = spreadsheetDate17.getDayOfWeek();
//        boolean boolean19 = spreadsheetDate1.isInRange(serialDate14, (org.jfree.data.time.SerialDate) spreadsheetDate17);
//        java.lang.String str20 = spreadsheetDate17.getDescription();
//        try {
//            org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate17.getNearestDayOfWeek((-304346));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNull(str20);
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        boolean boolean4 = fixedMillisecond2.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond2.getFirstMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond2.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date9);
//        boolean boolean12 = fixedMillisecond2.equals((java.lang.Object) date9);
//        boolean boolean14 = fixedMillisecond2.equals((java.lang.Object) 1560190856010L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond2.getMiddleMillisecond(calendar15);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190926506L + "'", long6 == 1560190926506L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560190926506L + "'", long16 == 1560190926506L);
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        timeSeries7.fireSeriesChanged();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
//        long long27 = day26.getFirstMillisecond();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number30);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem31, "June 2019", "June 2019", class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries36.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (byte) -1);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) year50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) year50);
//        long long55 = day26.getFirstMillisecond();
//        long long56 = day26.getSerialIndex();
//        java.util.Calendar calendar57 = null;
//        try {
//            long long58 = day26.getFirstMillisecond(calendar57);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190926541L + "'", long22 == 1560190926541L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560150000000L + "'", long55 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 43626L + "'", long56 == 43626L);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        java.util.TimeZone timeZone4 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date2);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date2);
//        long long9 = day8.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
//        java.lang.Object obj13 = timeSeriesDataItem12.clone();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
//        timeSeries17.removeAgedItems(true);
//        timeSeries17.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries17.setRangeDescription("hi!");
//        int int24 = day8.compareTo((java.lang.Object) timeSeries17);
//        org.jfree.data.time.SerialDate serialDate25 = day8.getSerialDate();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
//        int int28 = day8.compareTo((java.lang.Object) timePeriodFormatException27);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number14 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, number14);
//        java.lang.Object obj16 = timeSeriesDataItem15.clone();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem15, "June 2019", "June 2019", class19);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries20.removeChangeListener(seriesChangeListener21);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries20.removeChangeListener(seriesChangeListener23);
//        timeSeries20.clear();
//        boolean boolean26 = day11.equals((java.lang.Object) timeSeries20);
//        timeSeries20.clear();
//        int int28 = timeSeries20.getItemCount();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190927075L + "'", long7 == 1560190927075L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
//        java.lang.String str6 = serialDate5.toString();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) serialDate5);
//        org.jfree.data.time.SerialDate serialDate8 = null;
//        try {
//            boolean boolean9 = spreadsheetDate1.isAfter(serialDate8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        java.lang.String str8 = timeSeries7.getDescription();
        timeSeries7.setNotify(true);
        java.lang.String str11 = timeSeries7.getDescription();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190851620L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeriesDataItem2.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        java.lang.Class<?> wildcardClass11 = date8.getClass();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date8);
//        serialDate13.setDescription("");
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190927166L + "'", long7 == 1560190927166L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(serialDate13);
//    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int30 = spreadsheetDate29.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate32.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean36 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, serialDate32, (int) ' ');
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate39);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date43 = fixedMillisecond42.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(date43);
//        boolean boolean46 = fixedMillisecond44.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar47 = null;
//        long long48 = fixedMillisecond44.getFirstMillisecond(calendar47);
//        java.util.Date date49 = fixedMillisecond44.getTime();
//        java.util.TimeZone timeZone50 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date49, timeZone50);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date49);
//        int int53 = day52.getDayOfMonth();
//        int int55 = day52.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate56 = day52.getSerialDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate61);
//        org.jfree.data.time.SerialDate serialDate64 = serialDate62.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate66 = serialDate64.getNearestDayOfWeek(7);
//        boolean boolean67 = spreadsheetDate58.isAfter(serialDate66);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date69 = fixedMillisecond68.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond(date69);
//        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.createInstance(date69);
//        java.lang.String str72 = serialDate71.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int75 = spreadsheetDate74.getDayOfWeek();
//        boolean boolean76 = spreadsheetDate58.isInRange(serialDate71, (org.jfree.data.time.SerialDate) spreadsheetDate74);
//        java.lang.String str77 = spreadsheetDate74.getDescription();
//        org.jfree.data.time.SerialDate serialDate78 = serialDate56.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate74);
//        serialDate78.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean82 = spreadsheetDate1.isInRange(serialDate39, serialDate78, (int) '#');
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190927446L + "'", long9 == 1560190927446L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560190927472L + "'", long48 == 1560190927472L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 10 + "'", int53 == 10);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(serialDate71);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "10-June-2019" + "'", str72.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 3 + "'", int75 == 3);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNull(str77);
//        org.junit.Assert.assertNotNull(serialDate78);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8);
//        java.lang.String str13 = year12.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("hi!");
//        int int28 = year12.compareTo((java.lang.Object) "hi!");
//        boolean boolean30 = year12.equals((java.lang.Object) 1560190921231L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190928218L + "'", long7 == 1560190928218L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener11);
//        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
//        timeSeries7.setKey((java.lang.Comparable) 1560190859422L);
//        java.lang.Class class16 = timeSeries7.getTimePeriodClass();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date19 = fixedMillisecond18.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
//        boolean boolean22 = fixedMillisecond20.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond20.getFirstMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond20.getTime();
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date25, timeZone26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date25);
//        long long29 = day28.getFirstMillisecond();
//        int int30 = day28.getYear();
//        int int31 = day28.getDayOfMonth();
//        int int32 = day28.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 1L);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNull(class13);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560190928288L + "'", long24 == 1560190928288L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560150000000L + "'", long29 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem34);
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.next();
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar7 = null;
//        fixedMillisecond0.peg(calendar7);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190928342L + "'", long4 == 1560190928342L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
//        long long2 = year0.getSerialIndex();
//        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
//        int int5 = year0.compareTo((java.lang.Object) seriesException4);
//        int int7 = year0.compareTo((java.lang.Object) 1560190859545L);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond11.getFirstMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond11.getTime();
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date16, timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16);
//        int int20 = day19.getDayOfMonth();
//        boolean boolean21 = year0.equals((java.lang.Object) day19);
//        java.lang.Class class22 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date24 = fixedMillisecond23.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
//        boolean boolean27 = fixedMillisecond25.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond25.getFirstMillisecond(calendar28);
//        java.util.Date date30 = fixedMillisecond25.getTime();
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date30, timeZone31);
//        java.lang.Class<?> wildcardClass33 = date30.getClass();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date30);
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date30);
//        int int36 = year0.compareTo((java.lang.Object) date30);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1560190912479L);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560190928611L + "'", long15 == 1560190928611L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560190928613L + "'", long29 == 1560190928613L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=1560190859036]");
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int30 = spreadsheetDate29.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate32.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean36 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, serialDate32, (int) ' ');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate41);
//        org.jfree.data.time.SerialDate serialDate44 = serialDate42.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate46 = serialDate44.getNearestDayOfWeek(7);
//        boolean boolean47 = spreadsheetDate38.isAfter(serialDate46);
//        boolean boolean48 = spreadsheetDate1.isOn(serialDate46);
//        int int49 = spreadsheetDate1.getYYYY();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190928767L + "'", long9 == 1560190928767L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1900 + "'", int49 == 1900);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        java.lang.Class<?> wildcardClass11 = date8.getClass();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1560190855309L);
//        java.util.Date date18 = fixedMillisecond14.getTime();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date21 = fixedMillisecond20.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date21, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date18, timeZone23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number27 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, number27);
//        java.lang.Object obj29 = timeSeriesDataItem28.clone();
//        java.lang.Class class32 = null;
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem28, "June 2019", "June 2019", class32);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
//        timeSeries33.removeChangeListener(seriesChangeListener34);
//        java.util.Collection collection36 = timeSeries33.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries33.removeChangeListener(seriesChangeListener37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
//        long long40 = year39.getFirstMillisecond();
//        int int41 = timeSeries33.getIndex((org.jfree.data.time.RegularTimePeriod) year39);
//        timeSeries33.setMaximumItemCount((int) '4');
//        timeSeries33.setMaximumItemCount(100);
//        int int46 = timeSeries33.getMaximumItemCount();
//        java.lang.Class<?> wildcardClass47 = timeSeries33.getClass();
//        java.lang.Class class48 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date50 = fixedMillisecond49.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond(date50);
//        boolean boolean53 = fixedMillisecond51.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar54 = null;
//        long long55 = fixedMillisecond51.getFirstMillisecond(calendar54);
//        java.util.Date date56 = fixedMillisecond51.getTime();
//        java.util.TimeZone timeZone57 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date56, timeZone57);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date56, timeZone59);
//        java.lang.Class class61 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date63 = fixedMillisecond62.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(date63);
//        java.util.TimeZone timeZone65 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class61, date63, timeZone65);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond(date63);
//        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(date63);
//        java.lang.Class class69 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date71 = fixedMillisecond70.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond(date71);
//        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class69, date71, timeZone73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date63, timeZone73);
//        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date18, timeZone73);
//        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month(date8, timeZone73);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190928918L + "'", long7 == 1560190928918L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(obj29);
//        org.junit.Assert.assertNotNull(collection36);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1546329600000L + "'", long40 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 100 + "'", int46 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560190928924L + "'", long55 == 1560190928924L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(timeZone73);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertNull(regularTimePeriod75);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeries7.removeAgedItems(true);
        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
        timeSeries7.setRangeDescription("2019");
        timeSeries7.fireSeriesChanged();
        java.lang.Object obj15 = timeSeries7.clone();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray25 = seriesException24.getSuppressed();
        int int26 = timeSeriesDataItem2.compareTo((java.lang.Object) seriesException24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem2.getPeriod();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        int int5 = month0.getMonth();
        int int6 = month0.getYearValue();
        org.jfree.data.time.Year year7 = month0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(year7);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        java.util.Collection collection11 = timeSeries7.getTimePeriods();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
//        boolean boolean17 = fixedMillisecond15.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getFirstMillisecond(calendar18);
//        java.util.Date date20 = fixedMillisecond15.getTime();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date20, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20);
//        int int24 = day23.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 2);
//        timeSeries7.setDomainDescription("June 2019");
//        int int29 = timeSeries7.getMaximumItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date31 = fixedMillisecond30.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date31);
//        java.lang.String str34 = serialDate33.toString();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(serialDate33);
//        serialDate33.setDescription("June 2019");
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day38, (java.lang.Number) (-1.0d));
//        java.util.Calendar calendar41 = null;
//        try {
//            long long42 = day38.getFirstMillisecond(calendar41);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560190930199L + "'", long19 == 1560190930199L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2147483647 + "'", int29 == 2147483647);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem40);
//    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, number8);
//        timeSeriesDataItem9.setValue((java.lang.Number) (short) -1);
//        boolean boolean12 = fixedMillisecond0.equals((java.lang.Object) timeSeriesDataItem9);
//        timeSeriesDataItem9.setValue((java.lang.Number) 1560190868140L);
//        java.lang.Number number15 = timeSeriesDataItem9.getValue();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190930240L + "'", long4 == 1560190930240L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190930240L + "'", long6 == 1560190930240L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1560190868140L + "'", number15.equals(1560190868140L));
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getSerialIndex();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        int int5 = year0.compareTo((java.lang.Object) seriesException4);
        java.lang.Throwable[] throwableArray6 = seriesException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        java.lang.String str8 = seriesException4.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str8.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-304346));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-74263) + "'", int1 == (-74263));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number13 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number13);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "June 2019", "June 2019", class18);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        java.util.Collection collection22 = timeSeries19.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries19.removeChangeListener(seriesChangeListener23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        int int27 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
        timeSeries19.setMaximumItemCount((int) '4');
        timeSeries19.setMaximumItemCount(100);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries7.addAndOrUpdate(timeSeries19);
        java.lang.String str33 = timeSeries7.getRangeDescription();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        long long35 = month34.getSerialIndex();
        boolean boolean37 = month34.equals((java.lang.Object) 10);
        long long38 = month34.getFirstMillisecond();
        int int39 = month34.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month34.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number45 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, number45);
        java.lang.Object obj47 = timeSeriesDataItem46.clone();
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem46, "June 2019", "June 2019", class50);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener52 = null;
        timeSeries51.removeChangeListener(seriesChangeListener52);
        java.util.Collection collection54 = timeSeries51.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries51.removeChangeListener(seriesChangeListener55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        long long58 = year57.getFirstMillisecond();
        int int59 = timeSeries51.getIndex((org.jfree.data.time.RegularTimePeriod) year57);
        timeSeries51.setMaximumItemCount((int) '4');
        timeSeries51.setMaximumItemCount(100);
        int int64 = timeSeries51.getMaximumItemCount();
        java.lang.Class<?> wildcardClass65 = timeSeries51.getClass();
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2147483647, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass65);
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month34, (java.lang.Class) wildcardClass65);
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries7.addAndOrUpdate(timeSeries67);
        long long69 = timeSeries68.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number71 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70, number71);
        timeSeriesDataItem72.setValue((java.lang.Number) (short) -1);
        try {
            timeSeries68.add(timeSeriesDataItem72);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeries.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 24234L + "'", long35 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1559372400000L + "'", long38 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1546329600000L + "'", long58 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 100 + "'", int64 == 100);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 9223372036854775807L + "'", long69 == 9223372036854775807L);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
//        java.lang.String str6 = serialDate5.toString();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) serialDate5);
//        try {
//            org.jfree.data.time.SerialDate serialDate9 = serialDate5.getPreviousDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, number3);
        java.lang.Object obj5 = timeSeriesDataItem4.clone();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem4, "June 2019", "June 2019", class8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries9.removeChangeListener(seriesChangeListener10);
        java.util.Collection collection12 = timeSeries9.getTimePeriods();
        java.lang.Comparable comparable13 = timeSeries9.getKey();
        java.lang.String str14 = timeSeries9.getDomainDescription();
        java.util.List list15 = timeSeries9.getItems();
        boolean boolean16 = timeSeries9.getNotify();
        java.util.Collection collection17 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(collection17);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        int int28 = spreadsheetDate1.getDayOfWeek();
//        int int29 = spreadsheetDate1.getMonth();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190930422L + "'", long9 == 1560190930422L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        int int14 = day11.compareTo((java.lang.Object) 1560190851150L);
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day11.equals(obj15);
//        org.jfree.data.time.SerialDate serialDate17 = day11.getSerialDate();
//        long long18 = day11.getSerialIndex();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date21 = fixedMillisecond20.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date21, timeZone23);
//        java.lang.Class<?> wildcardClass25 = date21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long18, (java.lang.Class) wildcardClass25);
//        java.lang.String str27 = timeSeries26.getDescription();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190930501L + "'", long7 == 1560190930501L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNull(str27);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date2);
        java.util.Date date9 = day8.getStart();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 11:21:26 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond14.getMiddleMillisecond(calendar17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond14.getMiddleMillisecond(calendar19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1546329600000L);
//        long long23 = fixedMillisecond14.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560190930708L + "'", long18 == 1560190930708L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190930708L + "'", long20 == 1560190930708L);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190930708L + "'", long23 == 1560190930708L);
//    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        java.lang.Object obj10 = timeSeries7.clone();
//        boolean boolean11 = timeSeries7.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date13 = fixedMillisecond12.getTime();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond12.getMiddleMillisecond(calendar14);
//        long long16 = fixedMillisecond12.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond17.getLastMillisecond(calendar18);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond17.getMiddleMillisecond(calendar20);
//        boolean boolean22 = fixedMillisecond12.equals((java.lang.Object) fixedMillisecond17);
//        int int23 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        java.lang.Class class24 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date26);
//        boolean boolean29 = fixedMillisecond27.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond27.getFirstMillisecond(calendar30);
//        java.util.Date date32 = fixedMillisecond27.getTime();
//        java.util.TimeZone timeZone33 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date32, timeZone33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date32);
//        long long36 = day35.getFirstMillisecond();
//        java.util.Date date37 = day35.getStart();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
//        int int39 = fixedMillisecond17.compareTo((java.lang.Object) day38);
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond17.getFirstMillisecond(calendar40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond17.previous();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560190930755L + "'", long15 == 1560190930755L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560190930755L + "'", long16 == 1560190930755L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560190930755L + "'", long19 == 1560190930755L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560190930755L + "'", long21 == 1560190930755L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560190930756L + "'", long31 == 1560190930756L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560150000000L + "'", long36 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560190930755L + "'", long41 == 1560190930755L);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        timeSeries7.fireSeriesChanged();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
//        long long27 = day26.getFirstMillisecond();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number30);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem31, "June 2019", "June 2019", class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries36.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (byte) -1);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) year50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) year50);
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year55.next();
//        long long57 = year55.getSerialIndex();
//        long long58 = year55.getLastMillisecond();
//        java.lang.String str59 = year55.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year55, (java.lang.Number) 1560190912011L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year55.next();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190930912L + "'", long22 == 1560190930912L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 2019L + "'", long57 == 2019L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1577865599999L + "'", long58 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "2019" + "'", str59.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem61);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        java.util.Collection collection11 = timeSeries7.getTimePeriods();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
//        boolean boolean17 = fixedMillisecond15.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getFirstMillisecond(calendar18);
//        java.util.Date date20 = fixedMillisecond15.getTime();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date20, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20);
//        int int24 = day23.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 2);
//        timeSeries7.setDomainDescription("June 2019");
//        int int29 = timeSeries7.getMaximumItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date31 = fixedMillisecond30.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date31);
//        java.lang.String str34 = serialDate33.toString();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(serialDate33);
//        serialDate33.setDescription("June 2019");
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day38, (java.lang.Number) (-1.0d));
//        timeSeriesDataItem40.setValue((java.lang.Number) 1560190925749L);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560190931339L + "'", long19 == 1560190931339L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2147483647 + "'", int29 == 2147483647);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem40);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1560190859036L);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 1560190859036L + "'", obj2.equals(1560190859036L));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 1560190859036L + "'", obj3.equals(1560190859036L));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 1560190859036L + "'", obj4.equals(1560190859036L));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener39);
//        boolean boolean41 = timeSeries7.isEmpty();
//        try {
//            timeSeries7.update((int) (byte) 1, (java.lang.Number) 1561964399999L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190931541L + "'", long32 == 1560190931541L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190931541L + "'", long34 == 1560190931541L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries7.setMaximumItemCount((int) '4');
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number19 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, number19);
        java.lang.Object obj21 = timeSeriesDataItem20.clone();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem20, "June 2019", "June 2019", class24);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries25.removeChangeListener(seriesChangeListener26);
        java.util.Collection collection28 = timeSeries25.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries25.removeChangeListener(seriesChangeListener29);
        java.lang.Class class31 = timeSeries25.getTimePeriodClass();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        long long33 = month32.getSerialIndex();
        java.lang.Number number34 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) month32);
        long long35 = month32.getLastMillisecond();
        int int36 = month32.getYearValue();
        try {
            timeSeries7.update((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) 1560190924723L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertNull(class31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 24234L + "'", long33 == 24234L);
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1561964399999L + "'", long35 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        boolean boolean23 = timeSeries17.isEmpty();
        long long24 = timeSeries17.getMaximumItemAge();
        timeSeries17.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries17.createCopy(0, 2019);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener29);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries28);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("June 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, 31);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date17 = fixedMillisecond16.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) (byte) -1);
        try {
            org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy(9999, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number40 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, number40);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond39.getLastMillisecond(calendar42);
//        long long44 = fixedMillisecond39.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number46 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, number46);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond45.getLastMillisecond(calendar48);
//        long long50 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
//        long long52 = fixedMillisecond45.getMiddleMillisecond();
//        java.util.Calendar calendar53 = null;
//        long long54 = fixedMillisecond45.getFirstMillisecond(calendar53);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190931693L + "'", long32 == 1560190931693L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190931693L + "'", long34 == 1560190931693L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560190931694L + "'", long43 == 1560190931694L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560190931694L + "'", long44 == 1560190931694L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560190931695L + "'", long49 == 1560190931695L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560190931695L + "'", long50 == 1560190931695L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560190931695L + "'", long52 == 1560190931695L);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560190931695L + "'", long54 == 1560190931695L);
//    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        long long12 = day11.getFirstMillisecond();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        boolean boolean18 = fixedMillisecond16.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond16.getFirstMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond16.getTime();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date21);
//        boolean boolean26 = day11.equals((java.lang.Object) year25);
//        int int27 = day11.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day11.previous();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190931802L + "'", long7 == 1560190931802L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190931803L + "'", long20 == 1560190931803L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getFirstMillisecond();
//        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
//        timeSeries7.setMaximumItemCount((int) '4');
//        timeSeries7.setMaximumItemCount(100);
//        int int20 = timeSeries7.getMaximumItemCount();
//        java.lang.Class<?> wildcardClass21 = timeSeries7.getClass();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date24 = fixedMillisecond23.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
//        boolean boolean27 = fixedMillisecond25.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond25.getFirstMillisecond(calendar28);
//        java.util.Date date30 = fixedMillisecond25.getTime();
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date30, timeZone31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30);
//        long long34 = day33.getFirstMillisecond();
//        java.util.Date date35 = day33.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date35);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date39 = fixedMillisecond38.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date39);
//        boolean boolean42 = fixedMillisecond40.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond40.getFirstMillisecond(calendar43);
//        java.util.Date date45 = fixedMillisecond40.getTime();
//        java.util.TimeZone timeZone46 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date45, timeZone46);
//        java.lang.Class<?> wildcardClass48 = date45.getClass();
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date45);
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date45, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date35, timeZone50);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date35);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560190931907L + "'", long29 == 1560190931907L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560150000000L + "'", long34 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560190931909L + "'", long44 == 1560190931909L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getSerialIndex();
        java.lang.Number number16 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month14);
        long long17 = month14.getLastMillisecond();
        int int18 = month14.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 1560190859873L);
        java.lang.String str21 = month14.toString();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        timeSeries7.fireSeriesChanged();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
//        long long27 = day26.getFirstMillisecond();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number30);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem31, "June 2019", "June 2019", class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries36.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (byte) -1);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) year50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) year50);
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
//        long long56 = month55.getSerialIndex();
//        boolean boolean58 = month55.equals((java.lang.Object) 10);
//        long long59 = month55.getFirstMillisecond();
//        int int60 = month55.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month55.previous();
//        timeSeries7.setKey((java.lang.Comparable) regularTimePeriod61);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener63 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener63);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190932280L + "'", long22 == 1560190932280L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 24234L + "'", long56 == 24234L);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1559372400000L + "'", long59 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 6 + "'", int60 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-435), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        java.util.Collection collection11 = timeSeries7.getTimePeriods();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
//        boolean boolean17 = fixedMillisecond15.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getFirstMillisecond(calendar18);
//        java.util.Date date20 = fixedMillisecond15.getTime();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date20, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20);
//        int int24 = day23.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 2);
//        timeSeries7.setDomainDescription("June 2019");
//        int int29 = timeSeries7.getMaximumItemCount();
//        timeSeries7.setDescription("org.jfree.data.general.SeriesChangeEvent[source=1560190857476]");
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560190932598L + "'", long19 == 1560190932598L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2147483647 + "'", int29 == 2147483647);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
//        java.lang.Object obj13 = timeSeriesDataItem12.clone();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries17.removeChangeListener(seriesChangeListener18);
//        java.util.Collection collection20 = timeSeries17.getTimePeriods();
//        java.lang.Comparable comparable21 = timeSeries17.getKey();
//        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries17.addChangeListener(seriesChangeListener23);
//        timeSeries17.setDomainDescription("June 2019");
//        java.util.Collection collection27 = timeSeries17.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.lang.Object obj31 = timeSeriesDataItem30.clone();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem30, "June 2019", "June 2019", class34);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
//        timeSeries35.removeChangeListener(seriesChangeListener36);
//        timeSeries35.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number41 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, number41);
//        java.lang.Object obj43 = timeSeriesDataItem42.clone();
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem42, "June 2019", "June 2019", class46);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener48 = null;
//        timeSeries47.removeChangeListener(seriesChangeListener48);
//        java.util.Collection collection50 = timeSeries47.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener51 = null;
//        timeSeries47.removeChangeListener(seriesChangeListener51);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
//        long long54 = year53.getFirstMillisecond();
//        int int55 = timeSeries47.getIndex((org.jfree.data.time.RegularTimePeriod) year53);
//        timeSeries47.setMaximumItemCount((int) '4');
//        timeSeries47.setMaximumItemCount(100);
//        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries35.addAndOrUpdate(timeSeries47);
//        int int61 = timeSeries60.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date63 = fixedMillisecond62.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(date63);
//        long long65 = fixedMillisecond64.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (double) 1560190879376L);
//        timeSeries60.setDescription("org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries17.addAndOrUpdate(timeSeries60);
//        timeSeries60.fireSeriesChanged();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertNotNull(comparable21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(collection27);
//        org.junit.Assert.assertNotNull(obj31);
//        org.junit.Assert.assertNotNull(obj43);
//        org.junit.Assert.assertNotNull(collection50);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1546329600000L + "'", long54 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560190932684L + "'", long65 == 1560190932684L);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//        org.junit.Assert.assertNotNull(timeSeries70);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeries7.removeAgedItems(true);
        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
        timeSeries7.setRangeDescription("2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number15 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
        java.lang.Object obj17 = timeSeriesDataItem16.clone();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.removeChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries21.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries21.removeChangeListener(seriesChangeListener25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getFirstMillisecond();
        int int29 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) year27);
        timeSeries21.setMaximumItemCount((int) '4');
        timeSeries21.setMaximumItemCount(100);
        int int34 = timeSeries21.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries7.addAndOrUpdate(timeSeries21);
        java.lang.Object obj36 = timeSeries35.clone();
        java.lang.Comparable comparable37 = timeSeries35.getKey();
        timeSeries35.setMaximumItemAge(1560190932598L);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + "Overwritten values from: -1" + "'", comparable37.equals("Overwritten values from: -1"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
//        java.lang.String str6 = serialDate5.toString();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) serialDate5);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond11.getFirstMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond11.getTime();
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date16, timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16);
//        int int20 = day19.getDayOfMonth();
//        int int22 = day19.compareTo((java.lang.Object) 1560190851150L);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day19.equals(obj23);
//        org.jfree.data.time.SerialDate serialDate25 = day19.getSerialDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date30 = fixedMillisecond29.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date30);
//        boolean boolean33 = fixedMillisecond31.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond31.getFirstMillisecond(calendar34);
//        java.util.Date date36 = fixedMillisecond31.getTime();
//        java.util.TimeZone timeZone37 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date36, timeZone37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date36);
//        int int40 = day39.getDayOfMonth();
//        int int42 = day39.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate43 = day39.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate46);
//        org.jfree.data.time.SerialDate serialDate49 = serialDate47.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate51 = serialDate49.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate52 = serialDate43.getEndOfCurrentMonth(serialDate49);
//        boolean boolean53 = spreadsheetDate27.isOnOrBefore(serialDate52);
//        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate56);
//        org.jfree.data.time.SerialDate serialDate59 = serialDate57.getFollowingDayOfWeek(3);
//        boolean boolean60 = spreadsheetDate27.isOn(serialDate57);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int63 = spreadsheetDate62.getMonth();
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate66);
//        org.jfree.data.time.SerialDate serialDate69 = serialDate67.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate71 = serialDate69.getNearestDayOfWeek(7);
//        boolean boolean72 = spreadsheetDate62.isBefore(serialDate69);
//        boolean boolean73 = spreadsheetDate27.isOn((org.jfree.data.time.SerialDate) spreadsheetDate62);
//        boolean boolean74 = spreadsheetDate1.isInRange(serialDate25, (org.jfree.data.time.SerialDate) spreadsheetDate62);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560190933308L + "'", long15 == 1560190933308L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560190933341L + "'", long35 == 1560190933341L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 5 + "'", int63 == 5);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertNotNull(serialDate71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray25 = seriesException24.getSuppressed();
        int int26 = timeSeriesDataItem2.compareTo((java.lang.Object) seriesException24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("SerialDate.weekInMonthToString(): invalid code.");
        seriesException24.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        org.jfree.data.general.SeriesException seriesException31 = new org.jfree.data.general.SeriesException("June 2019");
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) seriesException31);
        org.jfree.data.general.SeriesException seriesException34 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: June 2019");
        seriesException31.addSuppressed((java.lang.Throwable) seriesException34);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        java.util.Collection collection11 = timeSeries7.getTimePeriods();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
//        boolean boolean17 = fixedMillisecond15.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getFirstMillisecond(calendar18);
//        java.util.Date date20 = fixedMillisecond15.getTime();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date20, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20);
//        int int24 = day23.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day23.previous();
//        org.jfree.data.time.SerialDate serialDate28 = day23.getSerialDate();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560190934163L + "'", long19 == 1560190934163L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(serialDate28);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.lang.String str2 = fixedMillisecond1.toString();
        long long3 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str2.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', (-435), 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 1560190855309L);
        java.util.Date date5 = fixedMillisecond1.getTime();
        java.lang.Class class6 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date8, timeZone10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date5);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("June");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries7.getDescription();
        boolean boolean11 = timeSeries7.getNotify();
        java.lang.String str12 = timeSeries7.getDescription();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = null;
        try {
            timeSeries7.add(timeSeriesDataItem13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(str12);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int30 = spreadsheetDate29.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate32.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean36 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, serialDate32, (int) ' ');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int39 = spreadsheetDate38.getDayOfWeek();
//        boolean boolean40 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate45);
//        org.jfree.data.time.SerialDate serialDate48 = serialDate46.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate50 = serialDate48.getNearestDayOfWeek(7);
//        boolean boolean51 = spreadsheetDate42.isAfter(serialDate50);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date53 = fixedMillisecond52.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(date53);
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(date53);
//        java.lang.String str56 = serialDate55.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int59 = spreadsheetDate58.getDayOfWeek();
//        boolean boolean60 = spreadsheetDate42.isInRange(serialDate55, (org.jfree.data.time.SerialDate) spreadsheetDate58);
//        boolean boolean61 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate42);
//        try {
//            org.jfree.data.time.SerialDate serialDate63 = spreadsheetDate1.getNearestDayOfWeek(100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190935386L + "'", long9 == 1560190935386L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 3 + "'", int39 == 3);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10-June-2019" + "'", str56.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 3 + "'", int59 == 3);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        boolean boolean4 = fixedMillisecond2.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond2.getFirstMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond2.getTime();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 1560190860069L);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190935428L + "'", long6 == 1560190935428L);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560190935450L + "'", long2 == 1560190935450L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560190935450L + "'", long3 == 1560190935450L);
//    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        java.lang.String str28 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate33);
//        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate38 = serialDate36.getNearestDayOfWeek(7);
//        boolean boolean39 = spreadsheetDate30.isAfter(serialDate38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date41 = fixedMillisecond40.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(date41);
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date41);
//        java.lang.String str44 = serialDate43.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int47 = spreadsheetDate46.getDayOfWeek();
//        boolean boolean48 = spreadsheetDate30.isInRange(serialDate43, (org.jfree.data.time.SerialDate) spreadsheetDate46);
//        spreadsheetDate30.setDescription("Wed Dec 31 15:59:59 PST 1969");
//        boolean boolean51 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
//        try {
//            int int53 = spreadsheetDate1.compareTo((java.lang.Object) 1560190856825L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190935458L + "'", long9 == 1560190935458L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "10-June-2019" + "'", str44.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 3 + "'", int47 == 3);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate30);
//        org.jfree.data.time.SerialDate serialDate33 = serialDate31.getFollowingDayOfWeek(3);
//        boolean boolean34 = spreadsheetDate1.isOn(serialDate31);
//        spreadsheetDate1.setDescription("ERROR : Relative To String");
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190935511L + "'", long9 == 1560190935511L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond14.getMiddleMillisecond(calendar17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond14.getMiddleMillisecond(calendar19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1546329600000L);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.previous();
//        java.lang.Number number26 = timeSeries7.getValue(regularTimePeriod25);
//        java.lang.String str27 = timeSeries7.getDescription();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560190935600L + "'", long18 == 1560190935600L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190935600L + "'", long20 == 1560190935600L);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1.5463296E12d + "'", number26.equals(1.5463296E12d));
//        org.junit.Assert.assertNull(str27);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("June");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
//        long long2 = year0.getSerialIndex();
//        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
//        int int5 = year0.compareTo((java.lang.Object) seriesException4);
//        int int7 = year0.compareTo((java.lang.Object) 1560190859545L);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond11.getFirstMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond11.getTime();
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date16, timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16);
//        int int20 = day19.getDayOfMonth();
//        boolean boolean21 = year0.equals((java.lang.Object) day19);
//        java.lang.Class class22 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date24 = fixedMillisecond23.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
//        boolean boolean27 = fixedMillisecond25.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond25.getFirstMillisecond(calendar28);
//        java.util.Date date30 = fixedMillisecond25.getTime();
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date30, timeZone31);
//        java.lang.Class<?> wildcardClass33 = date30.getClass();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date30);
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date30);
//        int int36 = year0.compareTo((java.lang.Object) date30);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date30);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560190935649L + "'", long15 == 1560190935649L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560190935671L + "'", long29 == 1560190935671L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int2 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class5 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
//        boolean boolean10 = fixedMillisecond8.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond8.getFirstMillisecond(calendar11);
//        java.util.Date date13 = fixedMillisecond8.getTime();
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date13, timeZone14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13);
//        int int17 = day16.getDayOfMonth();
//        int int19 = day16.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate20 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate23);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate24.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate28 = serialDate26.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate29 = serialDate20.getEndOfCurrentMonth(serialDate26);
//        boolean boolean30 = spreadsheetDate4.isOnOrBefore(serialDate29);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int33 = spreadsheetDate32.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate35.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean39 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, serialDate35, (int) ' ');
//        int int40 = spreadsheetDate4.getMonth();
//        boolean boolean41 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        java.lang.String str42 = spreadsheetDate4.toString();
//        try {
//            org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate4.getFollowingDayOfWeek((int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9999 + "'", int2 == 9999);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560190935817L + "'", long12 == 1560190935817L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3 + "'", int33 == 3);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "6-January-1900" + "'", str42.equals("6-January-1900"));
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Preceding" + "'", str1.equals("Preceding"));
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        java.util.Collection collection11 = timeSeries7.getTimePeriods();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
//        boolean boolean17 = fixedMillisecond15.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getFirstMillisecond(calendar18);
//        java.util.Date date20 = fixedMillisecond15.getTime();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date20, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20);
//        int int24 = day23.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 2);
//        timeSeries7.setDomainDescription("June 2019");
//        int int29 = timeSeries7.getMaximumItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date31 = fixedMillisecond30.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date31);
//        java.lang.String str34 = serialDate33.toString();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(serialDate33);
//        serialDate33.setDescription("June 2019");
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day38, (java.lang.Number) (-1.0d));
//        java.util.Date date41 = day38.getStart();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560190935840L + "'", long19 == 1560190935840L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2147483647 + "'", int29 == 2147483647);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "10-June-2019" + "'", str34.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(date41);
//    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number40 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, number40);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond39.getLastMillisecond(calendar42);
//        long long44 = fixedMillisecond39.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number46 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, number46);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond45.getLastMillisecond(calendar48);
//        long long50 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
//        long long52 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(9999);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date56 = fixedMillisecond55.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond(date56);
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance(date56);
//        java.lang.String str59 = serialDate58.toString();
//        boolean boolean60 = spreadsheetDate54.equals((java.lang.Object) serialDate58);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(serialDate58);
//        int int62 = fixedMillisecond45.compareTo((java.lang.Object) serialDate58);
//        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = year63.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year63.previous();
//        boolean boolean67 = year63.equals((java.lang.Object) 1560190852108L);
//        long long68 = year63.getFirstMillisecond();
//        java.lang.String str69 = year63.toString();
//        int int70 = fixedMillisecond45.compareTo((java.lang.Object) year63);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190936080L + "'", long32 == 1560190936080L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190936080L + "'", long34 == 1560190936080L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560190936081L + "'", long43 == 1560190936081L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560190936081L + "'", long44 == 1560190936081L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560190936082L + "'", long49 == 1560190936082L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560190936082L + "'", long50 == 1560190936082L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560190936082L + "'", long52 == 1560190936082L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "10-June-2019" + "'", str59.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1546329600000L + "'", long68 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "2019" + "'", str69.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number13 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number13);
//        java.lang.Object obj15 = timeSeriesDataItem14.clone();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "June 2019", "June 2019", class18);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries19.removeChangeListener(seriesChangeListener20);
//        java.util.Collection collection22 = timeSeries19.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries19.removeChangeListener(seriesChangeListener23);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        long long26 = year25.getFirstMillisecond();
//        int int27 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
//        timeSeries19.setMaximumItemCount((int) '4');
//        timeSeries19.setMaximumItemCount(100);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries7.addAndOrUpdate(timeSeries19);
//        int int33 = timeSeries32.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date35);
//        long long37 = fixedMillisecond36.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 1560190879376L);
//        timeSeries32.setDescription("org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.String str42 = timeSeries32.getRangeDescription();
//        try {
//            timeSeries32.delete(3, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj15);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560190936426L + "'", long37 == 1560190936426L);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Value" + "'", str42.equals("Value"));
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getFirstMillisecond();
//        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
//        timeSeries7.setMaximumItemCount((int) '4');
//        java.lang.Class class18 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number20 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, number20);
//        java.lang.Object obj22 = timeSeriesDataItem21.clone();
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem21, "June 2019", "June 2019", class25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries26.removeChangeListener(seriesChangeListener27);
//        java.util.Collection collection29 = timeSeries26.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries26.removeChangeListener(seriesChangeListener30);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        long long33 = year32.getFirstMillisecond();
//        int int34 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date36 = fixedMillisecond35.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date36);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (double) (byte) -1);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year40.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year40.previous();
//        boolean boolean43 = fixedMillisecond37.equals((java.lang.Object) year40);
//        boolean boolean44 = timeSeries7.equals((java.lang.Object) fixedMillisecond37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number49 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, number49);
//        java.lang.Object obj51 = timeSeriesDataItem50.clone();
//        java.lang.Class class54 = null;
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem50, "June 2019", "June 2019", class54);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener56 = null;
//        timeSeries55.removeChangeListener(seriesChangeListener56);
//        java.util.Collection collection58 = timeSeries55.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener59 = null;
//        timeSeries55.removeChangeListener(seriesChangeListener59);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        long long62 = year61.getFirstMillisecond();
//        int int63 = timeSeries55.getIndex((org.jfree.data.time.RegularTimePeriod) year61);
//        timeSeries55.setMaximumItemCount((int) '4');
//        timeSeries55.setMaximumItemCount(100);
//        int int68 = timeSeries55.getMaximumItemCount();
//        java.lang.Class<?> wildcardClass69 = timeSeries55.getClass();
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2147483647, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass69);
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond37, (java.lang.Class) wildcardClass69);
//        java.util.Calendar calendar72 = null;
//        long long73 = fixedMillisecond37.getLastMillisecond(calendar72);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertNull(class18);
//        org.junit.Assert.assertNotNull(obj22);
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(obj51);
//        org.junit.Assert.assertNotNull(collection58);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1546329600000L + "'", long62 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 100 + "'", int68 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass69);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1560190936443L + "'", long73 == 1560190936443L);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: June 2019");
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number40 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, number40);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond39.getLastMillisecond(calendar42);
//        long long44 = fixedMillisecond39.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number46 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, number46);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond45.getLastMillisecond(calendar48);
//        long long50 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
//        boolean boolean52 = timeSeries7.getNotify();
//        timeSeries7.fireSeriesChanged();
//        java.lang.Object obj54 = timeSeries7.clone();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190936768L + "'", long32 == 1560190936768L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190936768L + "'", long34 == 1560190936768L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560190936769L + "'", long43 == 1560190936769L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560190936769L + "'", long44 == 1560190936769L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560190936769L + "'", long49 == 1560190936769L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560190936769L + "'", long50 == 1560190936769L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertNotNull(obj54);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        long long4 = month3.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        timeSeries7.fireSeriesChanged();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
//        long long27 = day26.getFirstMillisecond();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number30);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem31, "June 2019", "June 2019", class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries36.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (byte) -1);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) year50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) year50);
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
//        long long56 = month55.getSerialIndex();
//        boolean boolean58 = month55.equals((java.lang.Object) 10);
//        long long59 = month55.getFirstMillisecond();
//        int int60 = month55.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month55.previous();
//        timeSeries7.setKey((java.lang.Comparable) regularTimePeriod61);
//        java.beans.PropertyChangeListener propertyChangeListener63 = null;
//        timeSeries7.removePropertyChangeListener(propertyChangeListener63);
//        java.util.List list65 = timeSeries7.getItems();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190936943L + "'", long22 == 1560190936943L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 24234L + "'", long56 == 24234L);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1559372400000L + "'", long59 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 6 + "'", int60 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(list65);
//    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test233");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
//        java.lang.String str6 = serialDate5.toString();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) serialDate5);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate5);
//        int int9 = day8.getMonth();
//        int int10 = day8.getMonth();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        long long4 = year0.getLastMillisecond();
        long long5 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        int int14 = day11.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate15 = day11.getSerialDate();
//        long long16 = day11.getSerialIndex();
//        int int17 = day11.getYear();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190937445L + "'", long7 == 1560190937445L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        int int14 = day11.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate15 = day11.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate18);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate24 = serialDate15.getEndOfCurrentMonth(serialDate21);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date27 = fixedMillisecond26.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date27);
//        boolean boolean30 = fixedMillisecond28.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getFirstMillisecond(calendar31);
//        java.util.Date date33 = fixedMillisecond28.getTime();
//        java.util.TimeZone timeZone34 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date33, timeZone34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date33);
//        int int37 = day36.getDayOfMonth();
//        int int39 = day36.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate40 = day36.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate43);
//        org.jfree.data.time.SerialDate serialDate46 = serialDate44.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate48 = serialDate46.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate49 = serialDate40.getEndOfCurrentMonth(serialDate46);
//        org.jfree.data.time.SerialDate serialDate50 = serialDate21.getEndOfCurrentMonth(serialDate40);
//        try {
//            org.jfree.data.time.SerialDate serialDate52 = serialDate40.getFollowingDayOfWeek((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190937490L + "'", long7 == 1560190937490L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190937493L + "'", long32 == 1560190937493L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate50);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 11:22:00 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number40 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, number40);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond39.getLastMillisecond(calendar42);
//        long long44 = fixedMillisecond39.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number46 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, number46);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond45.getLastMillisecond(calendar48);
//        long long50 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
//        boolean boolean53 = fixedMillisecond39.equals((java.lang.Object) '4');
//        java.util.Date date54 = fixedMillisecond39.getTime();
//        java.lang.Class class55 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date57 = fixedMillisecond56.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond(date57);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date57, timeZone59);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number62 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61, number62);
//        java.lang.Object obj64 = timeSeriesDataItem63.clone();
//        java.lang.Class class67 = null;
//        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem63, "June 2019", "June 2019", class67);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener69 = null;
//        timeSeries68.removeChangeListener(seriesChangeListener69);
//        java.util.Collection collection71 = timeSeries68.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener72 = null;
//        timeSeries68.removeChangeListener(seriesChangeListener72);
//        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year();
//        long long75 = year74.getFirstMillisecond();
//        int int76 = timeSeries68.getIndex((org.jfree.data.time.RegularTimePeriod) year74);
//        timeSeries68.setMaximumItemCount((int) '4');
//        timeSeries68.setMaximumItemCount(100);
//        int int81 = timeSeries68.getMaximumItemCount();
//        java.lang.Class<?> wildcardClass82 = timeSeries68.getClass();
//        java.lang.Class class83 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date85 = fixedMillisecond84.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond86 = new org.jfree.data.time.FixedMillisecond(date85);
//        boolean boolean88 = fixedMillisecond86.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar89 = null;
//        long long90 = fixedMillisecond86.getFirstMillisecond(calendar89);
//        java.util.Date date91 = fixedMillisecond86.getTime();
//        java.util.TimeZone timeZone92 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance(class83, date91, timeZone92);
//        java.util.TimeZone timeZone94 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass82, date91, timeZone94);
//        org.jfree.data.time.Year year96 = new org.jfree.data.time.Year(date57, timeZone94);
//        org.jfree.data.time.Month month97 = new org.jfree.data.time.Month(date54, timeZone94);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod98 = month97.previous();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190937517L + "'", long32 == 1560190937517L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190937517L + "'", long34 == 1560190937517L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560190937539L + "'", long43 == 1560190937539L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560190937539L + "'", long44 == 1560190937539L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560190937540L + "'", long49 == 1560190937540L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560190937540L + "'", long50 == 1560190937540L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(obj64);
//        org.junit.Assert.assertNotNull(collection71);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1546329600000L + "'", long75 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 100 + "'", int81 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass82);
//        org.junit.Assert.assertNotNull(date85);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1560190937544L + "'", long90 == 1560190937544L);
//        org.junit.Assert.assertNotNull(date91);
//        org.junit.Assert.assertNull(regularTimePeriod93);
//        org.junit.Assert.assertNotNull(timeZone94);
//        org.junit.Assert.assertNull(regularTimePeriod95);
//        org.junit.Assert.assertNotNull(regularTimePeriod98);
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        long long12 = day11.getFirstMillisecond();
//        int int13 = day11.getYear();
//        int int14 = day11.getDayOfMonth();
//        int int15 = day11.getDayOfMonth();
//        long long16 = day11.getSerialIndex();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190938203L + "'", long7 == 1560190938203L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Nearest");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date3, timeZone5);
//        java.lang.Class<?> wildcardClass7 = date3.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number12 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, number12);
//        java.lang.Object obj14 = timeSeriesDataItem13.clone();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem13, "June 2019", "June 2019", class17);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries18.removeChangeListener(seriesChangeListener19);
//        java.util.Collection collection21 = timeSeries18.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries18.removeChangeListener(seriesChangeListener22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        long long25 = year24.getFirstMillisecond();
//        int int26 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year24);
//        timeSeries18.setMaximumItemCount((int) '4');
//        timeSeries18.setMaximumItemCount(100);
//        int int31 = timeSeries18.getMaximumItemCount();
//        java.lang.Class<?> wildcardClass32 = timeSeries18.getClass();
//        java.lang.Class class33 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date35);
//        boolean boolean38 = fixedMillisecond36.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond36.getFirstMillisecond(calendar39);
//        java.util.Date date41 = fixedMillisecond36.getTime();
//        java.util.TimeZone timeZone42 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date41, timeZone42);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date41, timeZone44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date41);
//        java.lang.Class class47 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date49 = fixedMillisecond48.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(date49);
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date49, timeZone51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date41, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date9, timeZone51);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560190892344L, (java.lang.Class) wildcardClass7);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(obj14);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560190938257L + "'", long40 == 1560190938257L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Object obj10 = timeSeries7.clone();
        timeSeries7.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj10);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int30 = spreadsheetDate29.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate32.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean36 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, serialDate32, (int) ' ');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate41);
//        org.jfree.data.time.SerialDate serialDate44 = serialDate42.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate46 = serialDate44.getNearestDayOfWeek(7);
//        boolean boolean47 = spreadsheetDate38.isAfter(serialDate46);
//        boolean boolean48 = spreadsheetDate1.isOn(serialDate46);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class52 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date54 = fixedMillisecond53.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond(date54);
//        boolean boolean57 = fixedMillisecond55.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar58 = null;
//        long long59 = fixedMillisecond55.getFirstMillisecond(calendar58);
//        java.util.Date date60 = fixedMillisecond55.getTime();
//        java.util.TimeZone timeZone61 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date60, timeZone61);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date60);
//        int int64 = day63.getDayOfMonth();
//        int int66 = day63.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate67 = day63.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate70);
//        org.jfree.data.time.SerialDate serialDate73 = serialDate71.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate75 = serialDate73.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate76 = serialDate67.getEndOfCurrentMonth(serialDate73);
//        boolean boolean77 = spreadsheetDate51.isOnOrBefore(serialDate76);
//        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.addMonths(7, serialDate76);
//        org.jfree.data.time.SerialDate serialDate79 = serialDate46.getEndOfCurrentMonth(serialDate78);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190938635L + "'", long9 == 1560190938635L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560190938661L + "'", long59 == 1560190938661L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 10 + "'", int64 == 10);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertNotNull(serialDate71);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertNotNull(serialDate76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
//        org.junit.Assert.assertNotNull(serialDate78);
//        org.junit.Assert.assertNotNull(serialDate79);
//    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        int int14 = day11.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate15 = day11.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day11.previous();
//        long long17 = day11.getLastMillisecond();
//        long long18 = day11.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190939394L + "'", long7 == 1560190939394L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560236399999L + "'", long17 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        timeSeries7.fireSeriesChanged();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
//        long long27 = day26.getFirstMillisecond();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number30);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem31, "June 2019", "June 2019", class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries36.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (byte) -1);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) year50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) year50);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number56 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, number56);
//        java.lang.Object obj58 = timeSeriesDataItem57.clone();
//        java.lang.Class class61 = null;
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem57, "June 2019", "June 2019", class61);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener63 = null;
//        timeSeries62.removeChangeListener(seriesChangeListener63);
//        java.lang.String str65 = timeSeries62.getDescription();
//        boolean boolean66 = timeSeries62.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number68 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67, number68);
//        java.util.Calendar calendar70 = null;
//        long long71 = fixedMillisecond67.getLastMillisecond(calendar70);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries62.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67);
//        timeSeries62.setKey((java.lang.Comparable) false);
//        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries54.addAndOrUpdate(timeSeries62);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number77 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond76, number77);
//        java.lang.Object obj79 = timeSeriesDataItem78.clone();
//        java.lang.Class class82 = null;
//        org.jfree.data.time.TimeSeries timeSeries83 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem78, "June 2019", "June 2019", class82);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener84 = null;
//        timeSeries83.removeChangeListener(seriesChangeListener84);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener86 = null;
//        timeSeries83.removeChangeListener(seriesChangeListener86);
//        org.jfree.data.time.TimeSeries timeSeries88 = timeSeries75.addAndOrUpdate(timeSeries83);
//        java.lang.Class class89 = timeSeries75.getTimePeriodClass();
//        timeSeries75.setDescription("June 2019");
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190939423L + "'", long22 == 1560190939423L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(obj58);
//        org.junit.Assert.assertNull(str65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560190939451L + "'", long71 == 1560190939451L);
//        org.junit.Assert.assertNull(timeSeriesDataItem72);
//        org.junit.Assert.assertNotNull(timeSeries75);
//        org.junit.Assert.assertNotNull(obj79);
//        org.junit.Assert.assertNotNull(timeSeries88);
//        org.junit.Assert.assertNull(class89);
//    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        java.util.Date date13 = day11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190939974L + "'", long7 == 1560190939974L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(date13);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        boolean boolean4 = year0.equals((java.lang.Object) 1560190852108L);
        int int6 = year0.compareTo((java.lang.Object) 1560190855204L);
        java.util.Date date7 = year0.getStart();
        java.util.Date date8 = year0.getEnd();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year0.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        int int13 = day11.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190940022L + "'", long7 == 1560190940022L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date8);
//        org.jfree.data.time.SerialDate serialDate14 = day13.getSerialDate();
//        long long15 = day13.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190940062L + "'", long7 == 1560190940062L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560150000000L + "'", long15 == 1560150000000L);
//    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test251");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getFirstMillisecond();
//        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
//        timeSeries7.setMaximumItemCount((int) '4');
//        timeSeries7.setMaximumItemCount(100);
//        int int20 = timeSeries7.getMaximumItemCount();
//        java.lang.Class<?> wildcardClass21 = timeSeries7.getClass();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date24 = fixedMillisecond23.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
//        boolean boolean27 = fixedMillisecond25.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond25.getFirstMillisecond(calendar28);
//        java.util.Date date30 = fixedMillisecond25.getTime();
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date30, timeZone31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30);
//        long long34 = day33.getFirstMillisecond();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        boolean boolean40 = fixedMillisecond38.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond38.getFirstMillisecond(calendar41);
//        java.util.Date date43 = fixedMillisecond38.getTime();
//        java.util.TimeZone timeZone44 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date43, timeZone44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date43);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date43);
//        boolean boolean48 = day33.equals((java.lang.Object) year47);
//        long long49 = day33.getSerialIndex();
//        java.lang.String str50 = day33.toString();
//        try {
//            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day33, (double) ' ', false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560190940097L + "'", long29 == 1560190940097L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560150000000L + "'", long34 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560190940099L + "'", long42 == 1560190940099L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 43626L + "'", long49 == 43626L);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "10-June-2019" + "'", str50.equals("10-June-2019"));
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Nearest");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        boolean boolean5 = year1.equals((java.lang.Object) 1560190852108L);
        long long6 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(10, year1);
        int int8 = month7.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        int int5 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries17.removeChangeListener(seriesChangeListener21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        int int25 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        timeSeries17.setMaximumItemCount((int) '4');
        timeSeries17.setMaximumItemCount(100);
        int int30 = timeSeries17.getMaximumItemCount();
        java.lang.Class<?> wildcardClass31 = timeSeries17.getClass();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2147483647, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass31);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, (java.lang.Class) wildcardClass31);
        timeSeries33.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560190855309L);
        java.util.Date date4 = fixedMillisecond0.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Second");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesChangeEvent[source=1560190857476]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test259");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date11 = fixedMillisecond10.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
//        boolean boolean14 = fixedMillisecond12.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond12.getFirstMillisecond(calendar15);
//        java.lang.Number number17 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getLastMillisecond(calendar19);
//        long long21 = fixedMillisecond18.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 1560190877224L);
//        timeSeries7.removeAgedItems(false);
//        try {
//            java.lang.Number number27 = timeSeries7.getValue((-304346));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560190940275L + "'", long16 == 1560190940275L);
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190940276L + "'", long20 == 1560190940276L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560190940276L + "'", long21 == 1560190940276L);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        try {
            org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getNearestDayOfWeek((-304346));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        java.lang.Object obj10 = timeSeries7.clone();
//        boolean boolean11 = timeSeries7.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date13 = fixedMillisecond12.getTime();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond12.getMiddleMillisecond(calendar14);
//        long long16 = fixedMillisecond12.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond17.getLastMillisecond(calendar18);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond17.getMiddleMillisecond(calendar20);
//        boolean boolean22 = fixedMillisecond12.equals((java.lang.Object) fixedMillisecond17);
//        int int23 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        java.lang.Class class24 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date26);
//        boolean boolean29 = fixedMillisecond27.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond27.getFirstMillisecond(calendar30);
//        java.util.Date date32 = fixedMillisecond27.getTime();
//        java.util.TimeZone timeZone33 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date32, timeZone33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date32);
//        long long36 = day35.getFirstMillisecond();
//        java.util.Date date37 = day35.getStart();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
//        int int39 = fixedMillisecond17.compareTo((java.lang.Object) day38);
//        java.util.Calendar calendar40 = null;
//        try {
//            long long41 = day38.getFirstMillisecond(calendar40);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560190940295L + "'", long15 == 1560190940295L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560190940295L + "'", long16 == 1560190940295L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560190940317L + "'", long19 == 1560190940317L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560190940317L + "'", long21 == 1560190940317L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560190940318L + "'", long31 == 1560190940318L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560150000000L + "'", long36 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560190855309L);
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date7, timeZone9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number12 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, number12);
//        java.lang.Object obj14 = timeSeriesDataItem13.clone();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem13, "June 2019", "June 2019", class17);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries18.removeChangeListener(seriesChangeListener19);
//        java.util.Collection collection21 = timeSeries18.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries18.removeChangeListener(seriesChangeListener22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        long long25 = year24.getFirstMillisecond();
//        int int26 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year24);
//        timeSeries18.setMaximumItemCount((int) '4');
//        timeSeries18.setMaximumItemCount(100);
//        int int31 = timeSeries18.getMaximumItemCount();
//        java.lang.Class<?> wildcardClass32 = timeSeries18.getClass();
//        java.lang.Class class33 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date35);
//        boolean boolean38 = fixedMillisecond36.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond36.getFirstMillisecond(calendar39);
//        java.util.Date date41 = fixedMillisecond36.getTime();
//        java.util.TimeZone timeZone42 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date41, timeZone42);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date41, timeZone44);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date7, timeZone44);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date4, timeZone44);
//        long long48 = year47.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(obj14);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560190940336L + "'", long40 == 1560190940336L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2019L + "'", long48 == 2019L);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getSerialIndex();
        java.lang.Number number16 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month14);
        long long17 = month14.getLastMillisecond();
        int int18 = month14.getYearValue();
        long long19 = month14.getSerialIndex();
        java.lang.String str20 = month14.toString();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 24234L + "'", long19 == 24234L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test264");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int30 = spreadsheetDate29.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate32.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean36 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, serialDate32, (int) ' ');
//        int int37 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
//        java.lang.String str40 = fixedMillisecond39.toString();
//        long long41 = fixedMillisecond39.getLastMillisecond();
//        boolean boolean42 = spreadsheetDate1.equals((java.lang.Object) fixedMillisecond39);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190940558L + "'", long9 == 1560190940558L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str40.equals("Wed Dec 31 15:59:59 PST 1969"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        timeSeries7.fireSeriesChanged();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
//        long long27 = day26.getFirstMillisecond();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number30);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem31, "June 2019", "June 2019", class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries36.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (byte) -1);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) year50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) year50);
//        timeSeries54.setRangeDescription("September");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number58 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57, number58);
//        java.lang.Object obj60 = timeSeriesDataItem59.clone();
//        java.lang.Class class63 = null;
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem59, "June 2019", "June 2019", class63);
//        java.lang.Number number65 = timeSeriesDataItem59.getValue();
//        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month();
//        long long67 = month66.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number69 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, number69);
//        java.lang.Object obj71 = timeSeriesDataItem70.clone();
//        java.lang.Class class74 = null;
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem70, "June 2019", "June 2019", class74);
//        timeSeries75.removeAgedItems(true);
//        timeSeries75.setKey((java.lang.Comparable) (byte) -1);
//        boolean boolean80 = month66.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = month66.next();
//        int int82 = timeSeriesDataItem59.compareTo((java.lang.Object) month66);
//        try {
//            timeSeries54.add(timeSeriesDataItem59);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190940676L + "'", long22 == 1560190940676L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(obj60);
//        org.junit.Assert.assertNull(number65);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 24234L + "'", long67 == 24234L);
//        org.junit.Assert.assertNotNull(obj71);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
//    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int2 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class5 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
//        boolean boolean10 = fixedMillisecond8.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond8.getFirstMillisecond(calendar11);
//        java.util.Date date13 = fixedMillisecond8.getTime();
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date13, timeZone14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13);
//        int int17 = day16.getDayOfMonth();
//        int int19 = day16.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate20 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate23);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate24.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate28 = serialDate26.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate29 = serialDate20.getEndOfCurrentMonth(serialDate26);
//        boolean boolean30 = spreadsheetDate4.isOnOrBefore(serialDate29);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int33 = spreadsheetDate32.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate35.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean39 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, serialDate35, (int) ' ');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int42 = spreadsheetDate41.getDayOfWeek();
//        boolean boolean43 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        boolean boolean44 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        int int45 = spreadsheetDate1.getYYYY();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560190940724L + "'", long12 == 1560190940724L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3 + "'", int33 == 3);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 3 + "'", int42 == 3);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1927 + "'", int45 == 1927);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        int int5 = month0.getMonth();
        int int6 = month0.getYearValue();
        java.lang.String str7 = month0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        int int5 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries17.removeChangeListener(seriesChangeListener21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        int int25 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        timeSeries17.setMaximumItemCount((int) '4');
        timeSeries17.setMaximumItemCount(100);
        int int30 = timeSeries17.getMaximumItemCount();
        java.lang.Class<?> wildcardClass31 = timeSeries17.getClass();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2147483647, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass31);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, (java.lang.Class) wildcardClass31);
        timeSeries33.setNotify(true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = null;
        try {
            timeSeries33.add(regularTimePeriod36, (java.lang.Number) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.lang.Class class3 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date5 = fixedMillisecond4.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date5, timeZone7);
        java.lang.Class<?> wildcardClass9 = date5.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560190873643L, "June 2019", "org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass9);
        timeSeries10.setMaximumItemAge((long) 2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number13 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number13);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "June 2019", "June 2019", class18);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        java.util.Collection collection22 = timeSeries19.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries19.removeChangeListener(seriesChangeListener23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        int int27 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
        timeSeries19.setMaximumItemCount((int) '4');
        timeSeries19.setMaximumItemCount(100);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries7.addAndOrUpdate(timeSeries19);
        int int33 = timeSeries32.getItemCount();
        timeSeries32.setMaximumItemCount((int) (byte) 0);
        boolean boolean36 = timeSeries32.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number38 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, number38);
        timeSeriesDataItem39.setValue((java.lang.Number) (short) -1);
        timeSeriesDataItem39.setValue((java.lang.Number) (short) 1);
        timeSeriesDataItem39.setValue((java.lang.Number) 1560190861489L);
        try {
            timeSeries32.add(timeSeriesDataItem39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class3 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date5 = fixedMillisecond4.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
//        boolean boolean8 = fixedMillisecond6.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond6.getFirstMillisecond(calendar9);
//        java.util.Date date11 = fixedMillisecond6.getTime();
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date11, timeZone12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date11);
//        int int15 = day14.getDayOfMonth();
//        int int17 = day14.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate18 = day14.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate21);
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate24.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate27 = serialDate18.getEndOfCurrentMonth(serialDate24);
//        boolean boolean28 = spreadsheetDate2.isOnOrBefore(serialDate27);
//        int int29 = spreadsheetDate2.getDayOfWeek();
//        try {
//            org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560190940910L + "'", long10 == 1560190940910L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 7 + "'", int29 == 7);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("June");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getSerialIndex();
        java.lang.Number number16 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month14.next();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        boolean boolean5 = year1.equals((java.lang.Object) 1560190852108L);
        long long6 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(10, year1);
        int int8 = month7.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (double) 1560190876639L);
        long long11 = month7.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1569913200000L + "'", long11 == 1569913200000L);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int30 = spreadsheetDate29.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate32.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean36 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, serialDate32, (int) ' ');
//        boolean boolean38 = spreadsheetDate29.equals((java.lang.Object) 1560190876325L);
//        java.lang.String str39 = spreadsheetDate29.toString();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190941351L + "'", long9 == 1560190941351L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "17-May-1927" + "'", str39.equals("17-May-1927"));
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        int int5 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries17.removeChangeListener(seriesChangeListener21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        int int25 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        timeSeries17.setMaximumItemCount((int) '4');
        timeSeries17.setMaximumItemCount(100);
        int int30 = timeSeries17.getMaximumItemCount();
        java.lang.Class<?> wildcardClass31 = timeSeries17.getClass();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2147483647, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass31);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, (java.lang.Class) wildcardClass31);
        try {
            org.jfree.data.time.TimeSeries timeSeries36 = timeSeries33.createCopy(1963, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getSerialIndex();
        java.lang.Number number16 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month14);
        java.util.Collection collection17 = timeSeries7.getTimePeriods();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertNotNull(collection17);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        long long12 = day11.getFirstMillisecond();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        boolean boolean18 = fixedMillisecond16.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond16.getFirstMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond16.getTime();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date21);
//        boolean boolean26 = day11.equals((java.lang.Object) year25);
//        long long27 = day11.getSerialIndex();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
//        long long30 = year28.getSerialIndex();
//        org.jfree.data.general.SeriesException seriesException32 = new org.jfree.data.general.SeriesException("");
//        int int33 = year28.compareTo((java.lang.Object) seriesException32);
//        java.lang.Throwable[] throwableArray34 = seriesException32.getSuppressed();
//        int int35 = day11.compareTo((java.lang.Object) throwableArray34);
//        java.lang.String str36 = day11.toString();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190941596L + "'", long7 == 1560190941596L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190941598L + "'", long20 == 1560190941598L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(throwableArray34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10-June-2019" + "'", str36.equals("10-June-2019"));
//    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test280");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener39);
//        boolean boolean41 = timeSeries7.isEmpty();
//        java.lang.String str42 = timeSeries7.getRangeDescription();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190941715L + "'", long32 == 1560190941715L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190941715L + "'", long34 == 1560190941715L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(11, 3, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeries7.removeAgedItems(true);
        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
        timeSeries7.setRangeDescription("2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number15 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
        java.lang.Object obj17 = timeSeriesDataItem16.clone();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.removeChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries21.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries21.removeChangeListener(seriesChangeListener25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getFirstMillisecond();
        int int29 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) year27);
        timeSeries21.setMaximumItemCount((int) '4');
        timeSeries21.setMaximumItemCount(100);
        int int34 = timeSeries21.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries7.addAndOrUpdate(timeSeries21);
        java.lang.Object obj36 = timeSeries35.clone();
        java.lang.Comparable comparable37 = timeSeries35.getKey();
        java.lang.Object obj38 = timeSeries35.clone();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + "Overwritten values from: -1" + "'", comparable37.equals("Overwritten values from: -1"));
        org.junit.Assert.assertNotNull(obj38);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        boolean boolean17 = year13.equals((java.lang.Object) 1560190852108L);
        long long18 = year13.getFirstMillisecond();
        java.lang.String str19 = year13.toString();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 1560190900736L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
        java.util.List list2 = timeSeries1.getItems();
        int int3 = timeSeries1.getMaximumItemCount();
        timeSeries1.setDomainDescription("Preceding");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "Preceding");
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2958465) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int30 = spreadsheetDate29.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate32.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean36 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, serialDate32, (int) ' ');
//        java.lang.String[] strArray37 = org.jfree.data.time.SerialDate.getMonths();
//        boolean boolean38 = spreadsheetDate1.equals((java.lang.Object) strArray37);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date43 = fixedMillisecond42.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(date43);
//        boolean boolean46 = fixedMillisecond44.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar47 = null;
//        long long48 = fixedMillisecond44.getFirstMillisecond(calendar47);
//        java.util.Date date49 = fixedMillisecond44.getTime();
//        java.util.TimeZone timeZone50 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date49, timeZone50);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date49);
//        int int53 = day52.getDayOfMonth();
//        int int55 = day52.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate56 = day52.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate59);
//        org.jfree.data.time.SerialDate serialDate62 = serialDate60.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate64 = serialDate62.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate65 = serialDate56.getEndOfCurrentMonth(serialDate62);
//        boolean boolean66 = spreadsheetDate40.isOnOrBefore(serialDate65);
//        int int67 = spreadsheetDate40.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate68 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190941924L + "'", long9 == 1560190941924L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(strArray37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560190941949L + "'", long48 == 1560190941949L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 10 + "'", int53 == 10);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 7 + "'", int67 == 7);
//        org.junit.Assert.assertNotNull(serialDate68);
//    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        java.lang.Class<?> wildcardClass11 = date8.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190942473L + "'", long7 == 1560190942473L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        boolean boolean23 = timeSeries17.isEmpty();
        long long24 = timeSeries17.getMaximumItemAge();
        timeSeries17.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries17.createCopy(0, 2019);
        java.lang.String str29 = timeSeries17.getDescription();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNull(str29);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test289");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date11 = fixedMillisecond10.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
//        boolean boolean14 = fixedMillisecond12.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond12.getFirstMillisecond(calendar15);
//        java.lang.Number number17 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timeSeries7.removePropertyChangeListener(propertyChangeListener18);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560190942579L + "'", long16 == 1560190942579L);
//        org.junit.Assert.assertNull(number17);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, number3);
        int int6 = timeSeriesDataItem4.compareTo((java.lang.Object) '4');
        int int7 = month1.compareTo((java.lang.Object) '4');
        long long8 = month1.getLastMillisecond();
        java.lang.Class class9 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date11 = fixedMillisecond10.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date11, timeZone13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date11);
        int int16 = month1.compareTo((java.lang.Object) date11);
        java.lang.Class<?> wildcardClass17 = date11.getClass();
        try {
            org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries(comparable0, (java.lang.Class) wildcardClass17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        int int9 = timeSeriesDataItem2.compareTo((java.lang.Object) 1561964399999L);
        java.lang.Object obj10 = null;
        boolean boolean11 = timeSeriesDataItem2.equals(obj10);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test293");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        java.lang.Class<?> wildcardClass11 = date8.getClass();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8);
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date8, timeZone13);
//        boolean boolean16 = month14.equals((java.lang.Object) 1560190862158L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190942641L + "'", long7 == 1560190942641L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.lang.String str4 = month0.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getSerialIndex();
        java.lang.Number number16 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month14);
        java.lang.String str17 = timeSeries7.getDomainDescription();
        timeSeries7.fireSeriesChanged();
        java.lang.Class class19 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date21 = fixedMillisecond20.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date21, timeZone23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date21);
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month28, (double) 1560190855348L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod24);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number13 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number13);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "June 2019", "June 2019", class18);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        java.util.Collection collection22 = timeSeries19.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries19.removeChangeListener(seriesChangeListener23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        int int27 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
        timeSeries19.setMaximumItemCount((int) '4');
        timeSeries19.setMaximumItemCount(100);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries7.addAndOrUpdate(timeSeries19);
        java.lang.String str33 = timeSeries7.getRangeDescription();
        timeSeries7.setDomainDescription("May");
        java.lang.Object obj36 = timeSeries7.clone();
        timeSeries7.fireSeriesChanged();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertNotNull(obj36);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test297");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        boolean boolean4 = fixedMillisecond2.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond2.getFirstMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond2.getTime();
//        long long8 = fixedMillisecond2.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190942788L + "'", long6 == 1560190942788L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560190942788L + "'", long8 == 1560190942788L);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        boolean boolean5 = year1.equals((java.lang.Object) 1560190852108L);
        long long6 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(10, year1);
        int int8 = month7.getYearValue();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month7.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
        java.lang.String str14 = timeSeries7.getDomainDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = null;
        try {
            timeSeries7.update(regularTimePeriod15, (java.lang.Number) 1560190898255L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.lang.String str10 = timeSeries7.getDescription();
//        boolean boolean11 = timeSeries7.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number13 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number13);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond12.getLastMillisecond(calendar15);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        timeSeries7.setKey((java.lang.Comparable) false);
//        java.lang.String str20 = timeSeries7.getDomainDescription();
//        boolean boolean21 = timeSeries7.getNotify();
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener22);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560190943398L + "'", long16 == 1560190943398L);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        int int12 = timeSeries7.getMaximumItemCount();
        int int13 = timeSeries7.getItemCount();
        timeSeries7.removeAgedItems(true);
        java.util.List list16 = timeSeries7.getItems();
        try {
            org.jfree.data.time.TimeSeries timeSeries19 = timeSeries7.createCopy(1927, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Overwritten values from: -1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getFirstMillisecond();
//        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
//        timeSeries7.setMaximumItemCount((int) '4');
//        timeSeries7.setMaximumItemCount(100);
//        int int20 = timeSeries7.getMaximumItemCount();
//        java.lang.Class<?> wildcardClass21 = timeSeries7.getClass();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date24 = fixedMillisecond23.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
//        boolean boolean27 = fixedMillisecond25.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond25.getFirstMillisecond(calendar28);
//        java.util.Date date30 = fixedMillisecond25.getTime();
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date30, timeZone31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30);
//        long long34 = day33.getFirstMillisecond();
//        java.util.Date date35 = day33.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date35);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date39 = fixedMillisecond38.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date39);
//        boolean boolean42 = fixedMillisecond40.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond40.getFirstMillisecond(calendar43);
//        java.util.Date date45 = fixedMillisecond40.getTime();
//        java.util.TimeZone timeZone46 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date45, timeZone46);
//        java.lang.Class<?> wildcardClass48 = date45.getClass();
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date45);
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date45, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date35, timeZone50);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(date35);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560190943441L + "'", long29 == 1560190943441L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560150000000L + "'", long34 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560190943443L + "'", long44 == 1560190943443L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560190886313L);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test305");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        timeSeries7.fireSeriesChanged();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
//        long long27 = day26.getFirstMillisecond();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number30);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem31, "June 2019", "June 2019", class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries36.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (byte) -1);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) year50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) year50);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number56 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, number56);
//        java.lang.Object obj58 = timeSeriesDataItem57.clone();
//        java.lang.Class class61 = null;
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem57, "June 2019", "June 2019", class61);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener63 = null;
//        timeSeries62.removeChangeListener(seriesChangeListener63);
//        java.lang.String str65 = timeSeries62.getDescription();
//        boolean boolean66 = timeSeries62.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number68 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67, number68);
//        java.util.Calendar calendar70 = null;
//        long long71 = fixedMillisecond67.getLastMillisecond(calendar70);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries62.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67);
//        timeSeries62.setKey((java.lang.Comparable) false);
//        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries54.addAndOrUpdate(timeSeries62);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number77 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond76, number77);
//        java.lang.Object obj79 = timeSeriesDataItem78.clone();
//        java.lang.Class class82 = null;
//        org.jfree.data.time.TimeSeries timeSeries83 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem78, "June 2019", "June 2019", class82);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener84 = null;
//        timeSeries83.removeChangeListener(seriesChangeListener84);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener86 = null;
//        timeSeries83.removeChangeListener(seriesChangeListener86);
//        org.jfree.data.time.TimeSeries timeSeries88 = timeSeries75.addAndOrUpdate(timeSeries83);
//        java.lang.Class class89 = timeSeries75.getTimePeriodClass();
//        timeSeries75.setDomainDescription("Nearest");
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190943773L + "'", long22 == 1560190943773L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(obj58);
//        org.junit.Assert.assertNull(str65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560190943779L + "'", long71 == 1560190943779L);
//        org.junit.Assert.assertNull(timeSeriesDataItem72);
//        org.junit.Assert.assertNotNull(timeSeries75);
//        org.junit.Assert.assertNotNull(obj79);
//        org.junit.Assert.assertNotNull(timeSeries88);
//        org.junit.Assert.assertNull(class89);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray25 = seriesException24.getSuppressed();
        int int26 = timeSeriesDataItem2.compareTo((java.lang.Object) seriesException24);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190861538L);
        java.lang.Object obj29 = null;
        int int30 = timeSeriesDataItem2.compareTo(obj29);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1963, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1963");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1927, 3, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8);
//        long long13 = year12.getFirstMillisecond();
//        java.util.Date date14 = year12.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date20 = fixedMillisecond19.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date20, timeZone22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number25 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, number25);
//        java.lang.Object obj27 = timeSeriesDataItem26.clone();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem26, "June 2019", "June 2019", class30);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries31.removeChangeListener(seriesChangeListener32);
//        java.util.Collection collection34 = timeSeries31.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
//        timeSeries31.removeChangeListener(seriesChangeListener35);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
//        long long38 = year37.getFirstMillisecond();
//        int int39 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) year37);
//        timeSeries31.setMaximumItemCount((int) '4');
//        timeSeries31.setMaximumItemCount(100);
//        int int44 = timeSeries31.getMaximumItemCount();
//        java.lang.Class<?> wildcardClass45 = timeSeries31.getClass();
//        java.lang.Class class46 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date48 = fixedMillisecond47.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond(date48);
//        boolean boolean51 = fixedMillisecond49.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar52 = null;
//        long long53 = fixedMillisecond49.getFirstMillisecond(calendar52);
//        java.util.Date date54 = fixedMillisecond49.getTime();
//        java.util.TimeZone timeZone55 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date54, timeZone55);
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date54, timeZone57);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date20, timeZone57);
//        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date16, timeZone57);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date14, timeZone57);
//        java.util.Calendar calendar62 = null;
//        try {
//            long long63 = day61.getFirstMillisecond(calendar62);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190944328L + "'", long7 == 1560190944328L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(obj27);
//        org.junit.Assert.assertNotNull(collection34);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 100 + "'", int44 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560190944333L + "'", long53 == 1560190944333L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560190866736L);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560190866736L + "'", long2 == 1560190866736L);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        java.util.Collection collection11 = timeSeries7.getTimePeriods();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
//        boolean boolean17 = fixedMillisecond15.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getFirstMillisecond(calendar18);
//        java.util.Date date20 = fixedMillisecond15.getTime();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date20, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20);
//        int int24 = day23.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 2);
//        long long27 = day23.getFirstMillisecond();
//        int int28 = day23.getYear();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560190944361L + "'", long19 == 1560190944361L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeries7.removeAgedItems(true);
        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
        timeSeries7.setRangeDescription("hi!");
        timeSeries7.setDescription("hi!");
        long long16 = timeSeries7.getMaximumItemAge();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560190855309L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number5 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, number5);
        java.lang.Object obj7 = timeSeriesDataItem6.clone();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6, "June 2019", "June 2019", class10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.removeChangeListener(seriesChangeListener12);
        java.util.Collection collection14 = timeSeries11.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries11.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        int int19 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year17);
        int int20 = year17.getYear();
        java.lang.Class<?> wildcardClass21 = year17.getClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem3, (java.lang.Class) wildcardClass21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeriesDataItem3.getPeriod();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate8);
//        org.jfree.data.time.SerialDate serialDate11 = serialDate9.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getNearestDayOfWeek(7);
//        boolean boolean14 = spreadsheetDate5.isAfter(serialDate13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date16);
//        java.lang.String str19 = serialDate18.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int22 = spreadsheetDate21.getDayOfWeek();
//        boolean boolean23 = spreadsheetDate5.isInRange(serialDate18, (org.jfree.data.time.SerialDate) spreadsheetDate21);
//        int int24 = spreadsheetDate5.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int27 = spreadsheetDate26.getMonth();
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate30);
//        org.jfree.data.time.SerialDate serialDate33 = serialDate31.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate35 = serialDate33.getNearestDayOfWeek(7);
//        boolean boolean36 = spreadsheetDate26.isBefore(serialDate33);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class39 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date41 = fixedMillisecond40.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(date41);
//        boolean boolean44 = fixedMillisecond42.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar45 = null;
//        long long46 = fixedMillisecond42.getFirstMillisecond(calendar45);
//        java.util.Date date47 = fixedMillisecond42.getTime();
//        java.util.TimeZone timeZone48 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date47, timeZone48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date47);
//        int int51 = day50.getDayOfMonth();
//        int int53 = day50.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate54 = day50.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate57);
//        org.jfree.data.time.SerialDate serialDate60 = serialDate58.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate62 = serialDate60.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate63 = serialDate54.getEndOfCurrentMonth(serialDate60);
//        boolean boolean64 = spreadsheetDate38.isOnOrBefore(serialDate63);
//        int int65 = spreadsheetDate38.getDayOfWeek();
//        boolean boolean66 = spreadsheetDate5.isInRange(serialDate33, (org.jfree.data.time.SerialDate) spreadsheetDate38);
//        serialDate33.setDescription("14-April-2733");
//        boolean boolean69 = spreadsheetDate2.isOnOrAfter(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10-June-2019" + "'", str19.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 7 + "'", int24 == 7);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 5 + "'", int27 == 5);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560190944517L + "'", long46 == 1560190944517L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 7 + "'", int65 == 7);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
//        long long2 = year0.getSerialIndex();
//        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
//        int int5 = year0.compareTo((java.lang.Object) seriesException4);
//        int int7 = year0.compareTo((java.lang.Object) 1560190859545L);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond11.getFirstMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond11.getTime();
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date16, timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16);
//        int int20 = day19.getDayOfMonth();
//        boolean boolean21 = year0.equals((java.lang.Object) day19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year0.previous();
//        long long23 = year0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560190944942L + "'", long15 == 1560190944942L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560190944980L + "'", long3 == 1560190944980L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190944980L + "'", long4 == 1560190944980L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190944980L + "'", long6 == 1560190944980L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getSerialIndex();
        java.lang.Number number16 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month14);
        long long17 = month14.getLastMillisecond();
        int int18 = month14.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 1560190859873L);
        long long21 = month14.getFirstMillisecond();
        java.util.Date date22 = month14.getStart();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1559372400000L + "'", long21 == 1559372400000L);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(1964);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test322");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener11);
//        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
//        timeSeries7.setMaximumItemCount(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getLastMillisecond(calendar21);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 1560190855139L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number26 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number26);
//        java.lang.Object obj28 = timeSeriesDataItem27.clone();
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem27, "June 2019", "June 2019", class31);
//        timeSeries32.removeAgedItems(true);
//        timeSeries32.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries32.setRangeDescription("2019");
//        timeSeries32.fireSeriesChanged();
//        java.lang.Class class40 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date42 = fixedMillisecond41.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
//        boolean boolean45 = fixedMillisecond43.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond43.getFirstMillisecond(calendar46);
//        java.util.Date date48 = fixedMillisecond43.getTime();
//        java.util.TimeZone timeZone49 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date48, timeZone49);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date48);
//        long long52 = day51.getFirstMillisecond();
//        java.util.Date date53 = day51.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number55 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number55);
//        java.lang.Object obj57 = timeSeriesDataItem56.clone();
//        java.lang.Class class60 = null;
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem56, "June 2019", "June 2019", class60);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener62 = null;
//        timeSeries61.removeChangeListener(seriesChangeListener62);
//        java.util.Collection collection64 = timeSeries61.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener65 = null;
//        timeSeries61.removeChangeListener(seriesChangeListener65);
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
//        long long68 = year67.getFirstMillisecond();
//        int int69 = timeSeries61.getIndex((org.jfree.data.time.RegularTimePeriod) year67);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date71 = fixedMillisecond70.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond(date71);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond72, (double) (byte) -1);
//        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year75.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = year75.previous();
//        boolean boolean78 = fixedMillisecond72.equals((java.lang.Object) year75);
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) day51, (org.jfree.data.time.RegularTimePeriod) year75);
//        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month();
//        long long81 = month80.getSerialIndex();
//        boolean boolean83 = month80.equals((java.lang.Object) 10);
//        long long84 = month80.getFirstMillisecond();
//        int int85 = month80.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = month80.previous();
//        timeSeries32.setKey((java.lang.Comparable) regularTimePeriod86);
//        int int88 = fixedMillisecond18.compareTo((java.lang.Object) timeSeries32);
//        java.util.Calendar calendar89 = null;
//        long long90 = fixedMillisecond18.getFirstMillisecond(calendar89);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNull(class13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190945149L + "'", long22 == 1560190945149L);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560190945152L + "'", long47 == 1560190945152L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560150000000L + "'", long52 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(obj57);
//        org.junit.Assert.assertNotNull(collection64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1546329600000L + "'", long68 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNull(timeSeriesDataItem74);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(timeSeries79);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 24234L + "'", long81 == 24234L);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1559372400000L + "'", long84 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 6 + "'", int85 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod86);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
//        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1560190945149L + "'", long90 == 1560190945149L);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        timeSeriesDataItem2.setValue((java.lang.Number) (short) -1);
        timeSeriesDataItem2.setValue((java.lang.Number) (short) 1);
        int int8 = timeSeriesDataItem2.compareTo((java.lang.Object) 10L);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190941598L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test324");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond14.getMiddleMillisecond(calendar17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond14.getMiddleMillisecond(calendar19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1546329600000L);
//        long long23 = fixedMillisecond14.getLastMillisecond();
//        long long24 = fixedMillisecond14.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number26 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number26);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond25.getMiddleMillisecond(calendar28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number31 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, number31);
//        java.lang.Object obj33 = timeSeriesDataItem32.clone();
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem32, "June 2019", "June 2019", class36);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries37.removeChangeListener(seriesChangeListener38);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries37.removeChangeListener(seriesChangeListener40);
//        int int42 = timeSeries37.getMaximumItemCount();
//        int int43 = timeSeries37.getItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener44 = null;
//        timeSeries37.addPropertyChangeListener(propertyChangeListener44);
//        boolean boolean46 = fixedMillisecond25.equals((java.lang.Object) timeSeries37);
//        java.lang.String str47 = fixedMillisecond25.toString();
//        int int48 = fixedMillisecond14.compareTo((java.lang.Object) fixedMillisecond25);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560190945575L + "'", long18 == 1560190945575L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190945575L + "'", long20 == 1560190945575L);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190945575L + "'", long23 == 1560190945575L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560190945575L + "'", long24 == 1560190945575L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560190945576L + "'", long29 == 1560190945576L);
//        org.junit.Assert.assertNotNull(obj33);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2147483647 + "'", int42 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Mon Jun 10 11:22:25 PDT 2019" + "'", str47.equals("Mon Jun 10 11:22:25 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int5 = spreadsheetDate4.getDayOfWeek();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number7 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, number7);
//        java.lang.Object obj9 = timeSeriesDataItem8.clone();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem8, "June 2019", "June 2019", class12);
//        timeSeries13.removeAgedItems(true);
//        timeSeries13.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries13.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number21 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, number21);
//        java.lang.Object obj23 = timeSeriesDataItem22.clone();
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem22, "June 2019", "June 2019", class26);
//        timeSeries27.removeAgedItems(true);
//        timeSeries27.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries27.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number35 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, number35);
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond34.getMiddleMillisecond(calendar37);
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond34.getMiddleMillisecond(calendar39);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) 8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number46 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, number46);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond45.getLastMillisecond(calendar48);
//        long long50 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number52 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, number52);
//        java.util.Calendar calendar54 = null;
//        long long55 = fixedMillisecond51.getLastMillisecond(calendar54);
//        long long56 = fixedMillisecond51.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
//        long long58 = fixedMillisecond51.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(9999);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date62 = fixedMillisecond61.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond(date62);
//        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance(date62);
//        java.lang.String str65 = serialDate64.toString();
//        boolean boolean66 = spreadsheetDate60.equals((java.lang.Object) serialDate64);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(serialDate64);
//        int int68 = fixedMillisecond51.compareTo((java.lang.Object) serialDate64);
//        boolean boolean69 = spreadsheetDate4.isAfter(serialDate64);
//        boolean boolean71 = spreadsheetDate4.equals((java.lang.Object) 1560190881452L);
//        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate4);
//        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate72);
//        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate72);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertNotNull(obj9);
//        org.junit.Assert.assertNotNull(obj23);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560190945658L + "'", long38 == 1560190945658L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560190945658L + "'", long40 == 1560190945658L);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertNull(timeSeriesDataItem44);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560190945659L + "'", long49 == 1560190945659L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560190945659L + "'", long50 == 1560190945659L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560190945659L + "'", long55 == 1560190945659L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560190945659L + "'", long56 == 1560190945659L);
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560190945659L + "'", long58 == 1560190945659L);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "10-June-2019" + "'", str65.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertNotNull(serialDate72);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertNotNull(serialDate74);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560190936443L, "10-January-1900", "Mon Jun 10 11:21:26 PDT 2019", class3);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 10, 1927, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test328");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        long long39 = fixedMillisecond28.getMiddleMillisecond();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond28.getFirstMillisecond(calendar40);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190945991L + "'", long32 == 1560190945991L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190945991L + "'", long34 == 1560190945991L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560190945991L + "'", long39 == 1560190945991L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560190945991L + "'", long41 == 1560190945991L);
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test329");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int30 = spreadsheetDate29.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate32.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean36 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, serialDate32, (int) ' ');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int39 = spreadsheetDate38.getDayOfWeek();
//        boolean boolean40 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date45 = fixedMillisecond44.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(date45);
//        boolean boolean48 = fixedMillisecond46.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar49 = null;
//        long long50 = fixedMillisecond46.getFirstMillisecond(calendar49);
//        java.util.Date date51 = fixedMillisecond46.getTime();
//        java.util.TimeZone timeZone52 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date51, timeZone52);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date51);
//        int int55 = day54.getDayOfMonth();
//        int int57 = day54.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate58 = day54.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate61);
//        org.jfree.data.time.SerialDate serialDate64 = serialDate62.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate66 = serialDate64.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate67 = serialDate58.getEndOfCurrentMonth(serialDate64);
//        boolean boolean68 = spreadsheetDate42.isOnOrBefore(serialDate67);
//        java.lang.String str69 = spreadsheetDate42.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate74);
//        org.jfree.data.time.SerialDate serialDate77 = serialDate75.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate79 = serialDate77.getNearestDayOfWeek(7);
//        boolean boolean80 = spreadsheetDate71.isAfter(serialDate79);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date82 = fixedMillisecond81.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond(date82);
//        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.createInstance(date82);
//        java.lang.String str85 = serialDate84.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate87 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int88 = spreadsheetDate87.getDayOfWeek();
//        boolean boolean89 = spreadsheetDate71.isInRange(serialDate84, (org.jfree.data.time.SerialDate) spreadsheetDate87);
//        spreadsheetDate71.setDescription("Wed Dec 31 15:59:59 PST 1969");
//        boolean boolean92 = spreadsheetDate42.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate71);
//        org.jfree.data.time.SerialDate serialDate93 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate71);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190946037L + "'", long9 == 1560190946037L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 3 + "'", int39 == 3);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560190946041L + "'", long50 == 1560190946041L);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 10 + "'", int55 == 10);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
//        org.junit.Assert.assertNull(str69);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertNotNull(serialDate79);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(serialDate84);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "10-June-2019" + "'", str85.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 3 + "'", int88 == 3);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
//        org.junit.Assert.assertNotNull(serialDate93);
//    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test330");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.lang.String str7 = serialDate6.toString();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(11, serialDate6);
//        boolean boolean10 = spreadsheetDate1.isOnOrAfter(serialDate9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        boolean boolean18 = fixedMillisecond16.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond16.getFirstMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond16.getTime();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
//        int int25 = day24.getDayOfMonth();
//        int int27 = day24.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate28 = day24.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate31);
//        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate37 = serialDate28.getEndOfCurrentMonth(serialDate34);
//        boolean boolean38 = spreadsheetDate12.isOnOrBefore(serialDate37);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int41 = spreadsheetDate40.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate43.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean47 = spreadsheetDate12.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, serialDate43, (int) ' ');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int50 = spreadsheetDate49.getDayOfWeek();
//        boolean boolean51 = spreadsheetDate12.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate56);
//        org.jfree.data.time.SerialDate serialDate59 = serialDate57.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate61 = serialDate59.getNearestDayOfWeek(7);
//        boolean boolean62 = spreadsheetDate53.isAfter(serialDate61);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date64 = fixedMillisecond63.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond(date64);
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(date64);
//        java.lang.String str67 = serialDate66.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int70 = spreadsheetDate69.getDayOfWeek();
//        boolean boolean71 = spreadsheetDate53.isInRange(serialDate66, (org.jfree.data.time.SerialDate) spreadsheetDate69);
//        boolean boolean72 = spreadsheetDate12.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate53);
//        boolean boolean73 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date75 = fixedMillisecond74.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond(date75);
//        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.createInstance(date75);
//        boolean boolean78 = spreadsheetDate12.isOn(serialDate77);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190947038L + "'", long20 == 1560190947038L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 3 + "'", int41 == 3);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 3 + "'", int50 == 3);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "10-June-2019" + "'", str67.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 3 + "'", int70 == 3);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        int int5 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries17.removeChangeListener(seriesChangeListener21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        int int25 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        timeSeries17.setMaximumItemCount((int) '4');
        timeSeries17.setMaximumItemCount(100);
        int int30 = timeSeries17.getMaximumItemCount();
        java.lang.Class<?> wildcardClass31 = timeSeries17.getClass();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2147483647, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass31);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, (java.lang.Class) wildcardClass31);
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(class34);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test332");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener11);
//        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        long long15 = month14.getSerialIndex();
//        java.lang.Number number16 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month14);
//        java.lang.Class class17 = timeSeries7.getTimePeriodClass();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date20 = fixedMillisecond19.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
//        boolean boolean23 = fixedMillisecond21.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond21.getFirstMillisecond(calendar24);
//        java.util.Date date26 = fixedMillisecond21.getTime();
//        java.util.TimeZone timeZone27 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date26, timeZone27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date26);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date26);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date26);
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day31);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener33);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNull(class13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNull(class17);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560190947849L + "'", long25 == 1560190947849L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(9, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "September" + "'", str2.equals("September"));
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test334");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        java.lang.Object obj10 = timeSeries7.clone();
//        boolean boolean11 = timeSeries7.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date13 = fixedMillisecond12.getTime();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond12.getMiddleMillisecond(calendar14);
//        long long16 = fixedMillisecond12.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond17.getLastMillisecond(calendar18);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond17.getMiddleMillisecond(calendar20);
//        boolean boolean22 = fixedMillisecond12.equals((java.lang.Object) fixedMillisecond17);
//        int int23 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond17.previous();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560190947933L + "'", long15 == 1560190947933L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560190947933L + "'", long16 == 1560190947933L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560190947934L + "'", long19 == 1560190947934L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560190947934L + "'", long21 == 1560190947934L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
//        long long4 = month3.getLastMillisecond();
//        int int5 = month3.getMonth();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
//        boolean boolean11 = fixedMillisecond9.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond9.getFirstMillisecond(calendar12);
//        java.util.Date date14 = fixedMillisecond9.getTime();
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date14, timeZone15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14);
//        int int18 = day17.getMonth();
//        boolean boolean19 = month3.equals((java.lang.Object) day17);
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = month3.getFirstMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560190947994L + "'", long13 == 1560190947994L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560190855309L);
        java.util.Date date4 = fixedMillisecond0.getTime();
        java.lang.Class class5 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 1560190855309L);
        java.util.Date date10 = fixedMillisecond6.getTime();
        java.lang.Class class11 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date10, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date4, timeZone15);
        java.util.Calendar calendar19 = null;
        try {
            day18.peg(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNull(regularTimePeriod17);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test337");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        int int28 = spreadsheetDate1.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate31);
//        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getNearestDayOfWeek(7);
//        boolean boolean37 = spreadsheetDate1.isOnOrAfter(serialDate34);
//        int int38 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date41 = fixedMillisecond40.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(date41);
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date41);
//        java.lang.String str44 = serialDate43.toString();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(serialDate43);
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addYears(11, serialDate43);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate51);
//        org.jfree.data.time.SerialDate serialDate54 = serialDate52.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate56 = serialDate54.getNearestDayOfWeek(7);
//        boolean boolean57 = spreadsheetDate48.isAfter(serialDate56);
//        java.lang.String str58 = serialDate56.getDescription();
//        boolean boolean60 = spreadsheetDate1.isInRange(serialDate43, serialDate56, (-459));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190948017L + "'", long9 == 1560190948017L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "10-June-2019" + "'", str44.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNull(str58);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test338");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        long long12 = day11.getSerialIndex();
//        int int13 = day11.getYear();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190948499L + "'", long7 == 1560190948499L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number25 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, number25);
        int int28 = timeSeriesDataItem26.compareTo((java.lang.Object) '4');
        int int29 = month23.compareTo((java.lang.Object) '4');
        long long30 = month23.getLastMillisecond();
        java.lang.Class class31 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date33 = fixedMillisecond32.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date33, timeZone35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date33);
        int int38 = month23.compareTo((java.lang.Object) date33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month23.previous();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1561964399999L + "'", long30 == 1561964399999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test340");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
//        java.lang.Class class3 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date5 = fixedMillisecond4.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
//        boolean boolean8 = fixedMillisecond6.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond6.getFirstMillisecond(calendar9);
//        java.util.Date date11 = fixedMillisecond6.getTime();
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date11, timeZone12);
//        java.lang.Class<?> wildcardClass14 = date11.getClass();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date11);
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date11, timeZone16);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date1, timeZone16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date20 = fixedMillisecond19.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 1560190855309L);
//        java.util.Date date23 = fixedMillisecond19.getTime();
//        java.lang.Class class24 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date26);
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date26, timeZone28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number31 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, number31);
//        java.lang.Object obj33 = timeSeriesDataItem32.clone();
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem32, "June 2019", "June 2019", class36);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries37.removeChangeListener(seriesChangeListener38);
//        java.util.Collection collection40 = timeSeries37.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
//        timeSeries37.removeChangeListener(seriesChangeListener41);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        long long44 = year43.getFirstMillisecond();
//        int int45 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) year43);
//        timeSeries37.setMaximumItemCount((int) '4');
//        timeSeries37.setMaximumItemCount(100);
//        int int50 = timeSeries37.getMaximumItemCount();
//        java.lang.Class<?> wildcardClass51 = timeSeries37.getClass();
//        java.lang.Class class52 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date54 = fixedMillisecond53.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond(date54);
//        boolean boolean57 = fixedMillisecond55.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar58 = null;
//        long long59 = fixedMillisecond55.getFirstMillisecond(calendar58);
//        java.util.Date date60 = fixedMillisecond55.getTime();
//        java.util.TimeZone timeZone61 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date60, timeZone61);
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date60, timeZone63);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date26, timeZone63);
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date23, timeZone63);
//        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month(date1, timeZone63);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560190948683L + "'", long10 == 1560190948683L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(obj33);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1546329600000L + "'", long44 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 100 + "'", int50 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560190948694L + "'", long59 == 1560190948694L);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertNull(regularTimePeriod64);
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        long long12 = day11.getFirstMillisecond();
//        java.util.Date date13 = day11.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190949571L + "'", long7 == 1560190949571L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date13);
//    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test342");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date8);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190949612L + "'", long7 == 1560190949612L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month7.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test344");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number40 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, number40);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond39.getLastMillisecond(calendar42);
//        long long44 = fixedMillisecond39.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number46 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, number46);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond45.getLastMillisecond(calendar48);
//        long long50 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
//        long long52 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond45.previous();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190949664L + "'", long32 == 1560190949664L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190949664L + "'", long34 == 1560190949664L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560190949665L + "'", long43 == 1560190949665L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560190949665L + "'", long44 == 1560190949665L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560190949666L + "'", long49 == 1560190949666L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560190949666L + "'", long50 == 1560190949666L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560190949666L + "'", long52 == 1560190949666L);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test345");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        timeSeries7.fireSeriesChanged();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
//        long long27 = day26.getFirstMillisecond();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number30);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem31, "June 2019", "June 2019", class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries36.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (byte) -1);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) year50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) year50);
//        long long55 = day26.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day26.next();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190949790L + "'", long22 == 1560190949790L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560150000000L + "'", long55 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//    }
//}

