import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) 'a', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-1), (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.util.Calendar calendar2 = null;
        try {
            month0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month8, (double) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries7.getDataItem(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2958465, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number14 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, number14);
        int int17 = timeSeriesDataItem15.compareTo((java.lang.Object) '4');
        try {
            timeSeries7.add(timeSeriesDataItem15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.lang.String str3 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(11, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6, (int) (short) 0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        try {
            java.lang.Number number14 = timeSeries7.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number9 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, number9);
        java.lang.Object obj11 = timeSeriesDataItem10.clone();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem10, "June 2019", "June 2019", class14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries15.removeChangeListener(seriesChangeListener16);
        java.util.Collection collection18 = timeSeries15.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries15.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getFirstMillisecond();
        int int23 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year21, (double) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone4);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ', (int) (short) -1, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (35) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries7.setMaximumItemCount((int) '4');
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number19 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, number19);
        java.lang.Object obj21 = timeSeriesDataItem20.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        int int23 = timeSeriesDataItem20.compareTo((java.lang.Object) fixedMillisecond22);
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) 12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(11);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2958465, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test085");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        long long5 = fixedMillisecond0.getMiddleMillisecond();
//        long long6 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190855348L + "'", long4 == 1560190855348L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560190855348L + "'", long5 == 1560190855348L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190855348L + "'", long6 == 1560190855348L);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(5, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        java.util.Calendar calendar4 = null;
        try {
            month3.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date17 = fixedMillisecond16.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) (byte) -1);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
        boolean boolean24 = fixedMillisecond18.equals((java.lang.Object) year21);
        java.util.Calendar calendar25 = null;
        try {
            year21.peg(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day11.getFirstMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190857533L + "'", long7 == 1560190857533L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 1900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number9 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, number9);
//        java.lang.Object obj11 = timeSeriesDataItem10.clone();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem10, "June 2019", "June 2019", class14);
//        timeSeries15.removeAgedItems(true);
//        timeSeries15.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries15.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number23 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, number23);
//        java.lang.Object obj25 = timeSeriesDataItem24.clone();
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem24, "June 2019", "June 2019", class28);
//        timeSeries29.removeAgedItems(true);
//        timeSeries29.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries29.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number37 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, number37);
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond36.getMiddleMillisecond(calendar39);
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond36.getMiddleMillisecond(calendar41);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) 8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number48 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, number48);
//        java.util.Calendar calendar50 = null;
//        long long51 = fixedMillisecond47.getLastMillisecond(calendar50);
//        long long52 = fixedMillisecond47.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number54 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, number54);
//        java.util.Calendar calendar56 = null;
//        long long57 = fixedMillisecond53.getLastMillisecond(calendar56);
//        long long58 = fixedMillisecond53.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond53);
//        try {
//            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (java.lang.Number) 10, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertNotNull(obj25);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560190857643L + "'", long40 == 1560190857643L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560190857643L + "'", long42 == 1560190857643L);
//        org.junit.Assert.assertNull(timeSeriesDataItem44);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560190857645L + "'", long51 == 1560190857645L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560190857645L + "'", long52 == 1560190857645L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560190857652L + "'", long57 == 1560190857652L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560190857652L + "'", long58 == 1560190857652L);
//        org.junit.Assert.assertNotNull(timeSeries59);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        long long24 = month23.getSerialIndex();
        boolean boolean26 = month23.equals((java.lang.Object) 10);
        long long27 = month23.getFirstMillisecond();
        org.jfree.data.time.Year year28 = month23.getYear();
        try {
            timeSeries17.add((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 24234L + "'", long24 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
        org.junit.Assert.assertNotNull(year28);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
        try {
            java.lang.Number number15 = timeSeries7.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNull(class13);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        int int2 = month0.getYearValue();
        int int3 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        int int12 = timeSeries7.getMaximumItemCount();
        int int13 = timeSeries7.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries14 = null;
        try {
            java.util.Collection collection15 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int3 = month0.compareTo((java.lang.Object) 1.0d);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond14.getMiddleMillisecond(calendar17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond14.getMiddleMillisecond(calendar19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1546329600000L);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.previous();
//        java.lang.Number number26 = timeSeries7.getValue(regularTimePeriod25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date28 = fixedMillisecond27.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
//        boolean boolean31 = fixedMillisecond29.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond29.getFirstMillisecond(calendar32);
//        try {
//            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (double) 1560190854715L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560190858519L + "'", long18 == 1560190858519L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190858519L + "'", long20 == 1560190858519L);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1.5463296E12d + "'", number26.equals(1.5463296E12d));
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560190858521L + "'", long33 == 1560190858521L);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560190855309L);
        java.lang.Object obj4 = timeSeriesDataItem3.clone();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Wed Dec 31 15:59:59 PST 1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        java.lang.String str5 = month0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (short) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        java.util.Date date6 = month0.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (byte) 10, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'day' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getMonth();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day11.getLastMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190859399L + "'", long7 == 1560190859399L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getSerialIndex();
        java.lang.Number number16 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month14);
        long long17 = month14.getLastMillisecond();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = month14.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getSerialIndex();
        java.lang.Number number16 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month14);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
        org.junit.Assert.assertNull(number16);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Wed Dec 31 15:59:59 PST 1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        java.lang.String str8 = timeSeries7.getDescription();
        timeSeries7.setNotify(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number12 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, number12);
        java.lang.Object obj14 = timeSeriesDataItem13.clone();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem13, "June 2019", "June 2019", class17);
        timeSeriesDataItem13.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number22 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, number22);
        java.lang.Object obj24 = timeSeriesDataItem23.clone();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem23, "June 2019", "June 2019", class27);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries28.removeChangeListener(seriesChangeListener29);
        java.util.Collection collection31 = timeSeries28.getTimePeriods();
        java.lang.Comparable comparable32 = timeSeries28.getKey();
        boolean boolean33 = timeSeriesDataItem13.equals((java.lang.Object) timeSeries28);
        try {
            timeSeries7.add(timeSeriesDataItem13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(comparable32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries7.setMaximumItemCount((int) '4');
        timeSeries7.setMaximumItemCount(100);
        int int20 = timeSeries7.getMaximumItemCount();
        java.lang.Class<?> wildcardClass21 = timeSeries7.getClass();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
        try {
            timeSeries7.add(regularTimePeriod23, (java.lang.Number) 11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeries7.removeAgedItems(true);
        timeSeries7.setMaximumItemCount(100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number13 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number13);
        timeSeriesDataItem14.setValue((java.lang.Number) (short) -1);
        java.lang.Object obj17 = timeSeriesDataItem14.clone();
        try {
            timeSeries7.add(timeSeriesDataItem14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9999, 2147483647, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        boolean boolean14 = day11.equals((java.lang.Object) 1560190856010L);
//        java.util.Calendar calendar15 = null;
//        try {
//            day11.peg(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190860048L + "'", long7 == 1560190860048L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number4 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, number4);
        java.lang.Object obj6 = timeSeriesDataItem5.clone();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem5, "June 2019", "June 2019", class9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.removeChangeListener(seriesChangeListener11);
        java.util.Collection collection13 = timeSeries10.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries10.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getFirstMillisecond();
        int int18 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        int int19 = year16.getYear();
        java.lang.Class<?> wildcardClass20 = year16.getClass();
        try {
            org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries(comparable0, "org.jfree.data.general.SeriesException: ", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        java.lang.String str12 = timeSeries7.getDomainDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries7.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(comparable11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        int int12 = timeSeries7.getMaximumItemCount();
        int int13 = timeSeries7.getItemCount();
        try {
            timeSeries7.delete(5, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries7.getTimePeriod(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond14.getMiddleMillisecond(calendar17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond14.getMiddleMillisecond(calendar19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1546329600000L);
//        try {
//            java.lang.Number number24 = timeSeries7.getValue((int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560190860772L + "'", long18 == 1560190860772L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190860772L + "'", long20 == 1560190860772L);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        java.util.Collection collection11 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries7.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number17 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, number17);
        java.lang.Object obj19 = timeSeriesDataItem18.clone();
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem18, "June 2019", "June 2019", class22);
        timeSeries23.removeAgedItems(true);
        timeSeries23.setKey((java.lang.Comparable) (byte) -1);
        boolean boolean28 = month14.equals((java.lang.Object) (byte) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month14.next();
        try {
            timeSeries7.update((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 2019L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        boolean boolean4 = year0.equals((java.lang.Object) 1560190852108L);
        int int6 = year0.compareTo((java.lang.Object) 1560190855204L);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getMonth();
//        java.util.Calendar calendar13 = null;
//        try {
//            day11.peg(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190861363L + "'", long7 == 1560190861363L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, number8);
//        timeSeriesDataItem9.setValue((java.lang.Number) (short) -1);
//        boolean boolean12 = fixedMillisecond0.equals((java.lang.Object) timeSeriesDataItem9);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "SerialDate.weekInMonthToString(): invalid code.", "Wed Dec 31 15:59:59 PST 1969", class15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        int int18 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) month17);
//        java.lang.Comparable comparable19 = null;
//        try {
//            timeSeries16.setKey(comparable19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190861381L + "'", long4 == 1560190861381L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190861381L + "'", long6 == 1560190861381L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        java.util.Collection collection11 = timeSeries7.getTimePeriods();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
//        boolean boolean17 = fixedMillisecond15.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getFirstMillisecond(calendar18);
//        java.util.Date date20 = fixedMillisecond15.getTime();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date20, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20);
//        int int24 = day23.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 2);
//        java.util.Calendar calendar27 = null;
//        try {
//            long long28 = day23.getLastMillisecond(calendar27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560190861519L + "'", long19 == 1560190861519L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        boolean boolean6 = fixedMillisecond4.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond4.getFirstMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond4.getTime();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date9, timeZone10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date9);
//        int int13 = day12.getDayOfMonth();
//        int int15 = day12.compareTo((java.lang.Object) 1560190851150L);
//        java.lang.Object obj16 = null;
//        boolean boolean17 = day12.equals(obj16);
//        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(10, serialDate18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560190861567L + "'", long8 == 1560190861567L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(serialDate18);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        java.util.Calendar calendar16 = null;
        try {
            year13.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str3.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(9);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "September" + "'", str1.equals("September"));
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getFirstMillisecond();
//        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) (byte) -1);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date23 = fixedMillisecond22.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        boolean boolean26 = fixedMillisecond24.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond24.getFirstMillisecond(calendar27);
//        java.util.Date date29 = fixedMillisecond24.getTime();
//        java.util.TimeZone timeZone30 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date29, timeZone30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date29);
//        int int33 = day32.getDayOfMonth();
//        try {
//            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) 1560190861596L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560190861802L + "'", long28 == 1560190861802L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        int int5 = month0.getMonth();
        long long6 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        try {
            java.lang.Number number17 = timeSeries7.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        timeSeriesDataItem2.setValue((java.lang.Number) (short) -1);
//        timeSeriesDataItem2.setValue((java.lang.Number) (short) 1);
//        int int8 = timeSeriesDataItem2.compareTo((java.lang.Object) 10L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond11.getFirstMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond11.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1560190857893L);
//        boolean boolean19 = timeSeriesDataItem2.equals((java.lang.Object) 1560190857893L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560190862012L + "'", long15 == 1560190862012L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
//        java.lang.Object obj13 = timeSeriesDataItem12.clone();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries17.removeChangeListener(seriesChangeListener18);
//        java.util.Collection collection20 = timeSeries17.getTimePeriods();
//        java.lang.Comparable comparable21 = timeSeries17.getKey();
//        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
//        boolean boolean23 = timeSeries17.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number25 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, number25);
//        java.lang.Object obj27 = timeSeriesDataItem26.clone();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem26, "June 2019", "June 2019", class30);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries31.removeChangeListener(seriesChangeListener32);
//        java.lang.String str34 = timeSeries31.getDescription();
//        boolean boolean35 = timeSeries31.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number37 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, number37);
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond36.getLastMillisecond(calendar39);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
//        try {
//            timeSeries17.setKey((java.lang.Comparable) timeSeriesDataItem41);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertNotNull(comparable21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(obj27);
//        org.junit.Assert.assertNull(str34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560190862057L + "'", long40 == 1560190862057L);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        java.util.Collection collection11 = timeSeries7.getTimePeriods();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
//        boolean boolean17 = fixedMillisecond15.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getFirstMillisecond(calendar18);
//        java.util.Date date20 = fixedMillisecond15.getTime();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date20, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20);
//        int int24 = day23.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 2);
//        long long27 = day23.getFirstMillisecond();
//        java.util.Calendar calendar28 = null;
//        try {
//            long long29 = day23.getLastMillisecond(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560190862096L + "'", long19 == 1560190862096L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        boolean boolean4 = fixedMillisecond2.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond2.getFirstMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond2.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) 1560190857893L);
//        java.lang.Object obj10 = null;
//        int int11 = timeSeriesDataItem9.compareTo(obj10);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190862121L + "'", long6 == 1560190862121L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        boolean boolean4 = fixedMillisecond2.equals((java.lang.Object) 0L);
//        long long5 = fixedMillisecond2.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560190862158L + "'", long5 == 1560190862158L);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        int int14 = day11.compareTo((java.lang.Object) 1560190851150L);
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day11.equals(obj15);
//        org.jfree.data.time.SerialDate serialDate17 = day11.getSerialDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate19 = serialDate17.getPreviousDayOfWeek((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190862172L + "'", long7 == 1560190862172L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(serialDate17);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond28.getLastMillisecond(calendar39);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190862253L + "'", long32 == 1560190862253L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190862253L + "'", long34 == 1560190862253L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560190862253L + "'", long40 == 1560190862253L);
//    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        int int14 = day11.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year15.previous();
//        int int19 = day11.compareTo((java.lang.Object) year15);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190862324L + "'", long7 == 1560190862324L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries7.setMaximumItemCount((int) '4');
        timeSeries7.setMaximumItemCount(100);
        int int20 = timeSeries7.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number22 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, number22);
        timeSeriesDataItem23.setValue((java.lang.Number) (short) -1);
        timeSeriesDataItem23.setValue((java.lang.Number) (short) 1);
        int int29 = timeSeriesDataItem23.compareTo((java.lang.Object) 10L);
        try {
            timeSeries7.add(timeSeriesDataItem23, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        long long7 = month6.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getMiddleMillisecond();
//        java.lang.Number number16 = null;
//        try {
//            timeSeries7.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number16);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560190862954L + "'", long15 == 1560190862954L);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        int int12 = timeSeries7.getMaximumItemCount();
        int int13 = timeSeries7.getItemCount();
        int int14 = timeSeries7.getMaximumItemCount();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        int int13 = day11.getYear();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190863637L + "'", long7 == 1560190863637L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries17.addChangeListener(seriesChangeListener23);
        java.lang.String str25 = timeSeries17.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number27 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, number27);
        java.lang.Object obj29 = timeSeriesDataItem28.clone();
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem28, "June 2019", "June 2019", class32);
        timeSeriesDataItem28.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number37 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, number37);
        java.lang.Object obj39 = timeSeriesDataItem38.clone();
        java.lang.Class class42 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem38, "June 2019", "June 2019", class42);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener44 = null;
        timeSeries43.removeChangeListener(seriesChangeListener44);
        java.util.Collection collection46 = timeSeries43.getTimePeriods();
        java.lang.Comparable comparable47 = timeSeries43.getKey();
        boolean boolean48 = timeSeriesDataItem28.equals((java.lang.Object) timeSeries43);
        org.jfree.data.general.SeriesException seriesException50 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray51 = seriesException50.getSuppressed();
        int int52 = timeSeriesDataItem28.compareTo((java.lang.Object) seriesException50);
        try {
            timeSeries17.add(timeSeriesDataItem28, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(collection46);
        org.junit.Assert.assertNotNull(comparable47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries7.setMaximumItemCount((int) '4');
        timeSeries7.setMaximumItemCount(100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number21 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, number21);
        java.lang.Object obj23 = timeSeriesDataItem22.clone();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem22, "June 2019", "June 2019", class26);
        java.lang.Number number28 = timeSeriesDataItem22.getValue();
        try {
            timeSeries7.add(timeSeriesDataItem22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(number28);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
//        java.lang.Object obj13 = timeSeriesDataItem12.clone();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries17.removeChangeListener(seriesChangeListener18);
//        java.util.Collection collection20 = timeSeries17.getTimePeriods();
//        java.lang.Comparable comparable21 = timeSeries17.getKey();
//        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
//        boolean boolean23 = timeSeries17.isEmpty();
//        long long24 = timeSeries17.getMaximumItemAge();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date26);
//        boolean boolean29 = fixedMillisecond27.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond27.getFirstMillisecond(calendar30);
//        try {
//            timeSeries17.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 1560190856010L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertNotNull(comparable21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560190864325L + "'", long31 == 1560190864325L);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date17 = fixedMillisecond16.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) (byte) -1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number22 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, number22);
        int int25 = timeSeriesDataItem23.compareTo((java.lang.Object) '4');
        int int27 = timeSeriesDataItem23.compareTo((java.lang.Object) 1);
        try {
            timeSeries7.add(timeSeriesDataItem23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        boolean boolean5 = year1.equals((java.lang.Object) 1560190852108L);
        long long6 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(10, year1);
        java.util.Calendar calendar8 = null;
        try {
            month7.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        boolean boolean23 = timeSeries17.isEmpty();
        try {
            timeSeries17.removeAgedItems((long) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2147483647);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        try {
            timeSeries1.add(regularTimePeriod2, (java.lang.Number) 1560190853705L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        java.lang.String str12 = timeSeries7.getDescription();
        timeSeries7.removeAgedItems(true);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(comparable11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeries7.removeAgedItems(true);
        timeSeries7.setMaximumItemCount(100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
        java.lang.Number number13 = null;
        try {
            timeSeries7.add(regularTimePeriod12, number13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        int int5 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries17.removeChangeListener(seriesChangeListener21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        int int25 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        timeSeries17.setMaximumItemCount((int) '4');
        timeSeries17.setMaximumItemCount(100);
        int int30 = timeSeries17.getMaximumItemCount();
        java.lang.Class<?> wildcardClass31 = timeSeries17.getClass();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2147483647, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass31);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, (java.lang.Class) wildcardClass31);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number36 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, number36);
        int int39 = timeSeriesDataItem37.compareTo((java.lang.Object) '4');
        int int40 = month34.compareTo((java.lang.Object) '4');
        long long41 = month34.getLastMillisecond();
        int int42 = month34.getYearValue();
        try {
            timeSeries33.add((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) 9, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeries.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1561964399999L + "'", long41 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(11);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate2);
        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek(3);
        try {
            org.jfree.data.time.SerialDate serialDate7 = serialDate3.getPreviousDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeries7.removeAgedItems(true);
        java.lang.Object obj10 = timeSeries7.clone();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries7.getDataItem(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj10);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date11 = fixedMillisecond10.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
//        boolean boolean14 = fixedMillisecond12.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond12.getFirstMillisecond(calendar15);
//        java.lang.Number number17 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        timeSeries7.setNotify(false);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date22 = fixedMillisecond21.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(date22);
//        boolean boolean25 = fixedMillisecond23.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond23.getFirstMillisecond(calendar26);
//        java.util.Date date28 = fixedMillisecond23.getTime();
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date28, timeZone29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date28);
//        long long32 = day31.getFirstMillisecond();
//        int int33 = day31.getYear();
//        try {
//            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day31, (double) 1L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560190867088L + "'", long16 == 1560190867088L);
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560190867090L + "'", long27 == 1560190867090L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560150000000L + "'", long32 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        java.lang.String str12 = timeSeries7.getDomainDescription();
        java.util.List list13 = timeSeries7.getItems();
        boolean boolean14 = timeSeries7.getNotify();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.getDataItem((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(comparable11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        java.lang.String str12 = timeSeries7.getDomainDescription();
        timeSeries7.setRangeDescription("");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.getDataItem(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(comparable11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "June 2019" + "'", str12.equals("June 2019"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(7, 7, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        long long3 = month2.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Saturday" + "'", str1.equals("Saturday"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458) + "'", int1 == (-458));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        int int14 = day11.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate15 = day11.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate18);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate24 = serialDate15.getEndOfCurrentMonth(serialDate21);
//        try {
//            org.jfree.data.time.SerialDate serialDate26 = serialDate15.getNearestDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190867897L + "'", long7 == 1560190867897L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 0, (-1), (-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(11);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate2);
        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek(3);
        try {
            org.jfree.data.time.SerialDate serialDate7 = serialDate3.getFollowingDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond14.getMiddleMillisecond(calendar17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond14.getMiddleMillisecond(calendar19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1546329600000L);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.previous();
//        java.lang.Number number26 = timeSeries7.getValue(regularTimePeriod25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number28 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, number28);
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond27.getMiddleMillisecond(calendar30);
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond27.getMiddleMillisecond(calendar32);
//        try {
//            timeSeries7.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (java.lang.Number) 1560190861417L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560190867992L + "'", long18 == 1560190867992L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190867992L + "'", long20 == 1560190867992L);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1.5463296E12d + "'", number26.equals(1.5463296E12d));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560190867994L + "'", long31 == 1560190867994L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560190867994L + "'", long33 == 1560190867994L);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Preceding" + "'", str1.equals("Preceding"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        timeSeries7.delete(regularTimePeriod15);
        int int17 = timeSeries7.getItemCount();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560190862689L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(12, 4, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (short) -1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(9999);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1964 + "'", int1 == 1964);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        boolean boolean5 = year1.equals((java.lang.Object) 1560190852108L);
        long long6 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(10, year1);
        int int8 = month7.getYearValue();
        long long9 = month7.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1572591599999L + "'", long9 == 1572591599999L);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        long long7 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190870561L + "'", long4 == 1560190870561L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190870561L + "'", long6 == 1560190870561L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190870561L + "'", long7 == 1560190870561L);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date17 = fixedMillisecond16.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) (byte) -1);
        timeSeries7.setDescription("");
        try {
            timeSeries7.delete((int) (short) 100, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        timeSeries7.delete(regularTimePeriod15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = null;
        try {
            timeSeries7.delete(regularTimePeriod17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.util.Calendar calendar4 = null;
        try {
            month0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month6.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("ERROR : Relative To String");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, number3);
        java.lang.Object obj5 = timeSeriesDataItem4.clone();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem4, "June 2019", "June 2019", class8);
        timeSeries9.removeAgedItems(true);
        timeSeries9.setKey((java.lang.Comparable) (byte) -1);
        boolean boolean14 = month0.equals((java.lang.Object) (byte) -1);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = month0.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        java.util.Collection collection11 = timeSeries7.getTimePeriods();
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        long long14 = month13.getSerialIndex();
        boolean boolean16 = month13.equals((java.lang.Object) 10);
        long long17 = month13.getFirstMillisecond();
        int int18 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month13.previous();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month13, (double) 1560190865047L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24234L + "'", long14 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        int int16 = year13.getYear();
        java.lang.Class<?> wildcardClass17 = year13.getClass();
        int int18 = year13.getYear();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("September");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        int int5 = timeSeriesDataItem2.compareTo((java.lang.Object) fixedMillisecond4);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190865839L);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190866096L);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries7.setMaximumItemCount((int) '4');
        java.lang.String str18 = timeSeries7.getRangeDescription();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date2);
        long long9 = year8.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(11);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate4);
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getFollowingDayOfWeek(3);
        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(7);
        boolean boolean10 = spreadsheetDate1.isAfter(serialDate9);
        try {
            org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate1.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        java.util.Date date13 = day11.getEnd();
//        long long14 = day11.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190873342L + "'", long7 == 1560190873342L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560150000000L + "'", long14 == 1560150000000L);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        java.lang.Object obj8 = null;
        boolean boolean9 = month6.equals(obj8);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
//        java.lang.String str5 = serialDate4.toString();
//        try {
//            org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) 'a', serialDate4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10-June-2019" + "'", str5.equals("10-June-2019"));
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.lang.Comparable comparable0 = null;
        java.lang.Class class1 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date3, timeZone5);
        java.lang.Class<?> wildcardClass7 = date3.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        try {
            org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries(comparable0, (java.lang.Class) wildcardClass7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, number8);
//        timeSeriesDataItem9.setValue((java.lang.Number) (short) -1);
//        boolean boolean12 = fixedMillisecond0.equals((java.lang.Object) timeSeriesDataItem9);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "SerialDate.weekInMonthToString(): invalid code.", "Wed Dec 31 15:59:59 PST 1969", class15);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(9999, (-458));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190873441L + "'", long4 == 1560190873441L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190873441L + "'", long6 == 1560190873441L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray25 = seriesException24.getSuppressed();
        int int26 = timeSeriesDataItem2.compareTo((java.lang.Object) seriesException24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("SerialDate.weekInMonthToString(): invalid code.");
        seriesException24.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        org.jfree.data.general.SeriesException seriesException31 = new org.jfree.data.general.SeriesException("June 2019");
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) seriesException31);
        java.lang.String str33 = seriesException31.toString();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.general.SeriesException: June 2019" + "'", str33.equals("org.jfree.data.general.SeriesException: June 2019"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458) + "'", int1 == (-458));
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        long long12 = day11.getFirstMillisecond();
//        java.util.Date date13 = day11.getStart();
//        java.util.TimeZone timeZone14 = null;
//        try {
//            org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date13, timeZone14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190873791L + "'", long7 == 1560190873791L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date13);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number9 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, number9);
        java.lang.Object obj11 = timeSeriesDataItem10.clone();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem10, "June 2019", "June 2019", class14);
        java.lang.Number number16 = timeSeriesDataItem10.getValue();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        long long18 = month17.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, number20);
        java.lang.Object obj22 = timeSeriesDataItem21.clone();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem21, "June 2019", "June 2019", class25);
        timeSeries26.removeAgedItems(true);
        timeSeries26.setKey((java.lang.Comparable) (byte) -1);
        boolean boolean31 = month17.equals((java.lang.Object) (byte) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month17.next();
        int int33 = timeSeriesDataItem10.compareTo((java.lang.Object) month17);
        try {
            timeSeries7.add(timeSeriesDataItem10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 24234L + "'", long18 == 24234L);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        java.util.Date date13 = day11.getEnd();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190875289L + "'", long7 == 1560190875289L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(serialDate14);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        boolean boolean4 = year0.equals((java.lang.Object) 1560190852108L);
        long long5 = year0.getFirstMillisecond();
        java.lang.String str6 = year0.toString();
        java.util.Date date7 = year0.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate30);
//        org.jfree.data.time.SerialDate serialDate33 = serialDate31.getFollowingDayOfWeek(3);
//        boolean boolean34 = spreadsheetDate1.isOn(serialDate31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number36 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, number36);
//        try {
//            int int38 = spreadsheetDate1.compareTo((java.lang.Object) fixedMillisecond35);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.FixedMillisecond cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190875401L + "'", long9 == 1560190875401L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        timeSeries7.fireSeriesChanged();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
//        long long27 = day26.getFirstMillisecond();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number30);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem31, "June 2019", "June 2019", class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries36.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (byte) -1);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) year50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) year50);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries54.getDataItem(1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190875491L + "'", long22 == 1560190875491L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeries7.removeAgedItems(true);
        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
        timeSeries7.setRangeDescription("2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number15 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
        java.lang.Object obj17 = timeSeriesDataItem16.clone();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.removeChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries21.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries21.removeChangeListener(seriesChangeListener25);
        java.lang.Class class27 = timeSeries21.getTimePeriodClass();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        long long29 = month28.getSerialIndex();
        java.lang.Number number30 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) month28);
        long long31 = month28.getLastMillisecond();
        int int32 = month28.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, (double) 1560190859873L);
        try {
            timeSeries7.add(timeSeriesDataItem34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 24234L + "'", long29 == 24234L);
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1561964399999L + "'", long31 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        java.beans.PropertyChangeListener propertyChangeListener39 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener39);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date42 = fixedMillisecond41.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
//        boolean boolean45 = fixedMillisecond43.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond43.getFirstMillisecond(calendar46);
//        java.util.Date date48 = fixedMillisecond43.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (java.lang.Number) 1560190857893L);
//        try {
//            timeSeries7.add(timeSeriesDataItem50, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190875545L + "'", long32 == 1560190875545L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190875545L + "'", long34 == 1560190875545L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560190875546L + "'", long47 == 1560190875546L);
//        org.junit.Assert.assertNotNull(date48);
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeries7.getNextTimePeriod();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190875591L + "'", long32 == 1560190875591L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190875591L + "'", long34 == 1560190875591L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        int int14 = day11.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate15 = day11.getSerialDate();
//        int int16 = day11.getMonth();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        java.lang.String str18 = month17.toString();
//        java.lang.String str19 = month17.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month17.next();
//        boolean boolean21 = day11.equals((java.lang.Object) month17);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190876325L + "'", long7 == 1560190876325L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June 2019" + "'", str18.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        int int14 = day11.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate15 = day11.getSerialDate();
//        long long16 = day11.getSerialIndex();
//        long long17 = day11.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190876545L + "'", long7 == 1560190876545L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560190855309L);
        java.util.Date date4 = fixedMillisecond0.getTime();
        java.util.Calendar calendar5 = null;
        fixedMillisecond0.peg(calendar5);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeries7.removeAgedItems(true);
        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
        boolean boolean12 = timeSeries7.isEmpty();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond14.getMiddleMillisecond(calendar17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond14.getMiddleMillisecond(calendar19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1546329600000L);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.previous();
//        java.lang.Number number26 = timeSeries7.getValue(regularTimePeriod25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number28 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, number28);
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond27.getMiddleMillisecond(calendar30);
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond27.getMiddleMillisecond(calendar32);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number35 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, number35);
//        timeSeriesDataItem36.setValue((java.lang.Number) (short) -1);
//        boolean boolean39 = fixedMillisecond27.equals((java.lang.Object) timeSeriesDataItem36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = timeSeriesDataItem36.getPeriod();
//        try {
//            timeSeries7.add(regularTimePeriod40, (java.lang.Number) 1560190855139L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560190876666L + "'", long18 == 1560190876666L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190876666L + "'", long20 == 1560190876666L);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1.5463296E12d + "'", number26.equals(1.5463296E12d));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560190876669L + "'", long31 == 1560190876669L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560190876669L + "'", long33 == 1560190876669L);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries7.setMaximumItemCount((int) '4');
        java.lang.Class class18 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, number20);
        java.lang.Object obj22 = timeSeriesDataItem21.clone();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem21, "June 2019", "June 2019", class25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries26.removeChangeListener(seriesChangeListener27);
        java.util.Collection collection29 = timeSeries26.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries26.removeChangeListener(seriesChangeListener30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getFirstMillisecond();
        int int34 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date36 = fixedMillisecond35.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (double) (byte) -1);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year40.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year40.previous();
        boolean boolean43 = fixedMillisecond37.equals((java.lang.Object) year40);
        boolean boolean44 = timeSeries7.equals((java.lang.Object) fixedMillisecond37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number46 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, number46);
        java.lang.Object obj48 = timeSeriesDataItem47.clone();
        java.lang.Class class51 = null;
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem47, "June 2019", "June 2019", class51);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
        timeSeries52.removeChangeListener(seriesChangeListener53);
        java.util.Collection collection55 = timeSeries52.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener56 = null;
        timeSeries52.removeChangeListener(seriesChangeListener56);
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        long long59 = year58.getFirstMillisecond();
        int int60 = timeSeries52.getIndex((org.jfree.data.time.RegularTimePeriod) year58);
        int int61 = year58.getYear();
        try {
            timeSeries7.update((org.jfree.data.time.RegularTimePeriod) year58, (java.lang.Number) 9);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNotNull(collection55);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1546329600000L + "'", long59 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2019 + "'", int61 == 2019);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries7.getTimePeriod((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Saturday");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number40 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, number40);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond39.getLastMillisecond(calendar42);
//        long long44 = fixedMillisecond39.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number46 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, number46);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond45.getLastMillisecond(calendar48);
//        long long50 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
//        long long52 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(9999);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date56 = fixedMillisecond55.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond(date56);
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance(date56);
//        java.lang.String str59 = serialDate58.toString();
//        boolean boolean60 = spreadsheetDate54.equals((java.lang.Object) serialDate58);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(serialDate58);
//        int int62 = fixedMillisecond45.compareTo((java.lang.Object) serialDate58);
//        java.lang.String str63 = serialDate58.toString();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190877300L + "'", long32 == 1560190877300L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190877300L + "'", long34 == 1560190877300L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560190877301L + "'", long43 == 1560190877301L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560190877301L + "'", long44 == 1560190877301L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560190877301L + "'", long49 == 1560190877301L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560190877301L + "'", long50 == 1560190877301L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560190877301L + "'", long52 == 1560190877301L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "10-June-2019" + "'", str59.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "10-June-2019" + "'", str63.equals("10-June-2019"));
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code." + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 1, 9, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        java.util.Collection collection11 = timeSeries7.getTimePeriods();
        int int12 = timeSeries7.getMaximumItemCount();
        java.lang.String str13 = timeSeries7.getDescription();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertNull(str13);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate5);
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getNearestDayOfWeek(7);
//        boolean boolean11 = spreadsheetDate2.isAfter(serialDate10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date13 = fixedMillisecond12.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date13);
//        java.lang.String str16 = serialDate15.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int19 = spreadsheetDate18.getDayOfWeek();
//        boolean boolean20 = spreadsheetDate2.isInRange(serialDate15, (org.jfree.data.time.SerialDate) spreadsheetDate18);
//        int int21 = spreadsheetDate18.toSerial();
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10-June-2019" + "'", str16.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9999 + "'", int21 == 9999);
//        org.junit.Assert.assertNotNull(serialDate22);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        int int12 = timeSeries7.getMaximumItemCount();
        try {
            timeSeries7.delete(0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        long long15 = month14.getSerialIndex();
        java.lang.Number number16 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month14);
        long long17 = month14.getFirstMillisecond();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
        org.junit.Assert.assertNull(number16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        timeSeriesDataItem2.setValue((java.lang.Number) (short) -1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number6 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, number6);
//        java.lang.Object obj8 = timeSeriesDataItem7.clone();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem7, "June 2019", "June 2019", class11);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries12.removeChangeListener(seriesChangeListener13);
//        java.util.Collection collection15 = timeSeries12.getTimePeriods();
//        java.util.Collection collection16 = timeSeries12.getTimePeriods();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date19 = fixedMillisecond18.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
//        boolean boolean22 = fixedMillisecond20.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond20.getFirstMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond20.getTime();
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date25, timeZone26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date25);
//        int int29 = day28.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day28, (double) 2);
//        boolean boolean32 = timeSeriesDataItem2.equals((java.lang.Object) 2);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560190878820L + "'", long24 == 1560190878820L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        long long12 = day11.getFirstMillisecond();
//        java.util.Date date13 = day11.getStart();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190878912L + "'", long7 == 1560190878912L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(serialDate14);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, number3);
        java.lang.Object obj5 = timeSeriesDataItem4.clone();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem4, "June 2019", "June 2019", class8);
        timeSeries9.removeAgedItems(true);
        timeSeries9.setKey((java.lang.Comparable) (byte) -1);
        boolean boolean14 = month0.equals((java.lang.Object) (byte) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month0.next();
        java.util.Calendar calendar16 = null;
        try {
            month0.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries7.setMaximumItemCount((int) '4');
        java.lang.Class class18 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, number20);
        java.lang.Object obj22 = timeSeriesDataItem21.clone();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem21, "June 2019", "June 2019", class25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries26.removeChangeListener(seriesChangeListener27);
        java.util.Collection collection29 = timeSeries26.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries26.removeChangeListener(seriesChangeListener30);
        java.util.Collection collection32 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries26);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries26.removeChangeListener(seriesChangeListener33);
        try {
            java.lang.Number number36 = timeSeries26.getValue(1964);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1964, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertNotNull(collection32);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.lang.String str7 = serialDate6.toString();
//        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) serialDate6);
//        try {
//            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 10, serialDate6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        int int3 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date1);
//        java.lang.String str4 = serialDate3.toString();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day5.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int2 = spreadsheetDate1.getDayOfWeek();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number4 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, number4);
//        java.lang.Object obj6 = timeSeriesDataItem5.clone();
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem5, "June 2019", "June 2019", class9);
//        timeSeries10.removeAgedItems(true);
//        timeSeries10.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries10.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number18 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, number18);
//        java.lang.Object obj20 = timeSeriesDataItem19.clone();
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem19, "June 2019", "June 2019", class23);
//        timeSeries24.removeAgedItems(true);
//        timeSeries24.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries24.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number32 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, number32);
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond31.getMiddleMillisecond(calendar34);
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond31.getMiddleMillisecond(calendar36);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number43 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, number43);
//        java.util.Calendar calendar45 = null;
//        long long46 = fixedMillisecond42.getLastMillisecond(calendar45);
//        long long47 = fixedMillisecond42.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number49 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, number49);
//        java.util.Calendar calendar51 = null;
//        long long52 = fixedMillisecond48.getLastMillisecond(calendar51);
//        long long53 = fixedMillisecond48.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
//        long long55 = fixedMillisecond48.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(9999);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date59 = fixedMillisecond58.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond(date59);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(date59);
//        java.lang.String str62 = serialDate61.toString();
//        boolean boolean63 = spreadsheetDate57.equals((java.lang.Object) serialDate61);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(serialDate61);
//        int int65 = fixedMillisecond48.compareTo((java.lang.Object) serialDate61);
//        boolean boolean66 = spreadsheetDate1.isAfter(serialDate61);
//        int int67 = spreadsheetDate1.getYYYY();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertNotNull(obj20);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560190880726L + "'", long35 == 1560190880726L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560190880726L + "'", long37 == 1560190880726L);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560190880727L + "'", long46 == 1560190880727L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560190880727L + "'", long47 == 1560190880727L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560190880728L + "'", long52 == 1560190880728L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560190880728L + "'", long53 == 1560190880728L);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560190880728L + "'", long55 == 1560190880728L);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "10-June-2019" + "'", str62.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1927 + "'", int67 == 1927);
//    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = day11.getLastMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190880912L + "'", long7 == 1560190880912L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Second" + "'", str1.equals("Second"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 10, (int) (byte) 0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        long long8 = month6.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond14.getMiddleMillisecond(calendar17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond14.getMiddleMillisecond(calendar19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1546329600000L);
//        try {
//            timeSeries7.update(9, (java.lang.Number) 1560190873808L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560190881225L + "'", long18 == 1560190881225L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190881225L + "'", long20 == 1560190881225L);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        java.lang.Object obj10 = timeSeriesDataItem2.clone();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("September");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date17 = fixedMillisecond16.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) (byte) -1);
        timeSeries7.setDescription("");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries7.getDataItem(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
//        java.lang.String str6 = serialDate5.toString();
//        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) serialDate5);
//        try {
//            org.jfree.data.time.SerialDate serialDate9 = serialDate5.getFollowingDayOfWeek(2147483647);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries7.setMaximumItemCount((int) '4');
        java.lang.Class class18 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, number20);
        java.lang.Object obj22 = timeSeriesDataItem21.clone();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem21, "June 2019", "June 2019", class25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries26.removeChangeListener(seriesChangeListener27);
        java.util.Collection collection29 = timeSeries26.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries26.removeChangeListener(seriesChangeListener30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getFirstMillisecond();
        int int34 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date36 = fixedMillisecond35.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (double) (byte) -1);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year40.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year40.previous();
        boolean boolean43 = fixedMillisecond37.equals((java.lang.Object) year40);
        boolean boolean44 = timeSeries7.equals((java.lang.Object) fixedMillisecond37);
        timeSeries7.removeAgedItems(false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeries7.removeAgedItems(true);
        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
        timeSeries7.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate(regularTimePeriod14, (double) 1560190862971L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
        java.util.List list2 = timeSeries1.getItems();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-458));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-571) + "'", int1 == (-571));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeries7.removeAgedItems(true);
        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
        timeSeries7.setRangeDescription("2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number15 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
        java.lang.Object obj17 = timeSeriesDataItem16.clone();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.removeChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries21.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries21.removeChangeListener(seriesChangeListener25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getFirstMillisecond();
        int int29 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) year27);
        timeSeries21.setMaximumItemCount((int) '4');
        timeSeries21.setMaximumItemCount(100);
        int int34 = timeSeries21.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries7.addAndOrUpdate(timeSeries21);
        int int36 = timeSeries35.getMaximumItemCount();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2147483647 + "'", int36 == 2147483647);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        java.lang.Number number23 = timeSeriesDataItem2.getValue();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 1560190852108L + "'", number23.equals(1560190852108L));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        java.lang.Class class23 = timeSeries17.getTimePeriodClass();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        long long25 = month24.getSerialIndex();
        long long26 = month24.getSerialIndex();
        try {
            timeSeries17.add((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 1560190871961L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 24234L + "'", long26 == 24234L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, (int) (byte) 100, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        boolean boolean4 = year0.equals((java.lang.Object) 1560190852108L);
        long long5 = year0.getFirstMillisecond();
        java.lang.String str6 = year0.toString();
        long long7 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        boolean boolean4 = fixedMillisecond2.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond2.getFirstMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond2.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) 1560190857893L);
//        java.lang.Object obj10 = null;
//        int int11 = fixedMillisecond2.compareTo(obj10);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190882087L + "'", long6 == 1560190882087L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2147483647);
        timeSeries1.setDomainDescription("ERROR : Relative To String");
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        int int28 = spreadsheetDate1.getDayOfWeek();
//        try {
//            org.jfree.data.time.SerialDate serialDate30 = spreadsheetDate1.getFollowingDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190882754L + "'", long9 == 1560190882754L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 7 + "'", int28 == 7);
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        timeSeries7.fireSeriesChanged();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
//        long long27 = day26.getFirstMillisecond();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number30);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem31, "June 2019", "June 2019", class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries36.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (byte) -1);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) year50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) year50);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date56 = fixedMillisecond55.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond(date56);
//        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(date56);
//        int int59 = month58.getYearValue();
//        try {
//            timeSeries54.add((org.jfree.data.time.RegularTimePeriod) month58, (double) 1560190876699L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190882857L + "'", long22 == 1560190882857L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "May" + "'", str1.equals("May"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560190881743L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(11);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getFollowingDayOfWeek(3);
        org.jfree.data.time.SerialDate serialDate11 = serialDate9.getNearestDayOfWeek(7);
        int int12 = timeSeriesDataItem2.compareTo((java.lang.Object) 7);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number40 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, number40);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond39.getLastMillisecond(calendar42);
//        long long44 = fixedMillisecond39.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number46 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, number46);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond45.getLastMillisecond(calendar48);
//        long long50 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
//        long long52 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(9999);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date56 = fixedMillisecond55.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond(date56);
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance(date56);
//        java.lang.String str59 = serialDate58.toString();
//        boolean boolean60 = spreadsheetDate54.equals((java.lang.Object) serialDate58);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(serialDate58);
//        int int62 = fixedMillisecond45.compareTo((java.lang.Object) serialDate58);
//        long long63 = fixedMillisecond45.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190883307L + "'", long32 == 1560190883307L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190883307L + "'", long34 == 1560190883307L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560190883309L + "'", long43 == 1560190883309L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560190883309L + "'", long44 == 1560190883309L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560190883309L + "'", long49 == 1560190883309L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560190883309L + "'", long50 == 1560190883309L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560190883309L + "'", long52 == 1560190883309L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "10-June-2019" + "'", str59.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560190883309L + "'", long63 == 1560190883309L);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        boolean boolean6 = fixedMillisecond4.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond4.getFirstMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond4.getTime();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date9, timeZone10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date9);
//        int int13 = day12.getDayOfMonth();
//        int int15 = day12.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate16 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate19);
//        org.jfree.data.time.SerialDate serialDate22 = serialDate20.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate16.getEndOfCurrentMonth(serialDate22);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date28 = fixedMillisecond27.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
//        boolean boolean31 = fixedMillisecond29.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond29.getFirstMillisecond(calendar32);
//        java.util.Date date34 = fixedMillisecond29.getTime();
//        java.util.TimeZone timeZone35 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date34, timeZone35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date34);
//        int int38 = day37.getDayOfMonth();
//        int int40 = day37.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate41 = day37.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate44);
//        org.jfree.data.time.SerialDate serialDate47 = serialDate45.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate49 = serialDate47.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate50 = serialDate41.getEndOfCurrentMonth(serialDate47);
//        org.jfree.data.time.SerialDate serialDate51 = serialDate22.getEndOfCurrentMonth(serialDate41);
//        try {
//            org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(11, serialDate51);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560190883927L + "'", long8 == 1560190883927L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560190883930L + "'", long33 == 1560190883930L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(serialDate51);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (double) 1560190855309L);
        try {
            timeSeries1.add(timeSeriesDataItem5);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getFirstMillisecond();
//        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) (byte) -1);
//        long long21 = fixedMillisecond18.getLastMillisecond();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = fixedMillisecond18.equals(obj22);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560190885216L + "'", long21 == 1560190885216L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number13 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number13);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "June 2019", "June 2019", class18);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        java.util.Collection collection22 = timeSeries19.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries19.removeChangeListener(seriesChangeListener23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        int int27 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
        timeSeries19.setMaximumItemCount((int) '4');
        timeSeries19.setMaximumItemCount(100);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries7.addAndOrUpdate(timeSeries19);
        boolean boolean33 = timeSeries7.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries34 = null;
        try {
            java.util.Collection collection35 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate4);
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(7);
//        boolean boolean10 = spreadsheetDate1.isAfter(serialDate9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.lang.String str15 = serialDate14.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int18 = spreadsheetDate17.getDayOfWeek();
//        boolean boolean19 = spreadsheetDate1.isInRange(serialDate14, (org.jfree.data.time.SerialDate) spreadsheetDate17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date21 = fixedMillisecond20.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date21);
//        java.lang.String str24 = serialDate23.toString();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate23);
//        boolean boolean26 = spreadsheetDate1.isOnOrBefore(serialDate23);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year27.previous();
//        try {
//            int int31 = spreadsheetDate1.compareTo((java.lang.Object) regularTimePeriod30);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Year cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10-June-2019" + "'", str24.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        timeSeriesDataItem2.setValue((java.lang.Number) (short) -1);
        timeSeriesDataItem2.setValue((java.lang.Number) (short) 1);
        int int8 = timeSeriesDataItem2.compareTo((java.lang.Object) 10L);
        timeSeriesDataItem2.setValue((java.lang.Number) (byte) 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries17.addChangeListener(seriesChangeListener23);
        timeSeries17.setDomainDescription("June 2019");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeries17.getTimePeriod((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        timeSeries7.fireSeriesChanged();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
//        long long27 = day26.getFirstMillisecond();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number30);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem31, "June 2019", "June 2019", class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries36.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (byte) -1);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) year50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) year50);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number56 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, number56);
//        java.lang.Object obj58 = timeSeriesDataItem57.clone();
//        java.lang.Class class61 = null;
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem57, "June 2019", "June 2019", class61);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener63 = null;
//        timeSeries62.removeChangeListener(seriesChangeListener63);
//        java.lang.String str65 = timeSeries62.getDescription();
//        boolean boolean66 = timeSeries62.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number68 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67, number68);
//        java.util.Calendar calendar70 = null;
//        long long71 = fixedMillisecond67.getLastMillisecond(calendar70);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries62.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67);
//        timeSeries62.setKey((java.lang.Comparable) false);
//        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries54.addAndOrUpdate(timeSeries62);
//        try {
//            java.lang.Number number77 = timeSeries54.getValue(2147483647);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190885452L + "'", long22 == 1560190885452L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(obj58);
//        org.junit.Assert.assertNull(str65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560190885458L + "'", long71 == 1560190885458L);
//        org.junit.Assert.assertNull(timeSeriesDataItem72);
//        org.junit.Assert.assertNotNull(timeSeries75);
//    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener11);
//        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
//        timeSeries7.setMaximumItemCount(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getLastMillisecond(calendar21);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 1560190855139L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number26 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number26);
//        java.lang.Object obj28 = timeSeriesDataItem27.clone();
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem27, "June 2019", "June 2019", class31);
//        timeSeries32.removeAgedItems(true);
//        timeSeries32.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries32.setRangeDescription("2019");
//        timeSeries32.fireSeriesChanged();
//        java.lang.Class class40 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date42 = fixedMillisecond41.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
//        boolean boolean45 = fixedMillisecond43.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond43.getFirstMillisecond(calendar46);
//        java.util.Date date48 = fixedMillisecond43.getTime();
//        java.util.TimeZone timeZone49 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date48, timeZone49);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date48);
//        long long52 = day51.getFirstMillisecond();
//        java.util.Date date53 = day51.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number55 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number55);
//        java.lang.Object obj57 = timeSeriesDataItem56.clone();
//        java.lang.Class class60 = null;
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem56, "June 2019", "June 2019", class60);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener62 = null;
//        timeSeries61.removeChangeListener(seriesChangeListener62);
//        java.util.Collection collection64 = timeSeries61.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener65 = null;
//        timeSeries61.removeChangeListener(seriesChangeListener65);
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
//        long long68 = year67.getFirstMillisecond();
//        int int69 = timeSeries61.getIndex((org.jfree.data.time.RegularTimePeriod) year67);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date71 = fixedMillisecond70.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond(date71);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond72, (double) (byte) -1);
//        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year75.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = year75.previous();
//        boolean boolean78 = fixedMillisecond72.equals((java.lang.Object) year75);
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) day51, (org.jfree.data.time.RegularTimePeriod) year75);
//        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month();
//        long long81 = month80.getSerialIndex();
//        boolean boolean83 = month80.equals((java.lang.Object) 10);
//        long long84 = month80.getFirstMillisecond();
//        int int85 = month80.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = month80.previous();
//        timeSeries32.setKey((java.lang.Comparable) regularTimePeriod86);
//        int int88 = fixedMillisecond18.compareTo((java.lang.Object) timeSeries32);
//        java.beans.PropertyChangeListener propertyChangeListener89 = null;
//        timeSeries32.addPropertyChangeListener(propertyChangeListener89);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNull(class13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190885477L + "'", long22 == 1560190885477L);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560190885484L + "'", long47 == 1560190885484L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560150000000L + "'", long52 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(obj57);
//        org.junit.Assert.assertNotNull(collection64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1546329600000L + "'", long68 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNull(timeSeriesDataItem74);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(timeSeries79);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 24234L + "'", long81 == 24234L);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1559372400000L + "'", long84 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 6 + "'", int85 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod86);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.String str2 = month0.toString();
        int int3 = month0.getMonth();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date17 = fixedMillisecond16.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) (byte) -1);
        timeSeries7.setDescription("");
        java.lang.Class class23 = timeSeries7.getTimePeriodClass();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNull(class23);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("June 2019");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: June 2019" + "'", str2.equals("org.jfree.data.general.SeriesException: June 2019"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        java.util.Collection collection11 = timeSeries7.getTimePeriods();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
//        boolean boolean17 = fixedMillisecond15.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getFirstMillisecond(calendar18);
//        java.util.Date date20 = fixedMillisecond15.getTime();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date20, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date20);
//        int int24 = day23.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day23.previous();
//        long long28 = day23.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560190887041L + "'", long19 == 1560190887041L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560150000000L + "'", long28 == 1560150000000L);
//    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        long long12 = day11.getFirstMillisecond();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        boolean boolean18 = fixedMillisecond16.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond16.getFirstMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond16.getTime();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date21);
//        boolean boolean26 = day11.equals((java.lang.Object) year25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year25.previous();
//        long long28 = year25.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190887113L + "'", long7 == 1560190887113L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190887114L + "'", long20 == 1560190887114L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(10);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((-571));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560190857893L);
        long long2 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560190857893L + "'", long2 == 1560190857893L);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        boolean boolean6 = fixedMillisecond4.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond4.getFirstMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond4.getTime();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date9, timeZone10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date9);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date9);
//        long long14 = year13.getFirstMillisecond();
//        try {
//            org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(2958465, year13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560190887781L + "'", long8 == 1560190887781L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
//    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
//        java.lang.Object obj13 = timeSeriesDataItem12.clone();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries17.removeChangeListener(seriesChangeListener18);
//        java.util.Collection collection20 = timeSeries17.getTimePeriods();
//        java.lang.Comparable comparable21 = timeSeries17.getKey();
//        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
//        java.lang.Class class23 = timeSeries17.getTimePeriodClass();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number28 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, number28);
//        java.lang.Object obj30 = timeSeriesDataItem29.clone();
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem29, "June 2019", "June 2019", class33);
//        timeSeries34.removeAgedItems(true);
//        timeSeries34.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries34.setRangeDescription("2019");
//        timeSeries34.fireSeriesChanged();
//        java.lang.Class class42 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date44 = fixedMillisecond43.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(date44);
//        boolean boolean47 = fixedMillisecond45.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond45.getFirstMillisecond(calendar48);
//        java.util.Date date50 = fixedMillisecond45.getTime();
//        java.util.TimeZone timeZone51 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date50, timeZone51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date50);
//        long long54 = day53.getFirstMillisecond();
//        java.util.Date date55 = day53.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number57 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, number57);
//        java.lang.Object obj59 = timeSeriesDataItem58.clone();
//        java.lang.Class class62 = null;
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem58, "June 2019", "June 2019", class62);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener64 = null;
//        timeSeries63.removeChangeListener(seriesChangeListener64);
//        java.util.Collection collection66 = timeSeries63.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener67 = null;
//        timeSeries63.removeChangeListener(seriesChangeListener67);
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
//        long long70 = year69.getFirstMillisecond();
//        int int71 = timeSeries63.getIndex((org.jfree.data.time.RegularTimePeriod) year69);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date73 = fixedMillisecond72.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond(date73);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries63.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond74, (double) (byte) -1);
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = year77.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = year77.previous();
//        boolean boolean80 = fixedMillisecond74.equals((java.lang.Object) year77);
//        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day53, (org.jfree.data.time.RegularTimePeriod) year77);
//        org.jfree.data.time.Month month82 = new org.jfree.data.time.Month();
//        long long83 = month82.getSerialIndex();
//        boolean boolean85 = month82.equals((java.lang.Object) 10);
//        long long86 = month82.getFirstMillisecond();
//        int int87 = month82.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = month82.previous();
//        timeSeries34.setKey((java.lang.Comparable) regularTimePeriod88);
//        java.beans.PropertyChangeListener propertyChangeListener90 = null;
//        timeSeries34.addPropertyChangeListener(propertyChangeListener90);
//        boolean boolean92 = year24.equals((java.lang.Object) propertyChangeListener90);
//        java.lang.Number number93 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) year24);
//        long long94 = year24.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertNotNull(comparable21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNull(class23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(obj30);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560190887878L + "'", long49 == 1560190887878L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560150000000L + "'", long54 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(obj59);
//        org.junit.Assert.assertNotNull(collection66);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1546329600000L + "'", long70 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNull(timeSeriesDataItem76);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(timeSeries81);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 24234L + "'", long83 == 24234L);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 1559372400000L + "'", long86 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 6 + "'", int87 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
//        org.junit.Assert.assertNull(number93);
//        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 1546329600000L + "'", long94 == 1546329600000L);
//    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener11);
//        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
//        timeSeries7.setMaximumItemCount(10);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
//        boolean boolean21 = fixedMillisecond19.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond19.getFirstMillisecond(calendar22);
//        java.util.Date date24 = fixedMillisecond19.getTime();
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date24, timeZone25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date24);
//        long long28 = day27.getFirstMillisecond();
//        int int29 = day27.getYear();
//        int int30 = day27.getDayOfMonth();
//        try {
//            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day27, (double) 1964);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNull(class13);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560190888454L + "'", long23 == 1560190888454L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560150000000L + "'", long28 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) 'a');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(11);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-January-1900" + "'", str4.equals("10-January-1900"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (11) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries7.getDescription();
        boolean boolean11 = timeSeries7.getNotify();
        java.lang.String str12 = timeSeries7.getDescription();
        timeSeries7.setDomainDescription("Wed Dec 31 15:59:59 PST 1969");
        int int15 = timeSeries7.getItemCount();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        int int5 = timeSeriesDataItem2.compareTo((java.lang.Object) fixedMillisecond4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem2.getPeriod();
        java.lang.Number number7 = timeSeriesDataItem2.getValue();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("June 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number2 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number2);
        int int5 = timeSeriesDataItem3.compareTo((java.lang.Object) '4');
        int int6 = month0.compareTo((java.lang.Object) '4');
        long long7 = month0.getLastMillisecond();
        long long8 = month0.getSerialIndex();
        int int9 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24234L + "'", long8 == 24234L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, number8);
//        timeSeriesDataItem9.setValue((java.lang.Number) (short) -1);
//        boolean boolean12 = fixedMillisecond0.equals((java.lang.Object) timeSeriesDataItem9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 8);
//        java.lang.Object obj15 = null;
//        int int16 = timeSeriesDataItem14.compareTo(obj15);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190889882L + "'", long4 == 1560190889882L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190889882L + "'", long6 == 1560190889882L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.previous();
        boolean boolean6 = year2.equals((java.lang.Object) 1560190852108L);
        long long7 = year2.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year2.next();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(9, year2);
        java.lang.Object obj11 = null;
        int int12 = year2.compareTo(obj11);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        java.lang.Class<?> wildcardClass11 = date8.getClass();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date8);
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date8, timeZone13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date8);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190890163L + "'", long7 == 1560190890163L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(timeZone13);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries7.addChangeListener(seriesChangeListener12);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int2 = spreadsheetDate1.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class5 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
//        boolean boolean10 = fixedMillisecond8.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond8.getFirstMillisecond(calendar11);
//        java.util.Date date13 = fixedMillisecond8.getTime();
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date13, timeZone14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date13);
//        int int17 = day16.getDayOfMonth();
//        int int19 = day16.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate20 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate23);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate24.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate28 = serialDate26.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate29 = serialDate20.getEndOfCurrentMonth(serialDate26);
//        boolean boolean30 = spreadsheetDate4.isOnOrBefore(serialDate29);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int33 = spreadsheetDate32.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate35.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean39 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, serialDate35, (int) ' ');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int42 = spreadsheetDate41.getDayOfWeek();
//        boolean boolean43 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        boolean boolean44 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class48 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date50 = fixedMillisecond49.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond(date50);
//        boolean boolean53 = fixedMillisecond51.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar54 = null;
//        long long55 = fixedMillisecond51.getFirstMillisecond(calendar54);
//        java.util.Date date56 = fixedMillisecond51.getTime();
//        java.util.TimeZone timeZone57 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date56, timeZone57);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date56);
//        int int60 = day59.getDayOfMonth();
//        int int62 = day59.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate63 = day59.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate66);
//        org.jfree.data.time.SerialDate serialDate69 = serialDate67.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate71 = serialDate69.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate72 = serialDate63.getEndOfCurrentMonth(serialDate69);
//        boolean boolean73 = spreadsheetDate47.isOnOrBefore(serialDate72);
//        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.addMonths(7, serialDate72);
//        boolean boolean75 = spreadsheetDate1.isOnOrAfter(serialDate72);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560190890273L + "'", long12 == 1560190890273L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3 + "'", int33 == 3);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 3 + "'", int42 == 3);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560190890289L + "'", long55 == 1560190890289L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertNotNull(serialDate71);
//        org.junit.Assert.assertNotNull(serialDate72);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod3, (java.lang.Number) 1.5463296E12d);
        java.lang.Object obj6 = timeSeriesDataItem5.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number8 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, number8);
        java.lang.Object obj10 = timeSeriesDataItem9.clone();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem9, "June 2019", "June 2019", class13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.removeChangeListener(seriesChangeListener15);
        timeSeries14.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, number20);
        java.lang.Object obj22 = timeSeriesDataItem21.clone();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem21, "June 2019", "June 2019", class25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries26.removeChangeListener(seriesChangeListener27);
        java.util.Collection collection29 = timeSeries26.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries26.removeChangeListener(seriesChangeListener30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getFirstMillisecond();
        int int34 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        timeSeries26.setMaximumItemCount((int) '4');
        timeSeries26.setMaximumItemCount(100);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries14.addAndOrUpdate(timeSeries26);
        int int40 = timeSeriesDataItem5.compareTo((java.lang.Object) timeSeries39);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        int int14 = day11.compareTo((java.lang.Object) 1560190851150L);
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day11.equals(obj15);
//        org.jfree.data.time.SerialDate serialDate17 = day11.getSerialDate();
//        long long18 = day11.getSerialIndex();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date21 = fixedMillisecond20.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date21, timeZone23);
//        java.lang.Class<?> wildcardClass25 = date21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long18, (java.lang.Class) wildcardClass25);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries26.getDataItem(3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190890942L + "'", long7 == 1560190890942L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number13 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number13);
//        java.lang.Object obj15 = timeSeriesDataItem14.clone();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "June 2019", "June 2019", class18);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries19.removeChangeListener(seriesChangeListener20);
//        java.util.Collection collection22 = timeSeries19.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries19.removeChangeListener(seriesChangeListener23);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        long long26 = year25.getFirstMillisecond();
//        int int27 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
//        timeSeries19.setMaximumItemCount((int) '4');
//        timeSeries19.setMaximumItemCount(100);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries7.addAndOrUpdate(timeSeries19);
//        int int33 = timeSeries32.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date35);
//        long long37 = fixedMillisecond36.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 1560190879376L);
//        long long40 = fixedMillisecond36.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj15);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560190890971L + "'", long37 == 1560190890971L);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560190890971L + "'", long40 == 1560190890971L);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        java.util.Collection collection11 = timeSeries7.getTimePeriods();
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        try {
            timeSeries7.removeAgedItems((long) (short) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNull(class12);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2019L);
//        java.util.List list2 = timeSeries1.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number4 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, number4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getMiddleMillisecond(calendar6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond3.getMiddleMillisecond(calendar8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
//        timeSeriesDataItem12.setValue((java.lang.Number) (short) -1);
//        boolean boolean15 = fixedMillisecond3.equals((java.lang.Object) timeSeriesDataItem12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (double) 8);
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) 1560190885477L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(list2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190891130L + "'", long7 == 1560190891130L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190891130L + "'", long9 == 1560190891130L);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.time.TimePeriodFormatException: SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560190855309L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number10 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number10);
        java.lang.Object obj12 = timeSeriesDataItem11.clone();
        java.lang.Class class15 = null;
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem11, "June 2019", "June 2019", class15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries16.removeChangeListener(seriesChangeListener17);
        java.util.Collection collection19 = timeSeries16.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries16.removeChangeListener(seriesChangeListener20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getFirstMillisecond();
        int int24 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) year22);
        timeSeries16.setMaximumItemCount((int) '4');
        timeSeries16.setMaximumItemCount(100);
        int int29 = timeSeries16.getMaximumItemCount();
        java.lang.Class<?> wildcardClass30 = timeSeries16.getClass();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2147483647, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass30);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560190855309L, "", "June 2019", (java.lang.Class) wildcardClass30);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 100 + "'", int29 == 100);
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(11, (-1), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.util.Date date0 = null;
        java.lang.Class class1 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date3 = fixedMillisecond2.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (double) 1560190855309L);
        java.util.Date date6 = fixedMillisecond2.getTime();
        java.lang.Class class7 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date9, timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date6, timeZone11);
        try {
            org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date0, timeZone11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) -1, 2019, (-571));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number40 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, number40);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond39.getLastMillisecond(calendar42);
//        long long44 = fixedMillisecond39.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number46 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, number46);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond45.getLastMillisecond(calendar48);
//        long long50 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
//        java.util.Collection collection52 = timeSeries7.getTimePeriods();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190892343L + "'", long32 == 1560190892343L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190892343L + "'", long34 == 1560190892343L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560190892344L + "'", long43 == 1560190892344L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560190892344L + "'", long44 == 1560190892344L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560190892345L + "'", long49 == 1560190892345L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560190892345L + "'", long50 == 1560190892345L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNotNull(collection52);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        long long9 = year7.getSerialIndex();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("");
        int int12 = year7.compareTo((java.lang.Object) seriesException11);
        boolean boolean13 = year5.equals((java.lang.Object) seriesException11);
        java.util.Calendar calendar14 = null;
        try {
            year5.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(11);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate5);
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(3);
        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getNearestDayOfWeek(7);
        boolean boolean11 = spreadsheetDate2.isAfter(serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, serialDate10);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        java.lang.Comparable comparable11 = timeSeries7.getKey();
        int int12 = timeSeries7.getItemCount();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(comparable11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) ' ', 1927);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2);
        java.lang.String str8 = month7.toString();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month7.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        int int14 = day11.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day11.previous();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190892619L + "'", long7 == 1560190892619L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.lang.Object obj1 = null;
        boolean boolean2 = day0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        long long12 = day11.getFirstMillisecond();
//        java.util.Date date13 = day11.getStart();
//        int int14 = day11.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190893459L + "'", long7 == 1560190893459L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        timeSeries7.fireSeriesChanged();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
//        long long27 = day26.getFirstMillisecond();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number30);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem31, "June 2019", "June 2019", class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries36.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (byte) -1);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) year50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) year50);
//        long long55 = day26.getLastMillisecond();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190893489L + "'", long22 == 1560190893489L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560236399999L + "'", long55 == 1560236399999L);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number2 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number2);
        int int5 = timeSeriesDataItem3.compareTo((java.lang.Object) '4');
        int int6 = month0.compareTo((java.lang.Object) '4');
        long long7 = month0.getLastMillisecond();
        long long8 = month0.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month0.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24234L + "'", long8 == 24234L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Object obj10 = timeSeries7.clone();
        timeSeries7.setDomainDescription("2019");
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        java.lang.Number number8 = timeSeriesDataItem2.getValue();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number12 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, number12);
        java.lang.Object obj14 = timeSeriesDataItem13.clone();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem13, "June 2019", "June 2019", class17);
        timeSeries18.removeAgedItems(true);
        timeSeries18.setKey((java.lang.Comparable) (byte) -1);
        boolean boolean23 = month9.equals((java.lang.Object) (byte) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month9.next();
        int int25 = timeSeriesDataItem2.compareTo((java.lang.Object) month9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month9.previous();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24234L + "'", long10 == 24234L);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("10-June-2019");
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        timeSeries7.fireSeriesChanged();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
//        long long27 = day26.getFirstMillisecond();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number30);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem31, "June 2019", "June 2019", class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries36.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (byte) -1);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) year50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) year50);
//        java.util.Calendar calendar55 = null;
//        try {
//            day26.peg(calendar55);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190893903L + "'", long22 == 1560190893903L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        java.lang.String str2 = year0.toString();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date11 = fixedMillisecond10.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
//        boolean boolean14 = fixedMillisecond12.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond12.getFirstMillisecond(calendar15);
//        java.lang.Number number17 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond12.getLastMillisecond(calendar18);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560190893974L + "'", long16 == 1560190893974L);
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560190893974L + "'", long19 == 1560190893974L);
//    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate30);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date38 = fixedMillisecond37.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(date38);
//        boolean boolean41 = fixedMillisecond39.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond39.getFirstMillisecond(calendar42);
//        java.util.Date date44 = fixedMillisecond39.getTime();
//        java.util.TimeZone timeZone45 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date44, timeZone45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date44);
//        int int48 = day47.getDayOfMonth();
//        int int50 = day47.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate51 = day47.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate54);
//        org.jfree.data.time.SerialDate serialDate57 = serialDate55.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate59 = serialDate57.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate60 = serialDate51.getEndOfCurrentMonth(serialDate57);
//        boolean boolean61 = spreadsheetDate35.isOnOrBefore(serialDate60);
//        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addMonths(7, serialDate60);
//        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.addDays(1, serialDate62);
//        boolean boolean65 = spreadsheetDate1.isInRange(serialDate31, serialDate63, 0);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190894004L + "'", long9 == 1560190894004L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560190894018L + "'", long43 == 1560190894018L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 10 + "'", int48 == 10);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries7.getDataItem(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Second");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        boolean boolean23 = timeSeries17.isEmpty();
        int int24 = timeSeries17.getMaximumItemCount();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2147483647 + "'", int24 == 2147483647);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(1964, (int) (short) -1, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number14 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, number14);
//        java.lang.Object obj16 = timeSeriesDataItem15.clone();
//        int int17 = day11.compareTo(obj16);
//        java.util.Date date18 = day11.getStart();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190894774L + "'", long7 == 1560190894774L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(date18);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        java.lang.Number number8 = timeSeriesDataItem2.getValue();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number12 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, number12);
        java.lang.Object obj14 = timeSeriesDataItem13.clone();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem13, "June 2019", "June 2019", class17);
        timeSeries18.removeAgedItems(true);
        timeSeries18.setKey((java.lang.Comparable) (byte) -1);
        boolean boolean23 = month9.equals((java.lang.Object) (byte) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month9.next();
        int int25 = timeSeriesDataItem2.compareTo((java.lang.Object) month9);
        int int27 = month9.compareTo((java.lang.Object) 1560190860518L);
        org.jfree.data.time.Year year28 = month9.getYear();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24234L + "'", long10 == 24234L);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(year28);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 1, (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.Object obj10 = timeSeries7.clone();
        timeSeries7.setDescription("June 2019");
        try {
            timeSeries7.removeAgedItems(1560190874659L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, 0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-435) + "'", int1 == (-435));
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        boolean boolean4 = fixedMillisecond2.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond2.getFirstMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond2.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) 1560190857893L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond2.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190895249L + "'", long6 == 1560190895249L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        long long10 = month9.getSerialIndex();
        boolean boolean12 = month9.equals((java.lang.Object) 10);
        long long13 = month9.getFirstMillisecond();
        int int14 = month9.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month9.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, number20);
        java.lang.Object obj22 = timeSeriesDataItem21.clone();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem21, "June 2019", "June 2019", class25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries26.removeChangeListener(seriesChangeListener27);
        java.util.Collection collection29 = timeSeries26.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries26.removeChangeListener(seriesChangeListener30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getFirstMillisecond();
        int int34 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        timeSeries26.setMaximumItemCount((int) '4');
        timeSeries26.setMaximumItemCount(100);
        int int39 = timeSeries26.getMaximumItemCount();
        java.lang.Class<?> wildcardClass40 = timeSeries26.getClass();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2147483647, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass40);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, (java.lang.Class) wildcardClass40);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        long long44 = year43.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year43.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year43.next();
        java.lang.Number number47 = timeSeries42.getValue(regularTimePeriod46);
        try {
            timeSeries7.add(regularTimePeriod46, (java.lang.Number) 1560190872305L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24234L + "'", long10 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1559372400000L + "'", long13 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 100 + "'", int39 == 100);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1546329600000L + "'", long44 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNull(number47);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        java.lang.String str2 = month0.toString();
        int int3 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.previous();
        int int5 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray25 = seriesException24.getSuppressed();
        int int26 = timeSeriesDataItem2.compareTo((java.lang.Object) seriesException24);
        java.lang.String str27 = seriesException24.toString();
        java.lang.Throwable[] throwableArray28 = seriesException24.getSuppressed();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str27.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray28);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        java.util.Collection collection11 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries7.removeChangeListener(seriesChangeListener12);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(collection11);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, number8);
//        timeSeriesDataItem9.setValue((java.lang.Number) (short) -1);
//        boolean boolean12 = fixedMillisecond0.equals((java.lang.Object) timeSeriesDataItem9);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "SerialDate.weekInMonthToString(): invalid code.", "Wed Dec 31 15:59:59 PST 1969", class15);
//        java.lang.String str17 = timeSeries16.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number19 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, number19);
//        java.lang.Object obj21 = timeSeriesDataItem20.clone();
//        java.lang.Class class24 = null;
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem20, "June 2019", "June 2019", class24);
//        timeSeries25.removeAgedItems(true);
//        timeSeries25.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries25.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number33 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, number33);
//        java.lang.Object obj35 = timeSeriesDataItem34.clone();
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem34, "June 2019", "June 2019", class38);
//        timeSeries39.removeAgedItems(true);
//        timeSeries39.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries39.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number47 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, number47);
//        java.util.Calendar calendar49 = null;
//        long long50 = fixedMillisecond46.getMiddleMillisecond(calendar49);
//        java.util.Calendar calendar51 = null;
//        long long52 = fixedMillisecond46.getMiddleMillisecond(calendar51);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (java.lang.Number) 8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number58 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57, number58);
//        java.util.Calendar calendar60 = null;
//        long long61 = fixedMillisecond57.getLastMillisecond(calendar60);
//        long long62 = fixedMillisecond57.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number64 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, number64);
//        java.util.Calendar calendar66 = null;
//        long long67 = fixedMillisecond63.getLastMillisecond(calendar66);
//        long long68 = fixedMillisecond63.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = fixedMillisecond57.previous();
//        java.lang.Class class71 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date73 = fixedMillisecond72.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond(date73);
//        boolean boolean76 = fixedMillisecond74.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar77 = null;
//        long long78 = fixedMillisecond74.getFirstMillisecond(calendar77);
//        java.util.Date date79 = fixedMillisecond74.getTime();
//        java.util.TimeZone timeZone80 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class71, date79, timeZone80);
//        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date79);
//        int int83 = day82.getDayOfMonth();
//        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries16.createCopy(regularTimePeriod70, (org.jfree.data.time.RegularTimePeriod) day82);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond85 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date86 = fixedMillisecond85.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem88 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond85, (double) 1560190855309L);
//        java.lang.Number number89 = null;
//        try {
//            timeSeries84.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond85, number89);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190895792L + "'", long4 == 1560190895792L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190895792L + "'", long6 == 1560190895792L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertNotNull(obj35);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560190895804L + "'", long50 == 1560190895804L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560190895804L + "'", long52 == 1560190895804L);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//        org.junit.Assert.assertNull(timeSeriesDataItem56);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560190895805L + "'", long61 == 1560190895805L);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560190895805L + "'", long62 == 1560190895805L);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1560190895806L + "'", long67 == 1560190895806L);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560190895806L + "'", long68 == 1560190895806L);
//        org.junit.Assert.assertNotNull(timeSeries69);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1560190895807L + "'", long78 == 1560190895807L);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 10 + "'", int83 == 10);
//        org.junit.Assert.assertNotNull(timeSeries84);
//        org.junit.Assert.assertNotNull(date86);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        int int4 = timeSeriesDataItem2.compareTo((java.lang.Object) '4');
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        long long6 = month5.getSerialIndex();
        boolean boolean8 = month5.equals((java.lang.Object) 10);
        long long9 = month5.getFirstMillisecond();
        org.jfree.data.time.Year year10 = month5.getYear();
        int int11 = timeSeriesDataItem2.compareTo((java.lang.Object) year10);
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int11, "2019", "Saturday", class14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries15.addChangeListener(seriesChangeListener16);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray25 = seriesException24.getSuppressed();
        int int26 = timeSeriesDataItem2.compareTo((java.lang.Object) seriesException24);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("SerialDate.weekInMonthToString(): invalid code.");
        seriesException24.addSuppressed((java.lang.Throwable) timePeriodFormatException28);
        java.lang.String str30 = seriesException24.toString();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str30.equals("org.jfree.data.general.SeriesException: "));
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener11);
//        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
//        timeSeries7.setMaximumItemCount(10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getLastMillisecond(calendar21);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 1560190855139L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number26 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number26);
//        java.lang.Object obj28 = timeSeriesDataItem27.clone();
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem27, "June 2019", "June 2019", class31);
//        timeSeries32.removeAgedItems(true);
//        timeSeries32.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries32.setRangeDescription("2019");
//        timeSeries32.fireSeriesChanged();
//        java.lang.Class class40 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date42 = fixedMillisecond41.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
//        boolean boolean45 = fixedMillisecond43.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond43.getFirstMillisecond(calendar46);
//        java.util.Date date48 = fixedMillisecond43.getTime();
//        java.util.TimeZone timeZone49 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date48, timeZone49);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date48);
//        long long52 = day51.getFirstMillisecond();
//        java.util.Date date53 = day51.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number55 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number55);
//        java.lang.Object obj57 = timeSeriesDataItem56.clone();
//        java.lang.Class class60 = null;
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem56, "June 2019", "June 2019", class60);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener62 = null;
//        timeSeries61.removeChangeListener(seriesChangeListener62);
//        java.util.Collection collection64 = timeSeries61.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener65 = null;
//        timeSeries61.removeChangeListener(seriesChangeListener65);
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
//        long long68 = year67.getFirstMillisecond();
//        int int69 = timeSeries61.getIndex((org.jfree.data.time.RegularTimePeriod) year67);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date71 = fixedMillisecond70.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond(date71);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond72, (double) (byte) -1);
//        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year75.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = year75.previous();
//        boolean boolean78 = fixedMillisecond72.equals((java.lang.Object) year75);
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) day51, (org.jfree.data.time.RegularTimePeriod) year75);
//        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month();
//        long long81 = month80.getSerialIndex();
//        boolean boolean83 = month80.equals((java.lang.Object) 10);
//        long long84 = month80.getFirstMillisecond();
//        int int85 = month80.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = month80.previous();
//        timeSeries32.setKey((java.lang.Comparable) regularTimePeriod86);
//        int int88 = fixedMillisecond18.compareTo((java.lang.Object) timeSeries32);
//        java.lang.Object obj89 = null;
//        int int90 = fixedMillisecond18.compareTo(obj89);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertNull(class13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190896113L + "'", long22 == 1560190896113L);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560190896124L + "'", long47 == 1560190896124L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560150000000L + "'", long52 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(obj57);
//        org.junit.Assert.assertNotNull(collection64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1546329600000L + "'", long68 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNull(timeSeriesDataItem74);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(timeSeries79);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 24234L + "'", long81 == 24234L);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1559372400000L + "'", long84 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 6 + "'", int85 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod86);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 1 + "'", int90 == 1);
//    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getFirstMillisecond();
//        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
//        timeSeries7.setMaximumItemCount((int) '4');
//        timeSeries7.setMaximumItemCount(100);
//        int int20 = timeSeries7.getMaximumItemCount();
//        java.lang.Class<?> wildcardClass21 = timeSeries7.getClass();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date24 = fixedMillisecond23.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
//        boolean boolean27 = fixedMillisecond25.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond25.getFirstMillisecond(calendar28);
//        java.util.Date date30 = fixedMillisecond25.getTime();
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date30, timeZone31);
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date30, timeZone33);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date30);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560190896645L + "'", long29 == 1560190896645L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        timeSeries7.fireSeriesChanged();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
//        long long27 = day26.getFirstMillisecond();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number30);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem31, "June 2019", "June 2019", class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries36.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (byte) -1);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) year50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) year50);
//        long long55 = day26.getFirstMillisecond();
//        long long56 = day26.getSerialIndex();
//        long long57 = day26.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190896763L + "'", long22 == 1560190896763L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560150000000L + "'", long55 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 43626L + "'", long56 == 43626L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560193199999L + "'", long57 == 1560193199999L);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        java.lang.Class class23 = timeSeries17.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener24);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(class23);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
//        java.lang.Object obj13 = timeSeriesDataItem12.clone();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries17.removeChangeListener(seriesChangeListener18);
//        java.util.Collection collection20 = timeSeries17.getTimePeriods();
//        java.lang.Comparable comparable21 = timeSeries17.getKey();
//        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
//        java.lang.Class class23 = timeSeries17.getTimePeriodClass();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number28 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, number28);
//        java.lang.Object obj30 = timeSeriesDataItem29.clone();
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem29, "June 2019", "June 2019", class33);
//        timeSeries34.removeAgedItems(true);
//        timeSeries34.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries34.setRangeDescription("2019");
//        timeSeries34.fireSeriesChanged();
//        java.lang.Class class42 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date44 = fixedMillisecond43.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(date44);
//        boolean boolean47 = fixedMillisecond45.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond45.getFirstMillisecond(calendar48);
//        java.util.Date date50 = fixedMillisecond45.getTime();
//        java.util.TimeZone timeZone51 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date50, timeZone51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date50);
//        long long54 = day53.getFirstMillisecond();
//        java.util.Date date55 = day53.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number57 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, number57);
//        java.lang.Object obj59 = timeSeriesDataItem58.clone();
//        java.lang.Class class62 = null;
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem58, "June 2019", "June 2019", class62);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener64 = null;
//        timeSeries63.removeChangeListener(seriesChangeListener64);
//        java.util.Collection collection66 = timeSeries63.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener67 = null;
//        timeSeries63.removeChangeListener(seriesChangeListener67);
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
//        long long70 = year69.getFirstMillisecond();
//        int int71 = timeSeries63.getIndex((org.jfree.data.time.RegularTimePeriod) year69);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date73 = fixedMillisecond72.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond(date73);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries63.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond74, (double) (byte) -1);
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = year77.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = year77.previous();
//        boolean boolean80 = fixedMillisecond74.equals((java.lang.Object) year77);
//        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day53, (org.jfree.data.time.RegularTimePeriod) year77);
//        org.jfree.data.time.Month month82 = new org.jfree.data.time.Month();
//        long long83 = month82.getSerialIndex();
//        boolean boolean85 = month82.equals((java.lang.Object) 10);
//        long long86 = month82.getFirstMillisecond();
//        int int87 = month82.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = month82.previous();
//        timeSeries34.setKey((java.lang.Comparable) regularTimePeriod88);
//        java.beans.PropertyChangeListener propertyChangeListener90 = null;
//        timeSeries34.addPropertyChangeListener(propertyChangeListener90);
//        boolean boolean92 = year24.equals((java.lang.Object) propertyChangeListener90);
//        java.lang.Number number93 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) year24);
//        java.lang.String str94 = year24.toString();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertNotNull(comparable21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNull(class23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(obj30);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560190897323L + "'", long49 == 1560190897323L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560150000000L + "'", long54 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(obj59);
//        org.junit.Assert.assertNotNull(collection66);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1546329600000L + "'", long70 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNull(timeSeriesDataItem76);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(timeSeries81);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 24234L + "'", long83 == 24234L);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 1559372400000L + "'", long86 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 6 + "'", int87 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
//        org.junit.Assert.assertNull(number93);
//        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "2019" + "'", str94.equals("2019"));
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        timeSeries7.clear();
        java.lang.Comparable comparable13 = timeSeries7.getKey();
        timeSeries7.clear();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(comparable13);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries7.setMaximumItemCount((int) '4');
        java.lang.Class class18 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, number20);
        java.lang.Object obj22 = timeSeriesDataItem21.clone();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem21, "June 2019", "June 2019", class25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries26.removeChangeListener(seriesChangeListener27);
        java.util.Collection collection29 = timeSeries26.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries26.removeChangeListener(seriesChangeListener30);
        java.util.Collection collection32 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries26);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        long long34 = month33.getSerialIndex();
        boolean boolean36 = month33.equals((java.lang.Object) 10);
        long long37 = month33.getFirstMillisecond();
        int int38 = month33.getMonth();
        int int39 = month33.getYearValue();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month33);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 24234L + "'", long34 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1559372400000L + "'", long37 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        java.util.Collection collection11 = timeSeries7.getTimePeriods();
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.lang.String str15 = fixedMillisecond14.toString();
        long long16 = fixedMillisecond14.getLastMillisecond();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 1560190886149L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str15.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560190858794L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190898255L + "'", long4 == 1560190898255L);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        int int12 = timeSeries7.getMaximumItemCount();
        int int13 = timeSeries7.getItemCount();
        timeSeries7.removeAgedItems(true);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(11);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate18);
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getFollowingDayOfWeek(3);
        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getNearestDayOfWeek(7);
        boolean boolean24 = timeSeries7.equals((java.lang.Object) serialDate21);
        timeSeries7.removeAgedItems(true);
        long long27 = timeSeries7.getMaximumItemAge();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9223372036854775807L + "'", long27 == 9223372036854775807L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(1927);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        int int4 = month3.getYearValue();
        java.lang.String str5 = month3.toString();
        long long6 = month3.getFirstMillisecond();
        long long7 = month3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number13 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number13);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "June 2019", "June 2019", class18);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        java.util.Collection collection22 = timeSeries19.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries19.removeChangeListener(seriesChangeListener23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        int int27 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
        timeSeries19.setMaximumItemCount((int) '4');
        timeSeries19.setMaximumItemCount(100);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries7.addAndOrUpdate(timeSeries19);
        boolean boolean33 = timeSeries7.isEmpty();
        java.util.Collection collection34 = timeSeries7.getTimePeriods();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(collection34);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        java.lang.Comparable comparable21 = timeSeries17.getKey();
        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
        boolean boolean23 = timeSeries17.isEmpty();
        long long24 = timeSeries17.getMaximumItemAge();
        boolean boolean25 = timeSeries17.isEmpty();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries17.addOrUpdate(regularTimePeriod26, (double) 43626L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int30 = spreadsheetDate29.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate32.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean36 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, serialDate32, (int) ' ');
//        int int37 = spreadsheetDate1.getMonth();
//        int int38 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate42);
//        org.jfree.data.time.SerialDate serialDate45 = serialDate43.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate47 = serialDate45.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate45);
//        boolean boolean49 = spreadsheetDate1.isOnOrBefore(serialDate48);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190898577L + "'", long9 == 1560190898577L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate4);
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(7);
//        boolean boolean10 = spreadsheetDate1.isAfter(serialDate9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.lang.String str15 = serialDate14.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int18 = spreadsheetDate17.getDayOfWeek();
//        boolean boolean19 = spreadsheetDate1.isInRange(serialDate14, (org.jfree.data.time.SerialDate) spreadsheetDate17);
//        java.lang.String str20 = serialDate14.toString();
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10-June-2019" + "'", str20.equals("10-June-2019"));
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(9992);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1963 + "'", int1 == 1963);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        int int5 = month0.getMonth();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 2019, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.lang.Class class3 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date5 = fixedMillisecond4.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date5, timeZone7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number10 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, number10);
//        java.lang.Object obj12 = timeSeriesDataItem11.clone();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem11, "June 2019", "June 2019", class15);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries16.removeChangeListener(seriesChangeListener17);
//        java.util.Collection collection19 = timeSeries16.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries16.removeChangeListener(seriesChangeListener20);
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getFirstMillisecond();
//        int int24 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) year22);
//        timeSeries16.setMaximumItemCount((int) '4');
//        timeSeries16.setMaximumItemCount(100);
//        int int29 = timeSeries16.getMaximumItemCount();
//        java.lang.Class<?> wildcardClass30 = timeSeries16.getClass();
//        java.lang.Class class31 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        boolean boolean36 = fixedMillisecond34.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond34.getFirstMillisecond(calendar37);
//        java.util.Date date39 = fixedMillisecond34.getTime();
//        java.util.TimeZone timeZone40 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date39, timeZone40);
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date39, timeZone42);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date5, timeZone42);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date1, timeZone42);
//        java.util.Calendar calendar46 = null;
//        try {
//            long long47 = year45.getFirstMillisecond(calendar46);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 100 + "'", int29 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560190899276L + "'", long38 == 1560190899276L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Preceding");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class4 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date6 = fixedMillisecond5.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        boolean boolean9 = fixedMillisecond7.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond7.getFirstMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond7.getTime();
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date12, timeZone13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12);
//        int int16 = day15.getDayOfMonth();
//        int int18 = day15.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate19 = day15.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate22);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate27 = serialDate25.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate28 = serialDate19.getEndOfCurrentMonth(serialDate25);
//        boolean boolean29 = spreadsheetDate3.isOnOrBefore(serialDate28);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(7, serialDate28);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addDays(1, serialDate30);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = null;
//        try {
//            int int34 = timeSeries32.getIndex(regularTimePeriod33);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560190899327L + "'", long11 == 1560190899327L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (8) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries7.addChangeListener(seriesChangeListener39);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190899425L + "'", long32 == 1560190899425L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190899425L + "'", long34 == 1560190899425L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560190855309L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number5 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, number5);
        java.lang.Object obj7 = timeSeriesDataItem6.clone();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem6, "June 2019", "June 2019", class10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.removeChangeListener(seriesChangeListener12);
        java.util.Collection collection14 = timeSeries11.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries11.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        int int19 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year17);
        int int20 = year17.getYear();
        java.lang.Class<?> wildcardClass21 = year17.getClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem3, (java.lang.Class) wildcardClass21);
        java.lang.Object obj23 = timeSeries22.clone();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
        org.jfree.data.time.SerialDate serialDate2 = null;
        try {
            boolean boolean3 = spreadsheetDate1.isOnOrAfter(serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        long long4 = month3.getLastMillisecond();
        java.lang.String str5 = month3.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        int int14 = day11.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate15 = day11.getSerialDate();
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = day11.getMiddleMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190900549L + "'", long7 == 1560190900549L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(serialDate15);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries7.setMaximumItemCount((int) '4');
        java.lang.Class class18 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, number20);
        java.lang.Object obj22 = timeSeriesDataItem21.clone();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem21, "June 2019", "June 2019", class25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries26.removeChangeListener(seriesChangeListener27);
        java.util.Collection collection29 = timeSeries26.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries26.removeChangeListener(seriesChangeListener30);
        java.util.Collection collection32 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries26);
        java.lang.Class class33 = timeSeries26.getTimePeriodClass();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number36 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, number36);
        int int39 = timeSeriesDataItem37.compareTo((java.lang.Object) '4');
        int int40 = month34.compareTo((java.lang.Object) '4');
        java.lang.Number number41 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, number41);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNull(class33);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        java.util.Collection collection10 = timeSeries7.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        long long14 = year13.getFirstMillisecond();
//        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
//        timeSeries7.setMaximumItemCount((int) '4');
//        timeSeries7.setMaximumItemCount(100);
//        int int20 = timeSeries7.getMaximumItemCount();
//        java.lang.Class<?> wildcardClass21 = timeSeries7.getClass();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date24 = fixedMillisecond23.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
//        boolean boolean27 = fixedMillisecond25.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond25.getFirstMillisecond(calendar28);
//        java.util.Date date30 = fixedMillisecond25.getTime();
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date30, timeZone31);
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date30, timeZone33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date36 = fixedMillisecond35.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date38 = fixedMillisecond37.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(date38);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date42 = fixedMillisecond41.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date42, timeZone44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number47 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, number47);
//        java.lang.Object obj49 = timeSeriesDataItem48.clone();
//        java.lang.Class class52 = null;
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem48, "June 2019", "June 2019", class52);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
//        timeSeries53.removeChangeListener(seriesChangeListener54);
//        java.util.Collection collection56 = timeSeries53.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener57 = null;
//        timeSeries53.removeChangeListener(seriesChangeListener57);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
//        long long60 = year59.getFirstMillisecond();
//        int int61 = timeSeries53.getIndex((org.jfree.data.time.RegularTimePeriod) year59);
//        timeSeries53.setMaximumItemCount((int) '4');
//        timeSeries53.setMaximumItemCount(100);
//        int int66 = timeSeries53.getMaximumItemCount();
//        java.lang.Class<?> wildcardClass67 = timeSeries53.getClass();
//        java.lang.Class class68 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date70 = fixedMillisecond69.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond(date70);
//        boolean boolean73 = fixedMillisecond71.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar74 = null;
//        long long75 = fixedMillisecond71.getFirstMillisecond(calendar74);
//        java.util.Date date76 = fixedMillisecond71.getTime();
//        java.util.TimeZone timeZone77 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class68, date76, timeZone77);
//        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date76, timeZone79);
//        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year(date42, timeZone79);
//        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date38, timeZone79);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date36, timeZone79);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560190900723L + "'", long29 == 1560190900723L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(obj49);
//        org.junit.Assert.assertNotNull(collection56);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1546329600000L + "'", long60 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 100 + "'", int66 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1560190900736L + "'", long75 == 1560190900736L);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(timeZone79);
//        org.junit.Assert.assertNull(regularTimePeriod80);
//        org.junit.Assert.assertNull(regularTimePeriod83);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        boolean boolean4 = year0.equals((java.lang.Object) 1560190852108L);
        int int6 = year0.compareTo((java.lang.Object) 1560190855204L);
        java.util.Date date7 = year0.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-435), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond10.getMiddleMillisecond(calendar13);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond10.getMiddleMillisecond(calendar15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number18 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, number18);
//        timeSeriesDataItem19.setValue((java.lang.Number) (short) -1);
//        boolean boolean22 = fixedMillisecond10.equals((java.lang.Object) timeSeriesDataItem19);
//        int int23 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond10.getFirstMillisecond(calendar24);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560190901719L + "'", long14 == 1560190901719L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560190901719L + "'", long16 == 1560190901719L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560190901719L + "'", long25 == 1560190901719L);
//    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date11 = fixedMillisecond10.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
//        boolean boolean14 = fixedMillisecond12.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond12.getFirstMillisecond(calendar15);
//        java.lang.Number number17 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        long long18 = fixedMillisecond12.getSerialIndex();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560190901752L + "'", long16 == 1560190901752L);
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560190901752L + "'", long18 == 1560190901752L);
//    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number14 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, number14);
//        java.lang.Object obj16 = timeSeriesDataItem15.clone();
//        int int17 = day11.compareTo(obj16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day11.previous();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        long long20 = month19.getSerialIndex();
//        boolean boolean22 = month19.equals((java.lang.Object) 10);
//        long long23 = month19.getFirstMillisecond();
//        int int24 = month19.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month19.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number30);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem31, "June 2019", "June 2019", class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries36.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
//        timeSeries36.setMaximumItemCount((int) '4');
//        timeSeries36.setMaximumItemCount(100);
//        int int49 = timeSeries36.getMaximumItemCount();
//        java.lang.Class<?> wildcardClass50 = timeSeries36.getClass();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2147483647, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass50);
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month19, (java.lang.Class) wildcardClass50);
//        boolean boolean53 = day11.equals((java.lang.Object) month19);
//        int int54 = day11.getMonth();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190901779L + "'", long7 == 1560190901779L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 24234L + "'", long20 == 24234L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1559372400000L + "'", long23 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 100 + "'", int49 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 6 + "'", int54 == 6);
//    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        long long12 = day11.getFirstMillisecond();
//        java.util.Date date13 = day11.getStart();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = day11.getFirstMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190902021L + "'", long7 == 1560190902021L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date13);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(6, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June" + "'", str2.equals("June"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year5.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        int int14 = day11.compareTo((java.lang.Object) 1560190851150L);
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day11.equals(obj15);
//        org.jfree.data.time.SerialDate serialDate17 = day11.getSerialDate();
//        long long18 = day11.getSerialIndex();
//        long long19 = day11.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190902964L + "'", long7 == 1560190902964L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43626L + "'", long18 == 43626L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, number8);
//        timeSeriesDataItem9.setValue((java.lang.Number) (short) -1);
//        boolean boolean12 = fixedMillisecond0.equals((java.lang.Object) timeSeriesDataItem9);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "SerialDate.weekInMonthToString(): invalid code.", "Wed Dec 31 15:59:59 PST 1969", class15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        int int18 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) month17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number20 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, number20);
//        java.lang.Object obj22 = timeSeriesDataItem21.clone();
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem21, "June 2019", "June 2019", class25);
//        timeSeries26.removeAgedItems(true);
//        timeSeries26.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries26.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number34 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, number34);
//        java.lang.Object obj36 = timeSeriesDataItem35.clone();
//        java.lang.Class class39 = null;
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem35, "June 2019", "June 2019", class39);
//        timeSeries40.removeAgedItems(true);
//        timeSeries40.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries40.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number48 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, number48);
//        java.util.Calendar calendar50 = null;
//        long long51 = fixedMillisecond47.getMiddleMillisecond(calendar50);
//        java.util.Calendar calendar52 = null;
//        long long53 = fixedMillisecond47.getMiddleMillisecond(calendar52);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (java.lang.Number) 8);
//        long long58 = fixedMillisecond47.getMiddleMillisecond();
//        try {
//            timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) 1560190865047L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190902989L + "'", long4 == 1560190902989L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190902989L + "'", long6 == 1560190902989L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertNotNull(obj22);
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560190902994L + "'", long51 == 1560190902994L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560190902994L + "'", long53 == 1560190902994L);
//        org.junit.Assert.assertNull(timeSeriesDataItem55);
//        org.junit.Assert.assertNull(timeSeriesDataItem57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560190902994L + "'", long58 == 1560190902994L);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(11);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate5);
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(3);
        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getNearestDayOfWeek(7);
        boolean boolean11 = spreadsheetDate1.isBefore(serialDate8);
        spreadsheetDate1.setDescription("Preceding");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        long long3 = year0.getLastMillisecond();
        int int5 = year0.compareTo((java.lang.Object) 1560190873162L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeries7.removeAgedItems(true);
        timeSeries7.setMaximumItemCount(100);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.getDataItem(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.lang.String str2 = fixedMillisecond1.toString();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str2.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.previous();
//        java.lang.Object obj6 = null;
//        int int7 = fixedMillisecond0.compareTo(obj6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560190903183L + "'", long2 == 1560190903183L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190903183L + "'", long4 == 1560190903183L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("2019");
//        timeSeries7.fireSeriesChanged();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean20 = fixedMillisecond18.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
//        long long27 = day26.getFirstMillisecond();
//        java.util.Date date28 = day26.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, number30);
//        java.lang.Object obj32 = timeSeriesDataItem31.clone();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem31, "June 2019", "June 2019", class35);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries36.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries36.removeChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
//        long long43 = year42.getFirstMillisecond();
//        int int44 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) (byte) -1);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        boolean boolean53 = fixedMillisecond47.equals((java.lang.Object) year50);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) year50);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number56 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, number56);
//        java.lang.Object obj58 = timeSeriesDataItem57.clone();
//        java.lang.Class class61 = null;
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem57, "June 2019", "June 2019", class61);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener63 = null;
//        timeSeries62.removeChangeListener(seriesChangeListener63);
//        java.lang.String str65 = timeSeries62.getDescription();
//        boolean boolean66 = timeSeries62.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number68 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67, number68);
//        java.util.Calendar calendar70 = null;
//        long long71 = fixedMillisecond67.getLastMillisecond(calendar70);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries62.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67);
//        timeSeries62.setKey((java.lang.Comparable) false);
//        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries54.addAndOrUpdate(timeSeries62);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = null;
//        try {
//            timeSeries62.add(timeSeriesDataItem76);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560190903238L + "'", long22 == 1560190903238L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(obj58);
//        org.junit.Assert.assertNull(str65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560190903245L + "'", long71 == 1560190903245L);
//        org.junit.Assert.assertNull(timeSeriesDataItem72);
//        org.junit.Assert.assertNotNull(timeSeries75);
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        int int5 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        java.util.Collection collection20 = timeSeries17.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries17.removeChangeListener(seriesChangeListener21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        int int25 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
        timeSeries17.setMaximumItemCount((int) '4');
        timeSeries17.setMaximumItemCount(100);
        int int30 = timeSeries17.getMaximumItemCount();
        java.lang.Class<?> wildcardClass31 = timeSeries17.getClass();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2147483647, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass31);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, (java.lang.Class) wildcardClass31);
        int int34 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        int int9 = timeSeriesDataItem2.compareTo((java.lang.Object) 1561964399999L);
        java.lang.Object obj10 = timeSeriesDataItem2.clone();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(obj10);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        long long12 = day11.getFirstMillisecond();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        boolean boolean18 = fixedMillisecond16.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond16.getFirstMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond16.getTime();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date21);
//        boolean boolean26 = day11.equals((java.lang.Object) year25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year25.previous();
//        java.util.Calendar calendar28 = null;
//        try {
//            long long29 = year25.getFirstMillisecond(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190903424L + "'", long7 == 1560190903424L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190903426L + "'", long20 == 1560190903426L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
        timeSeries7.setMaximumItemCount(10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number17 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, number17);
        java.lang.Object obj19 = timeSeriesDataItem18.clone();
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem18, "June 2019", "June 2019", class22);
        java.lang.Number number24 = timeSeriesDataItem18.getValue();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        long long26 = month25.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number28 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, number28);
        java.lang.Object obj30 = timeSeriesDataItem29.clone();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem29, "June 2019", "June 2019", class33);
        timeSeries34.removeAgedItems(true);
        timeSeries34.setKey((java.lang.Comparable) (byte) -1);
        boolean boolean39 = month25.equals((java.lang.Object) (byte) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month25.next();
        int int41 = timeSeriesDataItem18.compareTo((java.lang.Object) month25);
        try {
            timeSeries7.add(timeSeriesDataItem18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 24234L + "'", long26 == 24234L);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate30);
//        org.jfree.data.time.SerialDate serialDate33 = serialDate31.getFollowingDayOfWeek(3);
//        boolean boolean34 = spreadsheetDate1.isOn(serialDate31);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int37 = spreadsheetDate36.getMonth();
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate40);
//        org.jfree.data.time.SerialDate serialDate43 = serialDate41.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate45 = serialDate43.getNearestDayOfWeek(7);
//        boolean boolean46 = spreadsheetDate36.isBefore(serialDate43);
//        boolean boolean47 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number49 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, number49);
//        java.lang.Object obj51 = timeSeriesDataItem50.clone();
//        java.lang.Class class54 = null;
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem50, "June 2019", "June 2019", class54);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener56 = null;
//        timeSeries55.removeChangeListener(seriesChangeListener56);
//        java.util.Collection collection58 = timeSeries55.getTimePeriods();
//        java.lang.Comparable comparable59 = timeSeries55.getKey();
//        java.lang.String str60 = timeSeries55.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar62 = null;
//        long long63 = fixedMillisecond61.getLastMillisecond(calendar62);
//        timeSeries55.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
//        boolean boolean65 = spreadsheetDate36.equals((java.lang.Object) fixedMillisecond61);
//        long long66 = fixedMillisecond61.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190903471L + "'", long9 == 1560190903471L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5 + "'", int37 == 5);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(obj51);
//        org.junit.Assert.assertNotNull(collection58);
//        org.junit.Assert.assertNotNull(comparable59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "June 2019" + "'", str60.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560190903479L + "'", long63 == 1560190903479L);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1560190903479L + "'", long66 == 1560190903479L);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries7.setMaximumItemCount((int) '4');
        java.lang.Class class18 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, number20);
        java.lang.Object obj22 = timeSeriesDataItem21.clone();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem21, "June 2019", "June 2019", class25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries26.removeChangeListener(seriesChangeListener27);
        java.util.Collection collection29 = timeSeries26.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries26.removeChangeListener(seriesChangeListener30);
        java.util.Collection collection32 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries26);
        boolean boolean33 = timeSeries26.isEmpty();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number13 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number13);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "June 2019", "June 2019", class18);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        java.util.Collection collection22 = timeSeries19.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries19.removeChangeListener(seriesChangeListener23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        int int27 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
        timeSeries19.setMaximumItemCount((int) '4');
        timeSeries19.setMaximumItemCount(100);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries7.addAndOrUpdate(timeSeries19);
        java.lang.String str33 = timeSeries7.getRangeDescription();
        timeSeries7.setNotify(false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate4);
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(7);
//        boolean boolean10 = spreadsheetDate1.isAfter(serialDate9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.lang.String str15 = serialDate14.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int18 = spreadsheetDate17.getDayOfWeek();
//        boolean boolean19 = spreadsheetDate1.isInRange(serialDate14, (org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int20 = spreadsheetDate17.toSerial();
//        org.jfree.data.time.SerialDate serialDate21 = null;
//        try {
//            boolean boolean22 = spreadsheetDate17.isOn(serialDate21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9999 + "'", int20 == 9999);
//    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate4);
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(7);
//        boolean boolean10 = spreadsheetDate1.isAfter(serialDate9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.lang.String str15 = serialDate14.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int18 = spreadsheetDate17.getDayOfWeek();
//        boolean boolean19 = spreadsheetDate1.isInRange(serialDate14, (org.jfree.data.time.SerialDate) spreadsheetDate17);
//        int int20 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int23 = spreadsheetDate22.getMonth();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate26);
//        org.jfree.data.time.SerialDate serialDate29 = serialDate27.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate31 = serialDate29.getNearestDayOfWeek(7);
//        boolean boolean32 = spreadsheetDate22.isBefore(serialDate29);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class35 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        boolean boolean40 = fixedMillisecond38.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond38.getFirstMillisecond(calendar41);
//        java.util.Date date43 = fixedMillisecond38.getTime();
//        java.util.TimeZone timeZone44 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date43, timeZone44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date43);
//        int int47 = day46.getDayOfMonth();
//        int int49 = day46.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate50 = day46.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate53);
//        org.jfree.data.time.SerialDate serialDate56 = serialDate54.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate58 = serialDate56.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate59 = serialDate50.getEndOfCurrentMonth(serialDate56);
//        boolean boolean60 = spreadsheetDate34.isOnOrBefore(serialDate59);
//        int int61 = spreadsheetDate34.getDayOfWeek();
//        boolean boolean62 = spreadsheetDate1.isInRange(serialDate29, (org.jfree.data.time.SerialDate) spreadsheetDate34);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(9999);
//        org.jfree.data.time.SerialDate serialDate65 = serialDate29.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate64);
//        serialDate65.setDescription("September");
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 7 + "'", int20 == 7);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560190904832L + "'", long42 == 1560190904832L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 10 + "'", int47 == 10);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 7 + "'", int61 == 7);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(serialDate65);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        timeSeries7.delete(regularTimePeriod15);
        java.lang.Class class17 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date19 = fixedMillisecond18.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date19, timeZone21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(date19);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date19);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date19);
        java.lang.Number number26 = null;
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day25, number26, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod22);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        java.util.Collection collection11 = timeSeries7.getTimePeriods();
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        java.lang.Comparable comparable13 = timeSeries7.getKey();
        timeSeries7.setDescription("Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNotNull(comparable13);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        timeSeries7.delete(regularTimePeriod15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number18 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, number18);
        java.lang.Object obj20 = timeSeriesDataItem19.clone();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem19, "June 2019", "June 2019", class23);
        timeSeriesDataItem19.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number28 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, number28);
        java.lang.Object obj30 = timeSeriesDataItem29.clone();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem29, "June 2019", "June 2019", class33);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries34.removeChangeListener(seriesChangeListener35);
        java.util.Collection collection37 = timeSeries34.getTimePeriods();
        java.lang.Comparable comparable38 = timeSeries34.getKey();
        boolean boolean39 = timeSeriesDataItem19.equals((java.lang.Object) timeSeries34);
        try {
            timeSeries7.add(timeSeriesDataItem19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertNotNull(comparable38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        java.lang.Number number8 = timeSeriesDataItem2.getValue();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
//        long long10 = month9.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number12 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, number12);
//        java.lang.Object obj14 = timeSeriesDataItem13.clone();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem13, "June 2019", "June 2019", class17);
//        timeSeries18.removeAgedItems(true);
//        timeSeries18.setKey((java.lang.Comparable) (byte) -1);
//        boolean boolean23 = month9.equals((java.lang.Object) (byte) -1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month9.next();
//        int int25 = timeSeriesDataItem2.compareTo((java.lang.Object) month9);
//        int int27 = month9.compareTo((java.lang.Object) 1560190860518L);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date30 = fixedMillisecond29.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date30);
//        boolean boolean33 = fixedMillisecond31.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond31.getFirstMillisecond(calendar34);
//        java.util.Date date36 = fixedMillisecond31.getTime();
//        java.util.TimeZone timeZone37 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date36, timeZone37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date36);
//        long long40 = day39.getFirstMillisecond();
//        java.lang.Class class41 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date43 = fixedMillisecond42.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(date43);
//        boolean boolean46 = fixedMillisecond44.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar47 = null;
//        long long48 = fixedMillisecond44.getFirstMillisecond(calendar47);
//        java.util.Date date49 = fixedMillisecond44.getTime();
//        java.util.TimeZone timeZone50 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date49, timeZone50);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date49);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date49);
//        boolean boolean54 = day39.equals((java.lang.Object) year53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year53.previous();
//        boolean boolean56 = month9.equals((java.lang.Object) regularTimePeriod55);
//        int int57 = month9.getYearValue();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24234L + "'", long10 == 24234L);
//        org.junit.Assert.assertNotNull(obj14);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560190905197L + "'", long35 == 1560190905197L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560150000000L + "'", long40 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560190905198L + "'", long48 == 1560190905198L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
//    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number40 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, number40);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond39.getLastMillisecond(calendar42);
//        long long44 = fixedMillisecond39.getMiddleMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number46 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, number46);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond45.getLastMillisecond(calendar48);
//        long long50 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
//        boolean boolean53 = fixedMillisecond39.equals((java.lang.Object) '4');
//        long long54 = fixedMillisecond39.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190905412L + "'", long32 == 1560190905412L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190905412L + "'", long34 == 1560190905412L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560190905413L + "'", long43 == 1560190905413L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560190905413L + "'", long44 == 1560190905413L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560190905413L + "'", long49 == 1560190905413L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560190905413L + "'", long50 == 1560190905413L);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560190905413L + "'", long54 == 1560190905413L);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        long long16 = timeSeries7.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener17);
        timeSeries7.setRangeDescription("May");
        timeSeries7.setMaximumItemCount(6);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Mon Jun 10 11:21:26 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        long long12 = day11.getFirstMillisecond();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        boolean boolean18 = fixedMillisecond16.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond16.getFirstMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond16.getTime();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date21);
//        boolean boolean26 = day11.equals((java.lang.Object) year25);
//        long long27 = day11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day11.previous();
//        java.util.Calendar calendar29 = null;
//        try {
//            long long30 = day11.getFirstMillisecond(calendar29);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190905531L + "'", long7 == 1560190905531L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560190905533L + "'", long20 == 1560190905533L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43626L + "'", long27 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int30 = spreadsheetDate29.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate32.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean36 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, serialDate32, (int) ' ');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate41);
//        org.jfree.data.time.SerialDate serialDate44 = serialDate42.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate46 = serialDate44.getNearestDayOfWeek(7);
//        boolean boolean47 = spreadsheetDate38.isAfter(serialDate46);
//        boolean boolean48 = spreadsheetDate1.isOn(serialDate46);
//        java.lang.String str49 = serialDate46.toString();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190905552L + "'", long9 == 1560190905552L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "14-April-2733" + "'", str49.equals("14-April-2733"));
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class3 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date5 = fixedMillisecond4.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
//        boolean boolean8 = fixedMillisecond6.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond6.getFirstMillisecond(calendar9);
//        java.util.Date date11 = fixedMillisecond6.getTime();
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date11, timeZone12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date11);
//        int int15 = day14.getDayOfMonth();
//        int int17 = day14.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate18 = day14.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate21);
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate24.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate27 = serialDate18.getEndOfCurrentMonth(serialDate24);
//        boolean boolean28 = spreadsheetDate2.isOnOrBefore(serialDate27);
//        int int29 = spreadsheetDate2.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate32);
//        org.jfree.data.time.SerialDate serialDate35 = serialDate33.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate37 = serialDate35.getNearestDayOfWeek(7);
//        boolean boolean38 = spreadsheetDate2.isOnOrAfter(serialDate35);
//        boolean boolean40 = spreadsheetDate2.equals((java.lang.Object) 0);
//        try {
//            org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560190906974L + "'", long10 == 1560190906974L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 7 + "'", int29 == 7);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1927);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        java.util.Collection collection11 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries7.removeChangeListener(seriesChangeListener12);
        try {
            timeSeries7.update(5, (java.lang.Number) 1560190892619L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertNotNull(collection11);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        timeSeries7.removeAgedItems(true);
        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
        timeSeries7.setRangeDescription("2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1560190855309L);
        try {
            timeSeries7.add(timeSeriesDataItem17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries7.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener11);
        int int13 = timeSeries7.getItemCount();
        timeSeries7.setRangeDescription("Saturday");
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        int int16 = year13.getYear();
        java.lang.Class<?> wildcardClass17 = year13.getClass();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = year13.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(9992);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.setNotify(false);
        try {
            java.lang.Number number13 = timeSeries7.getValue(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        timeSeries7.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number13 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number13);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "June 2019", "June 2019", class18);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        java.util.Collection collection22 = timeSeries19.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries19.removeChangeListener(seriesChangeListener23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        int int27 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
        timeSeries19.setMaximumItemCount((int) '4');
        timeSeries19.setMaximumItemCount(100);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries7.addAndOrUpdate(timeSeries19);
        boolean boolean33 = timeSeries7.isEmpty();
        timeSeries7.removeAgedItems(true);
        try {
            timeSeries7.delete((int) (byte) -1, 1963);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        int int2 = month0.getYearValue();
        long long3 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener8);
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number13 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number13);
//        java.lang.Object obj15 = timeSeriesDataItem14.clone();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "June 2019", "June 2019", class18);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries19.removeChangeListener(seriesChangeListener20);
//        java.util.Collection collection22 = timeSeries19.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries19.removeChangeListener(seriesChangeListener23);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        long long26 = year25.getFirstMillisecond();
//        int int27 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
//        timeSeries19.setMaximumItemCount((int) '4');
//        timeSeries19.setMaximumItemCount(100);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries7.addAndOrUpdate(timeSeries19);
//        int int33 = timeSeries32.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date35);
//        long long37 = fixedMillisecond36.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 1560190879376L);
//        java.util.Calendar calendar40 = null;
//        fixedMillisecond36.peg(calendar40);
//        long long42 = fixedMillisecond36.getSerialIndex();
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj15);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560190907744L + "'", long37 == 1560190907744L);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560190907744L + "'", long42 == 1560190907744L);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date2 = fixedMillisecond1.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
//        boolean boolean5 = fixedMillisecond3.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date8);
//        int int12 = day11.getDayOfMonth();
//        int int14 = day11.compareTo((java.lang.Object) 1560190851150L);
//        java.lang.Object obj15 = null;
//        boolean boolean16 = day11.equals(obj15);
//        long long17 = day11.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day11.previous();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560190907821L + "'", long7 == 1560190907821L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        java.lang.String str8 = timeSeries7.getDescription();
        timeSeries7.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener11);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries7.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.Calendar calendar3 = null;
        try {
            year2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        int int5 = timeSeriesDataItem2.compareTo((java.lang.Object) fixedMillisecond4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number7 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, number7);
        java.lang.Object obj9 = timeSeriesDataItem8.clone();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem8, "June 2019", "June 2019", class12);
        timeSeriesDataItem8.setValue((java.lang.Number) 1560190852108L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number17 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, number17);
        java.lang.Object obj19 = timeSeriesDataItem18.clone();
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem18, "June 2019", "June 2019", class22);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries23.removeChangeListener(seriesChangeListener24);
        java.util.Collection collection26 = timeSeries23.getTimePeriods();
        java.lang.Comparable comparable27 = timeSeries23.getKey();
        boolean boolean28 = timeSeriesDataItem8.equals((java.lang.Object) timeSeries23);
        org.jfree.data.general.SeriesException seriesException30 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray31 = seriesException30.getSuppressed();
        int int32 = timeSeriesDataItem8.compareTo((java.lang.Object) seriesException30);
        java.lang.String str33 = seriesException30.toString();
        int int34 = fixedMillisecond4.compareTo((java.lang.Object) str33);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertNotNull(comparable27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str33.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        boolean boolean4 = year0.equals((java.lang.Object) 1560190852108L);
        long long5 = year0.getFirstMillisecond();
        java.lang.String str6 = year0.toString();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(11);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate9);
        boolean boolean11 = year0.equals((java.lang.Object) serialDate9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number13 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number13);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem14, "June 2019", "June 2019", class18);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        timeSeries19.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number25 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, number25);
        java.lang.Object obj27 = timeSeriesDataItem26.clone();
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem26, "June 2019", "June 2019", class30);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries31.removeChangeListener(seriesChangeListener32);
        java.util.Collection collection34 = timeSeries31.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries31.removeChangeListener(seriesChangeListener35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getFirstMillisecond();
        int int39 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) year37);
        timeSeries31.setMaximumItemCount((int) '4');
        timeSeries31.setMaximumItemCount(100);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries19.addAndOrUpdate(timeSeries31);
        int int45 = year0.compareTo((java.lang.Object) timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeriesDataItem2.setValue((java.lang.Number) 1560190852108L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
//        java.lang.Object obj13 = timeSeriesDataItem12.clone();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "June 2019", "June 2019", class16);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries17.removeChangeListener(seriesChangeListener18);
//        java.util.Collection collection20 = timeSeries17.getTimePeriods();
//        java.lang.Comparable comparable21 = timeSeries17.getKey();
//        boolean boolean22 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries17);
//        java.lang.Class class23 = timeSeries17.getTimePeriodClass();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number28 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, number28);
//        java.lang.Object obj30 = timeSeriesDataItem29.clone();
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem29, "June 2019", "June 2019", class33);
//        timeSeries34.removeAgedItems(true);
//        timeSeries34.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries34.setRangeDescription("2019");
//        timeSeries34.fireSeriesChanged();
//        java.lang.Class class42 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date44 = fixedMillisecond43.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(date44);
//        boolean boolean47 = fixedMillisecond45.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond45.getFirstMillisecond(calendar48);
//        java.util.Date date50 = fixedMillisecond45.getTime();
//        java.util.TimeZone timeZone51 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date50, timeZone51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date50);
//        long long54 = day53.getFirstMillisecond();
//        java.util.Date date55 = day53.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number57 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, number57);
//        java.lang.Object obj59 = timeSeriesDataItem58.clone();
//        java.lang.Class class62 = null;
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem58, "June 2019", "June 2019", class62);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener64 = null;
//        timeSeries63.removeChangeListener(seriesChangeListener64);
//        java.util.Collection collection66 = timeSeries63.getTimePeriods();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener67 = null;
//        timeSeries63.removeChangeListener(seriesChangeListener67);
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
//        long long70 = year69.getFirstMillisecond();
//        int int71 = timeSeries63.getIndex((org.jfree.data.time.RegularTimePeriod) year69);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date73 = fixedMillisecond72.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond(date73);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries63.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond74, (double) (byte) -1);
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = year77.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = year77.previous();
//        boolean boolean80 = fixedMillisecond74.equals((java.lang.Object) year77);
//        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) day53, (org.jfree.data.time.RegularTimePeriod) year77);
//        org.jfree.data.time.Month month82 = new org.jfree.data.time.Month();
//        long long83 = month82.getSerialIndex();
//        boolean boolean85 = month82.equals((java.lang.Object) 10);
//        long long86 = month82.getFirstMillisecond();
//        int int87 = month82.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = month82.previous();
//        timeSeries34.setKey((java.lang.Comparable) regularTimePeriod88);
//        java.beans.PropertyChangeListener propertyChangeListener90 = null;
//        timeSeries34.addPropertyChangeListener(propertyChangeListener90);
//        boolean boolean92 = year24.equals((java.lang.Object) propertyChangeListener90);
//        java.lang.Number number93 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) year24);
//        timeSeries17.setNotify(false);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertNotNull(comparable21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNull(class23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(obj30);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560190908189L + "'", long49 == 1560190908189L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560150000000L + "'", long54 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(obj59);
//        org.junit.Assert.assertNotNull(collection66);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1546329600000L + "'", long70 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNull(timeSeriesDataItem76);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(timeSeries81);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 24234L + "'", long83 == 24234L);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 1559372400000L + "'", long86 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 6 + "'", int87 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
//        org.junit.Assert.assertNull(number93);
//    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Object obj3 = timeSeriesDataItem2.clone();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
//        timeSeries7.removeAgedItems(true);
//        timeSeries7.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number15 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, number15);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "June 2019", "June 2019", class20);
//        timeSeries21.removeAgedItems(true);
//        timeSeries21.setKey((java.lang.Comparable) (byte) -1);
//        timeSeries21.setRangeDescription("2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, number29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond28.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond28.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1546329600000L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 8);
//        java.beans.PropertyChangeListener propertyChangeListener39 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener39);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(1560190857893L);
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond42.getFirstMillisecond(calendar43);
//        try {
//            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (double) 1560190867740L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560190908726L + "'", long32 == 1560190908726L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190908726L + "'", long34 == 1560190908726L);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560190857893L + "'", long44 == 1560190857893L);
//    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate4);
//        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(7);
//        boolean boolean10 = spreadsheetDate1.isAfter(serialDate9);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date13 = fixedMillisecond12.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond14.getFirstMillisecond(calendar17);
//        java.util.Date date19 = fixedMillisecond14.getTime();
//        java.util.TimeZone timeZone20 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date19, timeZone20);
//        java.lang.Class<?> wildcardClass22 = date19.getClass();
//        boolean boolean23 = spreadsheetDate1.equals((java.lang.Object) wildcardClass22);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560190908740L + "'", long18 == 1560190908740L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        boolean boolean7 = fixedMillisecond5.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getFirstMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
//        int int14 = day13.getDayOfMonth();
//        int int16 = day13.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate17 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate20);
//        org.jfree.data.time.SerialDate serialDate23 = serialDate21.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate17.getEndOfCurrentMonth(serialDate23);
//        boolean boolean27 = spreadsheetDate1.isOnOrBefore(serialDate26);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int30 = spreadsheetDate29.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate32.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean36 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, serialDate32, (int) ' ');
//        try {
//            org.jfree.data.time.SerialDate serialDate38 = serialDate32.getPreviousDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190908799L + "'", long9 == 1560190908799L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        long long3 = month2.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(11);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate4);
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getFollowingDayOfWeek(3);
        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate7);
        try {
            org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 0, serialDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
//        long long5 = year4.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
//        boolean boolean8 = fixedMillisecond0.equals((java.lang.Object) year4);
//        long long9 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560190909204L + "'", long3 == 1560190909204L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190909204L + "'", long9 == 1560190909204L);
//    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, number8);
//        timeSeriesDataItem9.setValue((java.lang.Number) (short) -1);
//        boolean boolean12 = fixedMillisecond0.equals((java.lang.Object) timeSeriesDataItem9);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "SerialDate.weekInMonthToString(): invalid code.", "Wed Dec 31 15:59:59 PST 1969", class15);
//        java.lang.String str17 = timeSeries16.getDescription();
//        java.lang.String str18 = timeSeries16.getDomainDescription();
//        try {
//            java.lang.Number number20 = timeSeries16.getValue(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190909315L + "'", long4 == 1560190909315L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190909315L + "'", long6 == 1560190909315L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str18.equals("SerialDate.weekInMonthToString(): invalid code."));
//    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
//        long long2 = year0.getSerialIndex();
//        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
//        int int5 = year0.compareTo((java.lang.Object) seriesException4);
//        int int7 = year0.compareTo((java.lang.Object) 1560190859545L);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
//        boolean boolean13 = fixedMillisecond11.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond11.getFirstMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond11.getTime();
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date16, timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16);
//        int int20 = day19.getDayOfMonth();
//        boolean boolean21 = year0.equals((java.lang.Object) day19);
//        java.lang.String str22 = day19.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int25 = spreadsheetDate24.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(7);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date30 = fixedMillisecond29.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date30);
//        boolean boolean33 = fixedMillisecond31.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond31.getFirstMillisecond(calendar34);
//        java.util.Date date36 = fixedMillisecond31.getTime();
//        java.util.TimeZone timeZone37 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date36, timeZone37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date36);
//        int int40 = day39.getDayOfMonth();
//        int int42 = day39.compareTo((java.lang.Object) 1560190851150L);
//        org.jfree.data.time.SerialDate serialDate43 = day39.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(11);
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate46);
//        org.jfree.data.time.SerialDate serialDate49 = serialDate47.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SerialDate serialDate51 = serialDate49.getNearestDayOfWeek(7);
//        org.jfree.data.time.SerialDate serialDate52 = serialDate43.getEndOfCurrentMonth(serialDate49);
//        boolean boolean53 = spreadsheetDate27.isOnOrBefore(serialDate52);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int56 = spreadsheetDate55.getDayOfWeek();
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance(11);
//        serialDate58.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        boolean boolean62 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate55, serialDate58, (int) ' ');
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(9999);
//        int int65 = spreadsheetDate64.getDayOfWeek();
//        boolean boolean66 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate64);
//        boolean boolean67 = spreadsheetDate24.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate64);
//        boolean boolean68 = day19.equals((java.lang.Object) boolean67);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560190909328L + "'", long15 == 1560190909328L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5 + "'", int25 == 5);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560190909331L + "'", long35 == 1560190909331L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 3 + "'", int56 == 3);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 3 + "'", int65 == 3);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        boolean boolean3 = month0.equals((java.lang.Object) 10);
        long long4 = month0.getFirstMillisecond();
        int int5 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.previous();
        java.util.Date date7 = regularTimePeriod6.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.next();
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getLastMillisecond(calendar7);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560190909564L + "'", long4 == 1560190909564L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560190909564L + "'", long8 == 1560190909564L);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries7.setMaximumItemCount((int) '4');
        java.lang.Class class18 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, number20);
        java.lang.Object obj22 = timeSeriesDataItem21.clone();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem21, "June 2019", "June 2019", class25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries26.removeChangeListener(seriesChangeListener27);
        java.util.Collection collection29 = timeSeries26.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries26.removeChangeListener(seriesChangeListener30);
        java.util.Collection collection32 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries26);
        java.lang.Class class33 = timeSeries26.getTimePeriodClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = timeSeries26.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNull(class33);
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
//        boolean boolean4 = fixedMillisecond2.equals((java.lang.Object) 0L);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond2.getFirstMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond2.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) 1560190857893L);
//        long long10 = fixedMillisecond2.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560190909591L + "'", long6 == 1560190909591L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560190909591L + "'", long10 == 1560190909591L);
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "June 2019", "June 2019", class6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries7.removeChangeListener(seriesChangeListener8);
        java.util.Collection collection10 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries7.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        int int15 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        long long16 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(true);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
    }
}

