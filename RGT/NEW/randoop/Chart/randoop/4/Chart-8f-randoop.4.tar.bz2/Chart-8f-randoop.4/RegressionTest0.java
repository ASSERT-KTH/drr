import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.Week.FIRST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test010");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        boolean boolean7 = week0.equals((java.lang.Object) regularTimePeriod6);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        int int5 = week2.getWeek();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getStart();
        try {
            org.jfree.data.time.Year year7 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test024");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Calendar calendar5 = null;
//        try {
//            week0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test025");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date5 = week4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getFirstMillisecond();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.util.Calendar calendar10 = null;
//        try {
//            week0.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62041910400000L) + "'", long8 == (-62041910400000L));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date9 = week8.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone10);
        java.util.TimeZone timeZone12 = null;
        java.util.Locale locale13 = null;
        try {
            org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date9, timeZone12, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test028");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test031");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date5 = week4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getFirstMillisecond();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = week0.getFirstMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62041910400000L) + "'", long8 == (-62041910400000L));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.Week.LAST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test033");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        java.util.TimeZone timeZone15 = null;
//        java.util.Locale locale16 = null;
//        try {
//            org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date13, timeZone15, locale16);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 0, -1");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-1), 0);
        long long3 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62168616000001L) + "'", long3 == (-62168616000001L));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = regularTimePeriod5.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62200065600001L) + "'", long6 == (-62200065600001L));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 24, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        java.util.Calendar calendar6 = null;
//        try {
//            week0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = week0.equals((java.lang.Object) wildcardClass11);
//        java.util.Calendar calendar20 = null;
//        try {
//            week0.peg(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        java.lang.Class<?> wildcardClass3 = date2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date7 = week6.getEnd();
//        int int8 = week6.getYearValue();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
//        long long12 = week10.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week10.next();
//        org.jfree.data.time.Year year14 = week10.getYear();
//        java.util.Date date15 = year14.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date19 = week18.getEnd();
//        int int20 = week18.getYearValue();
//        java.lang.Class<?> wildcardClass21 = week18.getClass();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date25 = week24.getEnd();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date25, timeZone27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone27);
//        java.util.Locale locale30 = null;
//        try {
//            org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date2, timeZone27, locale30);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        int int5 = week2.getWeek();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getSerialIndex();
//        java.lang.Class<?> wildcardClass9 = week7.getClass();
//        int int10 = week2.compareTo((java.lang.Object) wildcardClass9);
//        long long11 = week2.getFirstMillisecond();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        int int15 = week2.compareTo((java.lang.Object) year14);
//        java.util.Calendar calendar16 = null;
//        try {
//            week2.peg(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62199763200000L) + "'", long11 == (-62199763200000L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date4 = week3.getEnd();
//        int int5 = week3.getYearValue();
//        java.lang.Class<?> wildcardClass6 = week3.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        long long9 = week7.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.next();
//        org.jfree.data.time.Year year11 = week7.getYear();
//        java.util.Date date12 = year11.getStart();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date16 = week15.getEnd();
//        int int17 = week15.getYearValue();
//        java.lang.Class<?> wildcardClass18 = week15.getClass();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date22 = week21.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date12, timeZone24);
//        java.util.Locale locale27 = null;
//        try {
//            org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date0, timeZone24, locale27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getSerialIndex();
//        java.lang.Class<?> wildcardClass9 = week7.getClass();
//        int int10 = week2.compareTo((java.lang.Object) wildcardClass9);
//        long long11 = week2.getFirstMillisecond();
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = week2.getLastMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62199763200000L) + "'", long11 == (-62199763200000L));
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test049");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = week0.equals((java.lang.Object) wildcardClass11);
//        java.lang.Object obj20 = null;
//        int int21 = week0.compareTo(obj20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        org.jfree.data.time.Year year3 = week1.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (byte) 100, year3);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(year3);
//    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test051");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        int int5 = week2.getWeek();
//        java.lang.String str6 = week2.toString();
//        java.util.Date date7 = week2.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        long long9 = week8.getSerialIndex();
//        java.lang.Class<?> wildcardClass10 = week8.getClass();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date14 = week13.getEnd();
//        int int15 = week13.getYearValue();
//        java.lang.Class<?> wildcardClass16 = week13.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date20 = week19.getEnd();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date20, timeZone21);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date26 = week25.getEnd();
//        int int27 = week25.getYearValue();
//        java.lang.Class<?> wildcardClass28 = week25.getClass();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date32 = week31.getEnd();
//        java.util.TimeZone timeZone33 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date32, timeZone33);
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date32, timeZone35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date32, timeZone37);
//        java.util.Locale locale39 = null;
//        try {
//            org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date7, timeZone37, locale39);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 0, -1" + "'", str6.equals("Week 0, -1"));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        int int5 = week2.getWeek();
        int int7 = week2.compareTo((java.lang.Object) (-1.0f));
        java.lang.String str8 = week2.toString();
        java.lang.Object obj9 = null;
        int int10 = week2.compareTo(obj9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week2.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 0, -1" + "'", str8.equals("Week 0, -1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        int int5 = week2.getWeek();
        java.lang.String str6 = week2.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 0, -1" + "'", str6.equals("Week 0, -1"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        long long6 = week4.getFirstMillisecond();
        long long7 = week4.getSerialIndex();
        long long8 = week4.getLastMillisecond();
        try {
            org.jfree.data.time.Year year9 = week4.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62041910400000L) + "'", long6 == (-62041910400000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 211L + "'", long7 == 211L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62041305600001L) + "'", long8 == (-62041305600001L));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (short) -1);
        long long3 = week2.getFirstMillisecond();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62139283200000L) + "'", long3 == (-62139283200000L));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        long long5 = week2.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            week2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62199763200000L) + "'", long5 == (-62199763200000L));
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        long long8 = week6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.next();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        java.util.Date date11 = year10.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        int int16 = week14.getYearValue();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date21 = week20.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone23);
//        java.util.TimeZone timeZone26 = null;
//        java.util.Locale locale27 = null;
//        try {
//            org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date11, timeZone26, locale27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone10);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        int int16 = week14.getYearValue();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.previous();
//        long long20 = week18.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week18.next();
//        org.jfree.data.time.Year year22 = week18.getYear();
//        java.util.Date date23 = year22.getStart();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date27 = week26.getEnd();
//        int int28 = week26.getYearValue();
//        java.lang.Class<?> wildcardClass29 = week26.getClass();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date33 = week32.getEnd();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date33);
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date33, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date23, timeZone35);
//        java.util.Locale locale38 = null;
//        try {
//            org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date9, timeZone35, locale38);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560063600000L + "'", long20 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getStart();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getFirstMillisecond();
//        int int4 = week0.getYearValue();
//        long long5 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) '#', 12);
        boolean boolean8 = week2.equals((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = week0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = week0.equals((java.lang.Object) wildcardClass11);
//        java.lang.Object obj20 = null;
//        int int21 = week0.compareTo(obj20);
//        int int22 = week0.getWeek();
//        java.util.Calendar calendar23 = null;
//        try {
//            long long24 = week0.getLastMillisecond(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 24 + "'", int22 == 24);
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test066");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        int int3 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        long long6 = week4.getFirstMillisecond();
        long long7 = week4.getSerialIndex();
        long long8 = week4.getLastMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week4.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62041910400000L) + "'", long6 == (-62041910400000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 211L + "'", long7 == 211L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62041305600001L) + "'", long8 == (-62041305600001L));
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        long long15 = week6.getFirstMillisecond();
//        java.util.Date date16 = week6.getStart();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date16);
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test069");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        java.util.Calendar calendar15 = null;
//        try {
//            week6.peg(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        long long3 = week2.getSerialIndex();
        long long4 = week2.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-53L) + "'", long3 == (-53L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62199158400001L) + "'", long4 == (-62199158400001L));
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = week0.equals((java.lang.Object) wildcardClass11);
//        java.util.Date date20 = week0.getEnd();
//        java.util.TimeZone timeZone21 = null;
//        java.util.Locale locale22 = null;
//        try {
//            org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date20, timeZone21, locale22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week4.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getFirstMillisecond();
//        java.util.Date date4 = week0.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date4);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test074");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        java.lang.String str7 = week0.toString();
//        java.lang.String str8 = week0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        long long3 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-53L) + "'", long3 == (-53L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException5.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray8);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        long long8 = week6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.next();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        java.util.Date date11 = year10.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        int int16 = week14.getYearValue();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date21 = week20.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone23);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date29 = week28.getEnd();
//        int int30 = week28.getYearValue();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date11, timeZone37);
//        java.util.Calendar calendar40 = null;
//        try {
//            long long41 = week39.getMiddleMillisecond(calendar40);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date5 = week4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getFirstMillisecond();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = week0.getLastMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62041910400000L) + "'", long8 == (-62041910400000L));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        int int6 = week0.getWeek();
//        java.util.Date date7 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.lang.String str4 = week0.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        long long8 = week6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.next();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        java.util.Date date11 = year10.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        int int16 = week14.getYearValue();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date21 = week20.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone23);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date29 = week28.getEnd();
//        int int30 = week28.getYearValue();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date11, timeZone37);
//        long long40 = week39.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1546761599999L + "'", long40 == 1546761599999L);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test083");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getSerialIndex();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        java.util.Date date5 = regularTimePeriod4.getStart();
        long long6 = regularTimePeriod4.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62200065600001L) + "'", long6 == (-62200065600001L));
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date10 = week9.getEnd();
//        int int11 = week9.getYearValue();
//        java.lang.Class<?> wildcardClass12 = week9.getClass();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date16 = week15.getEnd();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date16, timeZone18);
//        java.util.Locale locale20 = null;
//        try {
//            org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date5, timeZone18, locale20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        long long5 = week2.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-53L) + "'", long5 == (-53L));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 6);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date4 = week3.getEnd();
//        int int5 = week3.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.previous();
//        java.util.Date date7 = week3.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        long long9 = week8.getSerialIndex();
//        java.lang.Class<?> wildcardClass10 = week8.getClass();
//        int int11 = week3.compareTo((java.lang.Object) wildcardClass10);
//        long long12 = week3.getFirstMillisecond();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        int int14 = week13.getWeek();
//        org.jfree.data.time.Year year15 = week13.getYear();
//        int int16 = week3.compareTo((java.lang.Object) year15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) (byte) 1, year15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.previous();
//        long long20 = week18.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week18.next();
//        long long22 = week18.getSerialIndex();
//        int int23 = week18.getWeek();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date27 = week26.getEnd();
//        int int28 = week26.getYearValue();
//        java.lang.Class<?> wildcardClass29 = week26.getClass();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date33 = week32.getEnd();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date33);
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date33, timeZone35);
//        boolean boolean37 = week18.equals((java.lang.Object) wildcardClass29);
//        int int38 = week17.compareTo((java.lang.Object) boolean37);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62199763200000L) + "'", long12 == (-62199763200000L));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560063600000L + "'", long20 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 107031L + "'", long22 == 107031L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 24 + "'", int23 == 24);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        int int5 = week2.getWeek();
        int int7 = week2.compareTo((java.lang.Object) (-1.0f));
        java.lang.Class<?> wildcardClass8 = week2.getClass();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getSerialIndex();
//        java.util.Calendar calendar5 = null;
//        try {
//            week0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable throwable5 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date4 = week3.getEnd();
//        int int5 = week3.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.previous();
//        java.util.Date date7 = week3.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        long long9 = week8.getSerialIndex();
//        java.lang.Class<?> wildcardClass10 = week8.getClass();
//        int int11 = week3.compareTo((java.lang.Object) wildcardClass10);
//        long long12 = week3.getFirstMillisecond();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        int int14 = week13.getWeek();
//        org.jfree.data.time.Year year15 = week13.getYear();
//        int int16 = week3.compareTo((java.lang.Object) year15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) (byte) 1, year15);
//        java.lang.Class<?> wildcardClass18 = year15.getClass();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62199763200000L) + "'", long12 == (-62199763200000L));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        long long6 = week4.getFirstMillisecond();
        long long7 = week4.getSerialIndex();
        long long8 = week4.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            week4.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62041910400000L) + "'", long6 == (-62041910400000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 211L + "'", long7 == 211L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 211L + "'", long8 == 211L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week4.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.next();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week4.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        java.lang.Class<?> wildcardClass3 = date2.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        long long7 = week5.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.next();
//        long long9 = week5.getFirstMillisecond();
//        int int10 = week5.getWeek();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week5.equals((java.lang.Object) week11);
//        java.lang.String str15 = week11.toString();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        long long17 = week16.getSerialIndex();
//        java.util.Date date18 = week16.getEnd();
//        boolean boolean19 = week11.equals((java.lang.Object) date18);
//        java.lang.Class<?> wildcardClass20 = date18.getClass();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date18, timeZone21);
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 24, 2019" + "'", str15.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 107031L + "'", long17 == 107031L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(class23);
//    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        int int6 = week0.getWeek();
//        java.util.Date date7 = week0.getStart();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = week6.getFirstMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        long long6 = week4.getFirstMillisecond();
        long long7 = week4.getSerialIndex();
        long long8 = week4.getLastMillisecond();
        int int9 = week4.getWeek();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62041910400000L) + "'", long6 == (-62041910400000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 211L + "'", long7 == 211L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62041305600001L) + "'", long8 == (-62041305600001L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (-22));
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
//        long long15 = week13.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week13.next();
//        long long17 = week13.getFirstMillisecond();
//        int int18 = week13.getWeek();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        long long20 = week19.getSerialIndex();
//        java.util.Date date21 = week19.getEnd();
//        boolean boolean22 = week13.equals((java.lang.Object) week19);
//        java.lang.String str23 = week19.toString();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        long long25 = week24.getSerialIndex();
//        java.util.Date date26 = week24.getEnd();
//        boolean boolean27 = week19.equals((java.lang.Object) date26);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date31 = week30.getEnd();
//        java.lang.Object obj32 = null;
//        int int33 = week30.compareTo(obj32);
//        java.util.Date date34 = week30.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        long long36 = week35.getSerialIndex();
//        java.util.Date date37 = week35.getEnd();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date41 = week40.getEnd();
//        int int42 = week40.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week40.previous();
//        java.util.Date date44 = week40.getStart();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        long long46 = week45.getSerialIndex();
//        java.lang.Class<?> wildcardClass47 = week45.getClass();
//        int int48 = week40.compareTo((java.lang.Object) wildcardClass47);
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
//        long long51 = week50.getSerialIndex();
//        java.util.Date date52 = week50.getEnd();
//        java.lang.Class<?> wildcardClass53 = date52.getClass();
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date57 = week56.getEnd();
//        int int58 = week56.getYearValue();
//        java.lang.Class<?> wildcardClass59 = week56.getClass();
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date63 = week62.getEnd();
//        java.util.TimeZone timeZone64 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date63, timeZone64);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date69 = week68.getEnd();
//        int int70 = week68.getYearValue();
//        java.lang.Class<?> wildcardClass71 = week68.getClass();
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date75 = week74.getEnd();
//        java.util.TimeZone timeZone76 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass71, date75, timeZone76);
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date75, timeZone78);
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date52, timeZone78);
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date84 = week83.getEnd();
//        int int85 = week83.getYearValue();
//        java.lang.Class<?> wildcardClass86 = week83.getClass();
//        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date90 = week89.getEnd();
//        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date90);
//        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass86, date90, timeZone92);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date52, timeZone92);
//        org.jfree.data.time.Week week95 = new org.jfree.data.time.Week(date37, timeZone92);
//        org.jfree.data.time.Week week96 = new org.jfree.data.time.Week(date34, timeZone92);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date26, timeZone92);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 107031L + "'", long20 == 107031L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 24, 2019" + "'", str23.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107031L + "'", long25 == 107031L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 107031L + "'", long36 == 107031L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 107031L + "'", long46 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 107031L + "'", long51 == 107031L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass59);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass71);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(timeZone78);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1) + "'", int85 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass86);
//        org.junit.Assert.assertNotNull(date90);
//        org.junit.Assert.assertNotNull(timeZone92);
//        org.junit.Assert.assertNotNull(regularTimePeriod93);
//        org.junit.Assert.assertNotNull(regularTimePeriod94);
//        org.junit.Assert.assertNotNull(regularTimePeriod97);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date4 = week3.getEnd();
//        int int5 = week3.getYearValue();
//        java.lang.Class<?> wildcardClass6 = week3.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        long long9 = week7.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.next();
//        org.jfree.data.time.Year year11 = week7.getYear();
//        java.util.Date date12 = year11.getStart();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date16 = week15.getEnd();
//        int int17 = week15.getYearValue();
//        java.lang.Class<?> wildcardClass18 = week15.getClass();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date22 = week21.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date12, timeZone24);
//        try {
//            org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date0, timeZone24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        long long6 = week2.getFirstMillisecond();
        int int8 = week2.compareTo((java.lang.Object) 24);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62199763200000L) + "'", long6 == (-62199763200000L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getSerialIndex();
//        long long6 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getSerialIndex();
//        java.lang.Class<?> wildcardClass9 = week7.getClass();
//        int int10 = week2.compareTo((java.lang.Object) wildcardClass9);
//        long long11 = week2.getFirstMillisecond();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        int int15 = week2.compareTo((java.lang.Object) year14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week2.next();
//        boolean boolean18 = week2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62199763200000L) + "'", long11 == (-62199763200000L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        int int5 = week2.getWeek();
        int int7 = week2.compareTo((java.lang.Object) (-1.0f));
        java.lang.String str8 = week2.toString();
        java.lang.Object obj9 = null;
        int int10 = week2.compareTo(obj9);
        int int11 = week2.getWeek();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = week2.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 0, -1" + "'", str8.equals("Week 0, -1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        java.util.Date date5 = week4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date10 = week9.getEnd();
//        int int11 = week9.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week9.previous();
//        java.util.Date date13 = week9.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        long long15 = week14.getSerialIndex();
//        java.lang.Class<?> wildcardClass16 = week14.getClass();
//        int int17 = week9.compareTo((java.lang.Object) wildcardClass16);
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        long long20 = week19.getSerialIndex();
//        java.util.Date date21 = week19.getEnd();
//        java.lang.Class<?> wildcardClass22 = date21.getClass();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date26 = week25.getEnd();
//        int int27 = week25.getYearValue();
//        java.lang.Class<?> wildcardClass28 = week25.getClass();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date32 = week31.getEnd();
//        java.util.TimeZone timeZone33 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date32, timeZone33);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date38 = week37.getEnd();
//        int int39 = week37.getYearValue();
//        java.lang.Class<?> wildcardClass40 = week37.getClass();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date44 = week43.getEnd();
//        java.util.TimeZone timeZone45 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date44, timeZone45);
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date44, timeZone47);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date21, timeZone47);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date53 = week52.getEnd();
//        int int54 = week52.getYearValue();
//        java.lang.Class<?> wildcardClass55 = week52.getClass();
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date59 = week58.getEnd();
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date59);
//        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date59, timeZone61);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone61);
//        java.util.Locale locale64 = null;
//        try {
//            org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date5, timeZone61, locale64);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 107031L + "'", long15 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 107031L + "'", long20 == 107031L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone61);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date9 = week8.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.lang.Class<?> wildcardClass3 = week2.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getSerialIndex();
//        java.lang.Class<?> wildcardClass7 = week5.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date11 = week10.getEnd();
//        int int12 = week10.getYearValue();
//        java.lang.Class<?> wildcardClass13 = week10.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date17 = week16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date23 = week22.getEnd();
//        int int24 = week22.getYearValue();
//        java.lang.Class<?> wildcardClass25 = week22.getClass();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date29 = week28.getEnd();
//        java.util.TimeZone timeZone30 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date29, timeZone32);
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date29, timeZone34);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        long long37 = week36.getSerialIndex();
//        java.util.Date date38 = week36.getEnd();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date42 = week41.getEnd();
//        int int43 = week41.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week41.previous();
//        java.util.Date date45 = week41.getStart();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        long long47 = week46.getSerialIndex();
//        java.lang.Class<?> wildcardClass48 = week46.getClass();
//        int int49 = week41.compareTo((java.lang.Object) wildcardClass48);
//        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        long long52 = week51.getSerialIndex();
//        java.util.Date date53 = week51.getEnd();
//        java.lang.Class<?> wildcardClass54 = date53.getClass();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date58 = week57.getEnd();
//        int int59 = week57.getYearValue();
//        java.lang.Class<?> wildcardClass60 = week57.getClass();
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date64 = week63.getEnd();
//        java.util.TimeZone timeZone65 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date64, timeZone65);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date70 = week69.getEnd();
//        int int71 = week69.getYearValue();
//        java.lang.Class<?> wildcardClass72 = week69.getClass();
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date76 = week75.getEnd();
//        java.util.TimeZone timeZone77 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass72, date76, timeZone77);
//        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date76, timeZone79);
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date53, timeZone79);
//        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date85 = week84.getEnd();
//        int int86 = week84.getYearValue();
//        java.lang.Class<?> wildcardClass87 = week84.getClass();
//        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date91 = week90.getEnd();
//        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(date91);
//        java.util.TimeZone timeZone93 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass87, date91, timeZone93);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date53, timeZone93);
//        org.jfree.data.time.Week week96 = new org.jfree.data.time.Week(date38, timeZone93);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date29, timeZone93);
//        java.util.Date date98 = regularTimePeriod97.getStart();
//        org.jfree.data.time.Week week99 = new org.jfree.data.time.Week(date98);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 107031L + "'", long37 == 107031L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 107031L + "'", long47 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(class50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 107031L + "'", long52 == 107031L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass72);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(timeZone79);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertNotNull(date85);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-1) + "'", int86 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass87);
//        org.junit.Assert.assertNotNull(date91);
//        org.junit.Assert.assertNotNull(timeZone93);
//        org.junit.Assert.assertNotNull(regularTimePeriod94);
//        org.junit.Assert.assertNotNull(regularTimePeriod95);
//        org.junit.Assert.assertNotNull(regularTimePeriod97);
//        org.junit.Assert.assertNotNull(date98);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        long long8 = week6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.next();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        java.util.Date date11 = year10.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        int int16 = week14.getYearValue();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date21 = week20.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone23);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date29 = week28.getEnd();
//        int int30 = week28.getYearValue();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date11, timeZone37);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date11);
//        java.util.Calendar calendar41 = null;
//        try {
//            long long42 = week40.getMiddleMillisecond(calendar41);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, 0);
        long long3 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62164080000000L) + "'", long3 == (-62164080000000L));
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        long long8 = week6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.next();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        java.util.Date date11 = year10.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        int int16 = week14.getYearValue();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date21 = week20.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone23);
//        java.lang.Class<?> wildcardClass26 = regularTimePeriod25.getClass();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        long long15 = week6.getFirstMillisecond();
//        java.lang.String str16 = week6.toString();
//        long long17 = week6.getFirstMillisecond();
//        java.util.Calendar calendar18 = null;
//        try {
//            long long19 = week6.getMiddleMillisecond(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        long long3 = week2.getSerialIndex();
        long long4 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-53L) + "'", long3 == (-53L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62199158400001L) + "'", long4 == (-62199158400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        int int6 = week0.getWeek();
//        long long7 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, (-1));
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date5 = week4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getFirstMillisecond();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = week6.getMiddleMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62041910400000L) + "'", long8 == (-62041910400000L));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        long long15 = week6.getFirstMillisecond();
//        java.util.Date date16 = week6.getStart();
//        java.util.Calendar calendar17 = null;
//        try {
//            long long18 = week6.getFirstMillisecond(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date16);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        long long8 = week6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.next();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        java.util.Date date11 = year10.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        int int16 = week14.getYearValue();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date21 = week20.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone23);
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(class26);
//    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        int int6 = week0.getWeek();
//        java.util.Date date7 = week0.getStart();
//        java.lang.Class<?> wildcardClass8 = date7.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, (int) 'a');
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        java.lang.Class<?> wildcardClass15 = date13.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date13);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        long long18 = week17.getSerialIndex();
//        java.util.Date date19 = week17.getEnd();
//        java.lang.Class<?> wildcardClass20 = date19.getClass();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date24 = week23.getEnd();
//        int int25 = week23.getYearValue();
//        java.lang.Class<?> wildcardClass26 = week23.getClass();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date30 = week29.getEnd();
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date30, timeZone31);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date36 = week35.getEnd();
//        int int37 = week35.getYearValue();
//        java.lang.Class<?> wildcardClass38 = week35.getClass();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date42 = week41.getEnd();
//        java.util.TimeZone timeZone43 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date42, timeZone43);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date42, timeZone45);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date19, timeZone45);
//        java.util.Locale locale48 = null;
//        try {
//            org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date13, timeZone45, locale48);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 107031L + "'", long18 == 107031L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.next();
        java.lang.String str7 = week4.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 52, 3" + "'", str7.equals("Week 52, 3"));
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week6.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        long long7 = week0.getFirstMillisecond();
//        java.util.Date date8 = week0.getEnd();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getSerialIndex();
//        java.lang.Class<?> wildcardClass9 = week7.getClass();
//        int int10 = week2.compareTo((java.lang.Object) wildcardClass9);
//        long long11 = week2.getFirstMillisecond();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        int int15 = week2.compareTo((java.lang.Object) year14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week2.next();
//        try {
//            org.jfree.data.time.Year year17 = week2.getYear();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62199763200000L) + "'", long11 == (-62199763200000L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date6 = week5.getEnd();
//        int int7 = week5.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        long long11 = week10.getSerialIndex();
//        java.lang.Class<?> wildcardClass12 = week10.getClass();
//        int int13 = week5.compareTo((java.lang.Object) wildcardClass12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        long long16 = week15.getSerialIndex();
//        java.util.Date date17 = week15.getEnd();
//        java.lang.Class<?> wildcardClass18 = date17.getClass();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date22 = week21.getEnd();
//        int int23 = week21.getYearValue();
//        java.lang.Class<?> wildcardClass24 = week21.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date28 = week27.getEnd();
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date28, timeZone29);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date34 = week33.getEnd();
//        int int35 = week33.getYearValue();
//        java.lang.Class<?> wildcardClass36 = week33.getClass();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date40 = week39.getEnd();
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date40, timeZone41);
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date40, timeZone43);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date17, timeZone43);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date49 = week48.getEnd();
//        int int50 = week48.getYearValue();
//        java.lang.Class<?> wildcardClass51 = week48.getClass();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date55 = week54.getEnd();
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date55);
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date55, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date17, timeZone57);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date2, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = week60.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date4 = week3.getEnd();
//        int int5 = week3.getYearValue();
//        java.lang.Class<?> wildcardClass6 = week3.getClass();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date10 = week9.getEnd();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        long long15 = week14.getSerialIndex();
//        java.util.Date date16 = week14.getEnd();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date20 = week19.getEnd();
//        int int21 = week19.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week19.previous();
//        java.util.Date date23 = week19.getStart();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        long long25 = week24.getSerialIndex();
//        java.lang.Class<?> wildcardClass26 = week24.getClass();
//        int int27 = week19.compareTo((java.lang.Object) wildcardClass26);
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        long long30 = week29.getSerialIndex();
//        java.util.Date date31 = week29.getEnd();
//        java.lang.Class<?> wildcardClass32 = date31.getClass();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date36 = week35.getEnd();
//        int int37 = week35.getYearValue();
//        java.lang.Class<?> wildcardClass38 = week35.getClass();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date42 = week41.getEnd();
//        java.util.TimeZone timeZone43 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date42, timeZone43);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date48 = week47.getEnd();
//        int int49 = week47.getYearValue();
//        java.lang.Class<?> wildcardClass50 = week47.getClass();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date54 = week53.getEnd();
//        java.util.TimeZone timeZone55 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date54, timeZone55);
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date54, timeZone57);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date31, timeZone57);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date63 = week62.getEnd();
//        int int64 = week62.getYearValue();
//        java.lang.Class<?> wildcardClass65 = week62.getClass();
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date69 = week68.getEnd();
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date69);
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date69, timeZone71);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date31, timeZone71);
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date16, timeZone71);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date10, timeZone71);
//        java.util.Locale locale76 = null;
//        try {
//            org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date0, timeZone71, locale76);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 107031L + "'", long15 == 107031L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107031L + "'", long25 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 107031L + "'", long30 == 107031L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass65);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Week week1 = new org.jfree.data.time.Week(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Calendar calendar1 = null;
        try {
            week0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        long long6 = week4.getFirstMillisecond();
        long long7 = week4.getSerialIndex();
        long long8 = week4.getSerialIndex();
        java.lang.Class<?> wildcardClass9 = week4.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62041910400000L) + "'", long6 == (-62041910400000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 211L + "'", long7 == 211L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 211L + "'", long8 == 211L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62199763200000L) + "'", long3 == (-62199763200000L));
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getStart();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        java.lang.String str8 = week7.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 52, 3" + "'", str8.equals("Week 52, 3"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        long long3 = week2.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62199763200000L) + "'", long3 == (-62199763200000L));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 3);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 159L + "'", long4 == 159L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        int int5 = week2.getWeek();
        java.lang.String str6 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 0, -1" + "'", str6.equals("Week 0, -1"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date4 = week3.getEnd();
//        int int5 = week3.getYearValue();
//        java.lang.Class<?> wildcardClass6 = week3.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        long long9 = week7.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.next();
//        org.jfree.data.time.Year year11 = week7.getYear();
//        java.util.Date date12 = year11.getStart();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date16 = week15.getEnd();
//        int int17 = week15.getYearValue();
//        java.lang.Class<?> wildcardClass18 = week15.getClass();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date22 = week21.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date12, timeZone24);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date30 = week29.getEnd();
//        int int31 = week29.getYearValue();
//        java.lang.Class<?> wildcardClass32 = week29.getClass();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date36 = week35.getEnd();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date36);
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date36, timeZone38);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date12, timeZone38);
//        java.util.Locale locale41 = null;
//        try {
//            org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date0, timeZone38, locale41);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 12);
        long long3 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61789406400001L) + "'", long3 == (-61789406400001L));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) ' ', 100);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        java.lang.Class<?> wildcardClass3 = date2.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        long long7 = week5.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.next();
//        long long9 = week5.getFirstMillisecond();
//        int int10 = week5.getWeek();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week5.equals((java.lang.Object) week11);
//        java.lang.String str15 = week11.toString();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        long long17 = week16.getSerialIndex();
//        java.util.Date date18 = week16.getEnd();
//        boolean boolean19 = week11.equals((java.lang.Object) date18);
//        java.lang.Class<?> wildcardClass20 = date18.getClass();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date18, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18);
//        java.lang.Class<?> wildcardClass24 = date18.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 24, 2019" + "'", str15.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 107031L + "'", long17 == 107031L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
        java.util.Calendar calendar6 = null;
        try {
            week5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date6 = week5.getEnd();
//        int int7 = week5.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        long long11 = week10.getSerialIndex();
//        java.lang.Class<?> wildcardClass12 = week10.getClass();
//        int int13 = week5.compareTo((java.lang.Object) wildcardClass12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        long long16 = week15.getSerialIndex();
//        java.util.Date date17 = week15.getEnd();
//        java.lang.Class<?> wildcardClass18 = date17.getClass();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date22 = week21.getEnd();
//        int int23 = week21.getYearValue();
//        java.lang.Class<?> wildcardClass24 = week21.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date28 = week27.getEnd();
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date28, timeZone29);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date34 = week33.getEnd();
//        int int35 = week33.getYearValue();
//        java.lang.Class<?> wildcardClass36 = week33.getClass();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date40 = week39.getEnd();
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date40, timeZone41);
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date40, timeZone43);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date17, timeZone43);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date49 = week48.getEnd();
//        int int50 = week48.getYearValue();
//        java.lang.Class<?> wildcardClass51 = week48.getClass();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date55 = week54.getEnd();
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date55);
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date55, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date17, timeZone57);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date2, timeZone57);
//        long long61 = week60.getMiddleMillisecond();
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date65 = week64.getEnd();
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date65);
//        java.util.Date date67 = week66.getEnd();
//        long long68 = week66.getFirstMillisecond();
//        long long69 = week66.getSerialIndex();
//        long long70 = week66.getSerialIndex();
//        java.lang.Class<?> wildcardClass71 = week66.getClass();
//        boolean boolean72 = week60.equals((java.lang.Object) wildcardClass71);
//        java.lang.Class class73 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass71);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560365999999L + "'", long61 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-62041910400000L) + "'", long68 == (-62041910400000L));
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 211L + "'", long69 == 211L);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 211L + "'", long70 == 211L);
//        org.junit.Assert.assertNotNull(wildcardClass71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(class73);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        long long6 = week4.getFirstMillisecond();
        long long7 = week4.getSerialIndex();
        long long8 = week4.getLastMillisecond();
        long long9 = week4.getLastMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week4.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62041910400000L) + "'", long6 == (-62041910400000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 211L + "'", long7 == 211L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62041305600001L) + "'", long8 == (-62041305600001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62041305600001L) + "'", long9 == (-62041305600001L));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        long long6 = week4.getFirstMillisecond();
        long long7 = week4.getSerialIndex();
        long long8 = week4.getSerialIndex();
        int int9 = week4.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62041910400000L) + "'", long6 == (-62041910400000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 211L + "'", long7 == 211L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 211L + "'", long8 == 211L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.lang.String str4 = week0.toString();
//        long long5 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) (short) -1);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date6 = week5.getEnd();
//        int int7 = week5.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        long long11 = week10.getSerialIndex();
//        java.lang.Class<?> wildcardClass12 = week10.getClass();
//        int int13 = week5.compareTo((java.lang.Object) wildcardClass12);
//        long long14 = week5.getFirstMillisecond();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        int int16 = week15.getWeek();
//        org.jfree.data.time.Year year17 = week15.getYear();
//        int int18 = week5.compareTo((java.lang.Object) year17);
//        int int20 = week5.compareTo((java.lang.Object) 12);
//        try {
//            int int21 = week2.compareTo((java.lang.Object) week5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62199763200000L) + "'", long14 == (-62199763200000L));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        java.util.Date date7 = year6.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 100, year6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(24, year10);
//        long long12 = week11.getLastMillisecond();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week11.getFirstMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = week0.equals((java.lang.Object) wildcardClass11);
//        java.lang.Object obj20 = null;
//        int int21 = week0.compareTo(obj20);
//        int int22 = week0.getWeek();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) (byte) 10, 24);
//        boolean boolean26 = week0.equals((java.lang.Object) 24);
//        java.lang.Object obj27 = null;
//        boolean boolean28 = week0.equals(obj27);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 24 + "'", int22 == 24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str8 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        java.util.Date date7 = year6.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(0, year6);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 100, year6);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        long long4 = week2.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-53L) + "'", long4 == (-53L));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        int int5 = week2.getWeek();
        int int7 = week2.compareTo((java.lang.Object) (-1.0f));
        try {
            org.jfree.data.time.Year year8 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date9 = week8.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
        java.lang.Class<?> wildcardClass13 = week12.getClass();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getStart();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getSerialIndex();
//        java.lang.Class<?> wildcardClass9 = week7.getClass();
//        int int10 = week2.compareTo((java.lang.Object) wildcardClass9);
//        try {
//            org.jfree.data.time.Year year11 = week2.getYear();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        long long6 = week4.getFirstMillisecond();
        long long7 = week4.getSerialIndex();
        long long8 = week4.getSerialIndex();
        long long9 = week4.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62041910400000L) + "'", long6 == (-62041910400000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 211L + "'", long7 == 211L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 211L + "'", long8 == 211L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62041608000001L) + "'", long9 == (-62041608000001L));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        java.lang.Object obj4 = null;
        int int5 = week2.compareTo(obj4);
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test168");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.lang.Class<?> wildcardClass3 = week2.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        long long6 = week5.getSerialIndex();
//        java.lang.Class<?> wildcardClass7 = week5.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date11 = week10.getEnd();
//        int int12 = week10.getYearValue();
//        java.lang.Class<?> wildcardClass13 = week10.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date17 = week16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date23 = week22.getEnd();
//        int int24 = week22.getYearValue();
//        java.lang.Class<?> wildcardClass25 = week22.getClass();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date29 = week28.getEnd();
//        java.util.TimeZone timeZone30 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date29, timeZone32);
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date29, timeZone34);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        long long37 = week36.getSerialIndex();
//        java.util.Date date38 = week36.getEnd();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date42 = week41.getEnd();
//        int int43 = week41.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week41.previous();
//        java.util.Date date45 = week41.getStart();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        long long47 = week46.getSerialIndex();
//        java.lang.Class<?> wildcardClass48 = week46.getClass();
//        int int49 = week41.compareTo((java.lang.Object) wildcardClass48);
//        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        long long52 = week51.getSerialIndex();
//        java.util.Date date53 = week51.getEnd();
//        java.lang.Class<?> wildcardClass54 = date53.getClass();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date58 = week57.getEnd();
//        int int59 = week57.getYearValue();
//        java.lang.Class<?> wildcardClass60 = week57.getClass();
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date64 = week63.getEnd();
//        java.util.TimeZone timeZone65 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date64, timeZone65);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date70 = week69.getEnd();
//        int int71 = week69.getYearValue();
//        java.lang.Class<?> wildcardClass72 = week69.getClass();
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date76 = week75.getEnd();
//        java.util.TimeZone timeZone77 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass72, date76, timeZone77);
//        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date76, timeZone79);
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date53, timeZone79);
//        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date85 = week84.getEnd();
//        int int86 = week84.getYearValue();
//        java.lang.Class<?> wildcardClass87 = week84.getClass();
//        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date91 = week90.getEnd();
//        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(date91);
//        java.util.TimeZone timeZone93 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass87, date91, timeZone93);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date53, timeZone93);
//        org.jfree.data.time.Week week96 = new org.jfree.data.time.Week(date38, timeZone93);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date29, timeZone93);
//        java.lang.Class<?> wildcardClass98 = timeZone93.getClass();
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 107031L + "'", long37 == 107031L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 107031L + "'", long47 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(class50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 107031L + "'", long52 == 107031L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass72);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(timeZone79);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertNotNull(date85);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-1) + "'", int86 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass87);
//        org.junit.Assert.assertNotNull(date91);
//        org.junit.Assert.assertNotNull(timeZone93);
//        org.junit.Assert.assertNotNull(regularTimePeriod94);
//        org.junit.Assert.assertNotNull(regularTimePeriod95);
//        org.junit.Assert.assertNotNull(regularTimePeriod97);
//        org.junit.Assert.assertNotNull(wildcardClass98);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week1.next();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.util.Date date6 = year5.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year5);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week7.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        java.lang.Class<?> wildcardClass15 = date13.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date13);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date20 = week19.getEnd();
//        int int21 = week19.getYearValue();
//        java.lang.Class<?> wildcardClass22 = week19.getClass();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
//        long long25 = week23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week23.next();
//        org.jfree.data.time.Year year27 = week23.getYear();
//        java.util.Date date28 = year27.getStart();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date32 = week31.getEnd();
//        int int33 = week31.getYearValue();
//        java.lang.Class<?> wildcardClass34 = week31.getClass();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date38 = week37.getEnd();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date38);
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date28, timeZone40);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date46 = week45.getEnd();
//        int int47 = week45.getYearValue();
//        java.lang.Class<?> wildcardClass48 = week45.getClass();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date52 = week51.getEnd();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date52);
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date52, timeZone54);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date28, timeZone54);
//        java.lang.Class<?> wildcardClass57 = timeZone54.getClass();
//        java.util.Locale locale58 = null;
//        try {
//            org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date13, timeZone54, locale58);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560063600000L + "'", long25 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getMiddleMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, 0);
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62161660800001L) + "'", long3 == (-62161660800001L));
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        long long15 = week6.getFirstMillisecond();
//        long long16 = week6.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560365999999L + "'", long16 == 1560365999999L);
//    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        int int6 = week0.getWeek();
//        java.util.Date date7 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.previous();
//        java.util.Date date9 = regularTimePeriod8.getStart();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 6);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (6) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date16 = week15.getEnd();
//        int int17 = week15.getYearValue();
//        java.lang.Class<?> wildcardClass18 = week15.getClass();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date22 = week21.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone24);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date29 = week28.getEnd();
//        int int30 = week28.getYearValue();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date22, timeZone37);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date43 = week42.getEnd();
//        int int44 = week42.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week42.previous();
//        java.util.Date date46 = week42.getStart();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        long long48 = week47.getSerialIndex();
//        java.lang.Class<?> wildcardClass49 = week47.getClass();
//        int int50 = week42.compareTo((java.lang.Object) wildcardClass49);
//        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass49);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        long long53 = week52.getSerialIndex();
//        java.util.Date date54 = week52.getEnd();
//        java.lang.Class<?> wildcardClass55 = date54.getClass();
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date59 = week58.getEnd();
//        int int60 = week58.getYearValue();
//        java.lang.Class<?> wildcardClass61 = week58.getClass();
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date65 = week64.getEnd();
//        java.util.TimeZone timeZone66 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date65, timeZone66);
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date71 = week70.getEnd();
//        int int72 = week70.getYearValue();
//        java.lang.Class<?> wildcardClass73 = week70.getClass();
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date77 = week76.getEnd();
//        java.util.TimeZone timeZone78 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date77, timeZone78);
//        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date77, timeZone80);
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date54, timeZone80);
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date86 = week85.getEnd();
//        int int87 = week85.getYearValue();
//        java.lang.Class<?> wildcardClass88 = week85.getClass();
//        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date92 = week91.getEnd();
//        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date92);
//        java.util.TimeZone timeZone94 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass88, date92, timeZone94);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date54, timeZone94);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date22, timeZone94);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 107031L + "'", long48 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(class51);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 107031L + "'", long53 == 107031L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass73);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(timeZone80);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-1) + "'", int87 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass88);
//        org.junit.Assert.assertNotNull(date92);
//        org.junit.Assert.assertNotNull(timeZone94);
//        org.junit.Assert.assertNotNull(regularTimePeriod95);
//        org.junit.Assert.assertNotNull(regularTimePeriod96);
//        org.junit.Assert.assertNull(regularTimePeriod97);
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int3 = week0.getYearValue();
//        long long4 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year5);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, 0);
        long long3 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) (short) -1);
        java.util.Date date3 = week2.getStart();
        int int4 = week2.getWeek();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, 11);
        long long3 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61815110400000L) + "'", long3 == (-61815110400000L));
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = week0.equals((java.lang.Object) wildcardClass11);
//        java.util.Date date20 = week0.getEnd();
//        long long21 = week0.getSerialIndex();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        int int23 = week22.getWeek();
//        org.jfree.data.time.Year year24 = week22.getYear();
//        int int25 = week22.getYearValue();
//        long long26 = week22.getFirstMillisecond();
//        int int27 = week0.compareTo((java.lang.Object) week22);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 107031L + "'", long21 == 107031L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 24 + "'", int23 == 24);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560063600000L + "'", long26 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray8);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        java.util.Date date6 = week0.getStart();
//        java.lang.Object obj7 = null;
//        int int8 = week0.compareTo(obj7);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        long long8 = week6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.next();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        java.util.Date date11 = year10.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        int int16 = week14.getYearValue();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date21 = week20.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone23);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date29 = week28.getEnd();
//        int int30 = week28.getYearValue();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date11, timeZone37);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.previous();
//        long long43 = week41.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week41.next();
//        long long45 = week41.getSerialIndex();
//        int int46 = week41.getWeek();
//        int int47 = week41.getWeek();
//        java.util.Date date48 = week41.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week41.previous();
//        int int50 = week40.compareTo((java.lang.Object) regularTimePeriod49);
//        java.util.Date date51 = week40.getStart();
//        long long52 = week40.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560063600000L + "'", long43 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 107031L + "'", long45 == 107031L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 24 + "'", int46 == 24);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 24 + "'", int47 == 24);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-22) + "'", int50 == (-22));
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1546761599999L + "'", long52 == 1546761599999L);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 6);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        java.lang.Class<?> wildcardClass3 = date2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date7 = week6.getEnd();
//        int int8 = week6.getYearValue();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
//        long long12 = week10.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week10.next();
//        org.jfree.data.time.Year year14 = week10.getYear();
//        java.util.Date date15 = year14.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date19 = week18.getEnd();
//        int int20 = week18.getYearValue();
//        java.lang.Class<?> wildcardClass21 = week18.getClass();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date25 = week24.getEnd();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date25, timeZone27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone27);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date33 = week32.getEnd();
//        int int34 = week32.getYearValue();
//        java.lang.Class<?> wildcardClass35 = week32.getClass();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date39 = week38.getEnd();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date39);
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date39, timeZone41);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date15, timeZone41);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date2, timeZone41);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date2);
//        java.util.Date date46 = week45.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date46);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 52, 3");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', (int) (byte) 10);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int3 = week0.getYearValue();
//        java.util.Date date4 = week0.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 12);
        long long3 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 636L + "'", long3 == 636L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        long long6 = week4.getFirstMillisecond();
        long long7 = week4.getSerialIndex();
        long long8 = week4.getLastMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            week4.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62041910400000L) + "'", long6 == (-62041910400000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 211L + "'", long7 == 211L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62041305600001L) + "'", long8 == (-62041305600001L));
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        java.util.Calendar calendar3 = null;
//        try {
//            week0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        java.lang.String str5 = week0.toString();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getStart();
        long long7 = week2.getSerialIndex();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str13 = timePeriodFormatException11.toString();
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException11.getSuppressed();
        int int15 = week2.compareTo((java.lang.Object) timePeriodFormatException11);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-53L) + "'", long7 == (-53L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        long long15 = week6.getFirstMillisecond();
//        java.lang.String str16 = week6.toString();
//        java.lang.String str17 = week6.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str8 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException10.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray22);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        java.util.Calendar calendar11 = null;
//        try {
//            week6.peg(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = week0.equals((java.lang.Object) wildcardClass11);
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = week0.getLastMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str8 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
//        long long5 = week3.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.next();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        java.util.Date date8 = year7.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 100, year7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(24, year11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(7, year11);
//        boolean boolean15 = week13.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = week0.equals((java.lang.Object) wildcardClass11);
//        java.util.Date date20 = week0.getEnd();
//        long long21 = week0.getSerialIndex();
//        java.util.Date date22 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 107031L + "'", long21 == 107031L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        int int10 = week6.getWeek();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = week6.getMiddleMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        long long14 = week13.getSerialIndex();
//        java.util.Date date15 = week13.getEnd();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date19 = week18.getEnd();
//        int int20 = week18.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week18.previous();
//        java.util.Date date22 = week18.getStart();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        long long24 = week23.getSerialIndex();
//        java.lang.Class<?> wildcardClass25 = week23.getClass();
//        int int26 = week18.compareTo((java.lang.Object) wildcardClass25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        long long29 = week28.getSerialIndex();
//        java.util.Date date30 = week28.getEnd();
//        java.lang.Class<?> wildcardClass31 = date30.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        int int36 = week34.getYearValue();
//        java.lang.Class<?> wildcardClass37 = week34.getClass();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date41 = week40.getEnd();
//        java.util.TimeZone timeZone42 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date41, timeZone42);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date47 = week46.getEnd();
//        int int48 = week46.getYearValue();
//        java.lang.Class<?> wildcardClass49 = week46.getClass();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date53 = week52.getEnd();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date53, timeZone54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date53, timeZone56);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date30, timeZone56);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date62 = week61.getEnd();
//        int int63 = week61.getYearValue();
//        java.lang.Class<?> wildcardClass64 = week61.getClass();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date68 = week67.getEnd();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date68);
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date68, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date30, timeZone70);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date15, timeZone70);
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date9, timeZone70);
//        long long75 = week74.getSerialIndex();
//        java.util.Calendar calendar76 = null;
//        try {
//            long long77 = week74.getFirstMillisecond(calendar76);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 107031L + "'", long14 == 107031L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 107031L + "'", long24 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 107031L + "'", long29 == 107031L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 211L + "'", long75 == 211L);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 0, -1");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) ' ', 0);
        long long3 = week2.getMiddleMillisecond();
        int int4 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62148657600001L) + "'", long3 == (-62148657600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        int int5 = week2.getWeek();
        int int6 = week2.getYearValue();
        java.lang.Class<?> wildcardClass7 = week2.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Date date5 = week0.getEnd();
//        int int7 = week0.compareTo((java.lang.Object) (-62199763200000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        long long6 = week2.getFirstMillisecond();
//        int int7 = week2.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        long long9 = week8.getSerialIndex();
//        java.util.Date date10 = week8.getEnd();
//        boolean boolean11 = week2.equals((java.lang.Object) week8);
//        java.lang.String str12 = week8.toString();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        long long14 = week13.getSerialIndex();
//        java.util.Date date15 = week13.getEnd();
//        boolean boolean16 = week8.equals((java.lang.Object) date15);
//        long long17 = week8.getFirstMillisecond();
//        java.lang.String str18 = week8.toString();
//        boolean boolean19 = week0.equals((java.lang.Object) str18);
//        int int20 = week0.getYearValue();
//        java.lang.Object obj21 = null;
//        int int22 = week0.compareTo(obj21);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 107031L + "'", long14 == 107031L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 24, 2019" + "'", str18.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) (short) -1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
//        long long5 = week3.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.next();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        int int8 = week2.compareTo((java.lang.Object) week3);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        long long12 = week11.getFirstMillisecond();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week2.equals((java.lang.Object) date13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13);
//        java.lang.Class<?> wildcardClass16 = date13.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-2020) + "'", int8 == (-2020));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62199763200000L) + "'", long12 == (-62199763200000L));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date5 = week4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getFirstMillisecond();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        long long10 = week6.getMiddleMillisecond();
//        try {
//            org.jfree.data.time.Year year11 = week6.getYear();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62041910400000L) + "'", long8 == (-62041910400000L));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62041608000001L) + "'", long10 == (-62041608000001L));
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        boolean boolean7 = week0.equals((java.lang.Object) regularTimePeriod6);
//        long long8 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int3 = week0.getYearValue();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Date date5 = week0.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        long long6 = week2.getSerialIndex();
//        int int7 = week2.getWeek();
//        org.jfree.data.time.Year year8 = week2.getYear();
//        java.util.Date date9 = year8.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(12, year8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(0, year8);
//        java.lang.Class<?> wildcardClass12 = year8.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str13 = timePeriodFormatException6.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable throwable15 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date16 = week15.getEnd();
//        int int17 = week15.getYearValue();
//        java.lang.Class<?> wildcardClass18 = week15.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
//        long long21 = week19.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week19.next();
//        org.jfree.data.time.Year year23 = week19.getYear();
//        java.util.Date date24 = year23.getStart();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date28 = week27.getEnd();
//        int int29 = week27.getYearValue();
//        java.lang.Class<?> wildcardClass30 = week27.getClass();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date34 = week33.getEnd();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date34);
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date34, timeZone36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date24, timeZone36);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date42 = week41.getEnd();
//        int int43 = week41.getYearValue();
//        java.lang.Class<?> wildcardClass44 = week41.getClass();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date48 = week47.getEnd();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date48);
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date48, timeZone50);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date24, timeZone50);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date24);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        long long55 = week54.getSerialIndex();
//        java.lang.Class<?> wildcardClass56 = week54.getClass();
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date60 = week59.getEnd();
//        int int61 = week59.getYearValue();
//        java.lang.Class<?> wildcardClass62 = week59.getClass();
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date66 = week65.getEnd();
//        java.util.TimeZone timeZone67 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass62, date66, timeZone67);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date72 = week71.getEnd();
//        int int73 = week71.getYearValue();
//        java.lang.Class<?> wildcardClass74 = week71.getClass();
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date78 = week77.getEnd();
//        java.util.TimeZone timeZone79 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass74, date78, timeZone79);
//        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass62, date78, timeZone81);
//        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date78, timeZone83);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date24, timeZone83);
//        java.lang.Class<?> wildcardClass86 = timeZone83.getClass();
//        java.lang.Class class87 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass86);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560063600000L + "'", long21 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 107031L + "'", long55 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass74);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNull(regularTimePeriod80);
//        org.junit.Assert.assertNotNull(timeZone81);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(timeZone83);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertNotNull(regularTimePeriod85);
//        org.junit.Assert.assertNotNull(wildcardClass86);
//        org.junit.Assert.assertNotNull(class87);
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        int int11 = week6.compareTo((java.lang.Object) 'a');
//        int int13 = week6.compareTo((java.lang.Object) (-61789406400001L));
//        int int14 = week6.getWeek();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        long long15 = week6.getFirstMillisecond();
//        java.util.Date date16 = week6.getStart();
//        java.lang.Class<?> wildcardClass17 = date16.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = week0.equals((java.lang.Object) wildcardClass11);
//        java.lang.Object obj20 = null;
//        int int21 = week0.compareTo(obj20);
//        int int22 = week0.getWeek();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) (byte) 10, 24);
//        boolean boolean26 = week0.equals((java.lang.Object) 24);
//        java.util.Date date27 = week0.getStart();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 24 + "'", int22 == 24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(date27);
//    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week1.next();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(24, year5);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        long long6 = week4.getFirstMillisecond();
        java.lang.Class<?> wildcardClass7 = week4.getClass();
        java.util.Calendar calendar8 = null;
        try {
            week4.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62041910400000L) + "'", long6 == (-62041910400000L));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) (short) -1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
//        long long5 = week3.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.next();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        int int8 = week2.compareTo((java.lang.Object) week3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week3.previous();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = week3.getLastMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-2020) + "'", int8 == (-2020));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 0, -1");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException8.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
        long long8 = week4.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62041608000001L) + "'", long8 == (-62041608000001L));
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        long long8 = week6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.next();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        java.util.Date date11 = year10.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        int int16 = week14.getYearValue();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date21 = week20.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone23);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date29 = week28.getEnd();
//        int int30 = week28.getYearValue();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date11, timeZone37);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.previous();
//        long long43 = week41.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week41.next();
//        long long45 = week41.getSerialIndex();
//        int int46 = week41.getWeek();
//        int int47 = week41.getWeek();
//        java.util.Date date48 = week41.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week41.previous();
//        int int50 = week40.compareTo((java.lang.Object) regularTimePeriod49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = week40.next();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560063600000L + "'", long43 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 107031L + "'", long45 == 107031L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 24 + "'", int46 == 24);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 24 + "'", int47 == 24);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-22) + "'", int50 == (-22));
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        java.util.Date date7 = week0.getStart();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getSerialIndex();
//        java.util.Date date5 = week0.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        java.lang.Class<?> wildcardClass9 = date8.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
//        long long13 = week11.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week11.next();
//        long long15 = week11.getFirstMillisecond();
//        int int16 = week11.getWeek();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        long long18 = week17.getSerialIndex();
//        java.util.Date date19 = week17.getEnd();
//        boolean boolean20 = week11.equals((java.lang.Object) week17);
//        java.lang.String str21 = week17.toString();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        long long23 = week22.getSerialIndex();
//        java.util.Date date24 = week22.getEnd();
//        boolean boolean25 = week17.equals((java.lang.Object) date24);
//        java.lang.Class<?> wildcardClass26 = date24.getClass();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date24, timeZone27);
//        java.lang.Class<?> wildcardClass29 = timeZone27.getClass();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date5, timeZone27);
//        java.util.Calendar calendar31 = null;
//        try {
//            long long32 = week30.getMiddleMillisecond(calendar31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 107031L + "'", long18 == 107031L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 24, 2019" + "'", str21.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 107031L + "'", long23 == 107031L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-2020), 6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date4 = week3.getEnd();
//        int int5 = week3.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.previous();
//        java.util.Date date7 = week3.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        long long9 = week8.getSerialIndex();
//        java.lang.Class<?> wildcardClass10 = week8.getClass();
//        int int11 = week3.compareTo((java.lang.Object) wildcardClass10);
//        long long12 = week3.getFirstMillisecond();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        int int14 = week13.getWeek();
//        org.jfree.data.time.Year year15 = week13.getYear();
//        int int16 = week3.compareTo((java.lang.Object) year15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) (byte) 1, year15);
//        java.util.Calendar calendar18 = null;
//        try {
//            long long19 = week17.getFirstMillisecond(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62199763200000L) + "'", long12 == (-62199763200000L));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getSerialIndex();
//        java.lang.Class<?> wildcardClass9 = week7.getClass();
//        int int10 = week2.compareTo((java.lang.Object) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        long long13 = week12.getSerialIndex();
//        java.util.Date date14 = week12.getEnd();
//        java.lang.Class<?> wildcardClass15 = date14.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date19 = week18.getEnd();
//        int int20 = week18.getYearValue();
//        java.lang.Class<?> wildcardClass21 = week18.getClass();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date25 = week24.getEnd();
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date25, timeZone26);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date31 = week30.getEnd();
//        int int32 = week30.getYearValue();
//        java.lang.Class<?> wildcardClass33 = week30.getClass();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date37 = week36.getEnd();
//        java.util.TimeZone timeZone38 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date37, timeZone38);
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date37, timeZone40);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date14, timeZone40);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date46 = week45.getEnd();
//        int int47 = week45.getYearValue();
//        java.lang.Class<?> wildcardClass48 = week45.getClass();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date52 = week51.getEnd();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date52);
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date52, timeZone54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone54);
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
//        long long58 = week57.getSerialIndex();
//        java.util.Date date59 = week57.getEnd();
//        java.lang.Class<?> wildcardClass60 = date59.getClass();
//        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass62 = timeZone61.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date59, timeZone61);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107031L + "'", long13 == 107031L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 107031L + "'", long58 == 107031L);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertNotNull(timeZone61);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) (short) -1);
        java.util.Date date3 = week2.getStart();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date5 = week4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getFirstMillisecond();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = week6.getLastMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62041910400000L) + "'", long8 == (-62041910400000L));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) ' ', 0);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 7);
        int int3 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        java.util.Date date5 = week4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        java.lang.Class<?> wildcardClass9 = date8.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
//        long long13 = week11.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week11.next();
//        long long15 = week11.getFirstMillisecond();
//        int int16 = week11.getWeek();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        long long18 = week17.getSerialIndex();
//        java.util.Date date19 = week17.getEnd();
//        boolean boolean20 = week11.equals((java.lang.Object) week17);
//        java.lang.String str21 = week17.toString();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        long long23 = week22.getSerialIndex();
//        java.util.Date date24 = week22.getEnd();
//        boolean boolean25 = week17.equals((java.lang.Object) date24);
//        java.lang.Class<?> wildcardClass26 = date24.getClass();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date24, timeZone27);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date5, timeZone27);
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.util.Locale locale31 = null;
//        try {
//            org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date5, timeZone30, locale31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 107031L + "'", long18 == 107031L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 24, 2019" + "'", str21.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 107031L + "'", long23 == 107031L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(timeZone30);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 0, -1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.String str5 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 0, -1" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: Week 0, -1"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        long long5 = week2.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            week2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-53L) + "'", long5 == (-53L));
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week1.next();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.util.Date date6 = year5.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year5);
//        long long8 = year5.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
//    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = week0.equals((java.lang.Object) wildcardClass11);
//        java.lang.Object obj20 = null;
//        int int21 = week0.compareTo(obj20);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date25 = week24.getEnd();
//        int int26 = week24.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week24.previous();
//        java.util.Date date28 = week24.getStart();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        long long30 = week29.getSerialIndex();
//        java.lang.Class<?> wildcardClass31 = week29.getClass();
//        int int32 = week24.compareTo((java.lang.Object) wildcardClass31);
//        boolean boolean33 = week0.equals((java.lang.Object) week24);
//        long long34 = week24.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 107031L + "'", long30 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-53L) + "'", long34 == (-53L));
//    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getSerialIndex();
//        long long6 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        java.util.Calendar calendar7 = null;
//        try {
//            week0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, (int) (short) -1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) ' ', 0);
        long long3 = week2.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62148657600001L) + "'", long3 == (-62148657600001L));
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        java.lang.Object obj4 = null;
//        int int5 = week2.compareTo(obj4);
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getSerialIndex();
//        java.util.Date date9 = week7.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date13 = week12.getEnd();
//        int int14 = week12.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week12.previous();
//        java.util.Date date16 = week12.getStart();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        long long18 = week17.getSerialIndex();
//        java.lang.Class<?> wildcardClass19 = week17.getClass();
//        int int20 = week12.compareTo((java.lang.Object) wildcardClass19);
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        long long23 = week22.getSerialIndex();
//        java.util.Date date24 = week22.getEnd();
//        java.lang.Class<?> wildcardClass25 = date24.getClass();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date29 = week28.getEnd();
//        int int30 = week28.getYearValue();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        java.util.TimeZone timeZone36 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone36);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date41 = week40.getEnd();
//        int int42 = week40.getYearValue();
//        java.lang.Class<?> wildcardClass43 = week40.getClass();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date47 = week46.getEnd();
//        java.util.TimeZone timeZone48 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date47, timeZone48);
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date47, timeZone50);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date24, timeZone50);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date56 = week55.getEnd();
//        int int57 = week55.getYearValue();
//        java.lang.Class<?> wildcardClass58 = week55.getClass();
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date62 = week61.getEnd();
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date62);
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date62, timeZone64);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date24, timeZone64);
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date9, timeZone64);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date6, timeZone64);
//        long long69 = week68.getLastMillisecond();
//        long long70 = week68.getSerialIndex();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 107031L + "'", long18 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 107031L + "'", long23 == 107031L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-62041305600001L) + "'", long69 == (-62041305600001L));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 211L + "'", long70 == 211L);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str8 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.String str17 = timePeriodFormatException10.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.String str27 = timePeriodFormatException20.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException31);
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException29.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        java.lang.Throwable[] throwableArray42 = timePeriodFormatException20.getSuppressed();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(throwableArray42);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date8 = week7.getEnd();
//        int int9 = week7.getYearValue();
//        java.lang.Class<?> wildcardClass10 = week7.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        boolean boolean12 = week4.equals((java.lang.Object) wildcardClass10);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date16 = week15.getEnd();
//        int int17 = week15.getYearValue();
//        java.lang.Class<?> wildcardClass18 = week15.getClass();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date22 = week21.getEnd();
//        java.util.TimeZone timeZone23 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone23);
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date29 = week28.getEnd();
//        int int30 = week28.getYearValue();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
//        long long34 = week32.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week32.next();
//        org.jfree.data.time.Year year36 = week32.getYear();
//        java.util.Date date37 = year36.getStart();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date41 = week40.getEnd();
//        int int42 = week40.getYearValue();
//        java.lang.Class<?> wildcardClass43 = week40.getClass();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date47 = week46.getEnd();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date47);
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date47, timeZone49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date37, timeZone49);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date55 = week54.getEnd();
//        int int56 = week54.getYearValue();
//        java.lang.Class<?> wildcardClass57 = week54.getClass();
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date61 = week60.getEnd();
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date61);
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date61, timeZone63);
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date37, timeZone63);
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date37);
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        long long68 = week67.getSerialIndex();
//        java.lang.Class<?> wildcardClass69 = week67.getClass();
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date73 = week72.getEnd();
//        int int74 = week72.getYearValue();
//        java.lang.Class<?> wildcardClass75 = week72.getClass();
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date79 = week78.getEnd();
//        java.util.TimeZone timeZone80 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass75, date79, timeZone80);
//        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date85 = week84.getEnd();
//        int int86 = week84.getYearValue();
//        java.lang.Class<?> wildcardClass87 = week84.getClass();
//        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date91 = week90.getEnd();
//        java.util.TimeZone timeZone92 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass87, date91, timeZone92);
//        java.util.TimeZone timeZone94 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass75, date91, timeZone94);
//        java.util.TimeZone timeZone96 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date91, timeZone96);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod98 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date37, timeZone96);
//        int int99 = week4.compareTo((java.lang.Object) date37);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560063600000L + "'", long34 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 107031L + "'", long68 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass69);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass75);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(date85);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-1) + "'", int86 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass87);
//        org.junit.Assert.assertNotNull(date91);
//        org.junit.Assert.assertNull(regularTimePeriod93);
//        org.junit.Assert.assertNotNull(timeZone94);
//        org.junit.Assert.assertNotNull(regularTimePeriod95);
//        org.junit.Assert.assertNotNull(timeZone96);
//        org.junit.Assert.assertNotNull(regularTimePeriod97);
//        org.junit.Assert.assertNotNull(regularTimePeriod98);
//        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 1 + "'", int99 == 1);
//    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int3 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        long long14 = week13.getSerialIndex();
//        java.util.Date date15 = week13.getEnd();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date19 = week18.getEnd();
//        int int20 = week18.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week18.previous();
//        java.util.Date date22 = week18.getStart();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        long long24 = week23.getSerialIndex();
//        java.lang.Class<?> wildcardClass25 = week23.getClass();
//        int int26 = week18.compareTo((java.lang.Object) wildcardClass25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        long long29 = week28.getSerialIndex();
//        java.util.Date date30 = week28.getEnd();
//        java.lang.Class<?> wildcardClass31 = date30.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        int int36 = week34.getYearValue();
//        java.lang.Class<?> wildcardClass37 = week34.getClass();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date41 = week40.getEnd();
//        java.util.TimeZone timeZone42 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date41, timeZone42);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date47 = week46.getEnd();
//        int int48 = week46.getYearValue();
//        java.lang.Class<?> wildcardClass49 = week46.getClass();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date53 = week52.getEnd();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date53, timeZone54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date53, timeZone56);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date30, timeZone56);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date62 = week61.getEnd();
//        int int63 = week61.getYearValue();
//        java.lang.Class<?> wildcardClass64 = week61.getClass();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date68 = week67.getEnd();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date68);
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date68, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date30, timeZone70);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date15, timeZone70);
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date9, timeZone70);
//        java.lang.Class<?> wildcardClass75 = week74.getClass();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 107031L + "'", long14 == 107031L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 107031L + "'", long24 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 107031L + "'", long29 == 107031L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(wildcardClass75);
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getSerialIndex();
//        java.lang.Class<?> wildcardClass9 = week7.getClass();
//        int int10 = week2.compareTo((java.lang.Object) wildcardClass9);
//        java.lang.Class<?> wildcardClass11 = week2.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week2.next();
//        try {
//            org.jfree.data.time.Year year13 = week2.getYear();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        long long3 = week2.getSerialIndex();
        long long4 = week2.getLastMillisecond();
        int int5 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-53L) + "'", long3 == (-53L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62199158400001L) + "'", long4 == (-62199158400001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, 12);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = week0.equals((java.lang.Object) wildcardClass11);
//        java.util.Date date20 = week0.getEnd();
//        long long21 = week0.getSerialIndex();
//        java.util.Date date22 = week0.getEnd();
//        java.lang.Class<?> wildcardClass23 = week0.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 107031L + "'", long21 == 107031L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getSerialIndex();
//        java.lang.Class<?> wildcardClass9 = week7.getClass();
//        int int10 = week2.compareTo((java.lang.Object) wildcardClass9);
//        long long11 = week2.getFirstMillisecond();
//        long long12 = week2.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62199763200000L) + "'", long11 == (-62199763200000L));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62199460800001L) + "'", long12 == (-62199460800001L));
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date10 = week9.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
//        java.util.Date date12 = week11.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week11.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week11.previous();
//        java.util.Date date15 = week11.getStart();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        long long17 = week16.getSerialIndex();
//        java.util.Date date18 = week16.getEnd();
//        java.lang.Class<?> wildcardClass19 = date18.getClass();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date23 = week22.getEnd();
//        int int24 = week22.getYearValue();
//        java.lang.Class<?> wildcardClass25 = week22.getClass();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date29 = week28.getEnd();
//        java.util.TimeZone timeZone30 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        int int36 = week34.getYearValue();
//        java.lang.Class<?> wildcardClass37 = week34.getClass();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date41 = week40.getEnd();
//        java.util.TimeZone timeZone42 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date41, timeZone42);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date41, timeZone44);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date18, timeZone44);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date15, timeZone44);
//        java.util.Locale locale48 = null;
//        try {
//            org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date5, timeZone44, locale48);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 107031L + "'", long17 == 107031L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date6 = week5.getEnd();
//        int int7 = week5.getYearValue();
//        java.lang.Class<?> wildcardClass8 = week5.getClass();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date12 = week11.getEnd();
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date18 = week17.getEnd();
//        int int19 = week17.getYearValue();
//        java.lang.Class<?> wildcardClass20 = week17.getClass();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date24 = week23.getEnd();
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date24, timeZone25);
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date24, timeZone27);
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date24, timeZone29);
//        java.lang.Class<?> wildcardClass31 = regularTimePeriod30.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        java.util.Date date5 = week4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        java.lang.Class<?> wildcardClass9 = date8.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
//        long long13 = week11.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week11.next();
//        long long15 = week11.getFirstMillisecond();
//        int int16 = week11.getWeek();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        long long18 = week17.getSerialIndex();
//        java.util.Date date19 = week17.getEnd();
//        boolean boolean20 = week11.equals((java.lang.Object) week17);
//        java.lang.String str21 = week17.toString();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        long long23 = week22.getSerialIndex();
//        java.util.Date date24 = week22.getEnd();
//        boolean boolean25 = week17.equals((java.lang.Object) date24);
//        java.lang.Class<?> wildcardClass26 = date24.getClass();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date24, timeZone27);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date5, timeZone27);
//        long long30 = week29.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 107031L + "'", long18 == 107031L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 24, 2019" + "'", str21.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 107031L + "'", long23 == 107031L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-62041305600001L) + "'", long30 == (-62041305600001L));
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date9 = week8.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date15 = week14.getEnd();
        int int16 = week14.getYearValue();
        java.lang.Class<?> wildcardClass17 = week14.getClass();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date21 = week20.getEnd();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date21, timeZone24);
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize(class26);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertNotNull(class27);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 0, -1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable throwable4 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5);
        java.util.Date date8 = week7.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 0, -1");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        int int6 = week2.getYearValue();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        long long9 = week7.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.next();
//        org.jfree.data.time.Year year11 = week7.getYear();
//        int int12 = week2.compareTo((java.lang.Object) year11);
//        long long13 = year11.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        long long6 = week2.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62199763200000L) + "'", long6 == (-62199763200000L));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) 'a');
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Week 0, -1");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException19.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray23);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        long long15 = week6.getFirstMillisecond();
//        java.util.Date date16 = week6.getStart();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
//        long long19 = week17.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week17.next();
//        long long21 = week17.getSerialIndex();
//        int int22 = week17.getWeek();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date26 = week25.getEnd();
//        int int27 = week25.getYearValue();
//        java.lang.Class<?> wildcardClass28 = week25.getClass();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date32 = week31.getEnd();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date32);
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date32, timeZone34);
//        boolean boolean36 = week17.equals((java.lang.Object) wildcardClass28);
//        boolean boolean37 = week6.equals((java.lang.Object) week17);
//        long long38 = week6.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560063600000L + "'", long19 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 107031L + "'", long21 == 107031L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 24 + "'", int22 == 24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560668399999L + "'", long38 == 1560668399999L);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) (short) -1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
//        long long5 = week3.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.next();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        int int8 = week2.compareTo((java.lang.Object) week3);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        long long12 = week11.getFirstMillisecond();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week2.equals((java.lang.Object) date13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13);
//        long long16 = week15.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-2020) + "'", int8 == (-2020));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62199763200000L) + "'", long12 == (-62199763200000L));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62041305600001L) + "'", long16 == (-62041305600001L));
//    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        long long7 = week0.getFirstMillisecond();
//        int int8 = week0.getYearValue();
//        java.util.Date date9 = week0.getStart();
//        long long10 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560365999999L + "'", long10 == 1560365999999L);
//    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week1.next();
//        long long5 = week1.getSerialIndex();
//        int int6 = week1.getWeek();
//        org.jfree.data.time.Year year7 = week1.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(7, year7);
//        java.util.Calendar calendar9 = null;
//        try {
//            week8.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(year7);
//    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        java.util.Date date6 = week0.getStart();
//        long long7 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        java.lang.String str2 = week0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getFirstMillisecond();
//        int int4 = week0.getYearValue();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date8 = week7.getEnd();
//        int int9 = week7.getYearValue();
//        java.lang.Class<?> wildcardClass10 = week7.getClass();
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
//        boolean boolean13 = week0.equals((java.lang.Object) wildcardClass10);
//        long long14 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560668399999L + "'", long14 == 1560668399999L);
//    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        long long6 = week2.getSerialIndex();
//        int int7 = week2.getWeek();
//        org.jfree.data.time.Year year8 = week2.getYear();
//        java.util.Date date9 = year8.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(12, year8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (byte) 100, year8);
//        java.lang.Object obj12 = null;
//        boolean boolean13 = week11.equals(obj12);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) (short) -1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
//        long long5 = week3.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.next();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        int int8 = week2.compareTo((java.lang.Object) week3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week3.previous();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
//        java.lang.Throwable[] throwableArray15 = timePeriodFormatException11.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
//        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
//        java.lang.String str22 = timePeriodFormatException19.toString();
//        java.lang.Throwable[] throwableArray23 = timePeriodFormatException19.getSuppressed();
//        int int24 = week3.compareTo((java.lang.Object) timePeriodFormatException19);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-2020) + "'", int8 == (-2020));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(throwableArray15);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week1.next();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.util.Date date6 = year5.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year5);
//        java.util.Date date8 = year5.getStart();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        int int5 = week2.getWeek();
        int int7 = week2.compareTo((java.lang.Object) (-1.0f));
        long long8 = week2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62199763200000L) + "'", long8 == (-62199763200000L));
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) (short) -1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
//        long long5 = week3.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.next();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        int int8 = week2.compareTo((java.lang.Object) week3);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        long long12 = week11.getFirstMillisecond();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week2.equals((java.lang.Object) date13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date13);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(0, 1);
//        int int19 = week15.compareTo((java.lang.Object) 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-2020) + "'", int8 == (-2020));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62199763200000L) + "'", long12 == (-62199763200000L));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date4 = week3.getEnd();
//        int int5 = week3.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.previous();
//        java.util.Date date7 = week3.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        long long9 = week8.getSerialIndex();
//        java.lang.Class<?> wildcardClass10 = week8.getClass();
//        int int11 = week3.compareTo((java.lang.Object) wildcardClass10);
//        java.lang.Class<?> wildcardClass12 = week3.getClass();
//        java.util.Date date13 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date17 = week16.getEnd();
//        int int18 = week16.getYearValue();
//        java.lang.Class<?> wildcardClass19 = week16.getClass();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date23 = week22.getEnd();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date23);
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date23, timeZone25);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date30 = week29.getEnd();
//        int int31 = week29.getYearValue();
//        java.lang.Class<?> wildcardClass32 = week29.getClass();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date36 = week35.getEnd();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date36);
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date36, timeZone38);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date23, timeZone38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone38);
//        try {
//            org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date0, timeZone38);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) (short) -1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
//        long long5 = week3.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.next();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        int int8 = week2.compareTo((java.lang.Object) week3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week3.previous();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-2020) + "'", int8 == (-2020));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559761199999L + "'", long10 == 1559761199999L);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getFirstMillisecond();
        java.lang.String str5 = week2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62199763200000L) + "'", long4 == (-62199763200000L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 0, -1" + "'", str5.equals("Week 0, -1"));
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        long long7 = week0.getFirstMillisecond();
//        int int8 = week0.getYearValue();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
//        long long11 = week9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week9.next();
//        long long13 = week9.getFirstMillisecond();
//        int int14 = week9.getWeek();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        long long16 = week15.getSerialIndex();
//        java.util.Date date17 = week15.getEnd();
//        boolean boolean18 = week9.equals((java.lang.Object) week15);
//        java.lang.String str19 = week15.toString();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        long long21 = week20.getSerialIndex();
//        java.util.Date date22 = week20.getEnd();
//        boolean boolean23 = week15.equals((java.lang.Object) date22);
//        long long24 = week15.getFirstMillisecond();
//        java.lang.String str25 = week15.toString();
//        long long26 = week15.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week15.previous();
//        boolean boolean29 = week0.equals((java.lang.Object) week15);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560063600000L + "'", long11 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 24, 2019" + "'", str19.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 107031L + "'", long21 == 107031L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560063600000L + "'", long24 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Week 24, 2019" + "'", str25.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560063600000L + "'", long26 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = week6.getMiddleMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test289");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date5 = week4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getFirstMillisecond();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        long long10 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62041910400000L) + "'", long8 == (-62041910400000L));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560365999999L + "'", long10 == 1560365999999L);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62199763200000L) + "'", long3 == (-62199763200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date6 = week5.getEnd();
//        int int7 = week5.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        long long11 = week10.getSerialIndex();
//        java.lang.Class<?> wildcardClass12 = week10.getClass();
//        int int13 = week5.compareTo((java.lang.Object) wildcardClass12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        long long16 = week15.getSerialIndex();
//        java.util.Date date17 = week15.getEnd();
//        java.lang.Class<?> wildcardClass18 = date17.getClass();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date22 = week21.getEnd();
//        int int23 = week21.getYearValue();
//        java.lang.Class<?> wildcardClass24 = week21.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date28 = week27.getEnd();
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date28, timeZone29);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date34 = week33.getEnd();
//        int int35 = week33.getYearValue();
//        java.lang.Class<?> wildcardClass36 = week33.getClass();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date40 = week39.getEnd();
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date40, timeZone41);
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date40, timeZone43);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date17, timeZone43);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date49 = week48.getEnd();
//        int int50 = week48.getYearValue();
//        java.lang.Class<?> wildcardClass51 = week48.getClass();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date55 = week54.getEnd();
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date55);
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date55, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date17, timeZone57);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date2, timeZone57);
//        long long61 = week60.getMiddleMillisecond();
//        long long62 = week60.getSerialIndex();
//        java.util.Calendar calendar63 = null;
//        try {
//            week60.peg(calendar63);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560365999999L + "'", long61 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 107031L + "'", long62 == 107031L);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        java.lang.String str12 = timePeriodFormatException9.toString();
        java.lang.String str13 = timePeriodFormatException9.toString();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) ' ', 0);
        long long3 = week2.getMiddleMillisecond();
        long long4 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62148657600001L) + "'", long3 == (-62148657600001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62148657600001L) + "'", long4 == (-62148657600001L));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62199763200000L) + "'", long4 == (-62199763200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date5 = week4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getFirstMillisecond();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        long long10 = week6.getMiddleMillisecond();
//        java.util.Calendar calendar11 = null;
//        try {
//            week6.peg(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62041910400000L) + "'", long8 == (-62041910400000L));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62041608000001L) + "'", long10 == (-62041608000001L));
//    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getSerialIndex();
//        int int6 = week0.getWeek();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week0.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        long long3 = week2.getSerialIndex();
        int int4 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-53L) + "'", long3 == (-53L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        long long14 = week13.getSerialIndex();
//        java.util.Date date15 = week13.getEnd();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date19 = week18.getEnd();
//        int int20 = week18.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week18.previous();
//        java.util.Date date22 = week18.getStart();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        long long24 = week23.getSerialIndex();
//        java.lang.Class<?> wildcardClass25 = week23.getClass();
//        int int26 = week18.compareTo((java.lang.Object) wildcardClass25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        long long29 = week28.getSerialIndex();
//        java.util.Date date30 = week28.getEnd();
//        java.lang.Class<?> wildcardClass31 = date30.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        int int36 = week34.getYearValue();
//        java.lang.Class<?> wildcardClass37 = week34.getClass();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date41 = week40.getEnd();
//        java.util.TimeZone timeZone42 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date41, timeZone42);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date47 = week46.getEnd();
//        int int48 = week46.getYearValue();
//        java.lang.Class<?> wildcardClass49 = week46.getClass();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date53 = week52.getEnd();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date53, timeZone54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date53, timeZone56);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date30, timeZone56);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date62 = week61.getEnd();
//        int int63 = week61.getYearValue();
//        java.lang.Class<?> wildcardClass64 = week61.getClass();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date68 = week67.getEnd();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date68);
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date68, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date30, timeZone70);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date15, timeZone70);
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date9, timeZone70);
//        long long75 = week74.getSerialIndex();
//        long long76 = week74.getSerialIndex();
//        java.lang.Object obj77 = null;
//        boolean boolean78 = week74.equals(obj77);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 107031L + "'", long14 == 107031L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 107031L + "'", long24 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 107031L + "'", long29 == 107031L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 211L + "'", long75 == 211L);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 211L + "'", long76 == 211L);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getSerialIndex();
//        java.lang.Class<?> wildcardClass9 = week7.getClass();
//        int int10 = week2.compareTo((java.lang.Object) wildcardClass9);
//        java.lang.Class<?> wildcardClass11 = week2.getClass();
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = week2.getFirstMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
//        long long5 = week3.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.next();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        java.util.Date date8 = year7.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 100, year7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(24, year11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(7, year11);
//        long long14 = year11.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1562097599999L + "'", long14 == 1562097599999L);
//    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = week0.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        java.lang.Object obj4 = null;
        int int5 = week2.compareTo(obj4);
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date10 = week9.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.previous();
        int int12 = week9.getWeek();
        int int14 = week9.compareTo((java.lang.Object) (-1.0f));
        boolean boolean15 = week2.equals((java.lang.Object) week9);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week1.next();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.util.Date date6 = year5.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 100, year5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.previous();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = week7.getFirstMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getSerialIndex();
//        java.lang.Class<?> wildcardClass9 = week7.getClass();
//        int int10 = week2.compareTo((java.lang.Object) wildcardClass9);
//        long long11 = week2.getFirstMillisecond();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        int int15 = week2.compareTo((java.lang.Object) year14);
//        int int16 = week2.getYearValue();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62199763200000L) + "'", long11 == (-62199763200000L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week1.next();
//        long long5 = week1.getSerialIndex();
//        int int6 = week1.getWeek();
//        org.jfree.data.time.Year year7 = week1.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(7, year7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date12 = week11.getEnd();
//        int int13 = week11.getYearValue();
//        int int14 = week11.getWeek();
//        int int15 = week8.compareTo((java.lang.Object) int14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week8.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getSerialIndex();
//        java.lang.Class<?> wildcardClass3 = week1.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week1.previous();
//        java.util.Date date5 = week1.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
//        long long14 = week12.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week12.next();
//        org.jfree.data.time.Year year16 = week12.getYear();
//        java.util.Date date17 = year16.getStart();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date21 = week20.getEnd();
//        int int22 = week20.getYearValue();
//        java.lang.Class<?> wildcardClass23 = week20.getClass();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date27 = week26.getEnd();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date27);
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date27, timeZone29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone29);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        int int36 = week34.getYearValue();
//        java.lang.Class<?> wildcardClass37 = week34.getClass();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date41 = week40.getEnd();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date41);
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date41, timeZone43);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date17, timeZone43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone43);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560063600000L + "'", long14 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        long long7 = week0.getFirstMillisecond();
//        int int8 = week0.getYearValue();
//        java.util.Date date9 = week0.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(date9);
//    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getSerialIndex();
//        java.util.Date date5 = week0.getStart();
//        java.lang.Object obj6 = null;
//        int int7 = week0.compareTo(obj6);
//        org.jfree.data.time.Year year8 = week0.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(year8);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (short) -1);
        long long3 = week2.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 47L + "'", long3 == 47L);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        long long6 = week0.getMiddleMillisecond();
//        java.lang.String str7 = week0.toString();
//        org.jfree.data.time.Year year8 = week0.getYear();
//        int int9 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week0.previous();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = regularTimePeriod10.getMiddleMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        long long6 = week4.getFirstMillisecond();
        long long7 = week4.getSerialIndex();
        long long8 = week4.getSerialIndex();
        java.lang.Class<?> wildcardClass9 = week4.getClass();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week4.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62041910400000L) + "'", long6 == (-62041910400000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 211L + "'", long7 == 211L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 211L + "'", long8 == 211L);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        int int5 = week2.getWeek();
        int int6 = week2.getYearValue();
        try {
            org.jfree.data.time.Year year7 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        long long15 = week6.getFirstMillisecond();
//        java.util.Date date16 = week6.getStart();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
//        long long19 = week17.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week17.next();
//        long long21 = week17.getSerialIndex();
//        int int22 = week17.getWeek();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date26 = week25.getEnd();
//        int int27 = week25.getYearValue();
//        java.lang.Class<?> wildcardClass28 = week25.getClass();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date32 = week31.getEnd();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date32);
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date32, timeZone34);
//        boolean boolean36 = week17.equals((java.lang.Object) wildcardClass28);
//        boolean boolean37 = week6.equals((java.lang.Object) week17);
//        java.util.Calendar calendar38 = null;
//        try {
//            long long39 = week17.getFirstMillisecond(calendar38);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560063600000L + "'", long19 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 107031L + "'", long21 == 107031L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 24 + "'", int22 == 24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, 11);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
        java.util.Date date8 = week4.getStart();
        java.lang.String str9 = week4.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 52, 3" + "'", str9.equals("Week 52, 3"));
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        long long15 = week6.getFirstMillisecond();
//        java.lang.String str16 = week6.toString();
//        int int18 = week6.compareTo((java.lang.Object) (-1.0d));
//        int int19 = week6.getWeek();
//        long long20 = week6.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 24 + "'", int19 == 24);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560668399999L + "'", long20 == 1560668399999L);
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        long long8 = week6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.next();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        java.util.Date date11 = year10.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        int int16 = week14.getYearValue();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date21 = week20.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone23);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        long long27 = week26.getSerialIndex();
//        java.util.Date date28 = week26.getEnd();
//        java.lang.Class<?> wildcardClass29 = date28.getClass();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date33 = week32.getEnd();
//        int int34 = week32.getYearValue();
//        java.lang.Class<?> wildcardClass35 = week32.getClass();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week36.previous();
//        long long38 = week36.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week36.next();
//        org.jfree.data.time.Year year40 = week36.getYear();
//        java.util.Date date41 = year40.getStart();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date45 = week44.getEnd();
//        int int46 = week44.getYearValue();
//        java.lang.Class<?> wildcardClass47 = week44.getClass();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date51 = week50.getEnd();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date51);
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date51, timeZone53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date41, timeZone53);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date59 = week58.getEnd();
//        int int60 = week58.getYearValue();
//        java.lang.Class<?> wildcardClass61 = week58.getClass();
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date65 = week64.getEnd();
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date65);
//        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date65, timeZone67);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date41, timeZone67);
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date28, timeZone67);
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date28, timeZone71);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 107031L + "'", long27 == 107031L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560063600000L + "'", long38 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(year40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        java.util.Date date5 = week4.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.previous();
//        java.util.Date date8 = week4.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        long long10 = week9.getSerialIndex();
//        java.util.Date date11 = week9.getEnd();
//        java.lang.Class<?> wildcardClass12 = date11.getClass();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date16 = week15.getEnd();
//        int int17 = week15.getYearValue();
//        java.lang.Class<?> wildcardClass18 = week15.getClass();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date22 = week21.getEnd();
//        java.util.TimeZone timeZone23 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone23);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date28 = week27.getEnd();
//        int int29 = week27.getYearValue();
//        java.lang.Class<?> wildcardClass30 = week27.getClass();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date34 = week33.getEnd();
//        java.util.TimeZone timeZone35 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date34, timeZone35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date34, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date11, timeZone37);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date8, timeZone37);
//        java.util.Date date41 = week40.getStart();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date41);
//    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 12);
//        java.util.Date date3 = week2.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
//        long long6 = week4.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week4.next();
//        org.jfree.data.time.Year year8 = week4.getYear();
//        java.util.Date date9 = year8.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
//        int int12 = week2.compareTo((java.lang.Object) week10);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-2007) + "'", int12 == (-2007));
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        int int5 = week2.getWeek();
        int int7 = week2.compareTo((java.lang.Object) (-1.0f));
        java.lang.String str8 = week2.toString();
        java.lang.Object obj9 = null;
        int int10 = week2.compareTo(obj9);
        java.util.Calendar calendar11 = null;
        try {
            week2.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 0, -1" + "'", str8.equals("Week 0, -1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 12);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date6 = week5.getEnd();
        int int7 = week5.getYearValue();
        java.lang.Class<?> wildcardClass8 = week5.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date12 = week11.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone14);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date19 = week18.getEnd();
        int int20 = week18.getYearValue();
        java.lang.Class<?> wildcardClass21 = week18.getClass();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date25 = week24.getEnd();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date25, timeZone27);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date12, timeZone27);
        int int30 = week29.getYearValue();
        java.util.Date date31 = week29.getEnd();
        boolean boolean32 = week2.equals((java.lang.Object) week29);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        long long14 = week13.getSerialIndex();
//        java.util.Date date15 = week13.getEnd();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date19 = week18.getEnd();
//        int int20 = week18.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week18.previous();
//        java.util.Date date22 = week18.getStart();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        long long24 = week23.getSerialIndex();
//        java.lang.Class<?> wildcardClass25 = week23.getClass();
//        int int26 = week18.compareTo((java.lang.Object) wildcardClass25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        long long29 = week28.getSerialIndex();
//        java.util.Date date30 = week28.getEnd();
//        java.lang.Class<?> wildcardClass31 = date30.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        int int36 = week34.getYearValue();
//        java.lang.Class<?> wildcardClass37 = week34.getClass();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date41 = week40.getEnd();
//        java.util.TimeZone timeZone42 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date41, timeZone42);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date47 = week46.getEnd();
//        int int48 = week46.getYearValue();
//        java.lang.Class<?> wildcardClass49 = week46.getClass();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date53 = week52.getEnd();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date53, timeZone54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date53, timeZone56);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date30, timeZone56);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date62 = week61.getEnd();
//        int int63 = week61.getYearValue();
//        java.lang.Class<?> wildcardClass64 = week61.getClass();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date68 = week67.getEnd();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date68);
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date68, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date30, timeZone70);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date15, timeZone70);
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date9, timeZone70);
//        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass76 = timeZone75.getClass();
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date9, timeZone75);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 107031L + "'", long14 == 107031L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 107031L + "'", long24 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 107031L + "'", long29 == 107031L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(timeZone75);
//        org.junit.Assert.assertNotNull(wildcardClass76);
//    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) (short) -1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
//        long long5 = week3.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.next();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        int int8 = week2.compareTo((java.lang.Object) week3);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        long long12 = week11.getFirstMillisecond();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week2.equals((java.lang.Object) date13);
//        java.lang.Class<?> wildcardClass15 = week2.getClass();
//        try {
//            org.jfree.data.time.Year year16 = week2.getYear();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-2020) + "'", int8 == (-2020));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62199763200000L) + "'", long12 == (-62199763200000L));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException1.toString();
        java.lang.String str6 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (-2020));
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-2020) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        long long7 = week0.getFirstMillisecond();
//        int int8 = week0.getYearValue();
//        java.util.Date date9 = week0.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        long long11 = week10.getSerialIndex();
//        java.util.Date date12 = week10.getEnd();
//        java.lang.Class<?> wildcardClass13 = date12.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date17 = week16.getEnd();
//        int int18 = week16.getYearValue();
//        java.lang.Class<?> wildcardClass19 = week16.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.previous();
//        long long22 = week20.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week20.next();
//        org.jfree.data.time.Year year24 = week20.getYear();
//        java.util.Date date25 = year24.getStart();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date29 = week28.getEnd();
//        int int30 = week28.getYearValue();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone37);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date43 = week42.getEnd();
//        int int44 = week42.getYearValue();
//        java.lang.Class<?> wildcardClass45 = week42.getClass();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date49 = week48.getEnd();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date49);
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date49, timeZone51);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date25, timeZone51);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date12, timeZone51);
//        java.util.Locale locale55 = null;
//        try {
//            org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date9, timeZone51, locale55);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560063600000L + "'", long22 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, 0);
//        java.lang.Class<?> wildcardClass3 = week2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        long long8 = week6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.next();
//        long long10 = week6.getSerialIndex();
//        int int11 = week6.getWeek();
//        org.jfree.data.time.Year year12 = week6.getYear();
//        java.util.Date date13 = year12.getEnd();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, year12);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) 100, year12);
//        boolean boolean16 = week2.equals((java.lang.Object) year12);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(0, 12);
//        boolean boolean20 = week2.equals((java.lang.Object) 0);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        long long15 = week6.getFirstMillisecond();
//        java.lang.String str16 = week6.toString();
//        long long17 = week6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week6.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week6.previous();
//        java.util.Date date20 = regularTimePeriod19.getEnd();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date6 = week5.getEnd();
//        int int7 = week5.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.previous();
//        java.util.Date date9 = week5.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        long long11 = week10.getSerialIndex();
//        java.lang.Class<?> wildcardClass12 = week10.getClass();
//        int int13 = week5.compareTo((java.lang.Object) wildcardClass12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        long long16 = week15.getSerialIndex();
//        java.util.Date date17 = week15.getEnd();
//        java.lang.Class<?> wildcardClass18 = date17.getClass();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date22 = week21.getEnd();
//        int int23 = week21.getYearValue();
//        java.lang.Class<?> wildcardClass24 = week21.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date28 = week27.getEnd();
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date28, timeZone29);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date34 = week33.getEnd();
//        int int35 = week33.getYearValue();
//        java.lang.Class<?> wildcardClass36 = week33.getClass();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date40 = week39.getEnd();
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date40, timeZone41);
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date40, timeZone43);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date17, timeZone43);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date49 = week48.getEnd();
//        int int50 = week48.getYearValue();
//        java.lang.Class<?> wildcardClass51 = week48.getClass();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date55 = week54.getEnd();
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date55);
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date55, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date17, timeZone57);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date2, timeZone57);
//        long long61 = week60.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560063600000L + "'", long61 == 1560063600000L);
//    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        long long6 = week2.getFirstMillisecond();
//        int int7 = week2.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        long long9 = week8.getSerialIndex();
//        java.util.Date date10 = week8.getEnd();
//        boolean boolean11 = week2.equals((java.lang.Object) week8);
//        java.lang.String str12 = week8.toString();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        long long14 = week13.getSerialIndex();
//        java.util.Date date15 = week13.getEnd();
//        boolean boolean16 = week8.equals((java.lang.Object) date15);
//        long long17 = week8.getFirstMillisecond();
//        java.lang.String str18 = week8.toString();
//        boolean boolean19 = week0.equals((java.lang.Object) str18);
//        int int20 = week0.getYearValue();
//        java.util.Date date21 = week0.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 107031L + "'", long14 == 107031L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 24, 2019" + "'", str18.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(date21);
//    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        long long14 = week13.getSerialIndex();
//        java.util.Date date15 = week13.getEnd();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date19 = week18.getEnd();
//        int int20 = week18.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week18.previous();
//        java.util.Date date22 = week18.getStart();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        long long24 = week23.getSerialIndex();
//        java.lang.Class<?> wildcardClass25 = week23.getClass();
//        int int26 = week18.compareTo((java.lang.Object) wildcardClass25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        long long29 = week28.getSerialIndex();
//        java.util.Date date30 = week28.getEnd();
//        java.lang.Class<?> wildcardClass31 = date30.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        int int36 = week34.getYearValue();
//        java.lang.Class<?> wildcardClass37 = week34.getClass();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date41 = week40.getEnd();
//        java.util.TimeZone timeZone42 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date41, timeZone42);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date47 = week46.getEnd();
//        int int48 = week46.getYearValue();
//        java.lang.Class<?> wildcardClass49 = week46.getClass();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date53 = week52.getEnd();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date53, timeZone54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date53, timeZone56);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date30, timeZone56);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date62 = week61.getEnd();
//        int int63 = week61.getYearValue();
//        java.lang.Class<?> wildcardClass64 = week61.getClass();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date68 = week67.getEnd();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date68);
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date68, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date30, timeZone70);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date15, timeZone70);
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date9, timeZone70);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date9);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 107031L + "'", long14 == 107031L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 107031L + "'", long24 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 107031L + "'", long29 == 107031L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getSerialIndex();
//        int int6 = week0.getWeek();
//        java.lang.String str7 = week0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        long long15 = week6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week6.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date4 = week3.getEnd();
//        int int5 = week3.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.next();
//        int int7 = week3.getYearValue();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
//        long long10 = week8.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.next();
//        org.jfree.data.time.Year year12 = week8.getYear();
//        int int13 = week3.compareTo((java.lang.Object) year12);
//        java.lang.Class<?> wildcardClass14 = year12.getClass();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) 100, year12);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560063600000L + "'", long10 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        long long8 = week6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.next();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        java.util.Date date11 = year10.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        int int16 = week14.getYearValue();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date21 = week20.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone23);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date29 = week28.getEnd();
//        int int30 = week28.getYearValue();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date11, timeZone37);
//        java.util.Date date40 = week39.getEnd();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date40);
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = week0.equals((java.lang.Object) wildcardClass11);
//        java.util.Date date20 = week0.getEnd();
//        java.lang.Class<?> wildcardClass21 = date20.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone11);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date16 = week15.getEnd();
//        int int17 = week15.getYearValue();
//        java.lang.Class<?> wildcardClass18 = week15.getClass();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date22 = week21.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date9, timeZone24);
//        int int27 = week26.getYearValue();
//        java.util.Date date28 = week26.getEnd();
//        int int29 = week26.getYearValue();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date33 = week32.getEnd();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date33);
//        java.util.Date date35 = week34.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week34.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week34.previous();
//        java.util.Date date38 = week34.getStart();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        long long40 = week39.getSerialIndex();
//        java.util.Date date41 = week39.getEnd();
//        java.lang.Class<?> wildcardClass42 = date41.getClass();
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date46 = week45.getEnd();
//        int int47 = week45.getYearValue();
//        java.lang.Class<?> wildcardClass48 = week45.getClass();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date52 = week51.getEnd();
//        java.util.TimeZone timeZone53 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date52, timeZone53);
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date58 = week57.getEnd();
//        int int59 = week57.getYearValue();
//        java.lang.Class<?> wildcardClass60 = week57.getClass();
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date64 = week63.getEnd();
//        java.util.TimeZone timeZone65 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date64, timeZone65);
//        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date64, timeZone67);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date41, timeZone67);
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date38, timeZone67);
//        boolean boolean71 = week26.equals((java.lang.Object) week70);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 107031L + "'", long40 == 107031L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass60);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(timeZone67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
//    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 0, 0);
//        java.lang.Class<?> wildcardClass4 = week3.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        long long9 = week7.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.next();
//        long long11 = week7.getSerialIndex();
//        int int12 = week7.getWeek();
//        org.jfree.data.time.Year year13 = week7.getYear();
//        java.util.Date date14 = year13.getEnd();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(12, year13);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (byte) 100, year13);
//        boolean boolean17 = week3.equals((java.lang.Object) year13);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(97, year13);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        java.lang.Class<?> wildcardClass3 = date2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date7 = week6.getEnd();
//        int int8 = week6.getYearValue();
//        java.lang.Class<?> wildcardClass9 = week6.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
//        long long12 = week10.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week10.next();
//        org.jfree.data.time.Year year14 = week10.getYear();
//        java.util.Date date15 = year14.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date19 = week18.getEnd();
//        int int20 = week18.getYearValue();
//        java.lang.Class<?> wildcardClass21 = week18.getClass();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date25 = week24.getEnd();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date25, timeZone27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone27);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date33 = week32.getEnd();
//        int int34 = week32.getYearValue();
//        java.lang.Class<?> wildcardClass35 = week32.getClass();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date39 = week38.getEnd();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date39);
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date39, timeZone41);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date15, timeZone41);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date2, timeZone41);
//        long long45 = week44.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560668399999L + "'", long45 == 1560668399999L);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, 0);
        long long3 = week2.getSerialIndex();
        long long4 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62167708800001L) + "'", long4 == (-62167708800001L));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, 0);
        long long3 = week2.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        int int6 = week0.getWeek();
//        java.util.Date date7 = week0.getStart();
//        long long8 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str8 = timePeriodFormatException5.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        java.lang.Object obj4 = null;
//        int int5 = week2.compareTo(obj4);
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getSerialIndex();
//        java.util.Date date9 = week7.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date13 = week12.getEnd();
//        int int14 = week12.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week12.previous();
//        java.util.Date date16 = week12.getStart();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        long long18 = week17.getSerialIndex();
//        java.lang.Class<?> wildcardClass19 = week17.getClass();
//        int int20 = week12.compareTo((java.lang.Object) wildcardClass19);
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        long long23 = week22.getSerialIndex();
//        java.util.Date date24 = week22.getEnd();
//        java.lang.Class<?> wildcardClass25 = date24.getClass();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date29 = week28.getEnd();
//        int int30 = week28.getYearValue();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        java.util.TimeZone timeZone36 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone36);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date41 = week40.getEnd();
//        int int42 = week40.getYearValue();
//        java.lang.Class<?> wildcardClass43 = week40.getClass();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date47 = week46.getEnd();
//        java.util.TimeZone timeZone48 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date47, timeZone48);
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date47, timeZone50);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date24, timeZone50);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date56 = week55.getEnd();
//        int int57 = week55.getYearValue();
//        java.lang.Class<?> wildcardClass58 = week55.getClass();
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date62 = week61.getEnd();
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date62);
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date62, timeZone64);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date24, timeZone64);
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date9, timeZone64);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date6, timeZone64);
//        long long69 = week68.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = week68.previous();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 107031L + "'", long18 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 107031L + "'", long23 == 107031L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 211L + "'", long69 == 211L);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week1.next();
//        long long5 = week1.getSerialIndex();
//        int int6 = week1.getWeek();
//        org.jfree.data.time.Year year7 = week1.getYear();
//        java.util.Date date8 = year7.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, year7);
//        java.lang.String str10 = week9.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 12, 2019" + "'", str10.equals("Week 12, 2019"));
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(97, 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date4 = week3.getEnd();
        int int5 = week3.getYearValue();
        java.lang.Class<?> wildcardClass6 = week3.getClass();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date10 = week9.getEnd();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone12);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date17 = week16.getEnd();
        int int18 = week16.getYearValue();
        java.lang.Class<?> wildcardClass19 = week16.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date23 = week22.getEnd();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date23, timeZone25);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date10, timeZone25);
        try {
            org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date0, timeZone25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date9 = week8.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone11);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date16 = week15.getEnd();
        int int17 = week15.getYearValue();
        java.lang.Class<?> wildcardClass18 = week15.getClass();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date22 = week21.getEnd();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone24);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date9, timeZone24);
        int int27 = week26.getYearValue();
        long long28 = week26.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 211L + "'", long28 == 211L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) (short) -1);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = week0.equals((java.lang.Object) wildcardClass11);
//        java.lang.Object obj20 = null;
//        int int21 = week0.compareTo(obj20);
//        int int22 = week0.getWeek();
//        long long23 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 24 + "'", int22 == 24);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560668399999L + "'", long23 == 1560668399999L);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.String str9 = timePeriodFormatException5.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str11 = timePeriodFormatException5.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        long long6 = week0.getSerialIndex();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date10 = week9.getEnd();
//        int int11 = week9.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week9.previous();
//        java.util.Date date13 = week9.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        long long15 = week14.getSerialIndex();
//        java.lang.Class<?> wildcardClass16 = week14.getClass();
//        int int17 = week9.compareTo((java.lang.Object) wildcardClass16);
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        long long20 = week19.getSerialIndex();
//        java.util.Date date21 = week19.getEnd();
//        java.lang.Class<?> wildcardClass22 = date21.getClass();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date26 = week25.getEnd();
//        int int27 = week25.getYearValue();
//        java.lang.Class<?> wildcardClass28 = week25.getClass();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date32 = week31.getEnd();
//        java.util.TimeZone timeZone33 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date32, timeZone33);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date38 = week37.getEnd();
//        int int39 = week37.getYearValue();
//        java.lang.Class<?> wildcardClass40 = week37.getClass();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date44 = week43.getEnd();
//        java.util.TimeZone timeZone45 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date44, timeZone45);
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date44, timeZone47);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date21, timeZone47);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date53 = week52.getEnd();
//        int int54 = week52.getYearValue();
//        java.lang.Class<?> wildcardClass55 = week52.getClass();
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date59 = week58.getEnd();
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date59);
//        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date59, timeZone61);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone61);
//        int int64 = week0.compareTo((java.lang.Object) regularTimePeriod63);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 107031L + "'", long15 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 107031L + "'", long20 == 107031L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone61);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        java.lang.String str5 = week0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        int int11 = week6.compareTo((java.lang.Object) 'a');
//        int int13 = week6.compareTo((java.lang.Object) (-61789406400001L));
//        long long14 = week6.getLastMillisecond();
//        java.util.Calendar calendar15 = null;
//        try {
//            week6.peg(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560668399999L + "'", long14 == 1560668399999L);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, 11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 0, -1");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException6.getSuppressed();
        int int12 = week2.compareTo((java.lang.Object) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException6.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, (int) (short) -1);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
//        long long5 = week3.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.next();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        int int8 = week2.compareTo((java.lang.Object) week3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week3.previous();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = regularTimePeriod9.getMiddleMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-2020) + "'", int8 == (-2020));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week1.next();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.util.Date date6 = year5.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 100, year5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.previous();
//        long long10 = week7.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1606032000000L + "'", long10 == 1606032000000L);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date9 = week8.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone11);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date16 = week15.getEnd();
        int int17 = week15.getYearValue();
        java.lang.Class<?> wildcardClass18 = week15.getClass();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date22 = week21.getEnd();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone24);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date9, timeZone24);
        int int27 = week26.getYearValue();
        java.util.Date date28 = week26.getEnd();
        int int29 = week26.getYearValue();
        java.util.Calendar calendar30 = null;
        try {
            long long31 = week26.getFirstMillisecond(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 100, (int) (short) -1);
        long long3 = week2.getSerialIndex();
        java.lang.String str4 = week2.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 47L + "'", long3 == 47L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 100, -1" + "'", str4.equals("Week 100, -1"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        long long8 = week2.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62199158400001L) + "'", long8 == (-62199158400001L));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 12, 2019");
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, (-1));
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = week0.equals((java.lang.Object) wildcardClass11);
//        java.lang.Object obj20 = null;
//        int int21 = week0.compareTo(obj20);
//        int int22 = week0.getWeek();
//        java.util.Calendar calendar23 = null;
//        try {
//            week0.peg(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 24 + "'", int22 == 24);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, 12);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 100);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        int int3 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 24);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        int int5 = week2.getWeek();
        int int7 = week2.compareTo((java.lang.Object) (-1.0f));
        long long8 = week2.getMiddleMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62199460800001L) + "'", long8 == (-62199460800001L));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        long long6 = week4.getFirstMillisecond();
        java.lang.Class<?> wildcardClass7 = week4.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62041910400000L) + "'", long6 == (-62041910400000L));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 24);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (24) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        java.util.Date date7 = year6.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 100, year6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(24, year10);
//        long long12 = week11.getLastMillisecond();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week11.getLastMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
//    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getSerialIndex();
//        java.lang.Class<?> wildcardClass6 = week0.getClass();
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(class7);
//    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        java.lang.Class<?> wildcardClass3 = date2.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date9, timeZone11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date9);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getSerialIndex();
//        java.lang.Class<?> wildcardClass9 = week7.getClass();
//        int int10 = week2.compareTo((java.lang.Object) wildcardClass9);
//        long long11 = week2.getFirstMillisecond();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        int int15 = week2.compareTo((java.lang.Object) year14);
//        int int17 = week2.compareTo((java.lang.Object) 12);
//        java.util.Calendar calendar18 = null;
//        try {
//            week2.peg(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62199763200000L) + "'", long11 == (-62199763200000L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        java.util.Date date7 = year6.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 100, year6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(24, year10);
//        long long12 = week11.getLastMillisecond();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date16 = week15.getEnd();
//        int int17 = week15.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week15.previous();
//        java.util.Date date19 = week15.getStart();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        long long21 = week20.getSerialIndex();
//        java.lang.Class<?> wildcardClass22 = week20.getClass();
//        int int23 = week15.compareTo((java.lang.Object) wildcardClass22);
//        java.lang.Class<?> wildcardClass24 = week15.getClass();
//        java.util.Date date25 = null;
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date29 = week28.getEnd();
//        int int30 = week28.getYearValue();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone37);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date42 = week41.getEnd();
//        int int43 = week41.getYearValue();
//        java.lang.Class<?> wildcardClass44 = week41.getClass();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date48 = week47.getEnd();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date48);
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date48, timeZone50);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date35, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date25, timeZone50);
//        boolean boolean54 = week11.equals((java.lang.Object) date25);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 107031L + "'", long21 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        int int5 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getMiddleMillisecond();
        java.util.Date date7 = week2.getEnd();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62199460800001L) + "'", long6 == (-62199460800001L));
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = week0.equals((java.lang.Object) wildcardClass11);
//        java.util.Date date20 = week0.getStart();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date24 = week23.getEnd();
//        int int25 = week23.getYearValue();
//        java.lang.Class<?> wildcardClass26 = week23.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.previous();
//        long long29 = week27.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week27.next();
//        org.jfree.data.time.Year year31 = week27.getYear();
//        java.util.Date date32 = year31.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date36 = week35.getEnd();
//        int int37 = week35.getYearValue();
//        java.lang.Class<?> wildcardClass38 = week35.getClass();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date42 = week41.getEnd();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date42);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date42, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date32, timeZone44);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date20, timeZone44);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560063600000L + "'", long29 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62199763200000L) + "'", long4 == (-62199763200000L));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week1.next();
//        long long5 = week1.getSerialIndex();
//        int int6 = week1.getWeek();
//        org.jfree.data.time.Year year7 = week1.getYear();
//        java.util.Date date8 = year7.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(100, year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        long long6 = week4.getFirstMillisecond();
        java.util.Date date7 = week4.getEnd();
        long long8 = week4.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62041910400000L) + "'", long6 == (-62041910400000L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62041608000001L) + "'", long8 == (-62041608000001L));
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        long long2 = week1.getLastMillisecond();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date6 = week5.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
//        java.util.Date date8 = week7.getEnd();
//        long long9 = week7.getFirstMillisecond();
//        boolean boolean10 = week1.equals((java.lang.Object) week7);
//        java.lang.String str11 = week1.toString();
//        long long12 = week1.getLastMillisecond();
//        org.jfree.data.time.Year year13 = week1.getYear();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(53, year13);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62041910400000L) + "'", long9 == (-62041910400000L));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 24, 2019" + "'", str11.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
//        org.junit.Assert.assertNotNull(year13);
//    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getStart();
//        int int3 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        long long15 = week6.getFirstMillisecond();
//        java.util.Date date16 = week6.getStart();
//        long long17 = week6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week6.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week6.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = week0.equals((java.lang.Object) wildcardClass11);
//        java.lang.Object obj20 = null;
//        int int21 = week0.compareTo(obj20);
//        long long22 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560365999999L + "'", long22 == 1560365999999L);
//    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Date date5 = week0.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date22 = week21.getEnd();
//        int int23 = week21.getYearValue();
//        java.lang.Class<?> wildcardClass24 = week21.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date28 = week27.getEnd();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date28, timeZone30);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date15, timeZone30);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date5, timeZone30);
//        java.lang.Class<?> wildcardClass34 = date5.getClass();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getFirstMillisecond();
        long long5 = week2.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62199763200000L) + "'", long4 == (-62199763200000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-53L) + "'", long5 == (-53L));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        long long4 = week2.getFirstMillisecond();
        long long5 = week2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62199763200000L) + "'", long4 == (-62199763200000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62199763200000L) + "'", long5 == (-62199763200000L));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 0, -1");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException1.getSuppressed();
        java.lang.String str9 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.String str18 = timePeriodFormatException11.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.String str27 = timePeriodFormatException20.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        java.lang.String str37 = timePeriodFormatException30.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException39.addSuppressed((java.lang.Throwable) timePeriodFormatException41);
        java.lang.Throwable[] throwableArray43 = timePeriodFormatException39.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException45.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
        timePeriodFormatException39.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 0, -1" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: Week 0, -1"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str37.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray43);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date9, timeZone10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        long long14 = week13.getSerialIndex();
//        java.util.Date date15 = week13.getEnd();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date19 = week18.getEnd();
//        int int20 = week18.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week18.previous();
//        java.util.Date date22 = week18.getStart();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        long long24 = week23.getSerialIndex();
//        java.lang.Class<?> wildcardClass25 = week23.getClass();
//        int int26 = week18.compareTo((java.lang.Object) wildcardClass25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        long long29 = week28.getSerialIndex();
//        java.util.Date date30 = week28.getEnd();
//        java.lang.Class<?> wildcardClass31 = date30.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        int int36 = week34.getYearValue();
//        java.lang.Class<?> wildcardClass37 = week34.getClass();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date41 = week40.getEnd();
//        java.util.TimeZone timeZone42 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date41, timeZone42);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date47 = week46.getEnd();
//        int int48 = week46.getYearValue();
//        java.lang.Class<?> wildcardClass49 = week46.getClass();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date53 = week52.getEnd();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date53, timeZone54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date53, timeZone56);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date30, timeZone56);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date62 = week61.getEnd();
//        int int63 = week61.getYearValue();
//        java.lang.Class<?> wildcardClass64 = week61.getClass();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date68 = week67.getEnd();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date68);
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date68, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date30, timeZone70);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date15, timeZone70);
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date9, timeZone70);
//        long long75 = week74.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = week74.previous();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException78 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str79 = timePeriodFormatException78.toString();
//        boolean boolean80 = week74.equals((java.lang.Object) str79);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 107031L + "'", long14 == 107031L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 107031L + "'", long24 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 107031L + "'", long29 == 107031L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-62041305600001L) + "'", long75 == (-62041305600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str79.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        long long6 = week2.getFirstMillisecond();
//        int int7 = week2.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        long long9 = week8.getSerialIndex();
//        java.util.Date date10 = week8.getEnd();
//        boolean boolean11 = week2.equals((java.lang.Object) week8);
//        java.lang.String str12 = week8.toString();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        long long14 = week13.getSerialIndex();
//        java.util.Date date15 = week13.getEnd();
//        boolean boolean16 = week8.equals((java.lang.Object) date15);
//        long long17 = week8.getFirstMillisecond();
//        java.lang.String str18 = week8.toString();
//        boolean boolean19 = week0.equals((java.lang.Object) str18);
//        long long20 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 107031L + "'", long14 == 107031L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 24, 2019" + "'", str18.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 107031L + "'", long20 == 107031L);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, 0);
        int int4 = week2.compareTo((java.lang.Object) (short) 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, 8);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.String str20 = timePeriodFormatException16.toString();
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
//        long long5 = week3.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week3.next();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        java.util.Date date8 = year7.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 100, year7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        org.jfree.data.time.Year year11 = week9.getYear();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(24, year11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (byte) 0, year11);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year11);
//    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date5 = week4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        java.util.Date date7 = week6.getEnd();
//        long long8 = week6.getFirstMillisecond();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week0.toString();
//        long long11 = week0.getLastMillisecond();
//        org.jfree.data.time.Year year12 = week0.getYear();
//        int int13 = week0.getYearValue();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = week0.getMiddleMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62041910400000L) + "'", long8 == (-62041910400000L));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week1.next();
//        long long5 = week1.getSerialIndex();
//        int int6 = week1.getWeek();
//        org.jfree.data.time.Year year7 = week1.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(7, year7);
//        java.util.Date date9 = year7.getStart();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date9);
//    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week1.next();
//        org.jfree.data.time.Year year5 = week1.getYear();
//        java.util.Date date6 = year5.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year5);
//        long long8 = week7.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546156799999L + "'", long8 == 1546156799999L);
//    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        java.util.Date date5 = year4.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(5, (int) (short) 10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Week 0, -1");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        int int6 = week2.compareTo((java.lang.Object) throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        long long6 = week2.getMiddleMillisecond();
//        java.util.Date date7 = week2.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date11 = week10.getEnd();
//        int int12 = week10.getYearValue();
//        java.lang.Class<?> wildcardClass13 = week10.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date17 = week16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone18);
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date24 = week23.getEnd();
//        int int25 = week23.getYearValue();
//        java.lang.Class<?> wildcardClass26 = week23.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.previous();
//        long long29 = week27.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week27.next();
//        org.jfree.data.time.Year year31 = week27.getYear();
//        java.util.Date date32 = year31.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date36 = week35.getEnd();
//        int int37 = week35.getYearValue();
//        java.lang.Class<?> wildcardClass38 = week35.getClass();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date42 = week41.getEnd();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date42);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date42, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date32, timeZone44);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date50 = week49.getEnd();
//        int int51 = week49.getYearValue();
//        java.lang.Class<?> wildcardClass52 = week49.getClass();
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date56 = week55.getEnd();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date56);
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date56, timeZone58);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date32, timeZone58);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date32);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week();
//        long long63 = week62.getSerialIndex();
//        java.lang.Class<?> wildcardClass64 = week62.getClass();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date68 = week67.getEnd();
//        int int69 = week67.getYearValue();
//        java.lang.Class<?> wildcardClass70 = week67.getClass();
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date74 = week73.getEnd();
//        java.util.TimeZone timeZone75 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass70, date74, timeZone75);
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date80 = week79.getEnd();
//        int int81 = week79.getYearValue();
//        java.lang.Class<?> wildcardClass82 = week79.getClass();
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date86 = week85.getEnd();
//        java.util.TimeZone timeZone87 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass82, date86, timeZone87);
//        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass70, date86, timeZone89);
//        java.util.TimeZone timeZone91 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date86, timeZone91);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date32, timeZone91);
//        java.util.Locale locale94 = null;
//        try {
//            org.jfree.data.time.Week week95 = new org.jfree.data.time.Week(date7, timeZone91, locale94);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62199460800001L) + "'", long6 == (-62199460800001L));
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560063600000L + "'", long29 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 107031L + "'", long63 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass70);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-1) + "'", int81 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass82);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNull(regularTimePeriod88);
//        org.junit.Assert.assertNotNull(timeZone89);
//        org.junit.Assert.assertNotNull(regularTimePeriod90);
//        org.junit.Assert.assertNotNull(timeZone91);
//        org.junit.Assert.assertNotNull(regularTimePeriod92);
//        org.junit.Assert.assertNotNull(regularTimePeriod93);
//    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Year year6 = week0.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        long long9 = week8.getSerialIndex();
//        java.util.Date date10 = week8.getEnd();
//        java.lang.Class<?> wildcardClass11 = date10.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        int int16 = week14.getYearValue();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.previous();
//        long long20 = week18.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week18.next();
//        org.jfree.data.time.Year year22 = week18.getYear();
//        java.util.Date date23 = year22.getStart();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date27 = week26.getEnd();
//        int int28 = week26.getYearValue();
//        java.lang.Class<?> wildcardClass29 = week26.getClass();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date33 = week32.getEnd();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date33);
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date33, timeZone35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date23, timeZone35);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date41 = week40.getEnd();
//        int int42 = week40.getYearValue();
//        java.lang.Class<?> wildcardClass43 = week40.getClass();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date47 = week46.getEnd();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date47);
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date47, timeZone49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date23, timeZone49);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date10, timeZone49);
//        java.util.Locale locale53 = null;
//        try {
//            org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date7, timeZone49, locale53);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560063600000L + "'", long20 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        long long8 = week6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.next();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        java.util.Date date11 = year10.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        int int16 = week14.getYearValue();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date21 = week20.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone23);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date29 = week28.getEnd();
//        int int30 = week28.getYearValue();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date11, timeZone37);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        long long41 = week40.getSerialIndex();
//        java.util.Date date42 = week40.getEnd();
//        java.lang.Class<?> wildcardClass43 = date42.getClass();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date47 = week46.getEnd();
//        int int48 = week46.getYearValue();
//        java.lang.Class<?> wildcardClass49 = week46.getClass();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = week50.previous();
//        long long52 = week50.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week50.next();
//        org.jfree.data.time.Year year54 = week50.getYear();
//        java.util.Date date55 = year54.getStart();
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date59 = week58.getEnd();
//        int int60 = week58.getYearValue();
//        java.lang.Class<?> wildcardClass61 = week58.getClass();
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date65 = week64.getEnd();
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date65);
//        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date65, timeZone67);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date55, timeZone67);
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date73 = week72.getEnd();
//        int int74 = week72.getYearValue();
//        java.lang.Class<?> wildcardClass75 = week72.getClass();
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date79 = week78.getEnd();
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date79);
//        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass75, date79, timeZone81);
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date55, timeZone81);
//        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date42, timeZone81);
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date11, timeZone81);
//        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = week86.previous();
//        long long88 = week86.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = week86.next();
//        boolean boolean90 = week85.equals((java.lang.Object) week86);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 107031L + "'", long41 == 107031L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560063600000L + "'", long52 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(year54);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass75);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNotNull(timeZone81);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(regularTimePeriod87);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1560063600000L + "'", long88 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod89);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getFirstMillisecond();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        long long7 = week6.getSerialIndex();
//        java.util.Date date8 = week6.getEnd();
//        boolean boolean9 = week0.equals((java.lang.Object) week6);
//        java.lang.String str10 = week6.toString();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week6.equals((java.lang.Object) date13);
//        long long15 = week6.getFirstMillisecond();
//        java.lang.String str16 = week6.toString();
//        int int18 = week6.compareTo((java.lang.Object) (-1.0d));
//        int int19 = week6.getWeek();
//        org.jfree.data.time.Year year20 = week6.getYear();
//        int int21 = week6.getYearValue();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560063600000L + "'", long15 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 24 + "'", int19 == 24);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 100, -1");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.String str12 = timePeriodFormatException8.toString();
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str14 = timePeriodFormatException8.toString();
        java.lang.String str15 = timePeriodFormatException8.toString();
        int int16 = week2.compareTo((java.lang.Object) timePeriodFormatException8);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-53L) + "'", long4 == (-53L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(9, 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, (int) 'a');
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        long long8 = week6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.next();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        java.util.Date date11 = year10.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        int int16 = week14.getYearValue();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date21 = week20.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone23);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date29 = week28.getEnd();
//        int int30 = week28.getYearValue();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date11, timeZone37);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        long long41 = week40.getSerialIndex();
//        java.util.Date date42 = week40.getEnd();
//        java.lang.Class<?> wildcardClass43 = date42.getClass();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date47 = week46.getEnd();
//        int int48 = week46.getYearValue();
//        java.lang.Class<?> wildcardClass49 = week46.getClass();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = week50.previous();
//        long long52 = week50.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week50.next();
//        org.jfree.data.time.Year year54 = week50.getYear();
//        java.util.Date date55 = year54.getStart();
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date59 = week58.getEnd();
//        int int60 = week58.getYearValue();
//        java.lang.Class<?> wildcardClass61 = week58.getClass();
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date65 = week64.getEnd();
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date65);
//        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date65, timeZone67);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date55, timeZone67);
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date73 = week72.getEnd();
//        int int74 = week72.getYearValue();
//        java.lang.Class<?> wildcardClass75 = week72.getClass();
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date79 = week78.getEnd();
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date79);
//        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass75, date79, timeZone81);
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date55, timeZone81);
//        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date42, timeZone81);
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date11, timeZone81);
//        int int86 = week85.getWeek();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 107031L + "'", long41 == 107031L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560063600000L + "'", long52 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(year54);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass75);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNotNull(timeZone81);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, 0);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (byte) 10, (int) (byte) 0);
        int int6 = week2.compareTo((java.lang.Object) (byte) 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        int int3 = week0.getYearValue();
//        long long4 = week0.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getSerialIndex();
//        java.lang.Class<?> wildcardClass9 = week7.getClass();
//        int int10 = week2.compareTo((java.lang.Object) wildcardClass9);
//        long long11 = week2.getFirstMillisecond();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        int int15 = week2.compareTo((java.lang.Object) year14);
//        int int17 = week2.compareTo((java.lang.Object) 12);
//        int int18 = week2.getWeek();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62199763200000L) + "'", long11 == (-62199763200000L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        long long6 = week2.getFirstMillisecond();
//        int int7 = week2.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        long long9 = week8.getSerialIndex();
//        java.util.Date date10 = week8.getEnd();
//        boolean boolean11 = week2.equals((java.lang.Object) week8);
//        java.lang.String str12 = week8.toString();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        long long14 = week13.getSerialIndex();
//        java.util.Date date15 = week13.getEnd();
//        boolean boolean16 = week8.equals((java.lang.Object) date15);
//        long long17 = week8.getFirstMillisecond();
//        java.lang.String str18 = week8.toString();
//        boolean boolean19 = week0.equals((java.lang.Object) str18);
//        long long20 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 107031L + "'", long14 == 107031L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 24, 2019" + "'", str18.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560063600000L + "'", long20 == 1560063600000L);
//    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
        java.util.Date date3 = week2.getEnd();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        java.util.Date date7 = week2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        java.lang.Class<?> wildcardClass5 = week2.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
//        long long8 = week6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.next();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        java.util.Date date11 = year10.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        int int16 = week14.getYearValue();
//        java.lang.Class<?> wildcardClass17 = week14.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date21 = week20.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone23);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date29 = week28.getEnd();
//        int int30 = week28.getYearValue();
//        java.lang.Class<?> wildcardClass31 = week28.getClass();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date35 = week34.getEnd();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date11, timeZone37);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.previous();
//        long long43 = week41.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week41.next();
//        long long45 = week41.getSerialIndex();
//        int int46 = week41.getWeek();
//        int int47 = week41.getWeek();
//        java.util.Date date48 = week41.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week41.previous();
//        int int50 = week40.compareTo((java.lang.Object) regularTimePeriod49);
//        java.util.Calendar calendar51 = null;
//        try {
//            long long52 = week40.getMiddleMillisecond(calendar51);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560063600000L + "'", long43 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 107031L + "'", long45 == 107031L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 24 + "'", int46 == 24);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 24 + "'", int47 == 24);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-22) + "'", int50 == (-22));
//    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date3 = week2.getEnd();
//        int int4 = week2.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getSerialIndex();
//        java.lang.Class<?> wildcardClass9 = week7.getClass();
//        int int10 = week2.compareTo((java.lang.Object) wildcardClass9);
//        long long11 = week2.getFirstMillisecond();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        org.jfree.data.time.Year year14 = week12.getYear();
//        int int15 = week2.compareTo((java.lang.Object) year14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week2.next();
//        long long17 = week2.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62199763200000L) + "'", long11 == (-62199763200000L));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62199763200000L) + "'", long17 == (-62199763200000L));
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        long long3 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getSerialIndex();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        java.lang.String str13 = timePeriodFormatException6.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
//        java.lang.String str22 = timePeriodFormatException15.toString();
//        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
//        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
//        java.lang.String str32 = timePeriodFormatException25.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
//        java.lang.Throwable[] throwableArray38 = timePeriodFormatException34.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
//        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
//        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
//        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
//        int int47 = week0.compareTo((java.lang.Object) timePeriodFormatException25);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str32.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
//        org.junit.Assert.assertNotNull(throwableArray38);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 0, -1");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str10 = timePeriodFormatException6.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str12 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 0, -1" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: Week 0, -1"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(11, 8);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        long long4 = week2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        java.util.Date date7 = year6.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 100, year6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(24, year10);
//        long long12 = week11.getLastMillisecond();
//        java.lang.String str13 = week11.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = week0.previous();
//        long long2 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date9 = week8.getEnd();
//        int int10 = week8.getYearValue();
//        java.lang.Class<?> wildcardClass11 = week8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, (-1));
//        java.util.Date date15 = week14.getEnd();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = week0.equals((java.lang.Object) wildcardClass11);
//        java.util.Date date20 = week0.getEnd();
//        long long21 = week0.getSerialIndex();
//        java.util.Date date22 = week0.getEnd();
//        java.util.Calendar calendar23 = null;
//        try {
//            long long24 = week0.getMiddleMillisecond(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 107031L + "'", long21 == 107031L);
//        org.junit.Assert.assertNotNull(date22);
//    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week1.previous();
//        long long3 = week1.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week1.next();
//        long long5 = week1.getFirstMillisecond();
//        int int6 = week1.getWeek();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        long long8 = week7.getSerialIndex();
//        java.util.Date date9 = week7.getEnd();
//        boolean boolean10 = week1.equals((java.lang.Object) week7);
//        java.lang.String str11 = week7.toString();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        long long13 = week12.getSerialIndex();
//        java.util.Date date14 = week12.getEnd();
//        boolean boolean15 = week7.equals((java.lang.Object) date14);
//        long long16 = week7.getFirstMillisecond();
//        java.lang.String str17 = week7.toString();
//        int int19 = week7.compareTo((java.lang.Object) (-1.0d));
//        int int20 = week7.getWeek();
//        org.jfree.data.time.Year year21 = week7.getYear();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (byte) 10, year21);
//        org.jfree.data.time.Year year23 = week22.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560063600000L + "'", long3 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 24, 2019" + "'", str11.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107031L + "'", long13 == 107031L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560063600000L + "'", long16 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(year23);
//    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getSerialIndex();
//        java.util.Date date2 = week0.getEnd();
//        java.lang.Class<?> wildcardClass3 = date2.getClass();
//        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        long long7 = week5.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week5.next();
//        long long9 = week5.getFirstMillisecond();
//        int int10 = week5.getWeek();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        long long12 = week11.getSerialIndex();
//        java.util.Date date13 = week11.getEnd();
//        boolean boolean14 = week5.equals((java.lang.Object) week11);
//        java.lang.String str15 = week11.toString();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        long long17 = week16.getSerialIndex();
//        java.util.Date date18 = week16.getEnd();
//        boolean boolean19 = week11.equals((java.lang.Object) date18);
//        java.lang.Class<?> wildcardClass20 = date18.getClass();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date18, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18);
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date18);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 107031L + "'", long1 == 107031L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(class4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 107031L + "'", long12 == 107031L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 24, 2019" + "'", str15.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 107031L + "'", long17 == 107031L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//    }
//}

