import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo(entityCollection7);
        java.awt.geom.Rectangle2D rectangle2D9 = chartRenderingInfo8.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D10.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        piePlot3D10.notifyListeners(plotChangeEvent14);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D9, (org.jfree.chart.plot.Plot) piePlot3D10, "");
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets6.createInsetRectangle(rectangle2D9);
        legendTitle5.setLegendItemGraphicPadding(rectangleInsets6);
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle5.getBounds();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer21 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint22 = xYAreaRenderer21.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = xYAreaRenderer21.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke25 = xYAreaRenderer21.lookupSeriesStroke(2);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(2);
        java.awt.Paint paint31 = xYStepAreaRenderer27.getItemPaint(8, 3, true);
        try {
            org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem(attributedString0, "Nearest", "ChartChangeEventType.GENERAL", "PlotEntity: tooltip = ", (java.awt.Shape) rectangle2D20, stroke25, paint31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesShapesVisible(0, (java.lang.Boolean) false);
        try {
            xYStepRenderer0.setStepPoint((double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires stepPoint in [0.0;1.0]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getRangeMinorGridlineStroke();
        boolean boolean10 = xYAreaRenderer0.hasListener((java.util.EventListener) combinedRangeXYPlot8);
        java.awt.Paint paint11 = combinedRangeXYPlot8.getBackgroundPaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = combinedRangeXYPlot8.getSeriesRenderingOrder();
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((double) ' ', (double) 0L, (double) 100L, 90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockBorder17.getInsets();
        boolean boolean19 = seriesRenderingOrder12.equals((java.lang.Object) rectangleInsets18);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot3D0.getDatasetGroup();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = piePlot3D0.getLabelLinkStyle();
        piePlot3D0.setCircular(false, false);
        piePlot3D0.clearSectionOutlinePaints(false);
        double double13 = piePlot3D0.getDepthFactor();
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.12d + "'", double13 == 0.12d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint1.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot3D0.getDatasetGroup();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = piePlot3D0.getLabelLinkStyle();
        java.lang.String str8 = piePlot3D0.getPlotType();
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pie 3D Plot" + "'", str8.equals("Pie 3D Plot"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo4.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D6.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        piePlot3D6.notifyListeners(plotChangeEvent10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D5, (org.jfree.chart.plot.Plot) piePlot3D6, "");
        java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets2.createInsetRectangle(rectangle2D5);
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets2);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle1.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle1.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Boolean boolean2 = booleanList0.getBoolean((int) (short) 1);
        booleanList0.clear();
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            java.lang.Number number3 = xYSeriesCollection0.getY(0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation1 = null;
        try {
            boolean boolean3 = xYPlot0.removeAnnotation(xYAnnotation1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class10 = periodAxis9.getMinorTickTimePeriodClass();
        boolean boolean11 = periodAxis9.isMinorTickMarksVisible();
        java.awt.Stroke stroke12 = periodAxis9.getMinorTickMarkStroke();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.entity.EntityCollection entityCollection12 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo(entityCollection12);
        java.awt.geom.Rectangle2D rectangle2D14 = chartRenderingInfo13.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D15 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D15.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = null;
        piePlot3D15.notifyListeners(plotChangeEvent19);
        org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D14, (org.jfree.chart.plot.Plot) piePlot3D15, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity25 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis1, (java.awt.Shape) rectangle2D14, "", "");
        org.jfree.chart.axis.Axis axis26 = axisLabelEntity25.getAxis();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(axis26);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = logAxis5.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, list10, (org.jfree.data.Range) dateRange11, false);
        try {
            java.lang.Comparable comparable16 = timeSeriesCollection2.getSeriesKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer3);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(range14);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer0.setBase((double) (byte) 0);
        barRenderer0.setShadowYOffset(4000.0d);
        org.jfree.chart.renderer.category.BarPainter barPainter7 = null;
        try {
            barRenderer0.setBarPainter(barPainter7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint2 = barRenderer0.getShadowPaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint4 = xYAreaRenderer3.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYAreaRenderer3.getBasePositiveItemLabelPosition();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition5);
        boolean boolean7 = barRenderer0.isDrawBarOutline();
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = logAxis2.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = java.awt.Color.red;
        logAxis2.setTickMarkPaint((java.awt.Paint) color8);
        logAxis2.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape12 = logAxis2.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke14 = combinedRangeXYPlot13.getRangeMinorGridlineStroke();
        combinedRangeXYPlot13.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection16 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = combinedRangeXYPlot13.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection16);
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape12, (org.jfree.chart.plot.Plot) combinedRangeXYPlot13);
        combinedRangeXYPlot13.clearAnnotations();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        combinedRangeXYPlot21.setDomainAxisLocation((int) 'a', axisLocation23);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot21);
        org.jfree.chart.title.LegendTitle legendTitle27 = jFreeChart25.getLegend(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = barRenderer28.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke33 = barRenderer28.getItemOutlineStroke((int) '4', (int) (byte) 1, true);
        jFreeChart25.setBorderStroke(stroke33);
        combinedRangeXYPlot13.setDomainZeroBaselineStroke(stroke33);
        polarPlot0.setAngleGridlineStroke(stroke33);
        org.jfree.chart.entity.EntityCollection entityCollection39 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = new org.jfree.chart.ChartRenderingInfo(entityCollection39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo40);
        java.awt.geom.Rectangle2D rectangle2D42 = plotRenderingInfo41.getPlotArea();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot43 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke44 = combinedRangeXYPlot43.getRangeMinorGridlineStroke();
        combinedRangeXYPlot43.clearAnnotations();
        java.awt.Stroke stroke46 = combinedRangeXYPlot43.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer47 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer47.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer47.clearSeriesStrokes(false);
        java.awt.Paint paint53 = xYAreaRenderer47.getSeriesPaint(15);
        boolean boolean55 = xYAreaRenderer47.isSeriesItemLabelsVisible(0);
        int int56 = combinedRangeXYPlot43.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer47);
        org.jfree.chart.entity.EntityCollection entityCollection57 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = new org.jfree.chart.ChartRenderingInfo(entityCollection57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo58);
        java.awt.geom.Rectangle2D rectangle2D60 = plotRenderingInfo59.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D61 = plotRenderingInfo59.getDataArea();
        org.jfree.chart.axis.LogAxis logAxis63 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.axis.AxisState axisState65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = null;
        java.util.List list68 = logAxis63.refreshTicks(graphics2D64, axisState65, rectangle2D66, rectangleEdge67);
        java.awt.Color color69 = java.awt.Color.red;
        logAxis63.setTickMarkPaint((java.awt.Paint) color69);
        logAxis63.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape73 = logAxis63.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot74 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke75 = combinedRangeXYPlot74.getRangeMinorGridlineStroke();
        combinedRangeXYPlot74.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection77 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer78 = combinedRangeXYPlot74.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection77);
        org.jfree.chart.entity.PlotEntity plotEntity79 = new org.jfree.chart.entity.PlotEntity(shape73, (org.jfree.chart.plot.Plot) combinedRangeXYPlot74);
        combinedRangeXYPlot74.clearAnnotations();
        java.awt.geom.Point2D point2D81 = combinedRangeXYPlot74.getQuadrantOrigin();
        org.jfree.chart.plot.XYPlot xYPlot82 = combinedRangeXYPlot43.findSubplot(plotRenderingInfo59, point2D81);
        try {
            polarPlot0.zoomRangeAxes(1.0d, (double) (byte) 1, plotRenderingInfo41, point2D81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(xYItemRenderer17);
        org.junit.Assert.assertNull(legendTitle27);
        org.junit.Assert.assertNull(itemLabelPosition29);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(rectangle2D42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNull(paint53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(list68);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(shape73);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNull(xYItemRenderer78);
        org.junit.Assert.assertNotNull(point2D81);
        org.junit.Assert.assertNull(xYPlot82);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.plot.Plot plot5 = combinedRangeXYPlot0.getRootPlot();
        plot5.setBackgroundImageAlignment((-12566464));
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(plot5);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 255);
        try {
            java.lang.Number number6 = timeSeriesCollection1.getY(2147483647, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            int[] intArray5 = timeSeriesCollection1.getSurroundingItems((int) (short) 10, 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.awt.Shape shape0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType4, 4);
        int int7 = dateTickUnit6.getMultiple();
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D8.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        piePlot3D8.notifyListeners(plotChangeEvent12);
        java.awt.Shape shape14 = piePlot3D8.getLegendItemShape();
        boolean boolean15 = dateTickUnit6.equals((java.lang.Object) piePlot3D8);
        double double16 = dateTickUnit6.getSize();
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        java.util.Date date19 = dateTickUnit6.rollDate(date17);
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity21 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "First", "ItemLabelAnchor.INSIDE10", categoryDataset3, (java.lang.Comparable) date19, (java.lang.Comparable) 90.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4000.0d + "'", double16 == 4000.0d);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getDomainUpperBound(false);
        double double6 = xYSeriesCollection0.getRangeLowerBound(false);
        try {
            java.lang.Number number9 = xYSeriesCollection0.getY((int) ' ', 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getNumberInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}: ({1}, {2})", numberFormat1, numberFormat2);
        int int4 = numberFormat1.getMaximumIntegerDigits();
        java.lang.String str6 = numberFormat1.format(604800000L);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "604,800,000" + "'", str6.equals("604,800,000"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        logAxis1.setAxisLineVisible(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        logAxis1.setTickUnit(numberTickUnit4);
        org.junit.Assert.assertNotNull(numberTickUnit4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer1 = polarPlot0.getRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeMinorGridlineStroke();
        combinedRangeXYPlot2.clearAnnotations();
        java.awt.Color color5 = java.awt.Color.red;
        boolean boolean7 = color5.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot2.setRangeCrosshairPaint((java.awt.Paint) color5);
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) color5);
        java.lang.Object obj11 = rendererChangeEvent10.getRenderer();
        org.junit.Assert.assertNull(polarItemRenderer1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getRangeMinorGridlineStroke();
        boolean boolean10 = xYAreaRenderer0.hasListener((java.util.EventListener) combinedRangeXYPlot8);
        java.lang.String str11 = combinedRangeXYPlot8.getPlotType();
        java.awt.Paint paint12 = combinedRangeXYPlot8.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Combined Range XYPlot" + "'", str11.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        int int5 = xYSeriesCollection3.indexOf((java.lang.Comparable) '#');
        double double7 = xYSeriesCollection3.getDomainUpperBound(false);
        xYSeries2.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection3);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        xYSeries2.removePropertyChangeListener(propertyChangeListener9);
        double double11 = xYSeries2.getMinX();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 4);
        int int3 = dateTickUnit2.getMultiple();
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        boolean boolean11 = dateTickUnit2.equals((java.lang.Object) piePlot3D4);
        double double12 = dateTickUnit2.getSize();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        java.util.Date date15 = dateTickUnit2.rollDate(date13);
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone17 = null;
        try {
            java.util.Date date18 = dateTickUnit2.rollDate(date16, timeZone17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4000.0d + "'", double12 == 4000.0d);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRangeZoomable();
        java.awt.Paint paint2 = polarPlot0.getAngleGridlinePaint();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        java.util.List list11 = logAxis6.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
        java.awt.Color color12 = java.awt.Color.red;
        logAxis6.setTickMarkPaint((java.awt.Paint) color12);
        logAxis6.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape16 = logAxis6.getDownArrow();
        org.jfree.chart.entity.EntityCollection entityCollection17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = new org.jfree.chart.ChartRenderingInfo(entityCollection17);
        java.awt.geom.Rectangle2D rectangle2D19 = chartRenderingInfo18.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D20.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = null;
        piePlot3D20.notifyListeners(plotChangeEvent24);
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D19, (org.jfree.chart.plot.Plot) piePlot3D20, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity30 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis6, (java.awt.Shape) rectangle2D19, "", "");
        try {
            java.awt.Point point31 = polarPlot0.translateValueThetaRadiusToJava2D((double) 1577865599999L, (double) 13, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        java.lang.String str1 = itemLabelAnchor0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = itemLabelAnchor0.equals(obj2);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE10" + "'", str1.equals("ItemLabelAnchor.INSIDE10"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer1 = polarPlot0.getRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeMinorGridlineStroke();
        combinedRangeXYPlot2.clearAnnotations();
        java.awt.Color color5 = java.awt.Color.red;
        boolean boolean7 = color5.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot2.setRangeCrosshairPaint((java.awt.Paint) color5);
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color5);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = polarPlot0.getRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        java.awt.Stroke stroke15 = combinedRangeXYPlot12.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer16.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer16.clearSeriesStrokes(false);
        java.awt.Paint paint22 = xYAreaRenderer16.getSeriesPaint(15);
        boolean boolean24 = xYAreaRenderer16.isSeriesItemLabelsVisible(0);
        int int25 = combinedRangeXYPlot12.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer16);
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo27);
        java.awt.geom.Rectangle2D rectangle2D29 = plotRenderingInfo28.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D30 = plotRenderingInfo28.getDataArea();
        org.jfree.chart.axis.LogAxis logAxis32 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.axis.AxisState axisState34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        java.util.List list37 = logAxis32.refreshTicks(graphics2D33, axisState34, rectangle2D35, rectangleEdge36);
        java.awt.Color color38 = java.awt.Color.red;
        logAxis32.setTickMarkPaint((java.awt.Paint) color38);
        logAxis32.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape42 = logAxis32.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot43 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke44 = combinedRangeXYPlot43.getRangeMinorGridlineStroke();
        combinedRangeXYPlot43.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection46 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = combinedRangeXYPlot43.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection46);
        org.jfree.chart.entity.PlotEntity plotEntity48 = new org.jfree.chart.entity.PlotEntity(shape42, (org.jfree.chart.plot.Plot) combinedRangeXYPlot43);
        combinedRangeXYPlot43.clearAnnotations();
        java.awt.geom.Point2D point2D50 = combinedRangeXYPlot43.getQuadrantOrigin();
        org.jfree.chart.plot.XYPlot xYPlot51 = combinedRangeXYPlot12.findSubplot(plotRenderingInfo28, point2D50);
        org.jfree.chart.axis.LogAxis logAxis53 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.axis.AxisState axisState55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        java.util.List list58 = logAxis53.refreshTicks(graphics2D54, axisState55, rectangle2D56, rectangleEdge57);
        java.awt.Color color59 = java.awt.Color.red;
        logAxis53.setTickMarkPaint((java.awt.Paint) color59);
        logAxis53.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape63 = logAxis53.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot64 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke65 = combinedRangeXYPlot64.getRangeMinorGridlineStroke();
        combinedRangeXYPlot64.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection67 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = combinedRangeXYPlot64.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection67);
        org.jfree.chart.entity.PlotEntity plotEntity69 = new org.jfree.chart.entity.PlotEntity(shape63, (org.jfree.chart.plot.Plot) combinedRangeXYPlot64);
        combinedRangeXYPlot64.clearAnnotations();
        java.awt.geom.Point2D point2D71 = combinedRangeXYPlot64.getQuadrantOrigin();
        try {
            polarPlot0.zoomRangeAxes((double) 6, plotRenderingInfo28, point2D71, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(polarItemRenderer1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(polarItemRenderer10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(xYItemRenderer47);
        org.junit.Assert.assertNotNull(point2D50);
        org.junit.Assert.assertNull(xYPlot51);
        org.junit.Assert.assertNotNull(list58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNull(xYItemRenderer68);
        org.junit.Assert.assertNotNull(point2D71);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        logAxis1.setStandardTickUnits(tickUnitSource2);
        logAxis1.setVisible(false);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        logAxis1.setAxisLinePaint((java.awt.Paint) color6);
        java.awt.color.ColorSpace colorSpace8 = null;
        float[] floatArray14 = new float[] { 2, (-2208960000000L), 15, 1, 5 };
        try {
            float[] floatArray15 = color6.getComponents(colorSpace8, floatArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity18 = new org.jfree.chart.entity.PieSectionEntity(shape11, pieDataset12, (int) 'a', 2019, (java.lang.Comparable) "red", "", "red");
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean20 = pieSectionEntity18.equals((java.lang.Object) range19);
        org.jfree.chart.axis.LogAxis logAxis22 = new org.jfree.chart.axis.LogAxis("");
        boolean boolean23 = pieSectionEntity18.equals((java.lang.Object) "");
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        java.lang.Object obj10 = textTitle9.clone();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint2 = barRenderer0.getShadowPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getSeriesToolTipGenerator((int) (short) 100);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint6 = xYAreaRenderer5.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYAreaRenderer5.getBasePositiveItemLabelPosition();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        org.jfree.chart.entity.EntityCollection entityCollection12 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo(entityCollection12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        boolean boolean15 = month11.equals((java.lang.Object) chartRenderingInfo13);
        long long16 = month11.getFirstMillisecond();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis18 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month11, (org.jfree.data.time.RegularTimePeriod) year17);
        java.util.Locale locale19 = periodAxis18.getLocale();
        boolean boolean20 = itemLabelPosition7.equals((java.lang.Object) periodAxis18);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertNotNull(locale19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 4);
        java.lang.String str3 = dateTickUnitType0.toString();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType5 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType5, 4);
        java.text.DateFormat dateFormat9 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit10 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 10, dateTickUnitType5, (-1), dateFormat9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DateTickUnitType.SECOND" + "'", str3.equals("DateTickUnitType.SECOND"));
        org.junit.Assert.assertNotNull(dateTickUnitType5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis1.centerRange((double) 0L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        boolean boolean14 = logAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        try {
            java.lang.Number number3 = defaultXYDataset0.getX(255, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) false);
        java.lang.String str2 = rendererChangeEvent1.toString();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) str2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.chart.event.RendererChangeEvent[source=false]" + "'", str2.equals("org.jfree.chart.event.RendererChangeEvent[source=false]"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("red");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 1577836800000L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer16 = legendItem15.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer16);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 9, (float) 86400000L);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.NONE" + "'", str1.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesItemLabelsVisible(10, (java.lang.Boolean) false);
        barRenderer0.setIncludeBaseInRange(true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        boolean boolean5 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYAreaRenderer0.setUseFillPaint(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        textTitle9.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.jfree.chart.entity.EntityCollection entityCollection15 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo(entityCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        boolean boolean18 = month14.equals((java.lang.Object) chartRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D19 = chartRenderingInfo16.getChartArea();
        textTitle9.setBounds(rectangle2D19);
        textTitle9.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(2);
        boolean boolean2 = xYStepAreaRenderer1.getShapesVisible();
        boolean boolean3 = xYStepAreaRenderer1.getPlotArea();
        xYStepAreaRenderer1.setShapesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo(entityCollection2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        boolean boolean5 = month1.equals((java.lang.Object) chartRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D6 = chartRenderingInfo3.getChartArea();
        org.jfree.chart.RenderingSource renderingSource7 = null;
        chartRenderingInfo3.setRenderingSource(renderingSource7);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean2 = barRenderer0.getAutoPopulateSeriesFillPaint();
        boolean boolean3 = barRenderer0.getShadowsVisible();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer6.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer6.clearSeriesStrokes(false);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer6.setBaseLegendShape(shape12);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke15 = combinedRangeXYPlot14.getRangeMinorGridlineStroke();
        boolean boolean16 = xYAreaRenderer6.hasListener((java.util.EventListener) combinedRangeXYPlot14);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke19 = combinedRangeXYPlot18.getRangeMinorGridlineStroke();
        combinedRangeXYPlot18.clearAnnotations();
        boolean boolean21 = combinedRangeXYPlot18.isDomainPannable();
        boolean boolean22 = combinedRangeXYPlot18.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis24 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource25 = null;
        logAxis24.setStandardTickUnits(tickUnitSource25);
        boolean boolean27 = logAxis24.isNegativeArrowVisible();
        logAxis24.pan((double) (short) 1);
        combinedRangeXYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis24);
        org.jfree.chart.axis.LogAxis logAxis32 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.axis.AxisState axisState34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        java.util.List list37 = logAxis32.refreshTicks(graphics2D33, axisState34, rectangle2D35, rectangleEdge36);
        java.awt.Color color38 = java.awt.Color.red;
        logAxis32.setTickMarkPaint((java.awt.Paint) color38);
        logAxis32.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape42 = logAxis32.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot43 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke44 = combinedRangeXYPlot43.getRangeMinorGridlineStroke();
        combinedRangeXYPlot43.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection46 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = combinedRangeXYPlot43.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection46);
        org.jfree.chart.entity.PlotEntity plotEntity48 = new org.jfree.chart.entity.PlotEntity(shape42, (org.jfree.chart.plot.Plot) combinedRangeXYPlot43);
        java.util.List list49 = combinedRangeXYPlot43.getAnnotations();
        org.jfree.chart.axis.LogAxis logAxis52 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource53 = null;
        logAxis52.setStandardTickUnits(tickUnitSource53);
        boolean boolean55 = logAxis52.isNegativeArrowVisible();
        logAxis52.pan((double) (short) 1);
        combinedRangeXYPlot43.setDomainAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) logAxis52, false);
        org.jfree.chart.plot.PiePlot3D piePlot3D60 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D60.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent64 = null;
        piePlot3D60.notifyListeners(plotChangeEvent64);
        logAxis52.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D60);
        org.jfree.chart.plot.Marker marker67 = null;
        org.jfree.chart.block.BlockBorder blockBorder72 = new org.jfree.chart.block.BlockBorder((double) ' ', (double) 0L, (double) 100L, 90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets73 = blockBorder72.getInsets();
        org.jfree.chart.entity.EntityCollection entityCollection74 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo75 = new org.jfree.chart.ChartRenderingInfo(entityCollection74);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo76 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo75);
        java.awt.geom.Rectangle2D rectangle2D77 = chartRenderingInfo75.getChartArea();
        java.awt.Shape shape78 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D77);
        java.awt.geom.Rectangle2D rectangle2D79 = rectangleInsets73.createInsetRectangle(rectangle2D77);
        xYAreaRenderer6.drawDomainMarker(graphics2D17, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18, (org.jfree.chart.axis.ValueAxis) logAxis52, marker67, rectangle2D77);
        try {
            barRenderer0.drawBackground(graphics2D4, categoryPlot5, rectangle2D77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(xYItemRenderer47);
        org.junit.Assert.assertNotNull(list49);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangleInsets73);
        org.junit.Assert.assertNotNull(rectangle2D77);
        org.junit.Assert.assertNotNull(shape78);
        org.junit.Assert.assertNotNull(rectangle2D79);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        try {
            double double3 = defaultXYDataset0.getXValue(0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot3D0.getDatasetGroup();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = piePlot3D0.getLabelLinkStyle();
        piePlot3D0.setCircular(false, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        piePlot3D0.setDrawingSupplier(drawingSupplier11);
        java.awt.Paint paint13 = null;
        try {
            piePlot3D0.setBaseSectionOutlinePaint(paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Paint paint6 = xYAreaRenderer0.getSeriesPaint(15);
        boolean boolean7 = xYAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator9 = null;
        xYAreaRenderer0.setSeriesItemLabelGenerator((int) ' ', xYItemLabelGenerator9, false);
        java.awt.Stroke stroke13 = xYAreaRenderer0.getSeriesOutlineStroke(13);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(stroke13);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Object obj1 = null;
        boolean boolean2 = booleanList0.equals(obj1);
        int int3 = booleanList0.size();
        int int4 = booleanList0.size();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_SERIES_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "series" + "'", str0.equals("series"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        java.awt.Stroke stroke6 = xYAreaRenderer0.getBaseStroke();
        java.awt.Paint paint8 = xYAreaRenderer0.lookupSeriesOutlinePaint((-1));
        boolean boolean9 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYAreaRenderer0.getPositiveItemLabelPosition(0, 1, true);
        xYAreaRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "item", "[size=1]", "TextBlockAnchor.CENTER_RIGHT");
        double double4 = timeSeries3.getMaxY();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        int int2 = timeSeriesCollection1.getSeriesCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedRangeXYPlot12.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        java.util.List list18 = combinedRangeXYPlot12.getAnnotations();
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = null;
        logAxis21.setStandardTickUnits(tickUnitSource22);
        boolean boolean24 = logAxis21.isNegativeArrowVisible();
        logAxis21.pan((double) (short) 1);
        combinedRangeXYPlot12.setDomainAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) logAxis21, false);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) 8);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke33 = combinedRangeXYPlot32.getRangeMinorGridlineStroke();
        combinedRangeXYPlot32.clearAnnotations();
        java.awt.Color color35 = java.awt.Color.red;
        boolean boolean37 = color35.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot32.setRangeCrosshairPaint((java.awt.Paint) color35);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection40 = combinedRangeXYPlot32.getDomainMarkers(layer39);
        boolean boolean42 = combinedRangeXYPlot12.removeRangeMarker(2019, (org.jfree.chart.plot.Marker) valueMarker31, layer39, true);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, false);
        double double6 = intervalXYDelegate4.getDomainLowerBound(true);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.awt.geom.Rectangle2D rectangle2D2 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D3.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot3D3.notifyListeners(plotChangeEvent7);
        org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D2, (org.jfree.chart.plot.Plot) piePlot3D3, "");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke12 = combinedRangeXYPlot11.getRangeMinorGridlineStroke();
        combinedRangeXYPlot11.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedRangeXYPlot11.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection14);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D2, (org.jfree.chart.plot.Plot) combinedRangeXYPlot11, "");
        org.jfree.chart.axis.AxisSpace axisSpace18 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot11.setFixedDomainAxisSpace(axisSpace18);
        double double20 = axisSpace18.getBottom();
        axisSpace18.setTop(0.05d);
        double double23 = axisSpace18.getLeft();
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesShapesVisible(0, (java.lang.Boolean) false);
        java.awt.Font font5 = xYStepRenderer0.getLegendTextFont(8);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        xYStepRenderer0.setSeriesStroke((int) (byte) 0, stroke7, true);
        org.jfree.chart.LegendItem legendItem12 = xYStepRenderer0.getLegendItem((int) 'a', (int) '4');
        xYStepRenderer0.setSeriesShapesFilled((int) (byte) 1, false);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        combinedRangeXYPlot20.setDomainAxisLocation((int) 'a', axisLocation22);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot20);
        org.jfree.chart.axis.LogAxis logAxis26 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = null;
        logAxis26.setStandardTickUnits(tickUnitSource27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection32 = new org.jfree.data.time.TimeSeriesCollection(timeZone31);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = combinedRangeXYPlot30.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection32);
        try {
            xYStepRenderer0.drawItem(graphics2D16, xYItemRendererState17, rectangle2D18, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot20, (org.jfree.chart.axis.ValueAxis) logAxis26, valueAxis29, (org.jfree.data.xy.XYDataset) timeSeriesCollection32, 4, 0, false, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(legendItem12);
        org.junit.Assert.assertNull(xYItemRenderer33);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        logAxis1.setStandardTickUnits(tickUnitSource2);
        logAxis1.setVisible(false);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        logAxis1.setAxisLinePaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer8.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer8.clearSeriesStrokes(false);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYAreaRenderer8.setSeriesFillPaint((int) ' ', (java.awt.Paint) color14, true);
        float[] floatArray21 = new float[] { 0.5f, 2, (byte) 10, 100L };
        float[] floatArray22 = color14.getComponents(floatArray21);
        float[] floatArray23 = color6.getColorComponents(floatArray21);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100L, (float) (short) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot28 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation30 = null;
        combinedRangeXYPlot28.setDomainAxisLocation((int) 'a', axisLocation30);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot28);
        org.jfree.chart.title.LegendTitle legendTitle34 = jFreeChart32.getLegend(100);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity37 = new org.jfree.chart.entity.JFreeChartEntity(shape26, jFreeChart32, "", "0,0,1,1");
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int40 = color39.getGreen();
        java.awt.Color color41 = java.awt.Color.getColor("hi!", color39);
        boolean boolean42 = jFreeChart32.equals((java.lang.Object) color41);
        int int43 = jFreeChart32.getBackgroundImageAlignment();
        java.awt.Font font47 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color48 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine49 = new org.jfree.chart.text.TextLine("hi!", font47, (java.awt.Paint) color48);
        org.jfree.chart.plot.PolarPlot polarPlot50 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart52 = new org.jfree.chart.JFreeChart("0,0,1,1", font47, (org.jfree.chart.plot.Plot) polarPlot50, false);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("0,0,1,1", font47);
        textTitle53.setToolTipText("red");
        java.lang.String str56 = textTitle53.getID();
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        textTitle53.setBackgroundPaint((java.awt.Paint) color57);
        textTitle53.setText("item");
        jFreeChart32.addSubtitle((org.jfree.chart.title.Title) textTitle53);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType62 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent63 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color6, jFreeChart32, chartChangeEventType62);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNull(legendTitle34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 255 + "'", int40 == 255);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 15 + "'", int43 == 15);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(chartChangeEventType62);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getDomainUpperBound(false);
        double double5 = xYSeriesCollection0.getIntervalPositionFactor();
        double double6 = xYSeriesCollection0.getIntervalPositionFactor();
        org.jfree.chart.axis.LogAxis logAxis8 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = logAxis8.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        java.awt.Color color14 = java.awt.Color.red;
        logAxis8.setTickMarkPaint((java.awt.Paint) color14);
        logAxis8.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape18 = logAxis8.getDownArrow();
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity25 = new org.jfree.chart.entity.PieSectionEntity(shape18, pieDataset19, (int) 'a', 2019, (java.lang.Comparable) "red", "", "red");
        int int26 = pieSectionEntity25.getSectionIndex();
        boolean boolean27 = xYSeriesCollection0.equals((java.lang.Object) pieSectionEntity25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        combinedRangeXYPlot4.setDomainAxisLocation((int) 'a', axisLocation6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer11.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke16 = barRenderer11.getItemOutlineStroke((int) '4', (int) (byte) 1, true);
        jFreeChart8.setBorderStroke(stroke16);
        barRenderer0.setSeriesStroke(0, stroke16);
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = polarPlot19.getRenderer();
        java.awt.Font font21 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        polarPlot19.setAngleLabelFont(font21);
        barRenderer0.setBaseItemLabelFont(font21, true);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNull(legendTitle10);
        org.junit.Assert.assertNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(polarItemRenderer20);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("0,0,1,1", font2, (org.jfree.chart.plot.Plot) polarPlot5, false);
        jFreeChart7.setTitle("red");
        jFreeChart7.fireChartChanged();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        textTitle9.setToolTipText("red");
        java.lang.String str12 = textTitle9.getID();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        textTitle9.setBackgroundPaint((java.awt.Paint) color13);
        double double15 = textTitle9.getHeight();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = xYAreaRenderer0.getToolTipGenerator(8, 2019, false);
        boolean boolean7 = xYAreaRenderer0.isSeriesVisible(13);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(xYToolTipGenerator5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean2 = segmentedTimeline0.containsDomainValue(date1);
        java.util.List list3 = segmentedTimeline0.getExceptionSegments();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = combinedRangeXYPlot4.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = logAxis9.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6, list14, (org.jfree.data.Range) dateRange15, false);
        segmentedTimeline0.addExceptions(list14);
        java.util.Date date20 = null;
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        java.util.Date date22 = month21.getEnd();
        try {
            boolean boolean23 = segmentedTimeline0.containsDomainRange(date20, date22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 100);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = chartRenderingInfo5.getChartArea();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D7);
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D9.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        piePlot3D9.notifyListeners(plotChangeEvent13);
        org.jfree.data.general.DatasetGroup datasetGroup15 = piePlot3D9.getDatasetGroup();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle16 = piePlot3D9.getLabelLinkStyle();
        piePlot3D9.setCircular(false, false);
        piePlot3D9.clearSectionOutlinePaints(false);
        double double23 = piePlot3D9.getExplodePercent((java.lang.Comparable) "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.awt.Paint paint24 = piePlot3D9.getBaseSectionOutlinePaint();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection28 = new org.jfree.data.time.TimeSeriesCollection(timeZone27);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = combinedRangeXYPlot26.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection28);
        org.jfree.chart.axis.LogAxis logAxis31 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.axis.AxisState axisState33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        java.util.List list36 = logAxis31.refreshTicks(graphics2D32, axisState33, rectangle2D34, rectangleEdge35);
        org.jfree.data.time.DateRange dateRange37 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange38 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange37);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection28, list36, (org.jfree.data.Range) dateRange37, false);
        boolean boolean41 = day25.equals((java.lang.Object) false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer42 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint43 = xYAreaRenderer42.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = xYAreaRenderer42.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke46 = xYAreaRenderer42.lookupSeriesStroke(2);
        boolean boolean47 = day25.equals((java.lang.Object) stroke46);
        java.awt.Color color49 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Color color50 = java.awt.Color.getColor("AxisLabelEntity: label = hi!", color49);
        try {
            org.jfree.chart.LegendItem legendItem51 = new org.jfree.chart.LegendItem(attributedString0, "{0}: ({1}, {2})", "Nearest", "DateTickUnit[DateTickUnitType.SECOND, 4]", shape8, paint24, stroke46, (java.awt.Paint) color49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(datasetGroup15);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle16);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(xYItemRenderer29);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNull(range40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(itemLabelPosition44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color50);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.DESCENDING;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        int int3 = xYSeriesCollection1.indexOf((java.lang.Comparable) '#');
        double double5 = xYSeriesCollection1.getDomainUpperBound(false);
        double double6 = xYSeriesCollection1.getIntervalPositionFactor();
        org.jfree.data.Range range7 = xYStepRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1);
        xYSeriesCollection1.validateObject();
        double double10 = xYSeriesCollection1.getDomainUpperBound(true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getNumberInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}: ({1}, {2})", numberFormat1, numberFormat2);
        numberFormat1.setMaximumFractionDigits((int) (short) -1);
        int int6 = numberFormat1.getMinimumFractionDigits();
        int int7 = numberFormat1.getMinimumFractionDigits();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo2.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        plotRenderingInfo2.setPlotArea(rectangle2D4);
        org.junit.Assert.assertNull(rectangle2D3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        combinedRangeXYPlot0.setDomainAxisLocation((int) 'a', axisLocation2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = combinedRangeXYPlot0.getDomainAxis();
        boolean boolean5 = combinedRangeXYPlot0.isDomainMinorGridlinesVisible();
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        java.util.TimeZone timeZone2 = null;
        java.util.Locale locale3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1, timeZone2, locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.awt.Image image0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeImage(image0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color1);
        java.awt.Color color3 = color1.darker();
        int int4 = color3.getAlpha();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) int4, true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        piePlot3D0.setMinimumArcAngleToDraw((double) (short) 0);
        piePlot3D0.setExplodePercent((java.lang.Comparable) 4000.0d, (double) 100L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("0,0,1,1", font2, (org.jfree.chart.plot.Plot) polarPlot5, false);
        polarPlot5.setAngleLabelsVisible(false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "item", "[size=1]", "TextBlockAnchor.CENTER_RIGHT");
        timeSeries3.setMaximumItemAge(604800000L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        boolean boolean8 = year6.equals((java.lang.Object) 6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year6, (double) 2.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.05d, "", false);
        java.text.ParsePosition parsePosition5 = null;
        java.lang.Number number6 = logFormat3.parse("", parsePosition5);
        java.util.Currency currency7 = null;
        try {
            logFormat3.setCurrency(currency7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        boolean boolean24 = legendItem15.isLineVisible();
        org.jfree.data.xy.XYSeries xYSeries27 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double28 = xYSeries27.getMinX();
        xYSeries27.add((double) 100.0f, 0.0d);
        boolean boolean32 = legendItem15.equals((java.lang.Object) xYSeries27);
        java.awt.Font font36 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color37 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("hi!", font36, (java.awt.Paint) color37);
        org.jfree.chart.plot.PolarPlot polarPlot39 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("0,0,1,1", font36, (org.jfree.chart.plot.Plot) polarPlot39, false);
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("0,0,1,1", font36);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = textTitle42.getTextAlignment();
        java.lang.String str44 = horizontalAlignment43.toString();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot45 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke46 = combinedRangeXYPlot45.getRangeMinorGridlineStroke();
        combinedRangeXYPlot45.clearAnnotations();
        java.awt.Paint paint48 = combinedRangeXYPlot45.getDomainMinorGridlinePaint();
        java.awt.Color color49 = java.awt.Color.YELLOW;
        combinedRangeXYPlot45.setDomainGridlinePaint((java.awt.Paint) color49);
        boolean boolean51 = horizontalAlignment43.equals((java.lang.Object) color49);
        legendItem15.setFillPaint((java.awt.Paint) color49);
        boolean boolean53 = legendItem15.isLineVisible();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "HorizontalAlignment.CENTER" + "'", str44.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        textTitle9.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.jfree.chart.entity.EntityCollection entityCollection15 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo(entityCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        boolean boolean18 = month14.equals((java.lang.Object) chartRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D19 = chartRenderingInfo16.getChartArea();
        textTitle9.setBounds(rectangle2D19);
        textTitle9.setMaximumLinesToDisplay((int) (short) 100);
        double double23 = textTitle9.getHeight();
        textTitle9.setMaximumLinesToDisplay((int) (byte) -1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        boolean boolean4 = piePlot3D0.getAutoPopulateSectionPaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot3D0.getLabelDistributor();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord6 = null;
        try {
            abstractPieLabelDistributor5.addPieLabelRecord(pieLabelRecord6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.chart.entity.EntityCollection entityCollection6 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo(entityCollection6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        boolean boolean9 = month5.equals((java.lang.Object) chartRenderingInfo7);
        long long10 = month5.getFirstMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) year11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month5.next();
        java.lang.Comparable[] comparableArray14 = new java.lang.Comparable[] { '4', (-2.0d), (-1.0d), regularTimePeriod13 };
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.next();
        java.lang.Comparable[] comparableArray22 = new java.lang.Comparable[] { "ERROR : Relative To String", true, 1.0E-5d, 10L, regularTimePeriod20, (-1) };
        double[] doubleArray26 = new double[] { 3, 172800000L, (-2208960000000L) };
        double[] doubleArray30 = new double[] { 3, 172800000L, (-2208960000000L) };
        double[] doubleArray34 = new double[] { 3, 172800000L, (-2208960000000L) };
        double[] doubleArray38 = new double[] { 3, 172800000L, (-2208960000000L) };
        double[][] doubleArray39 = new double[][] { doubleArray26, doubleArray30, doubleArray34, doubleArray38 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray14, comparableArray22, doubleArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of column keys does not match the number of columns in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372400000L + "'", long10 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(comparableArray14);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(comparableArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        boolean boolean24 = legendItem15.isLineVisible();
        org.jfree.data.xy.XYSeries xYSeries27 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double28 = xYSeries27.getMinX();
        xYSeries27.add((double) 100.0f, 0.0d);
        boolean boolean32 = legendItem15.equals((java.lang.Object) xYSeries27);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer33 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer33.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer33.clearSeriesStrokes(false);
        xYAreaRenderer33.setAutoPopulateSeriesShape(true);
        java.awt.Shape shape40 = xYAreaRenderer33.getBaseShape();
        legendItem15.setLine(shape40);
        java.lang.String str42 = legendItem15.getToolTipText();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean3 = xYStepRenderer0.getItemLineVisible((-1), 100);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        java.util.List list11 = logAxis6.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
        java.awt.Color color12 = java.awt.Color.red;
        logAxis6.setTickMarkPaint((java.awt.Paint) color12);
        logAxis6.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape16 = logAxis6.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke18 = combinedRangeXYPlot17.getRangeMinorGridlineStroke();
        combinedRangeXYPlot17.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection20 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = combinedRangeXYPlot17.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection20);
        org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity(shape16, (org.jfree.chart.plot.Plot) combinedRangeXYPlot17);
        combinedRangeXYPlot17.clearAnnotations();
        org.jfree.chart.axis.LogAxis logAxis25 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.AxisState axisState27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        java.util.List list30 = logAxis25.refreshTicks(graphics2D26, axisState27, rectangle2D28, rectangleEdge29);
        java.awt.Color color31 = java.awt.Color.red;
        logAxis25.setTickMarkPaint((java.awt.Paint) color31);
        logAxis25.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis25.setAutoTickUnitSelection(true, true);
        combinedRangeXYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis25);
        org.jfree.chart.axis.LogAxis logAxis40 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.axis.AxisState axisState42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        java.util.List list45 = logAxis40.refreshTicks(graphics2D41, axisState42, rectangle2D43, rectangleEdge44);
        java.awt.Color color46 = java.awt.Color.red;
        logAxis40.setTickMarkPaint((java.awt.Paint) color46);
        double double48 = logAxis40.getAutoRangeMinimumSize();
        org.jfree.chart.entity.EntityCollection entityCollection49 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = new org.jfree.chart.ChartRenderingInfo(entityCollection49);
        java.awt.geom.Rectangle2D rectangle2D51 = chartRenderingInfo50.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D52 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D52.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent56 = null;
        piePlot3D52.notifyListeners(plotChangeEvent56);
        org.jfree.chart.entity.PlotEntity plotEntity59 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D51, (org.jfree.chart.plot.Plot) piePlot3D52, "");
        xYStepRenderer0.fillDomainGridBand(graphics2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot17, (org.jfree.chart.axis.ValueAxis) logAxis40, rectangle2D51, (-2.0d), 0.0d);
        logAxis40.setInverted(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0E-8d + "'", double48 == 1.0E-8d);
        org.junit.Assert.assertNotNull(rectangle2D51);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint3 = xYAreaRenderer2.getBaseItemLabelPaint();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = null;
        xYAreaRenderer2.setSeriesURLGenerator(8, xYURLGenerator5, false);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        combinedRangeXYPlot10.setDomainAxisLocation((int) 'a', axisLocation12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot10);
        boolean boolean15 = combinedRangeXYPlot10.isDomainZeroBaselineVisible();
        combinedRangeXYPlot10.setDomainPannable(false);
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.axis.AxisState axisState21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        java.util.List list24 = logAxis19.refreshTicks(graphics2D20, axisState21, rectangle2D22, rectangleEdge23);
        java.awt.Color color25 = java.awt.Color.red;
        logAxis19.setTickMarkPaint((java.awt.Paint) color25);
        logAxis19.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape29 = logAxis19.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke31 = combinedRangeXYPlot30.getRangeMinorGridlineStroke();
        combinedRangeXYPlot30.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection33 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = combinedRangeXYPlot30.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection33);
        org.jfree.chart.entity.PlotEntity plotEntity35 = new org.jfree.chart.entity.PlotEntity(shape29, (org.jfree.chart.plot.Plot) combinedRangeXYPlot30);
        java.util.List list36 = combinedRangeXYPlot30.getAnnotations();
        org.jfree.chart.axis.LogAxis logAxis39 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource40 = null;
        logAxis39.setStandardTickUnits(tickUnitSource40);
        boolean boolean42 = logAxis39.isNegativeArrowVisible();
        logAxis39.pan((double) (short) 1);
        combinedRangeXYPlot30.setDomainAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) logAxis39, false);
        double double48 = logAxis39.calculateValue((double) 1559372400000L);
        org.jfree.chart.plot.Marker marker49 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection51 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo52 = new org.jfree.chart.ChartRenderingInfo(entityCollection51);
        java.awt.geom.Rectangle2D rectangle2D53 = chartRenderingInfo52.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D54 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D54.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent58 = null;
        piePlot3D54.notifyListeners(plotChangeEvent58);
        org.jfree.chart.entity.PlotEntity plotEntity61 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D53, (org.jfree.chart.plot.Plot) piePlot3D54, "");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot62 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke63 = combinedRangeXYPlot62.getRangeMinorGridlineStroke();
        combinedRangeXYPlot62.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection65 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = combinedRangeXYPlot62.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection65);
        org.jfree.chart.entity.PlotEntity plotEntity68 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D53, (org.jfree.chart.plot.Plot) combinedRangeXYPlot62, "");
        java.awt.geom.Rectangle2D rectangle2D69 = rectangleInsets50.createOutsetRectangle(rectangle2D53);
        xYAreaRenderer2.drawDomainMarker(graphics2D8, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot10, (org.jfree.chart.axis.ValueAxis) logAxis39, marker49, rectangle2D53);
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = null;
        org.jfree.chart.entity.EntityCollection entityCollection73 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo74 = new org.jfree.chart.ChartRenderingInfo(entityCollection73);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo74);
        java.awt.geom.Rectangle2D rectangle2D76 = plotRenderingInfo75.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D77 = plotRenderingInfo75.getDataArea();
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState78 = barRenderer3D0.initialise(graphics2D1, rectangle2D53, categoryPlot71, 4, plotRenderingInfo75);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(xYItemRenderer34);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.POSITIVE_INFINITY + "'", double48 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNull(xYItemRenderer66);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNull(rectangle2D76);
        org.junit.Assert.assertNotNull(rectangle2D77);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        combinedRangeXYPlot1.setRangeCrosshairLockedOnData(true);
        java.lang.Object obj8 = combinedRangeXYPlot1.clone();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        combinedRangeXYPlot1.datasetChanged(datasetChangeEvent9);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer5.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer5.clearSeriesStrokes(false);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer5.setBaseLegendShape(shape11);
        combinedRangeXYPlot0.setRenderer(15, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5, true);
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        combinedRangeXYPlot0.setRangeZeroBaselinePaint(paint15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedRangeXYPlot0.getRangeAxisLocation();
        combinedRangeXYPlot0.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.function.Function2D function2D0 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(function2D0, (double) 10, (double) 1577836800000L, (int) ' ', comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean2 = barRenderer0.getAutoPopulateSeriesFillPaint();
        boolean boolean3 = barRenderer0.getShadowsVisible();
        double double4 = barRenderer0.getBase();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color1);
        boolean boolean3 = polarPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement0.clear();
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        combinedRangeXYPlot1.setDomainAxisLocation((int) 'a', axisLocation3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        jFreeChart5.setBackgroundImageAlignment(100);
        jFreeChart5.removeLegend();
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.color.ColorSpace colorSpace1 = null;
        org.jfree.chart.axis.LogAxis logAxis3 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        logAxis3.setStandardTickUnits(tickUnitSource4);
        logAxis3.setVisible(false);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        logAxis3.setAxisLinePaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer10.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer10.clearSeriesStrokes(false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYAreaRenderer10.setSeriesFillPaint((int) ' ', (java.awt.Paint) color16, true);
        float[] floatArray23 = new float[] { 0.5f, 2, (byte) 10, 100L };
        float[] floatArray24 = color16.getComponents(floatArray23);
        float[] floatArray25 = color8.getColorComponents(floatArray23);
        try {
            float[] floatArray26 = color0.getColorComponents(colorSpace1, floatArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        textTitle9.setToolTipText("red");
        java.awt.geom.Rectangle2D rectangle2D12 = textTitle9.getBounds();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
//        java.util.TimeZone timeZone2 = null;
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeZone2);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = combinedRangeXYPlot1.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
//        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
//        java.awt.Graphics2D graphics2D7 = null;
//        org.jfree.chart.axis.AxisState axisState8 = null;
//        java.awt.geom.Rectangle2D rectangle2D9 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
//        java.util.List list11 = logAxis6.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
//        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange();
//        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange12);
//        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3, list11, (org.jfree.data.Range) dateRange12, false);
//        boolean boolean16 = day0.equals((java.lang.Object) false);
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        java.awt.Paint paint18 = xYAreaRenderer17.getBaseItemLabelPaint();
//        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = xYAreaRenderer17.getBasePositiveItemLabelPosition();
//        java.awt.Stroke stroke21 = xYAreaRenderer17.lookupSeriesStroke(2);
//        boolean boolean22 = day0.equals((java.lang.Object) stroke21);
//        int int23 = day0.getDayOfMonth();
//        org.junit.Assert.assertNull(xYItemRenderer4);
//        org.junit.Assert.assertNotNull(list11);
//        org.junit.Assert.assertNull(range15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(paint18);
//        org.junit.Assert.assertNotNull(itemLabelPosition19);
//        org.junit.Assert.assertNotNull(stroke21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 13 + "'", int23 == 13);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = logAxis2.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = java.awt.Color.red;
        logAxis2.setTickMarkPaint((java.awt.Paint) color8);
        logAxis2.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape12 = logAxis2.getDownArrow();
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        java.awt.geom.Rectangle2D rectangle2D15 = chartRenderingInfo14.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D16 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D16.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = null;
        piePlot3D16.notifyListeners(plotChangeEvent20);
        org.jfree.chart.entity.PlotEntity plotEntity23 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D15, (org.jfree.chart.plot.Plot) piePlot3D16, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity26 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis2, (java.awt.Shape) rectangle2D15, "", "");
        boolean boolean27 = standardPieSectionLabelGenerator0.equals((java.lang.Object) logAxis2);
        boolean boolean28 = logAxis2.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean2 = segmentedTimeline0.containsDomainValue(date1);
        segmentedTimeline0.addException((long) (short) 100);
        segmentedTimeline0.addException((long) 255);
        long long7 = segmentedTimeline0.getSegmentSize();
        long long9 = segmentedTimeline0.toTimelineValue((long) (byte) 1);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 86400000L + "'", long7 == 86400000L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577836800000L + "'", long9 == 1577836800000L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        java.awt.geom.Rectangle2D rectangle2D6 = chartRenderingInfo5.getChartArea();
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) ' ', (double) 0L, (double) 100L, 90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo14.getChartArea();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D16);
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets12.createInsetRectangle(rectangle2D16);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke20 = combinedRangeXYPlot19.getRangeMinorGridlineStroke();
        combinedRangeXYPlot19.clearAnnotations();
        boolean boolean22 = combinedRangeXYPlot19.isDomainPannable();
        boolean boolean23 = combinedRangeXYPlot19.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = combinedRangeXYPlot19.getDomainAxisEdge();
        double double25 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D16, rectangleEdge24);
        try {
            java.util.List list26 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D6, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = barRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNull(categoryURLGenerator2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearRangeMarkers(0);
        boolean boolean3 = combinedRangeXYPlot0.isNotify();
        org.jfree.chart.axis.ValueAxis valueAxis5 = combinedRangeXYPlot0.getDomainAxis(2);
        boolean boolean6 = combinedRangeXYPlot0.canSelectByRegion();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.axis.NumberAxis numberAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke6 = combinedRangeXYPlot5.getRangeMinorGridlineStroke();
        combinedRangeXYPlot5.clearAnnotations();
        java.awt.Stroke stroke8 = combinedRangeXYPlot5.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer9.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer9.clearSeriesStrokes(false);
        java.awt.Paint paint15 = xYAreaRenderer9.getSeriesPaint(15);
        boolean boolean17 = xYAreaRenderer9.isSeriesItemLabelsVisible(0);
        int int18 = combinedRangeXYPlot5.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer9);
        org.jfree.chart.axis.LogAxis logAxis20 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.AxisState axisState22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        java.util.List list25 = logAxis20.refreshTicks(graphics2D21, axisState22, rectangle2D23, rectangleEdge24);
        java.awt.Color color26 = java.awt.Color.red;
        logAxis20.setTickMarkPaint((java.awt.Paint) color26);
        logAxis20.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape30 = logAxis20.getDownArrow();
        org.jfree.chart.entity.EntityCollection entityCollection31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo(entityCollection31);
        java.awt.geom.Rectangle2D rectangle2D33 = chartRenderingInfo32.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D34 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D34.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent38 = null;
        piePlot3D34.notifyListeners(plotChangeEvent38);
        org.jfree.chart.entity.PlotEntity plotEntity41 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D33, (org.jfree.chart.plot.Plot) piePlot3D34, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity44 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis20, (java.awt.Shape) rectangle2D33, "", "");
        java.lang.String str45 = logAxis20.getLabel();
        int int46 = combinedRangeXYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis20);
        java.awt.Font font47 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        logAxis20.setLabelFont(font47);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, 0.12d, 0.0d, Double.POSITIVE_INFINITY, 1.0E-8d, font47);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(font47);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, true);
        combinedRangeXYPlot0.clearRangeMarkers();
        java.lang.String str7 = combinedRangeXYPlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D5.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        piePlot3D5.notifyListeners(plotChangeEvent9);
        java.awt.Shape shape11 = piePlot3D5.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot12.setAngleGridlinePaint((java.awt.Paint) color13);
        java.awt.Color color15 = color13.darker();
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape11, (java.awt.Paint) color15);
        java.awt.Shape shape17 = legendItem16.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection18 = new org.jfree.data.xy.XYSeriesCollection();
        int int20 = xYSeriesCollection18.indexOf((java.lang.Comparable) '#');
        double double22 = xYSeriesCollection18.getDomainUpperBound(false);
        double double23 = xYSeriesCollection18.getIntervalPositionFactor();
        legendItem16.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection18);
        boolean boolean25 = legendItem16.isLineVisible();
        boolean boolean26 = standardGradientPaintTransformer0.equals((java.lang.Object) boolean25);
        java.lang.Object obj27 = standardGradientPaintTransformer0.clone();
        java.awt.GradientPaint gradientPaint28 = null;
        java.awt.Shape shape29 = null;
        try {
            java.awt.GradientPaint gradientPaint30 = standardGradientPaintTransformer0.transform(gradientPaint28, shape29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.5d + "'", double23 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("0,0,1,1", font2, (org.jfree.chart.plot.Plot) polarPlot5, false);
        jFreeChart7.setTitle("red");
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart7.getTitle();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(textTitle10);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) 604800000L, "13-June-2019", true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        boolean boolean8 = xYAreaRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint12 = xYAreaRenderer0.getItemLabelPaint(2019, 9999, true);
        java.lang.Object obj13 = null;
        boolean boolean14 = xYAreaRenderer0.equals(obj13);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        java.awt.Color color3 = java.awt.Color.red;
        boolean boolean5 = color3.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot0.setRangeCrosshairPaint((java.awt.Paint) color3);
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection8 = combinedRangeXYPlot0.getDomainMarkers(layer7);
        java.lang.Object obj9 = null;
        boolean boolean10 = layer7.equals(obj9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Object obj12 = barRenderer11.clone();
        boolean boolean13 = layer7.equals((java.lang.Object) barRenderer11);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = logAxis5.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, list10, (org.jfree.data.Range) dateRange11, false);
        timeSeriesCollection2.removeAllSeries();
        org.jfree.data.Range range17 = timeSeriesCollection2.getDomainBounds(true);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.junit.Assert.assertNull(xYItemRenderer3);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(range18);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        java.lang.String str4 = piePlot3D0.getPlotType();
        double double5 = piePlot3D0.getMaximumExplodePercent();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pie 3D Plot" + "'", str4.equals("Pie 3D Plot"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 4);
        int int3 = dateTickUnit2.getMultiple();
        java.lang.String str5 = dateTickUnit2.valueToString(100.0d);
        int int6 = dateTickUnit2.getCalendarField();
        java.lang.String str7 = dateTickUnit2.toString();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12/31/69" + "'", str5.equals("12/31/69"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTickUnit[DateTickUnitType.SECOND, 4]" + "'", str7.equals("DateTickUnit[DateTickUnitType.SECOND, 4]"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((double) ' ', (double) 0L, (double) 100L, 90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = blockBorder7.getInsets();
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo10.getChartArea();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D12);
        java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets8.createInsetRectangle(rectangle2D12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("red");
        float float18 = categoryAxis17.getMaximumCategoryLabelWidthRatio();
        categoryAxis17.setCategoryLabelPositionOffset(8);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection22 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo(entityCollection22);
        java.awt.geom.Rectangle2D rectangle2D24 = chartRenderingInfo23.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D25 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D25.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = null;
        piePlot3D25.notifyListeners(plotChangeEvent29);
        org.jfree.chart.entity.PlotEntity plotEntity32 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D24, (org.jfree.chart.plot.Plot) piePlot3D25, "");
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets21.createInsetRectangle(rectangle2D24);
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.axis.AxisState axisState37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        java.util.List list40 = logAxis35.refreshTicks(graphics2D36, axisState37, rectangle2D38, rectangleEdge39);
        java.awt.Color color41 = java.awt.Color.red;
        logAxis35.setTickMarkPaint((java.awt.Paint) color41);
        logAxis35.setMinorTickMarkInsideLength((float) (short) -1);
        org.jfree.chart.entity.AxisEntity axisEntity46 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D33, (org.jfree.chart.axis.Axis) logAxis35, "PieLabelLinkStyle.STANDARD");
        java.awt.Paint paint47 = logAxis35.getTickLabelPaint();
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        try {
            barRenderer3D0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D14, categoryPlot15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) logAxis35, categoryDataset48, 12, 9, true, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        shapeList0.clear();
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Nearest");
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "item", "[size=1]", "TextBlockAnchor.CENTER_RIGHT");
        timeSeries3.setMaximumItemAge(604800000L);
        try {
            timeSeries3.delete((-12566464), 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -12566464");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        xYSeries2.setKey((java.lang.Comparable) year3);
        boolean boolean5 = xYSeries2.getAutoSort();
        boolean boolean6 = xYSeries2.getAllowDuplicateXValues();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Paint paint6 = xYAreaRenderer0.getSeriesPaint(15);
        boolean boolean8 = xYAreaRenderer0.isSeriesItemLabelsVisible(0);
        xYAreaRenderer0.setItemLabelAnchorOffset((double) 60000L);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator14 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "{0}: ({1}, {2})");
        xYAreaRenderer0.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator14, false);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRangeZoomable();
        int int2 = polarPlot0.getSeriesCount();
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = logAxis4.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        java.awt.Color color10 = java.awt.Color.red;
        logAxis4.setTickMarkPaint((java.awt.Paint) color10);
        logAxis4.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape14 = logAxis4.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke16 = combinedRangeXYPlot15.getRangeMinorGridlineStroke();
        combinedRangeXYPlot15.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection18 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = combinedRangeXYPlot15.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection18);
        org.jfree.chart.entity.PlotEntity plotEntity20 = new org.jfree.chart.entity.PlotEntity(shape14, (org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        combinedRangeXYPlot15.clearAnnotations();
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.AxisState axisState25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        java.util.List list28 = logAxis23.refreshTicks(graphics2D24, axisState25, rectangle2D26, rectangleEdge27);
        java.awt.Color color29 = java.awt.Color.red;
        logAxis23.setTickMarkPaint((java.awt.Paint) color29);
        logAxis23.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis23.setAutoTickUnitSelection(true, true);
        combinedRangeXYPlot15.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis23);
        polarPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot15);
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType39 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit41 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType39, 4);
        int int42 = dateTickUnit41.getMultiple();
        org.jfree.chart.plot.PiePlot3D piePlot3D43 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D43.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent47 = null;
        piePlot3D43.notifyListeners(plotChangeEvent47);
        java.awt.Shape shape49 = piePlot3D43.getLegendItemShape();
        boolean boolean50 = dateTickUnit41.equals((java.lang.Object) piePlot3D43);
        double double51 = dateTickUnit41.getSize();
        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date52);
        java.util.Date date54 = dateTickUnit41.rollDate(date52);
        polarPlot38.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit41);
        java.awt.Font font56 = polarPlot38.getAngleLabelFont();
        polarPlot0.setAngleLabelFont(font56);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(dateTickUnitType39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 4000.0d + "'", double51 == 4000.0d);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(font56);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, false);
        try {
            java.lang.Number number7 = timeSeriesCollection1.getY(2147483647, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot3D0.getDatasetGroup();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = piePlot3D0.getLabelLinkStyle();
        piePlot3D0.setCircular(false, false);
        piePlot3D0.clearSectionOutlinePaints(false);
        piePlot3D0.setIgnoreZeroValues(false);
        java.lang.String str15 = piePlot3D0.getNoDataMessage();
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean2 = segmentedTimeline0.containsDomainValue(date1);
        segmentedTimeline0.addException((long) (short) 100);
        try {
            boolean boolean7 = segmentedTimeline0.containsDomainRange(1560668399999L, (long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: domainValueEnd (8) < domainValueStart (1560668399999)");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-12566464));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-3047828) + "'", int1 == (-3047828));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0E-8d);
        try {
            timeSeries1.delete(8, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        timeSeriesCollection1.removeAllSeries();
        timeSeriesCollection1.removeAllSeries();
        try {
            java.lang.Number number7 = timeSeriesCollection1.getEndX(6, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        combinedRangeXYPlot1.setDomainAxisLocation((int) 'a', axisLocation3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.title.LegendTitle legendTitle7 = jFreeChart5.getLegend(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer8.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke13 = barRenderer8.getItemOutlineStroke((int) '4', (int) (byte) 1, true);
        jFreeChart5.setBorderStroke(stroke13);
        java.util.List list15 = jFreeChart5.getSubtitles();
        org.junit.Assert.assertNull(legendTitle7);
        org.junit.Assert.assertNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity18 = new org.jfree.chart.entity.PieSectionEntity(shape11, pieDataset12, (int) 'a', 2019, (java.lang.Comparable) "red", "", "red");
        int int19 = pieSectionEntity18.getSectionIndex();
        int int20 = pieSectionEntity18.getSectionIndex();
        pieSectionEntity18.setSectionKey((java.lang.Comparable) 1.0E-8d);
        int int23 = pieSectionEntity18.getSectionIndex();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke3 = defaultDrawingSupplier2.getNextOutlineStroke();
        boolean boolean4 = dateTickMarkPosition0.equals((java.lang.Object) defaultDrawingSupplier2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.MIDDLE" + "'", str1.equals("DateTickMarkPosition.MIDDLE"));
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer1.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer1.clearSeriesStrokes(false);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer1.setBaseLegendShape(shape7);
        boolean boolean9 = rotation0.equals((java.lang.Object) shape7);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint11 = xYAreaRenderer10.getBaseItemLabelPaint();
        boolean boolean12 = rotation0.equals((java.lang.Object) xYAreaRenderer10);
        java.lang.String str13 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Rotation.CLOCKWISE" + "'", str13.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseShapesVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) false);
        xYStepRenderer0.notifyListeners(rendererChangeEvent4);
        boolean boolean7 = xYStepRenderer0.equals((java.lang.Object) "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double3 = xYSeries2.getMinX();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        xYSeries2.addPropertyChangeListener(propertyChangeListener4);
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeZone6);
        xYSeries2.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection7);
        double double10 = timeSeriesCollection7.getDomainUpperBound(true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        combinedRangeXYPlot12.configureDomainAxes();
        xYAreaRenderer11.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot12);
        java.awt.Stroke stroke17 = xYAreaRenderer11.getBaseStroke();
        java.awt.Paint paint19 = xYAreaRenderer11.lookupSeriesOutlinePaint((-1));
        boolean boolean20 = xYAreaRenderer11.getAutoPopulateSeriesOutlinePaint();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo21 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) boolean20, seriesChangeInfo21);
        timeSeriesCollection7.seriesChanged(seriesChangeEvent22);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        boolean boolean4 = piePlot3D0.getAutoPopulateSectionPaint();
        java.awt.Paint paint5 = piePlot3D0.getLabelOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        boolean boolean10 = periodAxis9.isMinorTickMarksVisible();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = periodAxis9.getFirst();
        periodAxis9.setFixedAutoRange((double) 86400000L);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        periodAxis9.setTickLabelPaint((java.awt.Paint) color14);
        org.jfree.data.Range range16 = periodAxis9.getRange();
        boolean boolean17 = periodAxis9.isMinorTickMarksVisible();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(2);
        xYStepAreaRenderer1.setShapesVisible(false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke6 = combinedRangeXYPlot5.getRangeMinorGridlineStroke();
        combinedRangeXYPlot5.clearAnnotations();
        combinedRangeXYPlot5.configureDomainAxes();
        xYAreaRenderer4.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot5);
        java.awt.Color color11 = java.awt.Color.CYAN;
        xYAreaRenderer4.setSeriesPaint((int) (short) 10, (java.awt.Paint) color11);
        xYStepAreaRenderer1.setBaseFillPaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.05d, "", false);
        org.jfree.chart.util.LogFormat logFormat8 = new org.jfree.chart.util.LogFormat(0.05d, "", false);
        java.lang.StringBuffer stringBuffer10 = null;
        java.text.FieldPosition fieldPosition11 = null;
        java.lang.StringBuffer stringBuffer12 = logFormat8.format((double) 1559372400000L, stringBuffer10, fieldPosition11);
        java.text.FieldPosition fieldPosition13 = null;
        java.lang.StringBuffer stringBuffer14 = logFormat3.format((double) 2019, stringBuffer12, fieldPosition13);
        logFormat3.setMinimumFractionDigits((-12566464));
        org.junit.Assert.assertNotNull(stringBuffer12);
        org.junit.Assert.assertNotNull(stringBuffer14);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        textTitle9.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.jfree.chart.entity.EntityCollection entityCollection15 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo(entityCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        boolean boolean18 = month14.equals((java.lang.Object) chartRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D19 = chartRenderingInfo16.getChartArea();
        textTitle9.setBounds(rectangle2D19);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100L, (float) (short) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
        combinedRangeXYPlot25.setDomainAxisLocation((int) 'a', axisLocation27);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot25);
        org.jfree.chart.title.LegendTitle legendTitle31 = jFreeChart29.getLegend(100);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity34 = new org.jfree.chart.entity.JFreeChartEntity(shape23, jFreeChart29, "", "0,0,1,1");
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int37 = color36.getGreen();
        java.awt.Color color38 = java.awt.Color.getColor("hi!", color36);
        boolean boolean39 = jFreeChart29.equals((java.lang.Object) color38);
        int int40 = jFreeChart29.getBackgroundImageAlignment();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity43 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape) rectangle2D19, jFreeChart29, "Pie 3D Plot", "Combined Range XYPlot");
        org.jfree.chart.axis.LogAxis logAxis45 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.axis.AxisState axisState47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = null;
        java.util.List list50 = logAxis45.refreshTicks(graphics2D46, axisState47, rectangle2D48, rectangleEdge49);
        double double51 = logAxis45.getFixedAutoRange();
        boolean boolean52 = jFreeChartEntity43.equals((java.lang.Object) logAxis45);
        org.jfree.chart.plot.PiePlot3D piePlot3D57 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D57.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent61 = null;
        piePlot3D57.notifyListeners(plotChangeEvent61);
        java.awt.Shape shape63 = piePlot3D57.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot64 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color65 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot64.setAngleGridlinePaint((java.awt.Paint) color65);
        java.awt.Color color67 = color65.darker();
        org.jfree.chart.LegendItem legendItem68 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape63, (java.awt.Paint) color67);
        java.awt.Shape shape69 = legendItem68.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection70 = new org.jfree.data.xy.XYSeriesCollection();
        int int72 = xYSeriesCollection70.indexOf((java.lang.Comparable) '#');
        double double74 = xYSeriesCollection70.getDomainUpperBound(false);
        double double75 = xYSeriesCollection70.getIntervalPositionFactor();
        legendItem68.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection70);
        boolean boolean77 = legendItem68.isLineVisible();
        boolean boolean78 = jFreeChartEntity43.equals((java.lang.Object) legendItem68);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(legendTitle31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 255 + "'", int37 == 255);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 15 + "'", int40 == 15);
        org.junit.Assert.assertNotNull(list50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertEquals((double) double74, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.5d + "'", double75 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getRangeMinorGridlineStroke();
        boolean boolean10 = xYAreaRenderer0.hasListener((java.util.EventListener) combinedRangeXYPlot8);
        java.awt.Paint paint11 = combinedRangeXYPlot8.getBackgroundPaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = combinedRangeXYPlot8.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer13.setSeriesShapesVisible(0, (java.lang.Boolean) false);
        java.awt.Font font18 = xYStepRenderer13.getLegendTextFont(8);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        xYStepRenderer13.setSeriesStroke((int) (byte) 0, stroke20, true);
        xYStepRenderer13.setSeriesShapesVisible(5, true);
        boolean boolean28 = xYStepRenderer13.getItemShapeVisible((int) (short) -1, 0);
        combinedRangeXYPlot8.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer13);
        org.jfree.chart.axis.AxisSpace axisSpace30 = combinedRangeXYPlot8.getFixedDomainAxisSpace();
        java.awt.Graphics2D graphics2D31 = null;
        java.util.Date date32 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.chart.entity.EntityCollection entityCollection34 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = new org.jfree.chart.ChartRenderingInfo(entityCollection34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo35);
        boolean boolean37 = month33.equals((java.lang.Object) chartRenderingInfo35);
        java.awt.geom.Rectangle2D rectangle2D38 = chartRenderingInfo35.getChartArea();
        org.jfree.chart.entity.ChartEntity chartEntity41 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D38, "", "Combined Range XYPlot");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline42 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date43 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean44 = segmentedTimeline42.containsDomainValue(date43);
        java.util.List list45 = segmentedTimeline42.getExceptionSegments();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot46 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection48 = new org.jfree.data.time.TimeSeriesCollection(timeZone47);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = combinedRangeXYPlot46.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection48);
        org.jfree.chart.axis.LogAxis logAxis51 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.axis.AxisState axisState53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        java.util.List list56 = logAxis51.refreshTicks(graphics2D52, axisState53, rectangle2D54, rectangleEdge55);
        org.jfree.data.time.DateRange dateRange57 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange58 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange57);
        org.jfree.data.Range range60 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection48, list56, (org.jfree.data.Range) dateRange57, false);
        segmentedTimeline42.addExceptions(list56);
        combinedRangeXYPlot8.drawDomainTickBands(graphics2D31, rectangle2D38, list56);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNull(font18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(axisSpace30);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(segmentedTimeline42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNull(xYItemRenderer49);
        org.junit.Assert.assertNotNull(list56);
        org.junit.Assert.assertNull(range60);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        textTitle9.setToolTipText("red");
        java.lang.String str12 = textTitle9.getID();
        java.awt.Paint paint13 = textTitle9.getPaint();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        logAxis1.setStandardTickUnits(tickUnitSource2);
        boolean boolean4 = logAxis1.isNegativeArrowVisible();
        logAxis1.pan((double) (short) 1);
        java.lang.Object obj7 = logAxis1.clone();
        logAxis1.setLabelURL("");
        java.lang.Object obj10 = logAxis1.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getDomainUpperBound(false);
        double double5 = xYSeriesCollection0.getIntervalPositionFactor();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate6 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.data.Range range8 = intervalXYDelegate6.getDomainBounds(true);
        double double10 = intervalXYDelegate6.getDomainUpperBound(false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double3 = xYSeries2.getMinX();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        xYSeries2.addPropertyChangeListener(propertyChangeListener4);
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeZone6);
        xYSeries2.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection7);
        double double10 = timeSeriesCollection7.getDomainUpperBound(true);
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeriesCollection7.getSeries((java.lang.Comparable) (short) 10);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertNull(timeSeries12);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean3 = xYStepRenderer0.getItemLineVisible((-1), 100);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        try {
            xYStepRenderer0.addAnnotation(xYAnnotation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 8);
        try {
            valueMarker1.setAlpha((float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("0,0,1,1", font2, (org.jfree.chart.plot.Plot) polarPlot5, false);
        polarPlot5.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = polarPlot5.getOrientation();
        java.awt.Paint paint11 = polarPlot5.getOutlinePaint();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        polarPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier12, false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = barRenderer1.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer1.setBase((double) (byte) 0);
        boolean boolean6 = year0.equals((java.lang.Object) barRenderer1);
        barRenderer1.removeAnnotations();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer1.getSeriesToolTipGenerator(3);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = legendTitle1.getBackgroundPaint();
        legendTitle1.setNotify(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor5);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getRangeMinorGridlineStroke();
        combinedRangeXYPlot8.clearAnnotations();
        boolean boolean11 = combinedRangeXYPlot8.isDomainPannable();
        boolean boolean12 = combinedRangeXYPlot8.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = null;
        logAxis14.setStandardTickUnits(tickUnitSource15);
        boolean boolean17 = logAxis14.isNegativeArrowVisible();
        logAxis14.pan((double) (short) 1);
        combinedRangeXYPlot8.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis14);
        java.awt.Paint paint21 = logAxis14.getAxisLinePaint();
        org.jfree.chart.entity.AxisEntity axisEntity22 = new org.jfree.chart.entity.AxisEntity(shape6, (org.jfree.chart.axis.Axis) logAxis14);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
        org.jfree.chart.RenderingSource renderingSource3 = null;
        chartRenderingInfo1.setRenderingSource(renderingSource3);
        java.lang.Object obj5 = chartRenderingInfo1.clone();
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        combinedRangeXYPlot0.setDomainMinorGridlinesVisible(false);
        java.lang.String str7 = combinedRangeXYPlot0.getPlotType();
        boolean boolean8 = combinedRangeXYPlot0.isNotify();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Combined Range XYPlot" + "'", str7.equals("Combined Range XYPlot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo(entityCollection2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo3.getChartArea();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = plotRenderingInfo11.getPlotArea();
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = barRenderer3D0.initialise(graphics2D1, rectangle2D5, categoryPlot7, (int) '4', plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(rectangle2D12);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        logAxis1.setStandardTickUnits(tickUnitSource2);
        boolean boolean4 = logAxis1.isNegativeArrowVisible();
        int int5 = logAxis1.getMinorTickCount();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.entity.EntityCollection entityCollection12 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo(entityCollection12);
        java.awt.geom.Rectangle2D rectangle2D14 = chartRenderingInfo13.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D15 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D15.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = null;
        piePlot3D15.notifyListeners(plotChangeEvent19);
        org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D14, (org.jfree.chart.plot.Plot) piePlot3D15, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity25 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis1, (java.awt.Shape) rectangle2D14, "", "");
        java.lang.String str26 = logAxis1.getLabel();
        boolean boolean27 = logAxis1.isPositiveArrowVisible();
        boolean boolean28 = logAxis1.isVisible();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesShapesVisible(0, (java.lang.Boolean) false);
        java.awt.Font font5 = xYStepRenderer0.getLegendTextFont(8);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        xYStepRenderer0.setSeriesStroke((int) (byte) 0, stroke7, true);
        xYStepRenderer0.setSeriesShapesVisible(5, true);
        org.jfree.data.xy.XYSeries xYSeries15 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection16 = new org.jfree.data.xy.XYSeriesCollection();
        int int18 = xYSeriesCollection16.indexOf((java.lang.Comparable) '#');
        double double20 = xYSeriesCollection16.getDomainUpperBound(false);
        xYSeries15.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection16);
        org.jfree.data.Range range22 = xYStepRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection16);
        xYStepRenderer0.setSeriesShapesVisible(100, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        combinedRangeXYPlot0.configureDomainAxes();
        combinedRangeXYPlot0.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot0.getDomainAxisLocation();
        java.lang.String str6 = axisLocation5.toString();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str6.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getExpandToFitSpace();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        int int5 = xYSeriesCollection3.indexOf((java.lang.Comparable) '#');
        double double7 = xYSeriesCollection3.getDomainUpperBound(false);
        xYSeries2.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection3);
        org.jfree.data.xy.XYSeries xYSeries11 = xYSeries2.createCopy((int) (short) 1, 255);
        boolean boolean12 = xYSeries2.getAllowDuplicateXValues();
        xYSeries2.add(0.12d, (java.lang.Number) 1.0E-100d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYSeries11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer1 = polarPlot0.getRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeMinorGridlineStroke();
        combinedRangeXYPlot2.clearAnnotations();
        java.awt.Color color5 = java.awt.Color.red;
        boolean boolean7 = color5.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot2.setRangeCrosshairPaint((java.awt.Paint) color5);
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color5);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = polarPlot0.getRenderer();
        java.awt.Image image11 = null;
        polarPlot0.setBackgroundImage(image11);
        org.junit.Assert.assertNull(polarItemRenderer1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(polarItemRenderer10);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        int int3 = month0.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        boolean boolean4 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        logAxis6.setStandardTickUnits(tickUnitSource7);
        boolean boolean9 = logAxis6.isNegativeArrowVisible();
        logAxis6.pan((double) (short) 1);
        combinedRangeXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.Paint paint13 = logAxis6.getAxisLinePaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer14 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke16 = combinedRangeXYPlot15.getRangeMinorGridlineStroke();
        combinedRangeXYPlot15.clearAnnotations();
        combinedRangeXYPlot15.configureDomainAxes();
        xYAreaRenderer14.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot15);
        xYAreaRenderer14.setDataBoundsIncludesVisibleSeriesOnly(false);
        boolean boolean22 = xYAreaRenderer14.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint26 = xYAreaRenderer14.getItemLabelPaint(2019, 9999, true);
        logAxis6.setTickLabelPaint(paint26);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint26);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        boolean boolean2 = segmentedTimeline0.containsDomainValue(date1);
//        java.util.List list3 = segmentedTimeline0.getExceptionSegments();
//        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
//        java.util.TimeZone timeZone5 = null;
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = combinedRangeXYPlot4.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
//        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("hi!");
//        java.awt.Graphics2D graphics2D10 = null;
//        org.jfree.chart.axis.AxisState axisState11 = null;
//        java.awt.geom.Rectangle2D rectangle2D12 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
//        java.util.List list14 = logAxis9.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
//        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange();
//        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange15);
//        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6, list14, (org.jfree.data.Range) dateRange15, false);
//        segmentedTimeline0.addExceptions(list14);
//        org.jfree.data.general.DefaultPieDataset defaultPieDataset20 = new org.jfree.data.general.DefaultPieDataset();
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline21 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        boolean boolean23 = segmentedTimeline21.containsDomainValue(date22);
//        int int24 = defaultPieDataset20.getIndex((java.lang.Comparable) date22);
//        long long25 = segmentedTimeline0.toTimelineValue(date22);
//        java.lang.Object obj26 = segmentedTimeline0.clone();
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(list3);
//        org.junit.Assert.assertNull(xYItemRenderer7);
//        org.junit.Assert.assertNotNull(list14);
//        org.junit.Assert.assertNull(range18);
//        org.junit.Assert.assertNotNull(segmentedTimeline21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2692525037755L + "'", long25 == 2692525037755L);
//        org.junit.Assert.assertNotNull(obj26);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        numberFormat0.setMinimumFractionDigits(2);
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        xYSeries2.setKey((java.lang.Comparable) year3);
        boolean boolean5 = xYSeries2.getAutoSort();
        boolean boolean6 = xYSeries2.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.jfree.chart.entity.EntityCollection entityCollection7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo(entityCollection7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        boolean boolean10 = month6.equals((java.lang.Object) chartRenderingInfo8);
        long long11 = month6.getFirstMillisecond();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) year12);
        java.util.Locale locale14 = periodAxis13.getLocale();
        boolean boolean15 = xYSeries3.equals((java.lang.Object) locale14);
        java.text.NumberFormat numberFormat16 = java.text.NumberFormat.getIntegerInstance(locale14);
        try {
            java.util.ResourceBundle resourceBundle17 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("[size=1]", locale14);
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name [size=1], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559372400000L + "'", long11 == 1559372400000L);
        org.junit.Assert.assertNotNull(locale14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(numberFormat16);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        numberFormat0.setMaximumFractionDigits((-1));
        java.util.Currency currency3 = null;
        try {
            numberFormat0.setCurrency(currency3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.awt.geom.Rectangle2D rectangle2D2 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D3.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot3D3.notifyListeners(plotChangeEvent7);
        org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D2, (org.jfree.chart.plot.Plot) piePlot3D3, "");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke12 = combinedRangeXYPlot11.getRangeMinorGridlineStroke();
        combinedRangeXYPlot11.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedRangeXYPlot11.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection14);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D2, (org.jfree.chart.plot.Plot) combinedRangeXYPlot11, "");
        org.jfree.chart.axis.AxisSpace axisSpace18 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot11.setFixedDomainAxisSpace(axisSpace18);
        double double20 = axisSpace18.getBottom();
        axisSpace18.setTop(0.05d);
        double double23 = axisSpace18.getTop();
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        boolean boolean4 = piePlot3D0.getAutoPopulateSectionPaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot3D0.getLabelDistributor();
        int int6 = piePlot3D0.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 4);
        int int3 = dateTickUnit2.getMultiple();
        java.lang.String str5 = dateTickUnit2.valueToString(100.0d);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) dateTickUnit2, false, false);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12/31/69" + "'", str5.equals("12/31/69"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(2);
        java.lang.Object obj2 = objectList1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.awt.geom.Line2D line2D0 = null;
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo(entityCollection1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D5 = plotRenderingInfo3.getDataArea();
        try {
            boolean boolean6 = org.jfree.chart.util.LineUtilities.clipLine(line2D0, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangle2D5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis1.centerRange((double) 0L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        java.lang.String str14 = combinedRangeXYPlot13.getPlotType();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 8);
        java.lang.String str18 = valueMarker17.getLabel();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke20 = combinedRangeXYPlot19.getRangeMinorGridlineStroke();
        combinedRangeXYPlot19.clearAnnotations();
        java.awt.Color color22 = java.awt.Color.red;
        boolean boolean24 = color22.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection27 = combinedRangeXYPlot19.getDomainMarkers(layer26);
        java.lang.Object obj28 = null;
        boolean boolean29 = layer26.equals(obj28);
        boolean boolean30 = combinedRangeXYPlot13.removeRangeMarker(12, (org.jfree.chart.plot.Marker) valueMarker17, layer26);
        java.util.Date date32 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.chart.entity.EntityCollection entityCollection34 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = new org.jfree.chart.ChartRenderingInfo(entityCollection34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo35);
        boolean boolean37 = month33.equals((java.lang.Object) chartRenderingInfo35);
        long long38 = month33.getFirstMillisecond();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis40 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month33, (org.jfree.data.time.RegularTimePeriod) year39);
        java.lang.Class class41 = periodAxis40.getMinorTickTimePeriodClass();
        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize(class41);
        try {
            java.util.EventListener[] eventListenerArray43 = valueMarker17.getListeners(class41);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.data.time.Day; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Combined Range XYPlot" + "'", str14.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1559372400000L + "'", long38 == 1559372400000L);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertNotNull(class42);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedRangeXYPlot12.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        combinedRangeXYPlot12.clearAnnotations();
        java.awt.geom.Point2D point2D19 = combinedRangeXYPlot12.getQuadrantOrigin();
        combinedRangeXYPlot12.setNotify(true);
        boolean boolean22 = combinedRangeXYPlot12.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        combinedRangeXYPlot1.setDomainAxisLocation((int) 'a', axisLocation3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        jFreeChart5.setBackgroundImageAlignment(100);
        jFreeChart5.setBorderVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot10 = jFreeChart5.getXYPlot();
        org.junit.Assert.assertNotNull(xYPlot10);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo(entityCollection2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        boolean boolean5 = month1.equals((java.lang.Object) chartRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D6 = chartRenderingInfo3.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo(entityCollection7);
        java.awt.geom.Rectangle2D rectangle2D9 = chartRenderingInfo8.getChartArea();
        chartRenderingInfo3.setChartArea(rectangle2D9);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        boolean boolean12 = chartRenderingInfo3.equals((java.lang.Object) stroke11);
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        chartRenderingInfo3.setEntityCollection(entityCollection13);
        org.jfree.chart.RenderingSource renderingSource15 = null;
        chartRenderingInfo3.setRenderingSource(renderingSource15);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1L + "'", long0 == 1L);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        timeSeriesCollection1.removeAllSeries();
        timeSeriesCollection1.removeAllSeries();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100L, (float) (short) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        combinedRangeXYPlot11.setDomainAxisLocation((int) 'a', axisLocation13);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot11);
        org.jfree.chart.title.LegendTitle legendTitle17 = jFreeChart15.getLegend(100);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity20 = new org.jfree.chart.entity.JFreeChartEntity(shape9, jFreeChart15, "", "0,0,1,1");
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int23 = color22.getGreen();
        java.awt.Color color24 = java.awt.Color.getColor("hi!", color22);
        boolean boolean25 = jFreeChart15.equals((java.lang.Object) color24);
        boolean boolean26 = jFreeChart15.getAntiAlias();
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.axis.AxisState axisState30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        java.util.List list33 = logAxis28.refreshTicks(graphics2D29, axisState30, rectangle2D31, rectangleEdge32);
        jFreeChart15.setSubtitles(list33);
        org.jfree.data.Range range35 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range37 = timeSeriesCollection1.getRangeBounds(list33, range35, false);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(legendTitle17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 255 + "'", int23 == 255);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(range37);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(2);
        boolean boolean2 = xYStepAreaRenderer1.getShapesVisible();
        boolean boolean3 = xYStepAreaRenderer1.getPlotArea();
        double double4 = xYStepAreaRenderer1.getRangeBase();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        textTitle9.setToolTipText("red");
        java.lang.String str12 = textTitle9.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo15.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D17.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        piePlot3D17.notifyListeners(plotChangeEvent21);
        org.jfree.chart.entity.PlotEntity plotEntity24 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D16, (org.jfree.chart.plot.Plot) piePlot3D17, "");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke26 = combinedRangeXYPlot25.getRangeMinorGridlineStroke();
        combinedRangeXYPlot25.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection28 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = combinedRangeXYPlot25.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection28);
        org.jfree.chart.entity.PlotEntity plotEntity31 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D16, (org.jfree.chart.plot.Plot) combinedRangeXYPlot25, "");
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets13.createOutsetRectangle(rectangle2D16);
        textTitle9.setBounds(rectangle2D16);
        textTitle9.setMaximumLinesToDisplay(6);
        double double36 = textTitle9.getHeight();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(xYItemRenderer29);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getDomainUpperBound(false);
        double double5 = xYSeriesCollection0.getIntervalPositionFactor();
        double double6 = xYSeriesCollection0.getIntervalPositionFactor();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeZone8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = combinedRangeXYPlot7.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        java.util.List list17 = logAxis12.refreshTicks(graphics2D13, axisState14, rectangle2D15, rectangleEdge16);
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange19 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection9, list17, (org.jfree.data.Range) dateRange18, false);
        java.util.List list22 = timeSeriesCollection9.getSeries();
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list22, true);
        try {
            double double27 = xYSeriesCollection0.getEndXValue(97, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(range24);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint2 = barRenderer0.getShadowPaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint4 = xYAreaRenderer3.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYAreaRenderer3.getBasePositiveItemLabelPosition();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition5);
        double double7 = itemLabelPosition5.getAngle();
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100L, (float) (short) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        combinedRangeXYPlot5.setDomainAxisLocation((int) 'a', axisLocation7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart9.getLegend(100);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity14 = new org.jfree.chart.entity.JFreeChartEntity(shape3, jFreeChart9, "", "0,0,1,1");
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int17 = color16.getGreen();
        java.awt.Color color18 = java.awt.Color.getColor("hi!", color16);
        boolean boolean19 = jFreeChart9.equals((java.lang.Object) color18);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str21 = chartChangeEventType20.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItemCollection0, jFreeChart9, chartChangeEventType20);
        java.lang.Object obj23 = jFreeChart9.getTextAntiAlias();
        org.jfree.chart.event.ChartChangeListener chartChangeListener24 = null;
        try {
            jFreeChart9.removeChangeListener(chartChangeListener24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendTitle11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str21.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertNull(obj23);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        java.util.Locale locale10 = periodAxis9.getLocale();
        double double11 = periodAxis9.getUpperMargin();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.Class<?> wildcardClass14 = rectangleAnchor13.getClass();
        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ChartChangeEventType.GENERAL", (java.lang.Class) wildcardClass14);
        periodAxis9.setMinorTickTimePeriodClass((java.lang.Class) wildcardClass14);
        periodAxis9.setFixedDimension(0.0d);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertNotNull(locale10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(inputStream15);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean3 = segmentedTimeline1.containsDomainValue(date2);
        int int4 = defaultPieDataset0.getIndex((java.lang.Comparable) date2);
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        try {
            java.lang.Number number7 = defaultPieDataset0.getValue((java.lang.Comparable) date5);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: Thu Jun 13 12:37:17 PDT 2019");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, true);
        boolean boolean3 = xYLineAndShapeRenderer2.getBaseShapesFilled();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setAutoRangeMinimumSize(100.0d, false);
        java.lang.String str5 = logAxis1.getLabelURL();
        org.jfree.data.Range range6 = logAxis1.getDefaultAutoRange();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("");
        java.lang.Object obj2 = standardPieToolTipGenerator1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 4);
        int int3 = dateTickUnit2.getMultiple();
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        boolean boolean11 = dateTickUnit2.equals((java.lang.Object) piePlot3D4);
        java.awt.Paint paint12 = piePlot3D4.getLabelPaint();
        try {
            piePlot3D4.setInteriorGap((double) 604800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (6.048E8) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, true);
        combinedRangeXYPlot0.clearRangeMarkers();
        combinedRangeXYPlot0.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        boolean boolean10 = periodAxis9.isMinorTickMarksVisible();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = periodAxis9.getFirst();
        boolean boolean12 = periodAxis9.isMinorTickMarksVisible();
        boolean boolean13 = periodAxis9.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot3D0.getDatasetGroup();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = piePlot3D0.getLabelLinkStyle();
        piePlot3D0.setCircular(false, false);
        piePlot3D0.clearSectionOutlinePaints(false);
        piePlot3D0.setIgnoreZeroValues(false);
        piePlot3D0.setAutoPopulateSectionOutlineStroke(true);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = barRenderer1.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer1.setBase((double) (byte) 0);
        boolean boolean6 = year0.equals((java.lang.Object) barRenderer1);
        barRenderer1.setAutoPopulateSeriesOutlineStroke(false);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double3 = xYSeries2.getMinX();
        xYSeries2.add((double) 100.0f, 0.0d);
        xYSeries2.clear();
        double[][] doubleArray8 = xYSeries2.toArray();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.util.Collection collection7 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list6);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(collection7);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) '#');
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint2 = barRenderer0.getShadowPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getSeriesToolTipGenerator((int) (short) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertNull(itemLabelPosition5);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer5.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer5.clearSeriesStrokes(false);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer5.setBaseLegendShape(shape11);
        combinedRangeXYPlot0.setRenderer(15, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("red");
        java.awt.Paint paint18 = categoryAxis16.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        combinedRangeXYPlot0.setDomainTickBandPaint(paint18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke23 = combinedRangeXYPlot22.getRangeMinorGridlineStroke();
        combinedRangeXYPlot22.clearAnnotations();
        java.awt.Stroke stroke25 = combinedRangeXYPlot22.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer26 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer26.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer26.clearSeriesStrokes(false);
        java.awt.Paint paint32 = xYAreaRenderer26.getSeriesPaint(15);
        boolean boolean34 = xYAreaRenderer26.isSeriesItemLabelsVisible(0);
        int int35 = combinedRangeXYPlot22.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer26);
        org.jfree.chart.entity.EntityCollection entityCollection36 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = new org.jfree.chart.ChartRenderingInfo(entityCollection36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo37);
        java.awt.geom.Rectangle2D rectangle2D39 = plotRenderingInfo38.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D40 = plotRenderingInfo38.getDataArea();
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.axis.AxisState axisState44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        java.util.List list47 = logAxis42.refreshTicks(graphics2D43, axisState44, rectangle2D45, rectangleEdge46);
        java.awt.Color color48 = java.awt.Color.red;
        logAxis42.setTickMarkPaint((java.awt.Paint) color48);
        logAxis42.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape52 = logAxis42.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot53 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke54 = combinedRangeXYPlot53.getRangeMinorGridlineStroke();
        combinedRangeXYPlot53.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection56 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = combinedRangeXYPlot53.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection56);
        org.jfree.chart.entity.PlotEntity plotEntity58 = new org.jfree.chart.entity.PlotEntity(shape52, (org.jfree.chart.plot.Plot) combinedRangeXYPlot53);
        combinedRangeXYPlot53.clearAnnotations();
        java.awt.geom.Point2D point2D60 = combinedRangeXYPlot53.getQuadrantOrigin();
        org.jfree.chart.plot.XYPlot xYPlot61 = combinedRangeXYPlot22.findSubplot(plotRenderingInfo38, point2D60);
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) (short) 100, plotRenderingInfo21, point2D60, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(list47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNull(xYItemRenderer57);
        org.junit.Assert.assertNotNull(point2D60);
        org.junit.Assert.assertNull(xYPlot61);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        boolean boolean10 = periodAxis9.isMinorTickMarksVisible();
        java.util.Locale locale11 = periodAxis9.getLocale();
        org.jfree.data.Range range12 = null;
        try {
            periodAxis9.setRangeWithMargins(range12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(locale11);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        int int5 = xYSeriesCollection3.indexOf((java.lang.Comparable) '#');
        double double7 = xYSeriesCollection3.getDomainUpperBound(false);
        xYSeries2.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection3);
        org.jfree.data.xy.XYSeries xYSeries11 = xYSeries2.createCopy((int) (short) 1, 255);
        boolean boolean12 = xYSeries2.isEmpty();
        java.lang.Number number14 = null;
        try {
            xYSeries2.updateByIndex(3, number14);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYSeries11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        timeSeriesCollection1.removeAllSeries();
        timeSeriesCollection1.removeAllSeries();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset5 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot((org.jfree.data.general.PieDataset) defaultPieDataset5);
        timeSeriesCollection1.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot6);
        double double8 = piePlot6.getMaximumExplodePercent();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        combinedRangeXYPlot1.setDomainAxisLocation((int) 'a', axisLocation3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        boolean boolean6 = combinedRangeXYPlot1.isDomainZeroBaselineVisible();
        boolean boolean7 = combinedRangeXYPlot1.isRangeCrosshairLockedOnData();
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot1.getDataset(8);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation10 = null;
        try {
            boolean boolean11 = combinedRangeXYPlot1.removeAnnotation(xYAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(xYDataset9);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint2 = barRenderer0.getShadowPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getSeriesToolTipGenerator((int) (short) 100);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer5.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer5.clearSeriesStrokes(false);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYAreaRenderer5.setSeriesFillPaint((int) ' ', (java.awt.Paint) color11, true);
        barRenderer0.setShadowPaint((java.awt.Paint) color11);
        java.lang.Boolean boolean16 = barRenderer0.getSeriesVisibleInLegend(1);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(boolean16);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot3D0.getDatasetGroup();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = piePlot3D0.getLabelLinkStyle();
        piePlot3D0.setCircular(false, false);
        piePlot3D0.clearSectionOutlinePaints(false);
        double double14 = piePlot3D0.getExplodePercent((java.lang.Comparable) "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.awt.Paint paint15 = piePlot3D0.getBaseSectionOutlinePaint();
        java.awt.Color color16 = java.awt.Color.YELLOW;
        java.awt.Color color17 = color16.darker();
        piePlot3D0.setLabelOutlinePaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = barRenderer19.getPositiveItemLabelPositionFallback();
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot21.setAngleGridlinePaint((java.awt.Paint) color22);
        java.awt.Color color24 = color22.darker();
        int int25 = color24.getAlpha();
        barRenderer19.setBaseItemLabelPaint((java.awt.Paint) color24);
        java.awt.Color color27 = color24.brighter();
        piePlot3D0.setLabelOutlinePaint((java.awt.Paint) color24);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(itemLabelPosition20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getRangeMinorGridlineStroke();
        boolean boolean10 = xYAreaRenderer0.hasListener((java.util.EventListener) combinedRangeXYPlot8);
        java.awt.Paint paint11 = combinedRangeXYPlot8.getBackgroundPaint();
        combinedRangeXYPlot8.clearRangeAxes();
        org.jfree.chart.plot.PiePlot3D piePlot3D13 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D13.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        piePlot3D13.notifyListeners(plotChangeEvent17);
        java.awt.Shape shape19 = piePlot3D13.getLegendItemShape();
        java.awt.Paint paint20 = piePlot3D13.getBaseSectionOutlinePaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator21 = piePlot3D13.getLegendLabelGenerator();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot22.clearRangeMarkers(0);
        java.awt.Stroke stroke25 = combinedRangeXYPlot22.getDomainGridlineStroke();
        piePlot3D13.setLabelOutlineStroke(stroke25);
        combinedRangeXYPlot8.setRangeGridlineStroke(stroke25);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator21);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = barRenderer0.getPlot();
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNull(categoryPlot2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer1.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer1.clearSeriesStrokes(false);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer1.setBaseLegendShape(shape7);
        boolean boolean9 = rotation0.equals((java.lang.Object) shape7);
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D10.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        piePlot3D10.notifyListeners(plotChangeEvent14);
        org.jfree.data.general.DatasetGroup datasetGroup16 = piePlot3D10.getDatasetGroup();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle17 = piePlot3D10.getLabelLinkStyle();
        double double18 = piePlot3D10.getLabelGap();
        piePlot3D10.setCircular(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        boolean boolean22 = piePlot3D10.equals((java.lang.Object) rectangleAnchor21);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor21, (double) 255, 0.0d);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.025d + "'", double18 == 0.025d);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint2 = barRenderer0.getShadowPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getSeriesToolTipGenerator((int) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection6 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo(entityCollection6);
        java.awt.geom.Rectangle2D rectangle2D8 = chartRenderingInfo7.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D9.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        piePlot3D9.notifyListeners(plotChangeEvent13);
        org.jfree.chart.entity.PlotEntity plotEntity16 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D8, (org.jfree.chart.plot.Plot) piePlot3D9, "");
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets5.createInsetRectangle(rectangle2D8);
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.axis.AxisState axisState21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        java.util.List list24 = logAxis19.refreshTicks(graphics2D20, axisState21, rectangle2D22, rectangleEdge23);
        java.awt.Color color25 = java.awt.Color.red;
        logAxis19.setTickMarkPaint((java.awt.Paint) color25);
        logAxis19.setMinorTickMarkInsideLength((float) (short) -1);
        org.jfree.chart.entity.AxisEntity axisEntity30 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D17, (org.jfree.chart.axis.Axis) logAxis19, "PieLabelLinkStyle.STANDARD");
        barRenderer0.setBaseLegendShape((java.awt.Shape) rectangle2D17);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer(6.0d);
        java.awt.Paint paint5 = xYBarRenderer4.getBaseItemLabelPaint();
        java.awt.geom.RectangularShape rectangularShape9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("red");
        java.awt.Paint paint13 = categoryAxis11.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke18 = combinedRangeXYPlot17.getRangeMinorGridlineStroke();
        combinedRangeXYPlot17.clearAnnotations();
        boolean boolean20 = combinedRangeXYPlot17.isDomainPannable();
        boolean boolean21 = combinedRangeXYPlot17.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = combinedRangeXYPlot17.getDomainAxisEdge();
        org.jfree.chart.axis.AxisState axisState23 = null;
        categoryAxis11.drawTickMarks(graphics2D14, (double) (-1.0f), rectangle2D16, rectangleEdge22, axisState23);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        try {
            gradientXYBarPainter0.paintBar(graphics2D2, xYBarRenderer4, (int) ' ', 0, false, rectangularShape9, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        boolean boolean4 = piePlot3D0.getAutoPopulateSectionPaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot3D0.getLabelDistributor();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) '#', (double) (short) 0, (double) 10, (double) (-1.0f));
        piePlot3D0.setSimpleLabelOffset(rectangleInsets10);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator12 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        piePlot3D0.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator12);
        java.lang.String str14 = standardPieToolTipGenerator12.getLabelFormat();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0}: ({1}, {2})" + "'", str14.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint2 = barRenderer0.getShadowPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getSeriesToolTipGenerator((int) (short) 100);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer5.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer5.clearSeriesStrokes(false);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYAreaRenderer5.setSeriesFillPaint((int) ' ', (java.awt.Paint) color11, true);
        barRenderer0.setShadowPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke15 = null;
        try {
            barRenderer0.setBaseOutlineStroke(stroke15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean3 = xYStepRenderer0.getItemLineVisible((-1), 100);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        java.util.List list11 = logAxis6.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
        java.awt.Color color12 = java.awt.Color.red;
        logAxis6.setTickMarkPaint((java.awt.Paint) color12);
        logAxis6.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape16 = logAxis6.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke18 = combinedRangeXYPlot17.getRangeMinorGridlineStroke();
        combinedRangeXYPlot17.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection20 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = combinedRangeXYPlot17.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection20);
        org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity(shape16, (org.jfree.chart.plot.Plot) combinedRangeXYPlot17);
        combinedRangeXYPlot17.clearAnnotations();
        org.jfree.chart.axis.LogAxis logAxis25 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.AxisState axisState27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        java.util.List list30 = logAxis25.refreshTicks(graphics2D26, axisState27, rectangle2D28, rectangleEdge29);
        java.awt.Color color31 = java.awt.Color.red;
        logAxis25.setTickMarkPaint((java.awt.Paint) color31);
        logAxis25.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis25.setAutoTickUnitSelection(true, true);
        combinedRangeXYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis25);
        org.jfree.chart.axis.LogAxis logAxis40 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.axis.AxisState axisState42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        java.util.List list45 = logAxis40.refreshTicks(graphics2D41, axisState42, rectangle2D43, rectangleEdge44);
        java.awt.Color color46 = java.awt.Color.red;
        logAxis40.setTickMarkPaint((java.awt.Paint) color46);
        double double48 = logAxis40.getAutoRangeMinimumSize();
        org.jfree.chart.entity.EntityCollection entityCollection49 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = new org.jfree.chart.ChartRenderingInfo(entityCollection49);
        java.awt.geom.Rectangle2D rectangle2D51 = chartRenderingInfo50.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D52 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D52.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent56 = null;
        piePlot3D52.notifyListeners(plotChangeEvent56);
        org.jfree.chart.entity.PlotEntity plotEntity59 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D51, (org.jfree.chart.plot.Plot) piePlot3D52, "");
        xYStepRenderer0.fillDomainGridBand(graphics2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot17, (org.jfree.chart.axis.ValueAxis) logAxis40, rectangle2D51, (-2.0d), 0.0d);
        xYStepRenderer0.setItemLabelAnchorOffset(0.0d);
        boolean boolean65 = xYStepRenderer0.getBaseLinesVisible();
        java.awt.Stroke stroke69 = xYStepRenderer0.getItemOutlineStroke(8, 0, false);
        org.jfree.chart.plot.PolarPlot polarPlot71 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer72 = polarPlot71.getRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot73 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke74 = combinedRangeXYPlot73.getRangeMinorGridlineStroke();
        combinedRangeXYPlot73.clearAnnotations();
        java.awt.Color color76 = java.awt.Color.red;
        boolean boolean78 = color76.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot73.setRangeCrosshairPaint((java.awt.Paint) color76);
        polarPlot71.setAngleGridlinePaint((java.awt.Paint) color76);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent81 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) color76);
        xYStepRenderer0.setSeriesItemLabelPaint((int) (byte) 10, (java.awt.Paint) color76);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0E-8d + "'", double48 == 1.0E-8d);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNull(polarItemRenderer72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(color76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.START;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean2 = segmentedTimeline0.containsDomainValue(date1);
        segmentedTimeline0.addException((long) (short) 100);
        segmentedTimeline0.addException((long) 255);
        long long7 = segmentedTimeline0.getStartTime();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType8 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType8, 4);
        int int11 = dateTickUnit10.getMultiple();
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D12.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        piePlot3D12.notifyListeners(plotChangeEvent16);
        java.awt.Shape shape18 = piePlot3D12.getLegendItemShape();
        boolean boolean19 = dateTickUnit10.equals((java.lang.Object) piePlot3D12);
        double double20 = dateTickUnit10.getSize();
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        java.util.Date date23 = dateTickUnit10.rollDate(date21);
        try {
            segmentedTimeline0.addBaseTimelineException(date23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208960000000L) + "'", long7 == (-2208960000000L));
        org.junit.Assert.assertNotNull(dateTickUnitType8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4000.0d + "'", double20 == 4000.0d);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState1.updateCrosshairY(0.0d);
        crosshairState1.setDatasetIndex((-3047828));
        crosshairState1.setCrosshairDistance(0.12d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        combinedRangeXYPlot1.setDomainAxisLocation((int) 'a', axisLocation3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        boolean boolean6 = combinedRangeXYPlot1.isDomainZeroBaselineVisible();
        boolean boolean7 = combinedRangeXYPlot1.isRangeCrosshairLockedOnData();
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot1.getDataset(8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot1.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        combinedRangeXYPlot1.setRenderer((int) '#', xYItemRenderer12, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection24 = new org.jfree.data.xy.XYSeriesCollection();
        int int26 = xYSeriesCollection24.indexOf((java.lang.Comparable) '#');
        double double28 = xYSeriesCollection24.getDomainUpperBound(false);
        double double29 = xYSeriesCollection24.getIntervalPositionFactor();
        double double30 = xYSeriesCollection24.getIntervalPositionFactor();
        int int31 = xYSeriesCollection24.getSeriesCount();
        org.jfree.data.Range range33 = xYSeriesCollection24.getRangeBounds(true);
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection24);
        java.lang.Comparable comparable35 = legendItem15.getSeriesKey();
        java.awt.Paint paint36 = legendItem15.getLabelPaint();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.5d + "'", double29 == 0.5d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.5d + "'", double30 == 0.5d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNull(comparable35);
        org.junit.Assert.assertNull(paint36);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("red");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor2, 1, 8, rectangle2D5, rectangleEdge6);
        categoryAxis1.setLowerMargin((double) 10L);
        java.lang.Comparable comparable10 = null;
        java.awt.Font font11 = null;
        try {
            categoryAxis1.setTickLabelFont(comparable10, font11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Object obj1 = barRenderer0.clone();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = barRenderer0.getBaseURLGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator3, true);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(categoryURLGenerator2);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        int int3 = xYSeriesCollection1.indexOf((java.lang.Comparable) '#');
        double double5 = xYSeriesCollection1.getDomainUpperBound(false);
        double double6 = xYSeriesCollection1.getIntervalPositionFactor();
        org.jfree.data.Range range7 = xYStepRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1);
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        int int13 = xYSeriesCollection11.indexOf((java.lang.Comparable) '#');
        double double15 = xYSeriesCollection11.getDomainUpperBound(false);
        xYSeries10.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection11);
        org.jfree.data.xy.XYSeries xYSeries19 = xYSeries10.createCopy((int) (short) 1, 255);
        boolean boolean20 = xYSeries10.getAllowDuplicateXValues();
        xYSeriesCollection1.removeSeries(xYSeries10);
        int int23 = xYSeries10.indexOf((java.lang.Number) 4000.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYSeries19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        boolean boolean4 = piePlot3D0.getAutoPopulateSectionPaint();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((double) ' ', (double) 0L, (double) 100L, 90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder9.getInsets();
        org.jfree.chart.entity.EntityCollection entityCollection11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo(entityCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = chartRenderingInfo12.getChartArea();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D14);
        java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets10.createInsetRectangle(rectangle2D14);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D14, (double) 10.0f, (float) 7, (float) (byte) 0);
        boolean boolean21 = piePlot3D0.equals((java.lang.Object) 7);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        java.awt.Stroke stroke6 = xYAreaRenderer0.getBaseStroke();
        boolean boolean10 = xYAreaRenderer0.getItemCreateEntity(15, 5, false);
        xYAreaRenderer0.removeAnnotations();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean3 = timeSeriesCollection1.equals((java.lang.Object) 255);
        org.jfree.data.Range range5 = timeSeriesCollection1.getDomainBounds(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        boolean boolean24 = legendItem15.isLineVisible();
        org.jfree.data.xy.XYSeries xYSeries27 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double28 = xYSeries27.getMinX();
        xYSeries27.add((double) 100.0f, 0.0d);
        boolean boolean32 = legendItem15.equals((java.lang.Object) xYSeries27);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer33 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer33.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer33.clearSeriesStrokes(false);
        xYAreaRenderer33.setAutoPopulateSeriesShape(true);
        java.awt.Shape shape40 = xYAreaRenderer33.getBaseShape();
        legendItem15.setLine(shape40);
        int int42 = legendItem15.getDatasetIndex();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparable0, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo(entityCollection2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        boolean boolean5 = month1.equals((java.lang.Object) chartRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D6 = chartRenderingInfo3.getChartArea();
        java.lang.Object obj7 = chartRenderingInfo3.clone();
        org.jfree.chart.RenderingSource renderingSource8 = null;
        chartRenderingInfo3.setRenderingSource(renderingSource8);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 6);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        logAxis1.setStandardTickUnits(tickUnitSource2);
        boolean boolean4 = logAxis1.isNegativeArrowVisible();
        logAxis1.pan((double) (short) 1);
        logAxis1.setMinorTickCount(3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        boolean boolean10 = periodAxis9.isMinorTickMarksVisible();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = periodAxis9.getFirst();
        periodAxis9.setFixedAutoRange((double) 86400000L);
        periodAxis9.configure();
        java.awt.Stroke stroke15 = periodAxis9.getAxisLineStroke();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "hi!", "red", "red");
        java.lang.String str8 = projectInfo7.getLicenceName();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "red" + "'", str8.equals("red"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedRangeXYPlot12.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        java.util.List list18 = combinedRangeXYPlot12.getAnnotations();
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = null;
        logAxis21.setStandardTickUnits(tickUnitSource22);
        boolean boolean24 = logAxis21.isNegativeArrowVisible();
        logAxis21.pan((double) (short) 1);
        combinedRangeXYPlot12.setDomainAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) logAxis21, false);
        org.jfree.chart.plot.PiePlot3D piePlot3D29 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D29.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        piePlot3D29.notifyListeners(plotChangeEvent33);
        logAxis21.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D29);
        piePlot3D29.clearSectionPaints(false);
        java.awt.Paint paint38 = null;
        piePlot3D29.setLabelShadowPaint(paint38);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color1);
        java.awt.Color color3 = color1.darker();
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { color3 };
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100L, (float) (short) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        combinedRangeXYPlot9.setDomainAxisLocation((int) 'a', axisLocation11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot9);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart13.getLegend(100);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity18 = new org.jfree.chart.entity.JFreeChartEntity(shape7, jFreeChart13, "", "0,0,1,1");
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int21 = color20.getGreen();
        java.awt.Color color22 = java.awt.Color.getColor("hi!", color20);
        boolean boolean23 = jFreeChart13.equals((java.lang.Object) color22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color22, color24 };
        java.awt.Stroke[] strokeArray26 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray27 = null;
        java.awt.Shape[] shapeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray25, strokeArray26, strokeArray27, shapeArray28);
        java.lang.Object obj30 = null;
        boolean boolean31 = defaultDrawingSupplier29.equals(obj30);
        java.lang.Object obj32 = defaultDrawingSupplier29.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(legendTitle15);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(shapeArray28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getRangeCrosshairPaint();
        java.awt.Paint paint2 = combinedRangeXYPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.setWeight(7);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState1.updateCrosshairY(0.0d);
        crosshairState1.setCrosshairDistance(0.0d);
        int int6 = crosshairState1.getDomainAxisIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class10 = periodAxis9.getMinorTickTimePeriodClass();
        boolean boolean11 = periodAxis9.isMinorTickMarksVisible();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeZone14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedRangeXYPlot13.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.AxisState axisState20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        java.util.List list23 = logAxis18.refreshTicks(graphics2D19, axisState20, rectangle2D21, rectangleEdge22);
        org.jfree.data.time.DateRange dateRange24 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange24);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection15, list23, (org.jfree.data.Range) dateRange24, false);
        boolean boolean28 = day12.equals((java.lang.Object) false);
        periodAxis9.setLast((org.jfree.data.time.RegularTimePeriod) day12);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesShapesVisible(0, (java.lang.Boolean) false);
        java.awt.Font font5 = xYStepRenderer0.getLegendTextFont(8);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        xYStepRenderer0.setSeriesStroke((int) (byte) 0, stroke7, true);
        xYStepRenderer0.setSeriesShapesVisible(5, true);
        org.jfree.data.xy.XYSeries xYSeries15 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection16 = new org.jfree.data.xy.XYSeriesCollection();
        int int18 = xYSeriesCollection16.indexOf((java.lang.Comparable) '#');
        double double20 = xYSeriesCollection16.getDomainUpperBound(false);
        xYSeries15.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection16);
        org.jfree.data.Range range22 = xYStepRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection16);
        java.lang.Object obj23 = xYStepRenderer0.clone();
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        java.util.Locale locale10 = periodAxis9.getLocale();
        boolean boolean11 = periodAxis9.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertNotNull(locale10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (short) 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.awt.geom.Rectangle2D rectangle2D2 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D3.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot3D3.notifyListeners(plotChangeEvent7);
        org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D2, (org.jfree.chart.plot.Plot) piePlot3D3, "");
        org.jfree.chart.LegendItemCollection legendItemCollection11 = piePlot3D3.getLegendItems();
        piePlot3D3.setMinimumArcAngleToDraw((double) 13);
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        boolean boolean10 = periodAxis9.isMinorTickMarksVisible();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = periodAxis9.getFirst();
        periodAxis9.setInverted(true);
        periodAxis9.setLabelURL("ItemLabelAnchor.INSIDE10");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        java.util.List list12 = combinedDomainXYPlot11.getSubplots();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
        java.awt.Image image8 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "{0}: ({1}, {2})", image8, "hi!", "0,0,1,1", "");
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) projectInfo12);
        basicProjectInfo4.addOptionalLibrary("AxisLocation.BOTTOM_OR_LEFT");
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean2 = segmentedTimeline0.containsDomainValue(date1);
        java.util.List list3 = segmentedTimeline0.getExceptionSegments();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = combinedRangeXYPlot4.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = logAxis9.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6, list14, (org.jfree.data.Range) dateRange15, false);
        segmentedTimeline0.addExceptions(list14);
        boolean boolean22 = segmentedTimeline0.containsDomainRange((long) (byte) 1, (long) (byte) 10);
        java.util.Date date24 = segmentedTimeline0.getDate((long) 6);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.Class<?> wildcardClass1 = rectangleAnchor0.getClass();
        java.lang.String str2 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str2.equals("RectangleAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot1.getDataExtractOrder();
        java.awt.Shape shape3 = multiplePiePlot1.getLegendItemShape();
        java.awt.Font font7 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color8 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("hi!", font7, (java.awt.Paint) color8);
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("0,0,1,1", font7, (org.jfree.chart.plot.Plot) polarPlot10, false);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("0,0,1,1", font7);
        textTitle13.setToolTipText("red");
        java.lang.String str16 = textTitle13.getID();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        textTitle13.setBackgroundPaint((java.awt.Paint) color17);
        textTitle13.setText("item");
        org.jfree.chart.entity.TitleEntity titleEntity21 = new org.jfree.chart.entity.TitleEntity(shape3, (org.jfree.chart.title.Title) textTitle13);
        java.lang.Object obj22 = titleEntity21.clone();
        org.jfree.chart.title.Title title23 = titleEntity21.getTitle();
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(title23);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) ' ', (double) 0L, (double) 100L, 90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets5.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(unitType6);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesShapesVisible(0, (java.lang.Boolean) false);
        java.awt.Font font5 = xYStepRenderer0.getLegendTextFont(8);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        xYStepRenderer0.setSeriesStroke((int) (byte) 0, stroke7, true);
        org.jfree.chart.LegendItem legendItem12 = xYStepRenderer0.getLegendItem((int) 'a', (int) '4');
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator14 = xYStepRenderer0.getSeriesItemLabelGenerator((int) 'a');
        java.awt.Shape shape16 = xYStepRenderer0.lookupLegendShape(0);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(legendItem12);
        org.junit.Assert.assertNull(xYItemLabelGenerator14);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        boolean boolean7 = month3.equals((java.lang.Object) chartRenderingInfo5);
        long long8 = month3.getFirstMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month3, (org.jfree.data.time.RegularTimePeriod) year9);
        java.lang.Class class11 = periodAxis10.getMinorTickTimePeriodClass();
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("item", class11);
        boolean boolean13 = org.jfree.chart.util.SerialUtilities.isSerializable(class11);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559372400000L + "'", long8 == 1559372400000L);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class10 = periodAxis9.getMinorTickTimePeriodClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
        boolean boolean12 = org.jfree.chart.util.SerialUtilities.isSerializable(class10);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer(6.0d);
        java.awt.Paint paint2 = xYBarRenderer1.getBaseItemLabelPaint();
        xYBarRenderer1.setShadowVisible(false);
        xYBarRenderer1.setUseYInterval(false);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer0.setBase((double) (byte) 0);
        barRenderer0.setShadowYOffset(4000.0d);
        double double7 = barRenderer0.getUpperClip();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getRangeMinorGridlineStroke();
        combinedRangeXYPlot8.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = combinedRangeXYPlot8.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        boolean boolean13 = barRenderer0.equals((java.lang.Object) xYItemRenderer12);
        org.junit.Assert.assertNull(categoryToolTipGenerator2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 15, (double) (-1), (double) (short) 0, (double) 0L);
        double double7 = rectangleInsets5.calculateLeftInset((double) 2);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-2.0d) + "'", double7 == (-2.0d));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.data.Range range4 = rectangleConstraint2.getHeightRange();
        double double5 = rectangleConstraint2.getWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        try {
            int int2 = defaultXYDataset0.getItemCount(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(100);
        java.text.NumberFormat numberFormat3 = java.text.NumberFormat.getNumberInstance();
        objectList1.set((int) (short) 1, (java.lang.Object) numberFormat3);
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.text.NumberFormat numberFormat1 = standardXYToolTipGenerator0.getYFormat();
        java.text.DateFormat dateFormat2 = standardXYToolTipGenerator0.getYDateFormat();
        java.lang.String str3 = standardXYToolTipGenerator0.getFormatString();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}: ({1}, {2})" + "'", str3.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.renderer.RendererUtilities rendererUtilities0 = new org.jfree.chart.renderer.RendererUtilities();
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesShapesVisible(0, (java.lang.Boolean) false);
        java.awt.Font font5 = xYStepRenderer0.getLegendTextFont(8);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        xYStepRenderer0.setSeriesStroke((int) (byte) 0, stroke7, true);
        xYStepRenderer0.setSeriesShapesVisible(5, true);
        boolean boolean15 = xYStepRenderer0.getItemShapeVisible((int) (short) -1, 0);
        boolean boolean16 = xYStepRenderer0.getBaseShapesFilled();
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("red");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis1.setAxisLineStroke(stroke4);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = categoryAxis1.getCategoryLabelPositions();
        float float7 = categoryAxis1.getMinorTickMarkInsideLength();
        double double8 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        textTitle9.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.jfree.chart.entity.EntityCollection entityCollection15 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo(entityCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        boolean boolean18 = month14.equals((java.lang.Object) chartRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D19 = chartRenderingInfo16.getChartArea();
        textTitle9.setBounds(rectangle2D19);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100L, (float) (short) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
        combinedRangeXYPlot25.setDomainAxisLocation((int) 'a', axisLocation27);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot25);
        org.jfree.chart.title.LegendTitle legendTitle31 = jFreeChart29.getLegend(100);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity34 = new org.jfree.chart.entity.JFreeChartEntity(shape23, jFreeChart29, "", "0,0,1,1");
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int37 = color36.getGreen();
        java.awt.Color color38 = java.awt.Color.getColor("hi!", color36);
        boolean boolean39 = jFreeChart29.equals((java.lang.Object) color38);
        int int40 = jFreeChart29.getBackgroundImageAlignment();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity43 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape) rectangle2D19, jFreeChart29, "Pie 3D Plot", "Combined Range XYPlot");
        jFreeChart29.setBorderVisible(true);
        boolean boolean46 = jFreeChart29.getAntiAlias();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNull(legendTitle31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 255 + "'", int37 == 255);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 15 + "'", int40 == 15);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D2.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        piePlot3D2.notifyListeners(plotChangeEvent6);
        java.awt.Shape shape8 = piePlot3D2.getLegendItemShape();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer9.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer9.clearSeriesStrokes(false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer14 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint15 = xYAreaRenderer14.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = xYAreaRenderer14.getBasePositiveItemLabelPosition();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke19 = combinedRangeXYPlot18.getRangeMinorGridlineStroke();
        combinedRangeXYPlot18.clearAnnotations();
        combinedRangeXYPlot18.configureDomainAxes();
        xYAreaRenderer17.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot18);
        xYAreaRenderer17.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer25 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer25.setSeriesShapesVisible(0, (java.lang.Boolean) false);
        java.awt.Font font30 = xYStepRenderer25.getLegendTextFont(8);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray31 = new org.jfree.chart.LegendItemSource[] { piePlot3D2, xYAreaRenderer9, xYAreaRenderer14, xYAreaRenderer17, xYStepRenderer25 };
        legendTitle1.setSources(legendItemSourceArray31);
        java.lang.Object obj33 = legendTitle1.clone();
        java.awt.Color color35 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int36 = color35.getGreen();
        java.awt.Color color37 = java.awt.Color.getColor("hi!", color35);
        legendTitle1.setItemPaint((java.awt.Paint) color37);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertNotNull(legendItemSourceArray31);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 255 + "'", int36 == 255);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        boolean boolean7 = month3.equals((java.lang.Object) chartRenderingInfo5);
        long long8 = month3.getFirstMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month3, (org.jfree.data.time.RegularTimePeriod) year9);
        java.util.Locale locale11 = periodAxis10.getLocale();
        java.text.NumberFormat numberFormat12 = java.text.NumberFormat.getIntegerInstance(locale11);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator13 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!", locale11);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559372400000L + "'", long8 == 1559372400000L);
        org.junit.Assert.assertNotNull(locale11);
        org.junit.Assert.assertNotNull(numberFormat12);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer4.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer4.clearSeriesStrokes(false);
        java.awt.Paint paint10 = xYAreaRenderer4.getSeriesPaint(15);
        boolean boolean12 = xYAreaRenderer4.isSeriesItemLabelsVisible(0);
        int int13 = combinedRangeXYPlot0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer4);
        combinedRangeXYPlot0.clearRangeAxes();
        double double15 = combinedRangeXYPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset0.setValue((java.lang.Comparable) 255, 12.0d);
        try {
            java.lang.Comparable comparable5 = defaultPieDataset0.getKey((-3047828));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -3047828");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis1.setAutoTickUnitSelection(true, true);
        java.lang.String str14 = logAxis1.getLabel();
        logAxis1.setFixedAutoRange((double) ' ');
        logAxis1.setRangeWithMargins(4.0d, (double) 5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getLastTextFragment();
        java.awt.Paint paint6 = textFragment5.getPaint();
        boolean boolean7 = itemLabelAnchor0.equals((java.lang.Object) paint6);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(textFragment5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("LengthConstraintType.NONE");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        java.lang.Object obj2 = defaultPieDataset0.clone();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Object obj4 = barRenderer3.clone();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = barRenderer3.getBaseURLGenerator();
        boolean boolean6 = defaultPieDataset0.equals((java.lang.Object) categoryURLGenerator5);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        xYStepAreaRenderer1.setRangeBase((double) (-1.0f));
        xYStepAreaRenderer1.setPlotArea(false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = logAxis2.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = java.awt.Color.red;
        logAxis2.setTickMarkPaint((java.awt.Paint) color8);
        logAxis2.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape12 = logAxis2.getDownArrow();
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        java.awt.geom.Rectangle2D rectangle2D15 = chartRenderingInfo14.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D16 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D16.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = null;
        piePlot3D16.notifyListeners(plotChangeEvent20);
        org.jfree.chart.entity.PlotEntity plotEntity23 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D15, (org.jfree.chart.plot.Plot) piePlot3D16, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity26 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis2, (java.awt.Shape) rectangle2D15, "", "");
        boolean boolean27 = standardPieSectionLabelGenerator0.equals((java.lang.Object) logAxis2);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset28 = new org.jfree.data.general.DefaultPieDataset();
        try {
            java.lang.String str30 = standardPieSectionLabelGenerator0.generateSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset28, (java.lang.Comparable) 2692525037755L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 2692525037755");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 4);
        int int3 = dateTickUnit2.getMinorTickCount();
        java.lang.String str4 = dateTickUnit2.toString();
        int int5 = dateTickUnit2.getMultiple();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "DateTickUnit[DateTickUnitType.SECOND, 4]" + "'", str4.equals("DateTickUnit[DateTickUnitType.SECOND, 4]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        java.awt.Stroke stroke9 = null;
        try {
            logAxis1.setAxisLineStroke(stroke9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.05d, "", false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke5 = combinedRangeXYPlot4.getRangeMinorGridlineStroke();
        combinedRangeXYPlot4.clearAnnotations();
        boolean boolean7 = combinedRangeXYPlot4.isDomainPannable();
        java.awt.Paint paint8 = combinedRangeXYPlot4.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = null;
        logAxis10.setStandardTickUnits(tickUnitSource11);
        boolean boolean13 = logAxis10.isNegativeArrowVisible();
        logAxis10.pan((double) (short) 1);
        java.lang.Object obj16 = logAxis10.clone();
        int int17 = combinedRangeXYPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis10);
        try {
            java.lang.String str18 = logFormat3.format((java.lang.Object) combinedRangeXYPlot4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        combinedRangeXYPlot0.configureDomainAxes();
        combinedRangeXYPlot0.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot0.getDomainAxisLocation();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint8 = xYAreaRenderer7.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYAreaRenderer7.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke11 = xYAreaRenderer7.lookupSeriesStroke(2);
        combinedRangeXYPlot0.setRenderer((int) 'a', (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer7, false);
        boolean boolean14 = combinedRangeXYPlot0.isDomainPannable();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D2.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        piePlot3D2.notifyListeners(plotChangeEvent6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        piePlot3D2.markerChanged(markerChangeEvent8);
        org.jfree.data.xy.XYSeries xYSeries12 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        xYSeries12.setKey((java.lang.Comparable) year13);
        java.awt.Stroke stroke15 = piePlot3D2.getSectionOutlineStroke((java.lang.Comparable) year13);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator16 = piePlot3D2.getLegendLabelURLGenerator();
        defaultPieDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3D2);
        org.junit.Assert.assertNull(stroke15);
        org.junit.Assert.assertNull(pieURLGenerator16);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("0,0,1,1", font2, (org.jfree.chart.plot.Plot) polarPlot5, false);
        jFreeChart7.setTitle("red");
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int12 = color11.getGreen();
        java.awt.Color color13 = java.awt.Color.getColor("hi!", color11);
        jFreeChart7.setBorderPaint((java.awt.Paint) color13);
        org.jfree.chart.entity.EntityCollection entityCollection17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = new org.jfree.chart.ChartRenderingInfo(entityCollection17);
        org.jfree.chart.entity.EntityCollection entityCollection19 = chartRenderingInfo18.getEntityCollection();
        jFreeChart7.handleClick((int) (short) 100, 0, chartRenderingInfo18);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(entityCollection19);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = logAxis2.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = java.awt.Color.red;
        logAxis2.setTickMarkPaint((java.awt.Paint) color8);
        logAxis2.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape12 = logAxis2.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke14 = combinedRangeXYPlot13.getRangeMinorGridlineStroke();
        combinedRangeXYPlot13.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection16 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = combinedRangeXYPlot13.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection16);
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape12, (org.jfree.chart.plot.Plot) combinedRangeXYPlot13);
        java.util.List list19 = combinedRangeXYPlot13.getAnnotations();
        boolean boolean20 = lengthAdjustmentType0.equals((java.lang.Object) combinedRangeXYPlot13);
        combinedRangeXYPlot13.clearRangeMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace22 = combinedRangeXYPlot13.getFixedDomainAxisSpace();
        boolean boolean23 = combinedRangeXYPlot13.isDomainMinorGridlinesVisible();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(xYItemRenderer17);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        combinedRangeXYPlot1.setDomainAxisLocation((int) 'a', axisLocation3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        boolean boolean6 = combinedRangeXYPlot1.isDomainZeroBaselineVisible();
        combinedRangeXYPlot1.setDomainPannable(false);
        org.jfree.data.xy.XYDataset xYDataset10 = combinedRangeXYPlot1.getDataset((int) '#');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke12 = combinedRangeXYPlot11.getRangeMinorGridlineStroke();
        combinedRangeXYPlot11.clearAnnotations();
        java.awt.Paint paint14 = combinedRangeXYPlot11.getDomainMinorGridlinePaint();
        combinedRangeXYPlot1.setDomainTickBandPaint(paint14);
        java.awt.Stroke stroke16 = combinedRangeXYPlot1.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState1.updateCrosshairY(0.0d);
        crosshairState1.updateCrosshairX((double) (-2208960000000L), 15);
        crosshairState1.updateCrosshairY((double) 900000L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis1.setAutoTickUnitSelection(true, true);
        logAxis1.resizeRange2(4.0d, (double) 'a');
        java.awt.Stroke stroke17 = logAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.axis.AxisState axisState20 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke23 = combinedRangeXYPlot22.getRangeMinorGridlineStroke();
        combinedRangeXYPlot22.clearAnnotations();
        boolean boolean25 = combinedRangeXYPlot22.isDomainPannable();
        boolean boolean26 = combinedRangeXYPlot22.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = combinedRangeXYPlot22.getDomainAxisEdge();
        axisState20.moveCursor(0.025d, rectangleEdge27);
        try {
            double double29 = logAxis1.lengthToJava2D((double) (-12566464), rectangle2D19, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer0.setBase((double) (byte) 0);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((double) ' ', (double) 0L, (double) 100L, 90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder9.getInsets();
        boolean boolean11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) barRenderer0, (java.lang.Object) rectangleInsets10);
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot12.setAngleGridlinePaint((java.awt.Paint) color13);
        java.awt.Color color15 = color13.darker();
        barRenderer0.setBasePaint((java.awt.Paint) color15);
        boolean boolean17 = barRenderer0.isDrawBarOutline();
        java.awt.Shape shape18 = null;
        barRenderer0.setBaseLegendShape(shape18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = barRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertNull(categoryToolTipGenerator2);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categoryURLGenerator20);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = xYAreaRenderer0.getBasePositiveItemLabelPosition();
        java.lang.Boolean boolean4 = xYAreaRenderer0.getSeriesVisibleInLegend((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = xYAreaRenderer0.getGradientTransformer();
        boolean boolean6 = xYAreaRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = xYAreaRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(xYItemLabelGenerator7);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis1.centerRange((double) 0L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        java.lang.String str14 = combinedRangeXYPlot13.getPlotType();
        java.awt.Paint paint15 = combinedRangeXYPlot13.getDomainZeroBaselinePaint();
        java.awt.Paint paint16 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        combinedRangeXYPlot13.setRangeMinorGridlinePaint(paint16);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Combined Range XYPlot" + "'", str14.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseItemLabelPaint();
        boolean boolean2 = xYAreaRenderer0.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer0.setShadowYOffset((double) 100L);
        int int5 = barRenderer0.getRowCount();
        int int6 = barRenderer0.getRowCount();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getRangeMinorGridlineStroke();
        combinedRangeXYPlot8.clearAnnotations();
        java.awt.Color color11 = java.awt.Color.red;
        boolean boolean13 = color11.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot8.setRangeCrosshairPaint((java.awt.Paint) color11);
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection16 = combinedRangeXYPlot8.getDomainMarkers(layer15);
        try {
            barRenderer0.addAnnotation(categoryAnnotation7, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(layer15);
        org.junit.Assert.assertNull(collection16);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "item", "[size=1]", "TextBlockAnchor.CENTER_RIGHT");
        timeSeries3.setMaximumItemAge(604800000L);
        timeSeries3.clear();
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D7.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = null;
        piePlot3D7.notifyListeners(plotChangeEvent11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        piePlot3D7.markerChanged(markerChangeEvent13);
        org.jfree.data.xy.XYSeries xYSeries17 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        xYSeries17.setKey((java.lang.Comparable) year18);
        java.awt.Stroke stroke20 = piePlot3D7.getSectionOutlineStroke((java.lang.Comparable) year18);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (-2.0d));
        org.junit.Assert.assertNull(stroke20);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = null;
        logAxis2.setStandardTickUnits(tickUnitSource3);
        boolean boolean5 = logAxis2.isNegativeArrowVisible();
        logAxis2.pan((double) (short) 1);
        java.lang.String str8 = logAxis2.getLabelURL();
        java.awt.Font font9 = logAxis2.getLabelFont();
        java.awt.Font font11 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("hi!", font11, (java.awt.Paint) color12);
        org.jfree.chart.text.TextFragment textFragment14 = textLine13.getLastTextFragment();
        java.awt.Paint paint15 = textFragment14.getPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer18 = null;
        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint15, (float) 255, (int) (byte) -1, textMeasurer18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.lang.String str24 = textBlockAnchor23.toString();
        java.awt.Shape shape28 = textBlock19.calculateBounds(graphics2D20, (float) 'a', (float) (short) 10, textBlockAnchor23, (float) 255, 1.0f, (double) 6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = textBlock19.getLineAlignment();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor33 = null;
        textBlock19.draw(graphics2D30, (float) 7, (float) 900000L, textBlockAnchor33, (float) 255, (float) 2, (double) (short) 100);
        boolean boolean39 = textBlock19.equals((java.lang.Object) 0.025d);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor43 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.lang.String str44 = textBlockAnchor43.toString();
        java.awt.Shape shape48 = textBlock19.calculateBounds(graphics2D40, (float) (short) 1, (float) (byte) 1, textBlockAnchor43, (float) 604800000L, 0.0f, (double) 3);
        org.jfree.chart.axis.LogAxis logAxis51 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource52 = null;
        logAxis51.setStandardTickUnits(tickUnitSource52);
        boolean boolean54 = logAxis51.isNegativeArrowVisible();
        logAxis51.pan((double) (short) 1);
        java.lang.String str57 = logAxis51.getLabelURL();
        java.awt.Font font58 = logAxis51.getLabelFont();
        org.jfree.chart.plot.PolarPlot polarPlot60 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot60.setAngleGridlinePaint((java.awt.Paint) color61);
        java.awt.Color color63 = java.awt.Color.getColor("{0}: ({1}, {2})", color61);
        textBlock19.addLine("Nearest", font58, (java.awt.Paint) color61);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment65 = textBlock19.getLineAlignment();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textFragment14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textBlock19);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TextBlockAnchor.CENTER_RIGHT" + "'", str24.equals("TextBlockAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "TextBlockAnchor.CENTER_RIGHT" + "'", str44.equals("TextBlockAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(horizontalAlignment65);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = barRenderer1.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer1.setBase((double) (byte) 0);
        boolean boolean6 = year0.equals((java.lang.Object) barRenderer1);
        barRenderer1.setBaseCreateEntities(true, true);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        combinedRangeXYPlot1.setDomainAxisLocation((int) 'a', axisLocation3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        boolean boolean6 = combinedRangeXYPlot1.isDomainZeroBaselineVisible();
        combinedRangeXYPlot1.setDomainPannable(false);
        org.jfree.chart.axis.ValueAxis valueAxis10 = combinedRangeXYPlot1.getDomainAxis((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        boolean boolean4 = piePlot3D0.getAutoPopulateSectionPaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot3D0.getLabelDistributor();
        int int6 = abstractPieLabelDistributor5.getItemCount();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord7 = null;
        try {
            abstractPieLabelDistributor5.addPieLabelRecord(pieLabelRecord7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean3 = xYStepRenderer0.getItemLineVisible((-1), 100);
        xYStepRenderer0.setSeriesLinesVisible((int) (short) 10, (java.lang.Boolean) true);
        java.awt.Shape shape8 = xYStepRenderer0.getLegendShape((int) (byte) 10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator10 = null;
        xYStepRenderer0.setSeriesItemLabelGenerator(3, xYItemLabelGenerator10, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(shape8);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        combinedRangeXYPlot1.setDomainAxisLocation((int) 'a', axisLocation3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        java.awt.geom.Rectangle2D rectangle2D11 = chartRenderingInfo10.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D12.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        piePlot3D12.notifyListeners(plotChangeEvent16);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D11, (org.jfree.chart.plot.Plot) piePlot3D12, "");
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets8.createInsetRectangle(rectangle2D11);
        legendTitle7.setLegendItemGraphicPadding(rectangleInsets8);
        jFreeChart5.addLegend(legendTitle7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("red");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis1.setAxisLineStroke(stroke4);
        org.jfree.chart.ui.ProjectInfo projectInfo7 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean10 = segmentedTimeline8.containsDomainValue(date9);
        java.util.List list11 = segmentedTimeline8.getExceptionSegments();
        projectInfo7.setContributors(list11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo15.getChartArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets13.createAdjustedRectangle(rectangle2D16, lengthAdjustmentType17, lengthAdjustmentType18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        try {
            double double21 = categoryAxis1.getCategoryMiddle((java.lang.Comparable) "ERROR : Relative To String", list11, rectangle2D19, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(projectInfo7);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseShapesVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) false);
        xYStepRenderer0.notifyListeners(rendererChangeEvent4);
        java.awt.Stroke stroke7 = xYStepRenderer0.getSeriesStroke(1);
        java.awt.Paint paint11 = xYStepRenderer0.getItemPaint(0, (int) (short) 10, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        combinedRangeXYPlot12.setFixedRangeAxisSpace(axisSpace15, true);
        combinedRangeXYPlot12.clearRangeMarkers();
        boolean boolean19 = xYStepRenderer0.equals((java.lang.Object) combinedRangeXYPlot12);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        combinedRangeXYPlot7.setDomainAxisLocation((int) 'a', axisLocation9);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        boolean boolean12 = combinedRangeXYPlot7.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        logAxis14.setPositiveArrowVisible(false);
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        org.jfree.chart.entity.EntityCollection entityCollection19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo(entityCollection19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        boolean boolean22 = month18.equals((java.lang.Object) chartRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D23 = chartRenderingInfo20.getChartArea();
        xYAreaRenderer0.fillDomainGridBand(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis14, rectangle2D23, (double) '4', 100.0d);
        boolean boolean27 = logAxis14.isAutoRange();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = xYAreaRenderer0.getToolTipGenerator(8, 2019, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = xYAreaRenderer0.getDrawingSupplier();
        boolean boolean7 = xYAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(xYToolTipGenerator5);
        org.junit.Assert.assertNull(drawingSupplier6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = chartRenderingInfo1.getEntityCollection();
        chartRenderingInfo1.clear();
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, false);
        try {
            java.lang.Number number7 = intervalXYDelegate4.getEndX(5, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = legendTitle1.getBackgroundPaint();
        legendTitle1.setNotify(true);
        boolean boolean6 = legendTitle1.equals((java.lang.Object) 1L);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendTitle1.getLegendItemGraphicLocation();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("series");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        try {
            java.util.Date date3 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer5.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer5.clearSeriesStrokes(false);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer5.setBaseLegendShape(shape11);
        combinedRangeXYPlot0.setRenderer(15, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5, true);
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        combinedRangeXYPlot0.setRangeZeroBaselinePaint(paint15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date19);
        org.jfree.chart.entity.EntityCollection entityCollection21 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo(entityCollection21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        boolean boolean24 = month20.equals((java.lang.Object) chartRenderingInfo22);
        long long25 = month20.getFirstMillisecond();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month20, (org.jfree.data.time.RegularTimePeriod) year26);
        boolean boolean28 = periodAxis27.isMinorTickMarksVisible();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = periodAxis27.getFirst();
        periodAxis27.setFixedAutoRange((double) 86400000L);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        periodAxis27.setTickLabelPaint((java.awt.Paint) color32);
        periodAxis27.setMinorTickMarkInsideLength((float) 5);
        combinedRangeXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) periodAxis27);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1559372400000L + "'", long25 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        java.util.Locale locale10 = periodAxis9.getLocale();
        double double11 = periodAxis9.getUpperMargin();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        combinedRangeXYPlot14.setDomainAxisLocation((int) 'a', axisLocation16);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot14);
        boolean boolean19 = combinedRangeXYPlot14.isDomainZeroBaselineVisible();
        combinedRangeXYPlot14.setDomainPannable(false);
        org.jfree.data.xy.XYDataset xYDataset23 = combinedRangeXYPlot14.getDataset((int) '#');
        combinedRangeXYPlot14.setRangeCrosshairLockedOnData(false);
        boolean boolean26 = combinedRangeXYPlot14.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemSource legendItemSource27 = null;
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle(legendItemSource27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection30 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = new org.jfree.chart.ChartRenderingInfo(entityCollection30);
        java.awt.geom.Rectangle2D rectangle2D32 = chartRenderingInfo31.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D33 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D33.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent37 = null;
        piePlot3D33.notifyListeners(plotChangeEvent37);
        org.jfree.chart.entity.PlotEntity plotEntity40 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D32, (org.jfree.chart.plot.Plot) piePlot3D33, "");
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets29.createInsetRectangle(rectangle2D32);
        legendTitle28.setLegendItemGraphicPadding(rectangleInsets29);
        java.awt.geom.Rectangle2D rectangle2D43 = legendTitle28.getBounds();
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("red");
        java.awt.Paint paint47 = categoryAxis45.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot51 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke52 = combinedRangeXYPlot51.getRangeMinorGridlineStroke();
        combinedRangeXYPlot51.clearAnnotations();
        boolean boolean54 = combinedRangeXYPlot51.isDomainPannable();
        boolean boolean55 = combinedRangeXYPlot51.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = combinedRangeXYPlot51.getDomainAxisEdge();
        org.jfree.chart.axis.AxisState axisState57 = null;
        categoryAxis45.drawTickMarks(graphics2D48, (double) (-1.0f), rectangle2D50, rectangleEdge56, axisState57);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot59 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke60 = combinedRangeXYPlot59.getRangeMinorGridlineStroke();
        combinedRangeXYPlot59.clearAnnotations();
        boolean boolean62 = combinedRangeXYPlot59.isDomainPannable();
        boolean boolean63 = combinedRangeXYPlot59.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis65 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource66 = null;
        logAxis65.setStandardTickUnits(tickUnitSource66);
        boolean boolean68 = logAxis65.isNegativeArrowVisible();
        logAxis65.pan((double) (short) 1);
        combinedRangeXYPlot59.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis65);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent72 = null;
        combinedRangeXYPlot59.plotChanged(plotChangeEvent72);
        org.jfree.chart.axis.AxisSpace axisSpace74 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot59.setFixedDomainAxisSpace(axisSpace74);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace76 = periodAxis9.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) combinedRangeXYPlot14, rectangle2D43, rectangleEdge56, axisSpace74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertNotNull(locale10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(xYDataset23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot2.setAngleGridlinePaint((java.awt.Paint) color3);
        java.awt.Color color5 = color3.darker();
        int int6 = color5.getAlpha();
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        barRenderer0.setMaximumBarWidth((double) 1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = barRenderer0.getToolTipGenerator((int) (short) 100, (int) '4', true);
        barRenderer0.setBase((double) 1577836800000L);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        java.lang.String str1 = tickType0.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAJOR" + "'", str1.equals("MAJOR"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        java.lang.String str4 = piePlot3D0.getPlotType();
        piePlot3D0.setLabelLinkMargin(100.0d);
        boolean boolean7 = piePlot3D0.getLabelLinksVisible();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pie 3D Plot" + "'", str4.equals("Pie 3D Plot"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        boolean boolean2 = defaultXYDataset0.equals((java.lang.Object) (byte) 100);
        try {
            java.lang.Number number5 = defaultXYDataset0.getY(7, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        logAxis1.setAxisLineVisible(true);
        logAxis1.setAutoTickUnitSelection(false, true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        combinedRangeXYPlot7.setDomainAxisLocation((int) 'a', axisLocation9);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        boolean boolean12 = combinedRangeXYPlot7.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        logAxis14.setPositiveArrowVisible(false);
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        org.jfree.chart.entity.EntityCollection entityCollection19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo(entityCollection19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        boolean boolean22 = month18.equals((java.lang.Object) chartRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D23 = chartRenderingInfo20.getChartArea();
        xYAreaRenderer0.fillDomainGridBand(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis14, rectangle2D23, (double) '4', 100.0d);
        java.awt.Shape shape27 = xYAreaRenderer0.getLegendArea();
        org.jfree.chart.plot.XYPlot xYPlot28 = xYAreaRenderer0.getPlot();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNull(xYPlot28);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity18 = new org.jfree.chart.entity.PieSectionEntity(shape11, pieDataset12, (int) 'a', 2019, (java.lang.Comparable) "red", "", "red");
        int int19 = pieSectionEntity18.getSectionIndex();
        int int20 = pieSectionEntity18.getSectionIndex();
        pieSectionEntity18.setSectionKey((java.lang.Comparable) 1.0E-8d);
        int int23 = pieSectionEntity18.getPieIndex();
        java.lang.Comparable comparable24 = pieSectionEntity18.getSectionKey();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 97 + "'", int23 == 97);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + 1.0E-8d + "'", comparable24.equals(1.0E-8d));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        combinedRangeXYPlot1.setRangeCrosshairLockedOnData(true);
        float float8 = combinedRangeXYPlot1.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer4.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer4.clearSeriesStrokes(false);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        combinedRangeXYPlot11.setDomainAxisLocation((int) 'a', axisLocation13);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot11);
        boolean boolean16 = combinedRangeXYPlot11.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("");
        logAxis18.setPositiveArrowVisible(false);
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.chart.entity.EntityCollection entityCollection23 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = new org.jfree.chart.ChartRenderingInfo(entityCollection23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        boolean boolean26 = month22.equals((java.lang.Object) chartRenderingInfo24);
        java.awt.geom.Rectangle2D rectangle2D27 = chartRenderingInfo24.getChartArea();
        xYAreaRenderer4.fillDomainGridBand(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (org.jfree.chart.axis.ValueAxis) logAxis18, rectangle2D27, (double) '4', 100.0d);
        java.awt.Shape shape31 = xYAreaRenderer4.getLegendArea();
        java.awt.Paint paint32 = null;
        try {
            org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("Nearest", "SerialDate.weekInMonthToString(): invalid code.", "RectangleAnchor.BOTTOM_LEFT", "0,0,1,1", shape31, paint32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        int int3 = xYSeriesCollection1.indexOf((java.lang.Comparable) '#');
        double double5 = xYSeriesCollection1.getDomainUpperBound(false);
        double double6 = xYSeriesCollection1.getIntervalPositionFactor();
        org.jfree.data.Range range7 = xYStepRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1);
        xYSeriesCollection1.validateObject();
        java.lang.Object obj9 = xYSeriesCollection1.clone();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1, true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(2);
        boolean boolean2 = xYStepAreaRenderer1.getShapesVisible();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = xYStepAreaRenderer1.getSeriesURLGenerator((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(xYURLGenerator4);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis1.centerRange((double) 0L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke17 = combinedRangeXYPlot16.getRangeMinorGridlineStroke();
        combinedRangeXYPlot16.clearAnnotations();
        java.awt.Color color19 = java.awt.Color.red;
        boolean boolean21 = color19.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot16.setRangeCrosshairPaint((java.awt.Paint) color19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection24 = combinedRangeXYPlot16.getDomainMarkers(layer23);
        boolean boolean25 = combinedRangeXYPlot13.removeDomainMarker((-12566464), marker15, layer23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = barRenderer26.getPositiveItemLabelPositionFallback();
        boolean boolean28 = layer23.equals((java.lang.Object) barRenderer26);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(itemLabelPosition27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        org.jfree.chart.text.TextFragment textFragment4 = textLine3.getLastTextFragment();
        org.jfree.chart.text.TextFragment textFragment5 = textLine3.getFirstTextFragment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textFragment4);
        org.junit.Assert.assertNotNull(textFragment5);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        combinedRangeXYPlot13.setDomainAxisLocation((int) 'a', axisLocation15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot13);
        boolean boolean18 = combinedRangeXYPlot13.isDomainZeroBaselineVisible();
        combinedRangeXYPlot13.setDomainPannable(false);
        org.jfree.data.xy.XYDataset xYDataset22 = combinedRangeXYPlot13.getDataset((int) '#');
        combinedDomainXYPlot11.remove((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot13);
        combinedRangeXYPlot13.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(xYDataset22);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot3D0.getDatasetGroup();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = piePlot3D0.getLabelLinkStyle();
        java.lang.String str8 = pieLabelLinkStyle7.toString();
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str8.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getRangeUpperBound(false);
        try {
            org.jfree.data.xy.XYSeries xYSeries6 = xYSeriesCollection0.getSeries((java.lang.Comparable) 100.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 100.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        java.lang.String str1 = timePeriodAnchor0.toString();
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TimePeriodAnchor.MIDDLE" + "'", str1.equals("TimePeriodAnchor.MIDDLE"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.data.Range range5 = combinedRangeXYPlot0.getDataRange(valueAxis4);
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        java.util.List list12 = logAxis7.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge11);
        java.awt.Color color13 = java.awt.Color.red;
        logAxis7.setTickMarkPaint((java.awt.Paint) color13);
        logAxis7.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape17 = logAxis7.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke19 = combinedRangeXYPlot18.getRangeMinorGridlineStroke();
        combinedRangeXYPlot18.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection21 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = combinedRangeXYPlot18.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection21);
        org.jfree.chart.entity.PlotEntity plotEntity23 = new org.jfree.chart.entity.PlotEntity(shape17, (org.jfree.chart.plot.Plot) combinedRangeXYPlot18);
        combinedRangeXYPlot18.clearAnnotations();
        org.jfree.chart.axis.LogAxis logAxis26 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.AxisState axisState28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        java.util.List list31 = logAxis26.refreshTicks(graphics2D27, axisState28, rectangle2D29, rectangleEdge30);
        java.awt.Color color32 = java.awt.Color.red;
        logAxis26.setTickMarkPaint((java.awt.Paint) color32);
        logAxis26.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis26.setAutoTickUnitSelection(true, true);
        combinedRangeXYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis26);
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18, 8);
        combinedRangeXYPlot18.configureDomainAxes();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.text.DateFormat dateFormat1 = null;
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat(0.05d, "", false);
        java.lang.StringBuffer stringBuffer7 = null;
        java.text.FieldPosition fieldPosition8 = null;
        java.lang.StringBuffer stringBuffer9 = logFormat5.format((double) 1559372400000L, stringBuffer7, fieldPosition8);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator10 = new org.jfree.chart.labels.StandardXYToolTipGenerator("604,800,000", dateFormat1, (java.text.NumberFormat) logFormat5);
        java.lang.String str11 = standardXYToolTipGenerator10.getFormatString();
        org.junit.Assert.assertNotNull(stringBuffer9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "604,800,000" + "'", str11.equals("604,800,000"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        combinedRangeXYPlot0.configureDomainAxes();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) 0);
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.chart.entity.EntityCollection entityCollection11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo(entityCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        boolean boolean14 = month10.equals((java.lang.Object) chartRenderingInfo12);
        long long15 = month10.getFirstMillisecond();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) year16);
        java.util.Locale locale18 = periodAxis17.getLocale();
        double double19 = periodAxis17.getUpperMargin();
        combinedRangeXYPlot0.setDomainAxis(5, (org.jfree.chart.axis.ValueAxis) periodAxis17);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
        org.junit.Assert.assertNotNull(locale18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer(6.0d);
        xYBarRenderer1.setShadowXOffset(0.05d);
        java.lang.Object obj4 = xYBarRenderer1.clone();
        boolean boolean5 = xYBarRenderer1.getDataBoundsIncludesVisibleSeriesOnly();
        java.lang.Object obj6 = xYBarRenderer1.clone();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(axisSpace1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer4.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer4.clearSeriesStrokes(false);
        java.awt.Paint paint10 = xYAreaRenderer4.getSeriesPaint(15);
        boolean boolean12 = xYAreaRenderer4.isSeriesItemLabelsVisible(0);
        int int13 = combinedRangeXYPlot0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer4);
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo15.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D17.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        piePlot3D17.notifyListeners(plotChangeEvent21);
        org.jfree.chart.entity.PlotEntity plotEntity24 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D16, (org.jfree.chart.plot.Plot) piePlot3D17, "");
        boolean boolean25 = xYAreaRenderer4.equals((java.lang.Object) piePlot3D17);
        java.lang.Object obj26 = piePlot3D17.clone();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100L, (float) (short) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        combinedRangeXYPlot5.setDomainAxisLocation((int) 'a', axisLocation7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart9.getLegend(100);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity14 = new org.jfree.chart.entity.JFreeChartEntity(shape3, jFreeChart9, "", "0,0,1,1");
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int17 = color16.getGreen();
        java.awt.Color color18 = java.awt.Color.getColor("hi!", color16);
        boolean boolean19 = jFreeChart9.equals((java.lang.Object) color18);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str21 = chartChangeEventType20.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItemCollection0, jFreeChart9, chartChangeEventType20);
        java.lang.Object obj23 = jFreeChart9.getTextAntiAlias();
        jFreeChart9.setTitle("{0}: ({1}, {2})");
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendTitle11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str21.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertNull(obj23);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) (short) 1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer(6.0d);
        java.lang.Object obj2 = xYBarRenderer1.clone();
        java.awt.Paint paint4 = xYBarRenderer1.lookupSeriesFillPaint((int) (short) 10);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesShapesVisible(0, (java.lang.Boolean) false);
        java.awt.Font font5 = xYStepRenderer0.getLegendTextFont(8);
        boolean boolean6 = xYStepRenderer0.getBaseShapesVisible();
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.plot.Plot plot5 = combinedRangeXYPlot0.getRootPlot();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke7 = combinedRangeXYPlot6.getRangeMinorGridlineStroke();
        combinedRangeXYPlot6.clearAnnotations();
        boolean boolean9 = combinedRangeXYPlot6.isDomainPannable();
        boolean boolean10 = combinedRangeXYPlot6.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = null;
        logAxis12.setStandardTickUnits(tickUnitSource13);
        boolean boolean15 = logAxis12.isNegativeArrowVisible();
        logAxis12.pan((double) (short) 1);
        combinedRangeXYPlot6.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis12);
        org.jfree.chart.axis.LogAxis logAxis20 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.AxisState axisState22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        java.util.List list25 = logAxis20.refreshTicks(graphics2D21, axisState22, rectangle2D23, rectangleEdge24);
        java.awt.Color color26 = java.awt.Color.red;
        logAxis20.setTickMarkPaint((java.awt.Paint) color26);
        logAxis20.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape30 = logAxis20.getDownArrow();
        org.jfree.chart.entity.EntityCollection entityCollection31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo(entityCollection31);
        java.awt.geom.Rectangle2D rectangle2D33 = chartRenderingInfo32.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D34 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D34.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent38 = null;
        piePlot3D34.notifyListeners(plotChangeEvent38);
        org.jfree.chart.entity.PlotEntity plotEntity41 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D33, (org.jfree.chart.plot.Plot) piePlot3D34, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity44 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis20, (java.awt.Shape) rectangle2D33, "", "");
        java.lang.String str45 = logAxis20.getLabel();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot47 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation49 = null;
        combinedRangeXYPlot47.setDomainAxisLocation((int) 'a', axisLocation49);
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot47);
        boolean boolean52 = combinedRangeXYPlot47.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.LogAxis logAxis55 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = null;
        logAxis55.setStandardTickUnits(tickUnitSource56);
        logAxis55.setVisible(false);
        combinedRangeXYPlot47.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) logAxis55, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { logAxis20, logAxis55 };
        combinedRangeXYPlot6.setRangeAxes(valueAxisArray62);
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray62);
        combinedRangeXYPlot0.setWeight(10);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(valueAxisArray62);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer1 = polarPlot0.getRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeMinorGridlineStroke();
        combinedRangeXYPlot2.clearAnnotations();
        java.awt.Color color5 = java.awt.Color.red;
        boolean boolean7 = color5.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot2.setRangeCrosshairPaint((java.awt.Paint) color5);
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color5);
        java.awt.Color color10 = java.awt.Color.gray;
        polarPlot0.setAngleLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        java.awt.geom.Rectangle2D rectangle2D16 = plotRenderingInfo15.getPlotArea();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke18 = combinedRangeXYPlot17.getRangeMinorGridlineStroke();
        combinedRangeXYPlot17.clearAnnotations();
        java.awt.Stroke stroke20 = combinedRangeXYPlot17.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer21 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer21.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer21.clearSeriesStrokes(false);
        java.awt.Paint paint27 = xYAreaRenderer21.getSeriesPaint(15);
        boolean boolean29 = xYAreaRenderer21.isSeriesItemLabelsVisible(0);
        int int30 = combinedRangeXYPlot17.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer21);
        org.jfree.chart.entity.EntityCollection entityCollection31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo(entityCollection31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        java.awt.geom.Rectangle2D rectangle2D34 = plotRenderingInfo33.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D35 = plotRenderingInfo33.getDataArea();
        org.jfree.chart.axis.LogAxis logAxis37 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = logAxis37.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Color color43 = java.awt.Color.red;
        logAxis37.setTickMarkPaint((java.awt.Paint) color43);
        logAxis37.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape47 = logAxis37.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot48 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke49 = combinedRangeXYPlot48.getRangeMinorGridlineStroke();
        combinedRangeXYPlot48.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection51 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = combinedRangeXYPlot48.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection51);
        org.jfree.chart.entity.PlotEntity plotEntity53 = new org.jfree.chart.entity.PlotEntity(shape47, (org.jfree.chart.plot.Plot) combinedRangeXYPlot48);
        combinedRangeXYPlot48.clearAnnotations();
        java.awt.geom.Point2D point2D55 = combinedRangeXYPlot48.getQuadrantOrigin();
        org.jfree.chart.plot.XYPlot xYPlot56 = combinedRangeXYPlot17.findSubplot(plotRenderingInfo33, point2D55);
        try {
            polarPlot0.zoomRangeAxes((double) 8, plotRenderingInfo15, point2D55, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(polarItemRenderer1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(rectangle2D16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNull(xYItemRenderer52);
        org.junit.Assert.assertNotNull(point2D55);
        org.junit.Assert.assertNull(xYPlot56);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getRangeMinorGridlineStroke();
        boolean boolean10 = xYAreaRenderer0.hasListener((java.util.EventListener) combinedRangeXYPlot8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        boolean boolean15 = combinedRangeXYPlot12.isDomainPannable();
        boolean boolean16 = combinedRangeXYPlot12.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = null;
        logAxis18.setStandardTickUnits(tickUnitSource19);
        boolean boolean21 = logAxis18.isNegativeArrowVisible();
        logAxis18.pan((double) (short) 1);
        combinedRangeXYPlot12.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis18);
        org.jfree.chart.axis.LogAxis logAxis26 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.AxisState axisState28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        java.util.List list31 = logAxis26.refreshTicks(graphics2D27, axisState28, rectangle2D29, rectangleEdge30);
        java.awt.Color color32 = java.awt.Color.red;
        logAxis26.setTickMarkPaint((java.awt.Paint) color32);
        logAxis26.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape36 = logAxis26.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot37 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke38 = combinedRangeXYPlot37.getRangeMinorGridlineStroke();
        combinedRangeXYPlot37.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection40 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = combinedRangeXYPlot37.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection40);
        org.jfree.chart.entity.PlotEntity plotEntity42 = new org.jfree.chart.entity.PlotEntity(shape36, (org.jfree.chart.plot.Plot) combinedRangeXYPlot37);
        java.util.List list43 = combinedRangeXYPlot37.getAnnotations();
        org.jfree.chart.axis.LogAxis logAxis46 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource47 = null;
        logAxis46.setStandardTickUnits(tickUnitSource47);
        boolean boolean49 = logAxis46.isNegativeArrowVisible();
        logAxis46.pan((double) (short) 1);
        combinedRangeXYPlot37.setDomainAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) logAxis46, false);
        org.jfree.chart.plot.PiePlot3D piePlot3D54 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D54.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent58 = null;
        piePlot3D54.notifyListeners(plotChangeEvent58);
        logAxis46.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D54);
        org.jfree.chart.plot.Marker marker61 = null;
        org.jfree.chart.block.BlockBorder blockBorder66 = new org.jfree.chart.block.BlockBorder((double) ' ', (double) 0L, (double) 100L, 90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = blockBorder66.getInsets();
        org.jfree.chart.entity.EntityCollection entityCollection68 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo69 = new org.jfree.chart.ChartRenderingInfo(entityCollection68);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo69);
        java.awt.geom.Rectangle2D rectangle2D71 = chartRenderingInfo69.getChartArea();
        java.awt.Shape shape72 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D71);
        java.awt.geom.Rectangle2D rectangle2D73 = rectangleInsets67.createInsetRectangle(rectangle2D71);
        xYAreaRenderer0.drawDomainMarker(graphics2D11, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot12, (org.jfree.chart.axis.ValueAxis) logAxis46, marker61, rectangle2D71);
        java.awt.Color color76 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int77 = color76.getGreen();
        xYAreaRenderer0.setLegendTextPaint(2019, (java.awt.Paint) color76);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator80 = null;
        xYAreaRenderer0.setSeriesItemLabelGenerator(0, xYItemLabelGenerator80);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNull(xYItemRenderer41);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertNotNull(shape72);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(color76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 255 + "'", int77 == 255);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 2147483647, (double) 10L);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        logAxis6.setStandardTickUnits(tickUnitSource7);
        boolean boolean9 = logAxis6.isNegativeArrowVisible();
        logAxis6.pan((double) (short) 1);
        java.lang.Object obj12 = logAxis6.clone();
        logAxis6.setLabelURL("");
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 8);
        java.lang.String str17 = valueMarker16.getLabel();
        org.jfree.chart.entity.EntityCollection entityCollection18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo(entityCollection18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo19.getChartArea();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D21);
        barRenderer3D2.drawRangeMarker(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, (org.jfree.chart.plot.Marker) valueMarker16, rectangle2D21);
        org.jfree.chart.plot.PiePlot3D piePlot3D24 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D24.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent28 = null;
        piePlot3D24.notifyListeners(plotChangeEvent28);
        org.jfree.data.general.DatasetGroup datasetGroup30 = piePlot3D24.getDatasetGroup();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle31 = piePlot3D24.getLabelLinkStyle();
        piePlot3D24.setCircular(false, false);
        piePlot3D24.clearSectionOutlinePaints(false);
        double double38 = piePlot3D24.getExplodePercent((java.lang.Comparable) "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.awt.Paint paint39 = piePlot3D24.getBaseSectionOutlinePaint();
        java.awt.Color color40 = java.awt.Color.YELLOW;
        java.awt.Color color41 = color40.darker();
        piePlot3D24.setLabelOutlinePaint((java.awt.Paint) color41);
        valueMarker16.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot3D24);
        piePlot3D24.setPieIndex(9);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(datasetGroup30);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle31);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color41);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        boolean boolean10 = periodAxis9.isMinorTickMarksVisible();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = periodAxis9.getFirst();
        periodAxis9.setFixedAutoRange((double) 86400000L);
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo14 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray15 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo14 };
        periodAxis9.setLabelInfo(periodAxisLabelInfoArray15);
        java.awt.Paint paint17 = null;
        try {
            periodAxis9.setAxisLinePaint(paint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray15);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseShapesVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) false);
        xYStepRenderer0.notifyListeners(rendererChangeEvent4);
        java.lang.Object obj6 = xYStepRenderer0.clone();
        boolean boolean7 = xYStepRenderer0.getDrawOutlines();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = logAxis5.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, list10, (org.jfree.data.Range) dateRange11, false);
        timeSeriesCollection2.removeAllSeries();
        double double17 = timeSeriesCollection2.getDomainUpperBound(true);
        try {
            int int21 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) timeSeriesCollection2, 15, 1.0E-8d, (double) 60000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (15).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer3);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("MAJOR");
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat(0.05d, "", false);
        java.text.ParsePosition parsePosition7 = null;
        java.lang.Number number8 = logFormat5.parse("", parsePosition7);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean11 = segmentedTimeline9.containsDomainValue(date10);
        segmentedTimeline9.addException((long) (short) 100);
        segmentedTimeline9.addException((long) 255);
        boolean boolean16 = logFormat5.equals((java.lang.Object) segmentedTimeline9);
        java.text.DateFormat dateFormat17 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator18 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", (java.text.NumberFormat) logFormat5, dateFormat17);
        boolean boolean19 = defaultDrawingSupplier0.equals((java.lang.Object) standardXYToolTipGenerator18);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(segmentedTimeline9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, false);
        double double6 = intervalXYDelegate4.getDomainLowerBound(false);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint2 = barRenderer0.getShadowPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getSeriesToolTipGenerator((int) (short) 100);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint6 = xYAreaRenderer5.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYAreaRenderer5.getBasePositiveItemLabelPosition();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = null;
        logAxis12.setStandardTickUnits(tickUnitSource13);
        boolean boolean15 = logAxis12.isNegativeArrowVisible();
        logAxis12.pan((double) (short) 1);
        java.lang.Object obj18 = logAxis12.clone();
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        logAxis12.removeChangeListener(axisChangeListener19);
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date22);
        org.jfree.chart.entity.EntityCollection entityCollection24 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo(entityCollection24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo25);
        boolean boolean27 = month23.equals((java.lang.Object) chartRenderingInfo25);
        java.awt.geom.Rectangle2D rectangle2D28 = chartRenderingInfo25.getChartArea();
        org.jfree.chart.entity.ChartEntity chartEntity31 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D28, "", "Combined Range XYPlot");
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D28, rectangleEdge32);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("red");
        java.awt.Paint paint37 = categoryAxis35.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke42 = combinedRangeXYPlot41.getRangeMinorGridlineStroke();
        combinedRangeXYPlot41.clearAnnotations();
        boolean boolean44 = combinedRangeXYPlot41.isDomainPannable();
        boolean boolean45 = combinedRangeXYPlot41.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = combinedRangeXYPlot41.getDomainAxisEdge();
        org.jfree.chart.axis.AxisState axisState47 = null;
        categoryAxis35.drawTickMarks(graphics2D38, (double) (-1.0f), rectangle2D40, rectangleEdge46, axisState47);
        double double49 = logAxis12.java2DToValue((double) (byte) 100, rectangle2D28, rectangleEdge46);
        try {
            barRenderer0.drawBackground(graphics2D9, categoryPlot10, rectangle2D28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Pie 3D Plot", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        try {
            java.lang.Comparable comparable6 = xYSeriesCollection3.getSeriesKey((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(xYItemRenderer4);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getLowerClip();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.data.Range range4 = barRenderer0.findRangeBounds(categoryDataset2, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        boolean boolean24 = legendItem15.isLineVisible();
        org.jfree.data.xy.XYSeries xYSeries27 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double28 = xYSeries27.getMinX();
        xYSeries27.add((double) 100.0f, 0.0d);
        boolean boolean32 = legendItem15.equals((java.lang.Object) xYSeries27);
        double double33 = xYSeries27.getMinY();
        double double34 = xYSeries27.getMinX();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.0d + "'", double34 == 100.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        boolean boolean2 = piePlot3D1.getAutoPopulateSectionPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot3D0.setLegendLabelURLGenerator(pieURLGenerator4);
        piePlot3D0.setBackgroundImageAlignment((int) (byte) 1);
        piePlot3D0.setCircular(false, false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        piePlot3D0.setURLGenerator(pieURLGenerator11);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setLabel("red");
        double double11 = logAxis1.getUpperBound();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean4 = segmentedTimeline2.containsDomainValue(date3);
        int int5 = defaultPieDataset1.getIndex((java.lang.Comparable) date3);
        try {
            java.lang.String str7 = standardPieSectionLabelGenerator0.generateSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset1, (java.lang.Comparable) 0.12d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 0.12");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.data.Range range5 = combinedRangeXYPlot0.getDataRange(valueAxis4);
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        java.util.List list12 = logAxis7.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge11);
        java.awt.Color color13 = java.awt.Color.red;
        logAxis7.setTickMarkPaint((java.awt.Paint) color13);
        logAxis7.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape17 = logAxis7.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke19 = combinedRangeXYPlot18.getRangeMinorGridlineStroke();
        combinedRangeXYPlot18.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection21 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = combinedRangeXYPlot18.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection21);
        org.jfree.chart.entity.PlotEntity plotEntity23 = new org.jfree.chart.entity.PlotEntity(shape17, (org.jfree.chart.plot.Plot) combinedRangeXYPlot18);
        combinedRangeXYPlot18.clearAnnotations();
        org.jfree.chart.axis.LogAxis logAxis26 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.AxisState axisState28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        java.util.List list31 = logAxis26.refreshTicks(graphics2D27, axisState28, rectangle2D29, rectangleEdge30);
        java.awt.Color color32 = java.awt.Color.red;
        logAxis26.setTickMarkPaint((java.awt.Paint) color32);
        logAxis26.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis26.setAutoTickUnitSelection(true, true);
        combinedRangeXYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis26);
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18, 8);
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) 8);
        java.awt.Stroke stroke44 = null;
        valueMarker43.setOutlineStroke(stroke44);
        combinedRangeXYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker43);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        java.lang.Object obj1 = standardPieToolTipGenerator0.clone();
        java.lang.Object obj2 = standardPieToolTipGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        java.lang.String str4 = rectangleConstraint3.toString();
        java.lang.String str5 = rectangleConstraint3.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str4.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str5.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Object obj1 = null;
        boolean boolean2 = booleanList0.equals(obj1);
        int int3 = booleanList0.size();
        booleanList0.setBoolean(15, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.awt.Color color0 = java.awt.Color.white;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=255,b=255]" + "'", str1.equals("java.awt.Color[r=255,g=255,b=255]"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("red");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeZone4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = combinedRangeXYPlot3.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection5);
        org.jfree.chart.axis.LogAxis logAxis8 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        java.util.List list13 = logAxis8.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge12);
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange14);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection5, list13, (org.jfree.data.Range) dateRange14, false);
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.axis.AxisState axisState21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        java.util.List list24 = logAxis19.refreshTicks(graphics2D20, axisState21, rectangle2D22, rectangleEdge23);
        java.awt.Color color25 = java.awt.Color.red;
        logAxis19.setTickMarkPaint((java.awt.Paint) color25);
        logAxis19.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape29 = logAxis19.getDownArrow();
        org.jfree.chart.entity.EntityCollection entityCollection30 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = new org.jfree.chart.ChartRenderingInfo(entityCollection30);
        java.awt.geom.Rectangle2D rectangle2D32 = chartRenderingInfo31.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D33 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D33.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent37 = null;
        piePlot3D33.notifyListeners(plotChangeEvent37);
        org.jfree.chart.entity.PlotEntity plotEntity40 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D32, (org.jfree.chart.plot.Plot) piePlot3D33, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity43 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis19, (java.awt.Shape) rectangle2D32, "", "");
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D32, (double) 900000L, (double) (byte) 1);
        org.jfree.chart.axis.LogAxis logAxis48 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = null;
        logAxis48.setStandardTickUnits(tickUnitSource49);
        boolean boolean51 = logAxis48.isNegativeArrowVisible();
        logAxis48.pan((double) (short) 1);
        java.lang.Object obj54 = logAxis48.clone();
        org.jfree.chart.event.AxisChangeListener axisChangeListener55 = null;
        logAxis48.removeChangeListener(axisChangeListener55);
        java.util.Date date58 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month(date58);
        org.jfree.chart.entity.EntityCollection entityCollection60 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo61 = new org.jfree.chart.ChartRenderingInfo(entityCollection60);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo61);
        boolean boolean63 = month59.equals((java.lang.Object) chartRenderingInfo61);
        java.awt.geom.Rectangle2D rectangle2D64 = chartRenderingInfo61.getChartArea();
        org.jfree.chart.entity.ChartEntity chartEntity67 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D64, "", "Combined Range XYPlot");
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
        double double69 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D64, rectangleEdge68);
        org.jfree.chart.axis.CategoryAxis categoryAxis71 = new org.jfree.chart.axis.CategoryAxis("red");
        java.awt.Paint paint73 = categoryAxis71.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        java.awt.Graphics2D graphics2D74 = null;
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot77 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke78 = combinedRangeXYPlot77.getRangeMinorGridlineStroke();
        combinedRangeXYPlot77.clearAnnotations();
        boolean boolean80 = combinedRangeXYPlot77.isDomainPannable();
        boolean boolean81 = combinedRangeXYPlot77.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = combinedRangeXYPlot77.getDomainAxisEdge();
        org.jfree.chart.axis.AxisState axisState83 = null;
        categoryAxis71.drawTickMarks(graphics2D74, (double) (-1.0f), rectangle2D76, rectangleEdge82, axisState83);
        double double85 = logAxis48.java2DToValue((double) (byte) 100, rectangle2D64, rectangleEdge82);
        try {
            double double86 = categoryAxis1.getCategoryMiddle((java.lang.Comparable) 1.0f, list13, rectangle2D32, rectangleEdge82);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(obj54);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(rectangleEdge82);
        org.junit.Assert.assertEquals((double) double85, Double.NaN, 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MONTH;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        boolean boolean3 = dateTickUnitType0.equals((java.lang.Object) categoryDataset1);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRangeZoomable();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        polarPlot0.setRadiusGridlineStroke(stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        polarPlot0.setAngleGridlineStroke(stroke4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        boolean boolean24 = legendItem15.isLineVisible();
        org.jfree.data.xy.XYSeries xYSeries27 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double28 = xYSeries27.getMinX();
        xYSeries27.add((double) 100.0f, 0.0d);
        boolean boolean32 = legendItem15.equals((java.lang.Object) xYSeries27);
        java.awt.Paint paint33 = legendItem15.getLabelPaint();
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.axis.AxisState axisState37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        java.util.List list40 = logAxis35.refreshTicks(graphics2D36, axisState37, rectangle2D38, rectangleEdge39);
        java.awt.Color color41 = java.awt.Color.red;
        logAxis35.setTickMarkPaint((java.awt.Paint) color41);
        logAxis35.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis35.centerRange((double) 0L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot47 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis35);
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline50 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date51 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean52 = segmentedTimeline50.containsDomainValue(date51);
        java.util.List list53 = segmentedTimeline50.getExceptionSegments();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot54 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection56 = new org.jfree.data.time.TimeSeriesCollection(timeZone55);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = combinedRangeXYPlot54.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection56);
        org.jfree.chart.axis.LogAxis logAxis59 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D60 = null;
        org.jfree.chart.axis.AxisState axisState61 = null;
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = null;
        java.util.List list64 = logAxis59.refreshTicks(graphics2D60, axisState61, rectangle2D62, rectangleEdge63);
        org.jfree.data.time.DateRange dateRange65 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange66 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange65);
        org.jfree.data.Range range68 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection56, list64, (org.jfree.data.Range) dateRange65, false);
        segmentedTimeline50.addExceptions(list64);
        combinedRangeXYPlot47.drawDomainTickBands(graphics2D48, rectangle2D49, list64);
        org.jfree.chart.plot.PiePlot3D piePlot3D71 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D71.setCircular(true, true);
        piePlot3D71.setSimpleLabels(true);
        org.jfree.data.general.PieDataset pieDataset77 = null;
        piePlot3D71.setDataset(pieDataset77);
        org.jfree.chart.util.RectangleInsets rectangleInsets79 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection80 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo81 = new org.jfree.chart.ChartRenderingInfo(entityCollection80);
        java.awt.geom.Rectangle2D rectangle2D82 = chartRenderingInfo81.getChartArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType83 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType84 = null;
        java.awt.geom.Rectangle2D rectangle2D85 = rectangleInsets79.createAdjustedRectangle(rectangle2D82, lengthAdjustmentType83, lengthAdjustmentType84);
        piePlot3D71.setLabelPadding(rectangleInsets79);
        java.awt.Stroke stroke87 = piePlot3D71.getLabelOutlineStroke();
        combinedRangeXYPlot47.setDomainGridlineStroke(stroke87);
        legendItem15.setOutlineStroke(stroke87);
        org.jfree.chart.axis.LogAxis logAxis91 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource92 = null;
        logAxis91.setStandardTickUnits(tickUnitSource92);
        boolean boolean94 = logAxis91.isNegativeArrowVisible();
        logAxis91.pan((double) (short) 1);
        java.lang.String str97 = logAxis91.getLabelURL();
        java.awt.Font font98 = logAxis91.getLabelFont();
        legendItem15.setLabelFont(font98);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(segmentedTimeline50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertNull(xYItemRenderer57);
        org.junit.Assert.assertNotNull(list64);
        org.junit.Assert.assertNull(range68);
        org.junit.Assert.assertNotNull(rectangleInsets79);
        org.junit.Assert.assertNotNull(rectangle2D82);
        org.junit.Assert.assertNotNull(rectangle2D85);
        org.junit.Assert.assertNotNull(stroke87);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNull(str97);
        org.junit.Assert.assertNotNull(font98);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "item", "[size=1]", "TextBlockAnchor.CENTER_RIGHT");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 10, (int) '#');
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month8);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo(entityCollection1);
        java.awt.geom.Rectangle2D rectangle2D3 = chartRenderingInfo2.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        org.jfree.chart.entity.PlotEntity plotEntity11 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D3, (org.jfree.chart.plot.Plot) piePlot3D4, "");
        java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets0.createInsetRectangle(rectangle2D3);
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = logAxis14.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        java.awt.Color color20 = java.awt.Color.red;
        logAxis14.setTickMarkPaint((java.awt.Paint) color20);
        logAxis14.setMinorTickMarkInsideLength((float) (short) -1);
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D12, (org.jfree.chart.axis.Axis) logAxis14, "PieLabelLinkStyle.STANDARD");
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = logAxis14.getLabelInsets();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleInsets26);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "item", "[size=1]", "TextBlockAnchor.CENTER_RIGHT");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries3.getDataItem(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double3 = xYSeries2.getMinX();
        try {
            org.jfree.data.xy.XYDataItem xYDataItem5 = xYSeries2.remove(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getRangeMinorGridlineStroke();
        boolean boolean10 = xYAreaRenderer0.hasListener((java.util.EventListener) combinedRangeXYPlot8);
        java.awt.Paint paint11 = combinedRangeXYPlot8.getBackgroundPaint();
        combinedRangeXYPlot8.clearRangeAxes();
        int int13 = combinedRangeXYPlot8.getRendererCount();
        int int14 = combinedRangeXYPlot8.getBackgroundImageAlignment();
        boolean boolean15 = combinedRangeXYPlot8.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRangeZoomable();
        java.awt.Paint paint2 = polarPlot0.getAngleGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot0.getAxis();
        java.awt.Font font4 = polarPlot0.getNoDataMessageFont();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        polarPlot0.setRenderer(polarItemRenderer5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint2 = barRenderer0.getShadowPaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint4 = xYAreaRenderer3.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYAreaRenderer3.getBasePositiveItemLabelPosition();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition5);
        int int7 = barRenderer0.getColumnCount();
        org.jfree.chart.util.ObjectList objectList9 = new org.jfree.chart.util.ObjectList(100);
        org.jfree.chart.axis.LogAxis logAxis11 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource12 = null;
        logAxis11.setStandardTickUnits(tickUnitSource12);
        boolean boolean14 = logAxis11.isNegativeArrowVisible();
        boolean boolean15 = logAxis11.isInverted();
        int int16 = objectList9.indexOf((java.lang.Object) boolean15);
        boolean boolean17 = barRenderer0.equals((java.lang.Object) int16);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter0);
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer5.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer5.clearSeriesStrokes(false);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer5.setBaseLegendShape(shape11);
        combinedRangeXYPlot0.setRenderer(15, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5, true);
        java.awt.Paint paint15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        combinedRangeXYPlot0.setRangeZeroBaselinePaint(paint15);
        boolean boolean17 = combinedRangeXYPlot0.isSubplot();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer18 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer18.setBaseShapesVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) false);
        xYStepRenderer18.notifyListeners(rendererChangeEvent22);
        java.awt.Stroke stroke25 = xYStepRenderer18.getSeriesStroke(1);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer18);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(stroke25);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getRangeMinorGridlineStroke();
        boolean boolean10 = xYAreaRenderer0.hasListener((java.util.EventListener) combinedRangeXYPlot8);
        java.awt.Paint paint11 = combinedRangeXYPlot8.getBackgroundPaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = combinedRangeXYPlot8.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer13 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer13.setSeriesShapesVisible(0, (java.lang.Boolean) false);
        java.awt.Font font18 = xYStepRenderer13.getLegendTextFont(8);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        xYStepRenderer13.setSeriesStroke((int) (byte) 0, stroke20, true);
        xYStepRenderer13.setSeriesShapesVisible(5, true);
        boolean boolean28 = xYStepRenderer13.getItemShapeVisible((int) (short) -1, 0);
        combinedRangeXYPlot8.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer13);
        org.jfree.chart.axis.AxisSpace axisSpace30 = combinedRangeXYPlot8.getFixedDomainAxisSpace();
        org.jfree.chart.plot.XYPlot xYPlot31 = null;
        try {
            combinedRangeXYPlot8.add(xYPlot31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNull(font18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(axisSpace30);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean3 = xYStepRenderer0.getItemLineVisible((-1), 100);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        java.util.List list11 = logAxis6.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
        java.awt.Color color12 = java.awt.Color.red;
        logAxis6.setTickMarkPaint((java.awt.Paint) color12);
        logAxis6.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape16 = logAxis6.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke18 = combinedRangeXYPlot17.getRangeMinorGridlineStroke();
        combinedRangeXYPlot17.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection20 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = combinedRangeXYPlot17.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection20);
        org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity(shape16, (org.jfree.chart.plot.Plot) combinedRangeXYPlot17);
        combinedRangeXYPlot17.clearAnnotations();
        org.jfree.chart.axis.LogAxis logAxis25 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.AxisState axisState27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        java.util.List list30 = logAxis25.refreshTicks(graphics2D26, axisState27, rectangle2D28, rectangleEdge29);
        java.awt.Color color31 = java.awt.Color.red;
        logAxis25.setTickMarkPaint((java.awt.Paint) color31);
        logAxis25.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis25.setAutoTickUnitSelection(true, true);
        combinedRangeXYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis25);
        org.jfree.chart.axis.LogAxis logAxis40 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.axis.AxisState axisState42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        java.util.List list45 = logAxis40.refreshTicks(graphics2D41, axisState42, rectangle2D43, rectangleEdge44);
        java.awt.Color color46 = java.awt.Color.red;
        logAxis40.setTickMarkPaint((java.awt.Paint) color46);
        double double48 = logAxis40.getAutoRangeMinimumSize();
        org.jfree.chart.entity.EntityCollection entityCollection49 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = new org.jfree.chart.ChartRenderingInfo(entityCollection49);
        java.awt.geom.Rectangle2D rectangle2D51 = chartRenderingInfo50.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D52 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D52.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent56 = null;
        piePlot3D52.notifyListeners(plotChangeEvent56);
        org.jfree.chart.entity.PlotEntity plotEntity59 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D51, (org.jfree.chart.plot.Plot) piePlot3D52, "");
        xYStepRenderer0.fillDomainGridBand(graphics2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot17, (org.jfree.chart.axis.ValueAxis) logAxis40, rectangle2D51, (-2.0d), 0.0d);
        java.awt.Paint paint64 = null;
        try {
            combinedRangeXYPlot17.setQuadrantPaint((-12566464), paint64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-12566464) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0E-8d + "'", double48 == 1.0E-8d);
        org.junit.Assert.assertNotNull(rectangle2D51);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("0,0,1,1", timeZone1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean5 = segmentedTimeline3.containsDomainValue(date4);
        segmentedTimeline3.addException((long) (short) 100);
        segmentedTimeline3.addException((long) 255);
        long long10 = segmentedTimeline3.getStartTime();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType11 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType11, 4);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType14 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType14, 4);
        int int17 = dateTickUnit16.getMultiple();
        org.jfree.chart.plot.PiePlot3D piePlot3D18 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D18.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = null;
        piePlot3D18.notifyListeners(plotChangeEvent22);
        java.awt.Shape shape24 = piePlot3D18.getLegendItemShape();
        boolean boolean25 = dateTickUnit16.equals((java.lang.Object) piePlot3D18);
        double double26 = dateTickUnit16.getSize();
        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
        java.util.Date date29 = dateTickUnit16.rollDate(date27);
        java.util.Date date30 = dateTickUnit13.rollDate(date27);
        boolean boolean31 = segmentedTimeline3.containsDomainValue(date27);
        dateAxis2.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline3);
        dateAxis2.setRange(1.0d, (double) 100);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2208960000000L) + "'", long10 == (-2208960000000L));
        org.junit.Assert.assertNotNull(dateTickUnitType11);
        org.junit.Assert.assertNotNull(dateTickUnitType14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4000.0d + "'", double26 == 4000.0d);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesShapesVisible(0, (java.lang.Boolean) false);
        xYStepRenderer0.setDrawSeriesLineAsPath(true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = legendTitle1.getBackgroundPaint();
        legendTitle1.setNotify(true);
        boolean boolean6 = legendTitle1.equals((java.lang.Object) 1L);
        org.jfree.chart.axis.LogAxis logAxis8 = new org.jfree.chart.axis.LogAxis("");
        logAxis8.setLowerMargin(0.0d);
        boolean boolean11 = legendTitle1.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean2 = barRenderer0.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator3);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRangeZoomable();
        java.awt.Paint paint2 = polarPlot0.getAngleGridlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis3 = polarPlot0.getAxis();
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.jfree.chart.entity.EntityCollection entityCollection7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo(entityCollection7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        boolean boolean10 = month6.equals((java.lang.Object) chartRenderingInfo8);
        long long11 = month6.getFirstMillisecond();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) year12);
        boolean boolean14 = periodAxis13.isMinorTickMarksVisible();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = periodAxis13.getFirst();
        periodAxis13.setFixedAutoRange((double) 86400000L);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        periodAxis13.setTickLabelPaint((java.awt.Paint) color18);
        periodAxis13.setMinorTickMarkInsideLength((float) 5);
        org.jfree.data.Range range22 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) periodAxis13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1559372400000L + "'", long11 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        combinedRangeXYPlot1.setDomainAxisLocation((int) 'a', axisLocation3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        boolean boolean6 = combinedRangeXYPlot1.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = null;
        logAxis9.setStandardTickUnits(tickUnitSource10);
        logAxis9.setVisible(false);
        combinedRangeXYPlot1.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) logAxis9, false);
        org.jfree.data.time.TimeSeries timeSeries16 = null;
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeSeries16, timeZone17);
        boolean boolean19 = combinedRangeXYPlot1.equals((java.lang.Object) timeZone17);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.chart.entity.EntityCollection entityCollection6 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo(entityCollection6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        boolean boolean9 = month5.equals((java.lang.Object) chartRenderingInfo7);
        long long10 = month5.getFirstMillisecond();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) year11);
        java.util.Locale locale13 = periodAxis12.getLocale();
        boolean boolean14 = xYSeries2.equals((java.lang.Object) locale13);
        java.text.NumberFormat numberFormat15 = java.text.NumberFormat.getIntegerInstance(locale13);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale13);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372400000L + "'", long10 == 1559372400000L);
        org.junit.Assert.assertNotNull(locale13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(numberFormat15);
        org.junit.Assert.assertNotNull(tickUnitSource16);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("12/31/69", "TextBlockAnchor.CENTER_RIGHT", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "MAJOR", "TimePeriodAnchor.MIDDLE");
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        float[] floatArray3 = null;
        float[] floatArray4 = java.awt.Color.RGBtoHSB(2, (int) (byte) 10, 100, floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        boolean boolean2 = defaultXYDataset0.equals((java.lang.Object) (byte) 100);
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        xYSeries6.setKey((java.lang.Comparable) year7);
        double[][] doubleArray9 = xYSeries6.toArray();
        defaultXYDataset0.addSeries((java.lang.Comparable) (byte) 100, doubleArray9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        int int13 = defaultXYDataset0.indexOf((java.lang.Comparable) regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        logAxis1.setStandardTickUnits(tickUnitSource2);
        boolean boolean4 = logAxis1.isNegativeArrowVisible();
        logAxis1.pan((double) (short) 1);
        java.lang.String str7 = logAxis1.getLabelURL();
        java.awt.Font font8 = logAxis1.getLabelFont();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) font8, false);
        boolean boolean11 = rendererChangeEvent10.getSeriesVisibilityChanged();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        polarPlot0.setRadiusGridlinePaint((java.awt.Paint) color1);
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("hi!");
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) logAxis4);
        boolean boolean6 = logAxis4.isAxisLineVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JFreeChart" + "'", str1.equals("JFreeChart"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean3 = xYStepRenderer0.getItemLineVisible((-1), 100);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        java.util.List list11 = logAxis6.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
        java.awt.Color color12 = java.awt.Color.red;
        logAxis6.setTickMarkPaint((java.awt.Paint) color12);
        logAxis6.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape16 = logAxis6.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke18 = combinedRangeXYPlot17.getRangeMinorGridlineStroke();
        combinedRangeXYPlot17.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection20 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = combinedRangeXYPlot17.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection20);
        org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity(shape16, (org.jfree.chart.plot.Plot) combinedRangeXYPlot17);
        combinedRangeXYPlot17.clearAnnotations();
        org.jfree.chart.axis.LogAxis logAxis25 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.AxisState axisState27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        java.util.List list30 = logAxis25.refreshTicks(graphics2D26, axisState27, rectangle2D28, rectangleEdge29);
        java.awt.Color color31 = java.awt.Color.red;
        logAxis25.setTickMarkPaint((java.awt.Paint) color31);
        logAxis25.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis25.setAutoTickUnitSelection(true, true);
        combinedRangeXYPlot17.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis25);
        org.jfree.chart.axis.LogAxis logAxis40 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.axis.AxisState axisState42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        java.util.List list45 = logAxis40.refreshTicks(graphics2D41, axisState42, rectangle2D43, rectangleEdge44);
        java.awt.Color color46 = java.awt.Color.red;
        logAxis40.setTickMarkPaint((java.awt.Paint) color46);
        double double48 = logAxis40.getAutoRangeMinimumSize();
        org.jfree.chart.entity.EntityCollection entityCollection49 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = new org.jfree.chart.ChartRenderingInfo(entityCollection49);
        java.awt.geom.Rectangle2D rectangle2D51 = chartRenderingInfo50.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D52 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D52.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent56 = null;
        piePlot3D52.notifyListeners(plotChangeEvent56);
        org.jfree.chart.entity.PlotEntity plotEntity59 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D51, (org.jfree.chart.plot.Plot) piePlot3D52, "");
        xYStepRenderer0.fillDomainGridBand(graphics2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot17, (org.jfree.chart.axis.ValueAxis) logAxis40, rectangle2D51, (-2.0d), 0.0d);
        xYStepRenderer0.setItemLabelAnchorOffset(0.0d);
        boolean boolean65 = xYStepRenderer0.getBaseLinesVisible();
        java.awt.Stroke stroke69 = xYStepRenderer0.getItemOutlineStroke(8, 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator70 = null;
        xYStepRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator70);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0E-8d + "'", double48 == 1.0E-8d);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(stroke69);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        boolean boolean4 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        logAxis6.setStandardTickUnits(tickUnitSource7);
        boolean boolean9 = logAxis6.isNegativeArrowVisible();
        logAxis6.pan((double) (short) 1);
        combinedRangeXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis6);
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = logAxis14.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        java.awt.Color color20 = java.awt.Color.red;
        logAxis14.setTickMarkPaint((java.awt.Paint) color20);
        logAxis14.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape24 = logAxis14.getDownArrow();
        org.jfree.chart.entity.EntityCollection entityCollection25 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = new org.jfree.chart.ChartRenderingInfo(entityCollection25);
        java.awt.geom.Rectangle2D rectangle2D27 = chartRenderingInfo26.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D28.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = null;
        piePlot3D28.notifyListeners(plotChangeEvent32);
        org.jfree.chart.entity.PlotEntity plotEntity35 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D27, (org.jfree.chart.plot.Plot) piePlot3D28, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity38 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis14, (java.awt.Shape) rectangle2D27, "", "");
        java.lang.String str39 = logAxis14.getLabel();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation43 = null;
        combinedRangeXYPlot41.setDomainAxisLocation((int) 'a', axisLocation43);
        org.jfree.chart.JFreeChart jFreeChart45 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot41);
        boolean boolean46 = combinedRangeXYPlot41.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.LogAxis logAxis49 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource50 = null;
        logAxis49.setStandardTickUnits(tickUnitSource50);
        logAxis49.setVisible(false);
        combinedRangeXYPlot41.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) logAxis49, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray56 = new org.jfree.chart.axis.ValueAxis[] { logAxis14, logAxis49 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray56);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = combinedRangeXYPlot0.getRenderer();
        org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker((double) 8);
        combinedRangeXYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker60);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType62 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker60.setLabelOffsetType(lengthAdjustmentType62);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(valueAxisArray56);
        org.junit.Assert.assertNull(xYItemRenderer58);
        org.junit.Assert.assertNotNull(lengthAdjustmentType62);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer0.setShadowYOffset((double) 100L);
        boolean boolean5 = barRenderer0.getBaseItemLabelsVisible();
        double double6 = barRenderer0.getLowerClip();
        org.junit.Assert.assertNull(categoryToolTipGenerator2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator1 = barRenderer3D0.getBaseToolTipGenerator();
        org.junit.Assert.assertNull(categoryToolTipGenerator1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean3 = segmentedTimeline1.containsDomainValue(date2);
        int int4 = defaultPieDataset0.getIndex((java.lang.Comparable) date2);
        boolean boolean5 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        try {
            defaultPieDataset0.remove((java.lang.Comparable) 0.12d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (0.12) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        java.awt.Font font10 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color11 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("hi!", font10, (java.awt.Paint) color11);
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("0,0,1,1", font10, (org.jfree.chart.plot.Plot) polarPlot13, false);
        polarPlot13.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = polarPlot13.getOrientation();
        crosshairState1.updateCrosshairPoint(0.12d, (double) 2.0f, 8, 1, (double) 13, (double) (short) 10, plotOrientation18);
        crosshairState1.updateCrosshairX((double) ' ', 8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(plotOrientation18);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = null;
        xYAreaRenderer0.setSeriesItemLabelGenerator(7, xYItemLabelGenerator7, false);
        xYAreaRenderer0.setBaseItemLabelsVisible(true, false);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "item", "[size=1]", "TextBlockAnchor.CENTER_RIGHT");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getMaximumItemCount();
        try {
            timeSeries3.update(2, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setRangeBase((double) 0.5f);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.jfree.chart.axis.LogAxis logAxis3 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        java.util.List list8 = logAxis3.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge7);
        java.awt.Color color9 = java.awt.Color.red;
        logAxis3.setTickMarkPaint((java.awt.Paint) color9);
        logAxis3.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape13 = logAxis3.getDownArrow();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity(shape13, pieDataset14, (int) 'a', 2019, (java.lang.Comparable) "red", "", "red");
        boolean boolean21 = rectangleAnchor0.equals((java.lang.Object) pieSectionEntity20);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str1.equals("RectangleAnchor.BOTTOM_LEFT"));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Paint paint6 = xYAreaRenderer0.getSeriesPaint(15);
        boolean boolean8 = xYAreaRenderer0.isSeriesItemLabelsVisible(0);
        xYAreaRenderer0.setItemLabelAnchorOffset((double) 60000L);
        boolean boolean11 = xYAreaRenderer0.getPlotShapes();
        xYAreaRenderer0.setSeriesItemLabelsVisible(15, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator17 = null;
        xYAreaRenderer0.setSeriesItemLabelGenerator(8, xYItemLabelGenerator17);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer4.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer4.clearSeriesStrokes(false);
        java.awt.Paint paint10 = xYAreaRenderer4.getSeriesPaint(15);
        boolean boolean12 = xYAreaRenderer4.isSeriesItemLabelsVisible(0);
        int int13 = combinedRangeXYPlot0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer4);
        org.jfree.chart.axis.LogAxis logAxis15 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.AxisState axisState17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        java.util.List list20 = logAxis15.refreshTicks(graphics2D16, axisState17, rectangle2D18, rectangleEdge19);
        java.awt.Color color21 = java.awt.Color.red;
        logAxis15.setTickMarkPaint((java.awt.Paint) color21);
        logAxis15.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape25 = logAxis15.getDownArrow();
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        java.awt.geom.Rectangle2D rectangle2D28 = chartRenderingInfo27.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D29 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D29.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        piePlot3D29.notifyListeners(plotChangeEvent33);
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D28, (org.jfree.chart.plot.Plot) piePlot3D29, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity39 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis15, (java.awt.Shape) rectangle2D28, "", "");
        java.lang.String str40 = logAxis15.getLabel();
        int int41 = combinedRangeXYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis15);
        logAxis15.pan((double) (-1L));
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange0);
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange1);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Class class10 = periodAxis9.getMinorTickTimePeriodClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
        boolean boolean12 = org.jfree.chart.util.SerialUtilities.isSerializable(class11);
        java.lang.ClassLoader classLoader13 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class11);
        java.lang.ClassLoader classLoader14 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class11);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader14);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(classLoader13);
        org.junit.Assert.assertNotNull(classLoader14);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        timeSeriesCollection1.removeAllSeries();
        try {
            timeSeriesCollection1.removeSeries(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (4).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot2.setAngleGridlinePaint((java.awt.Paint) color3);
        java.awt.Color color5 = color3.darker();
        int int6 = color5.getAlpha();
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        barRenderer0.setMaximumBarWidth((double) 1);
        int int10 = barRenderer0.getPassCount();
        barRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        boolean boolean24 = legendItem15.isLineVisible();
        org.jfree.data.xy.XYSeries xYSeries27 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double28 = xYSeries27.getMinX();
        xYSeries27.add((double) 100.0f, 0.0d);
        boolean boolean32 = legendItem15.equals((java.lang.Object) xYSeries27);
        java.awt.Font font36 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color37 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine38 = new org.jfree.chart.text.TextLine("hi!", font36, (java.awt.Paint) color37);
        org.jfree.chart.plot.PolarPlot polarPlot39 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("0,0,1,1", font36, (org.jfree.chart.plot.Plot) polarPlot39, false);
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("0,0,1,1", font36);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = textTitle42.getTextAlignment();
        java.lang.String str44 = horizontalAlignment43.toString();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot45 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke46 = combinedRangeXYPlot45.getRangeMinorGridlineStroke();
        combinedRangeXYPlot45.clearAnnotations();
        java.awt.Paint paint48 = combinedRangeXYPlot45.getDomainMinorGridlinePaint();
        java.awt.Color color49 = java.awt.Color.YELLOW;
        combinedRangeXYPlot45.setDomainGridlinePaint((java.awt.Paint) color49);
        boolean boolean51 = horizontalAlignment43.equals((java.lang.Object) color49);
        legendItem15.setFillPaint((java.awt.Paint) color49);
        java.awt.Stroke stroke53 = legendItem15.getOutlineStroke();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "HorizontalAlignment.CENTER" + "'", str44.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(stroke53);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot1.getDataExtractOrder();
        java.lang.Object obj3 = multiplePiePlot1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo(entityCollection5);
        java.awt.geom.Rectangle2D rectangle2D7 = chartRenderingInfo6.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D8.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        piePlot3D8.notifyListeners(plotChangeEvent12);
        org.jfree.chart.entity.PlotEntity plotEntity15 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D7, (org.jfree.chart.plot.Plot) piePlot3D8, "");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke17 = combinedRangeXYPlot16.getRangeMinorGridlineStroke();
        combinedRangeXYPlot16.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection19 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = combinedRangeXYPlot16.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection19);
        org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D7, (org.jfree.chart.plot.Plot) combinedRangeXYPlot16, "");
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets4.createOutsetRectangle(rectangle2D7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str25 = rectangleAnchor24.toString();
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D7, rectangleAnchor24, (-1.0d), (double) 2.0f);
        multiplePiePlot1.setLegendItemShape((java.awt.Shape) rectangle2D7);
        org.jfree.chart.JFreeChart jFreeChart30 = multiplePiePlot1.getPieChart();
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(xYItemRenderer20);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str25.equals("RectangleAnchor.BOTTOM_LEFT"));
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(jFreeChart30);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot2.setAngleGridlinePaint((java.awt.Paint) color3);
        java.awt.Color color5 = color3.darker();
        int int6 = color5.getAlpha();
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        barRenderer0.setMaximumBarWidth((double) 1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = barRenderer0.getToolTipGenerator((int) (short) 100, (int) '4', true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNull(itemLabelPosition14);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedRangeXYPlot12.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        java.util.List list18 = combinedRangeXYPlot12.getAnnotations();
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = null;
        logAxis21.setStandardTickUnits(tickUnitSource22);
        boolean boolean24 = logAxis21.isNegativeArrowVisible();
        logAxis21.pan((double) (short) 1);
        combinedRangeXYPlot12.setDomainAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) logAxis21, false);
        org.jfree.chart.plot.PiePlot3D piePlot3D29 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D29.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = null;
        piePlot3D29.notifyListeners(plotChangeEvent33);
        logAxis21.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D29);
        piePlot3D29.clearSectionPaints(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator38 = null;
        piePlot3D29.setURLGenerator(pieURLGenerator38);
        piePlot3D29.setDarkerSides(false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorDown((double) 12);
        java.util.List list3 = axisState0.getTicks();
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer0.setShadowYOffset((double) 100L);
        boolean boolean5 = barRenderer0.getBaseItemLabelsVisible();
        double double6 = barRenderer0.getBase();
        boolean boolean7 = barRenderer0.getShadowsVisible();
        org.junit.Assert.assertNull(categoryToolTipGenerator2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.text.NumberFormat numberFormat1 = standardXYToolTipGenerator0.getYFormat();
        java.text.DateFormat dateFormat2 = standardXYToolTipGenerator0.getYDateFormat();
        java.text.DateFormat dateFormat3 = standardXYToolTipGenerator0.getYDateFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNull(dateFormat3);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        java.util.Locale locale10 = periodAxis9.getLocale();
        double double11 = periodAxis9.getUpperMargin();
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        java.util.List list18 = logAxis13.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge17);
        java.awt.Color color19 = java.awt.Color.red;
        logAxis13.setTickMarkPaint((java.awt.Paint) color19);
        logAxis13.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape23 = logAxis13.getDownArrow();
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity30 = new org.jfree.chart.entity.PieSectionEntity(shape23, pieDataset24, (int) 'a', 2019, (java.lang.Comparable) "red", "", "red");
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean32 = pieSectionEntity30.equals((java.lang.Object) range31);
        org.jfree.data.Range range35 = org.jfree.data.Range.shift(range31, 1.0E-8d, true);
        periodAxis9.setRange(range31, true, false);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray39 = periodAxis9.getLabelInfo();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertNotNull(locale10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray39);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        xYAreaRenderer0.setAutoPopulateSeriesShape(true);
        java.awt.Shape shape7 = xYAreaRenderer0.getBaseShape();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getRangeMinorGridlineStroke();
        combinedRangeXYPlot8.clearAnnotations();
        combinedRangeXYPlot8.configureDomainAxes();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = combinedRangeXYPlot8.getDataRange(valueAxis12);
        org.jfree.chart.axis.LogAxis logAxis15 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.AxisState axisState17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        java.util.List list20 = logAxis15.refreshTicks(graphics2D16, axisState17, rectangle2D18, rectangleEdge19);
        java.awt.Color color21 = java.awt.Color.red;
        logAxis15.setTickMarkPaint((java.awt.Paint) color21);
        logAxis15.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape25 = logAxis15.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke27 = combinedRangeXYPlot26.getRangeMinorGridlineStroke();
        combinedRangeXYPlot26.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection29 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = combinedRangeXYPlot26.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection29);
        org.jfree.chart.entity.PlotEntity plotEntity31 = new org.jfree.chart.entity.PlotEntity(shape25, (org.jfree.chart.plot.Plot) combinedRangeXYPlot26);
        combinedRangeXYPlot26.clearAnnotations();
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.axis.AxisState axisState36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        java.util.List list39 = logAxis34.refreshTicks(graphics2D35, axisState36, rectangle2D37, rectangleEdge38);
        java.awt.Color color40 = java.awt.Color.red;
        logAxis34.setTickMarkPaint((java.awt.Paint) color40);
        logAxis34.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis34.setAutoTickUnitSelection(true, true);
        combinedRangeXYPlot26.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis34);
        combinedRangeXYPlot8.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot26, 8);
        xYAreaRenderer0.setPlot((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot8);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(xYItemRenderer30);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        polarPlot2.setRadiusGridlinePaint((java.awt.Paint) color3);
        xYStepAreaRenderer0.setSeriesPaint(7, (java.awt.Paint) color3, true);
        java.awt.Paint paint8 = xYStepAreaRenderer0.getSeriesOutlinePaint(0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot2.setAngleGridlinePaint((java.awt.Paint) color3);
        java.awt.Color color5 = color3.darker();
        int int6 = color5.getAlpha();
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.chart.entity.EntityCollection entityCollection10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo(entityCollection10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        boolean boolean13 = month9.equals((java.lang.Object) chartRenderingInfo11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month9.previous();
        java.util.Date date15 = regularTimePeriod14.getEnd();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset16 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline17 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean19 = segmentedTimeline17.containsDomainValue(date18);
        int int20 = defaultPieDataset16.getIndex((java.lang.Comparable) date18);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("red");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor24 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = categoryAxis23.getCategoryJava2DCoordinate(categoryAnchor24, 1, 8, rectangle2D27, rectangleEdge28);
        java.awt.Color color30 = java.awt.Color.YELLOW;
        java.awt.image.ColorModel colorModel31 = null;
        java.awt.Rectangle rectangle32 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection34 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = new org.jfree.chart.ChartRenderingInfo(entityCollection34);
        java.awt.geom.Rectangle2D rectangle2D36 = chartRenderingInfo35.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D37.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent41 = null;
        piePlot3D37.notifyListeners(plotChangeEvent41);
        org.jfree.chart.entity.PlotEntity plotEntity44 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D36, (org.jfree.chart.plot.Plot) piePlot3D37, "");
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets33.createInsetRectangle(rectangle2D36);
        org.jfree.chart.axis.LogAxis logAxis47 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.axis.AxisState axisState49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = null;
        java.util.List list52 = logAxis47.refreshTicks(graphics2D48, axisState49, rectangle2D50, rectangleEdge51);
        java.awt.Color color53 = java.awt.Color.red;
        logAxis47.setTickMarkPaint((java.awt.Paint) color53);
        logAxis47.setMinorTickMarkInsideLength((float) (short) -1);
        org.jfree.chart.entity.AxisEntity axisEntity58 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D45, (org.jfree.chart.axis.Axis) logAxis47, "PieLabelLinkStyle.STANDARD");
        java.awt.geom.AffineTransform affineTransform59 = null;
        java.awt.RenderingHints renderingHints60 = null;
        java.awt.PaintContext paintContext61 = color30.createContext(colorModel31, rectangle32, rectangle2D45, affineTransform59, renderingHints60);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot63 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation65 = null;
        combinedRangeXYPlot63.setDomainAxisLocation((int) 'a', axisLocation65);
        org.jfree.chart.JFreeChart jFreeChart67 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot63);
        boolean boolean68 = combinedRangeXYPlot63.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.LogAxis logAxis71 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource72 = null;
        logAxis71.setStandardTickUnits(tickUnitSource72);
        logAxis71.setVisible(false);
        combinedRangeXYPlot63.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) logAxis71, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = combinedRangeXYPlot63.getRangeAxisEdge((-1));
        try {
            double double80 = barRenderer0.getItemMiddle((java.lang.Comparable) date15, (java.lang.Comparable) int20, categoryDataset21, categoryAxis23, rectangle2D45, rectangleEdge79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(segmentedTimeline17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(list52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(paintContext61);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(rectangleEdge79);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        java.awt.Stroke stroke6 = xYAreaRenderer0.getBaseStroke();
        boolean boolean10 = xYAreaRenderer0.isItemLabelVisible((int) (byte) 0, (int) ' ', true);
        boolean boolean11 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYAreaRenderer0.setSeriesVisible(6, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearRangeMarkers(0);
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getDomainGridlineStroke();
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = plotRenderingInfo11.getPlotArea();
        java.awt.geom.Point2D point2D13 = null;
        combinedRangeXYPlot4.panDomainAxes((double) 8, plotRenderingInfo11, point2D13);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke16 = combinedRangeXYPlot15.getRangeMinorGridlineStroke();
        combinedRangeXYPlot15.clearAnnotations();
        java.awt.Stroke stroke18 = combinedRangeXYPlot15.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer19.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer19.clearSeriesStrokes(false);
        java.awt.Paint paint25 = xYAreaRenderer19.getSeriesPaint(15);
        boolean boolean27 = xYAreaRenderer19.isSeriesItemLabelsVisible(0);
        int int28 = combinedRangeXYPlot15.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer19);
        org.jfree.chart.entity.EntityCollection entityCollection29 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = new org.jfree.chart.ChartRenderingInfo(entityCollection29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo30);
        java.awt.geom.Rectangle2D rectangle2D32 = plotRenderingInfo31.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D33 = plotRenderingInfo31.getDataArea();
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.axis.AxisState axisState37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        java.util.List list40 = logAxis35.refreshTicks(graphics2D36, axisState37, rectangle2D38, rectangleEdge39);
        java.awt.Color color41 = java.awt.Color.red;
        logAxis35.setTickMarkPaint((java.awt.Paint) color41);
        logAxis35.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape45 = logAxis35.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot46 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke47 = combinedRangeXYPlot46.getRangeMinorGridlineStroke();
        combinedRangeXYPlot46.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection49 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = combinedRangeXYPlot46.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection49);
        org.jfree.chart.entity.PlotEntity plotEntity51 = new org.jfree.chart.entity.PlotEntity(shape45, (org.jfree.chart.plot.Plot) combinedRangeXYPlot46);
        combinedRangeXYPlot46.clearAnnotations();
        java.awt.geom.Point2D point2D53 = combinedRangeXYPlot46.getQuadrantOrigin();
        org.jfree.chart.plot.XYPlot xYPlot54 = combinedRangeXYPlot15.findSubplot(plotRenderingInfo31, point2D53);
        try {
            polarPlot0.zoomRangeAxes((double) 'a', plotRenderingInfo11, point2D53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(rectangle2D12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNull(xYItemRenderer50);
        org.junit.Assert.assertNotNull(point2D53);
        org.junit.Assert.assertNull(xYPlot54);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState1.updateCrosshairY(0.0d);
        crosshairState1.updateCrosshairX((double) (-2208960000000L), 15);
        crosshairState1.setAnchorY(0.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = waferMapPlot0.getDataset();
        org.junit.Assert.assertNull(waferMapDataset1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint2 = barRenderer0.getShadowPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getSeriesToolTipGenerator((int) (short) 100);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer5.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer5.clearSeriesStrokes(false);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYAreaRenderer5.setSeriesFillPaint((int) ' ', (java.awt.Paint) color11, true);
        barRenderer0.setShadowPaint((java.awt.Paint) color11);
        barRenderer0.setShadowVisible(false);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis1.setAutoTickUnitSelection(true, true);
        java.text.NumberFormat numberFormat14 = java.text.NumberFormat.getNumberInstance();
        logAxis1.setNumberFormatOverride(numberFormat14);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(numberFormat14);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean2 = barRenderer0.getAutoPopulateSeriesFillPaint();
        boolean boolean3 = barRenderer0.getShadowsVisible();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = barRenderer0.getSeriesToolTipGenerator((int) (byte) -1);
        double double6 = barRenderer0.getItemMargin();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("0,0,1,1", timeZone1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean5 = segmentedTimeline3.containsDomainValue(date4);
        segmentedTimeline3.addException((long) (short) 100);
        segmentedTimeline3.addException((long) 255);
        long long10 = segmentedTimeline3.getStartTime();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType11 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType11, 4);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType14 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType14, 4);
        int int17 = dateTickUnit16.getMultiple();
        org.jfree.chart.plot.PiePlot3D piePlot3D18 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D18.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = null;
        piePlot3D18.notifyListeners(plotChangeEvent22);
        java.awt.Shape shape24 = piePlot3D18.getLegendItemShape();
        boolean boolean25 = dateTickUnit16.equals((java.lang.Object) piePlot3D18);
        double double26 = dateTickUnit16.getSize();
        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
        java.util.Date date29 = dateTickUnit16.rollDate(date27);
        java.util.Date date30 = dateTickUnit13.rollDate(date27);
        boolean boolean31 = segmentedTimeline3.containsDomainValue(date27);
        dateAxis2.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline3);
        dateAxis2.setPositiveArrowVisible(true);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2208960000000L) + "'", long10 == (-2208960000000L));
        org.junit.Assert.assertNotNull(dateTickUnitType11);
        org.junit.Assert.assertNotNull(dateTickUnitType14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4000.0d + "'", double26 == 4000.0d);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot2.setAngleGridlinePaint((java.awt.Paint) color3);
        java.awt.Color color5 = color3.darker();
        int int6 = color5.getAlpha();
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        barRenderer0.setMaximumBarWidth((double) 1);
        int int10 = barRenderer0.getPassCount();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator11, false);
        java.awt.Paint paint14 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        barRenderer0.setBasePaint(paint14);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = xYAreaRenderer0.getToolTipGenerator(8, 2019, false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = null;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) ' ', (double) 0L, (double) 100L, 90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = chartRenderingInfo15.getChartArea();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D17);
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets13.createInsetRectangle(rectangle2D17);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        combinedRangeXYPlot21.setDomainAxisLocation((int) 'a', axisLocation23);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot21);
        boolean boolean26 = combinedRangeXYPlot21.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource30 = null;
        logAxis29.setStandardTickUnits(tickUnitSource30);
        logAxis29.setVisible(false);
        combinedRangeXYPlot21.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) logAxis29, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot37 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation39 = null;
        combinedRangeXYPlot37.setDomainAxisLocation((int) 'a', axisLocation39);
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot37);
        boolean boolean42 = combinedRangeXYPlot37.isDomainZeroBaselineVisible();
        java.util.Date date45 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date45);
        org.jfree.chart.entity.EntityCollection entityCollection47 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = new org.jfree.chart.ChartRenderingInfo(entityCollection47);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo48);
        boolean boolean50 = month46.equals((java.lang.Object) chartRenderingInfo48);
        long long51 = month46.getFirstMillisecond();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis53 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month46, (org.jfree.data.time.RegularTimePeriod) year52);
        java.lang.Class class54 = periodAxis53.getMinorTickTimePeriodClass();
        boolean boolean55 = periodAxis53.isMinorTickMarksVisible();
        combinedRangeXYPlot37.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) periodAxis53);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot57 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke58 = combinedRangeXYPlot57.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.Plot plot59 = combinedRangeXYPlot57.getRootPlot();
        org.jfree.chart.axis.LogAxis logAxis61 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource62 = null;
        logAxis61.setStandardTickUnits(tickUnitSource62);
        boolean boolean64 = logAxis61.isNegativeArrowVisible();
        logAxis61.pan((double) (short) 1);
        logAxis61.setTickMarksVisible(true);
        combinedRangeXYPlot57.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis61);
        boolean boolean70 = logAxis61.isAutoRange();
        java.util.TimeZone timeZone71 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection72 = new org.jfree.data.time.TimeSeriesCollection(timeZone71);
        boolean boolean74 = timeSeriesCollection72.equals((java.lang.Object) 255);
        try {
            xYAreaRenderer0.drawItem(graphics2D6, xYItemRendererState7, rectangle2D17, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot21, (org.jfree.chart.axis.ValueAxis) periodAxis53, (org.jfree.chart.axis.ValueAxis) logAxis61, (org.jfree.data.xy.XYDataset) timeSeriesCollection72, 3, (-3047828), false, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(xYToolTipGenerator5);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1559372400000L + "'", long51 == 1559372400000L);
        org.junit.Assert.assertNotNull(class54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(plot59);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        combinedRangeXYPlot4.setDomainAxisLocation((int) 'a', axisLocation6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer11.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke16 = barRenderer11.getItemOutlineStroke((int) '4', (int) (byte) 1, true);
        jFreeChart8.setBorderStroke(stroke16);
        barRenderer0.setSeriesStroke(0, stroke16);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = null;
        barRenderer0.setSeriesURLGenerator(12, categoryURLGenerator20, false);
        java.awt.Stroke stroke24 = barRenderer0.getSeriesOutlineStroke(12);
        barRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, true);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNull(legendTitle10);
        org.junit.Assert.assertNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(stroke24);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        textTitle9.setToolTipText("red");
        java.lang.String str12 = textTitle9.getID();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        textTitle9.setBackgroundPaint((java.awt.Paint) color13);
        java.lang.String str15 = textTitle9.getText();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0,0,1,1" + "'", str15.equals("0,0,1,1"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo4.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D6.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        piePlot3D6.notifyListeners(plotChangeEvent10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D5, (org.jfree.chart.plot.Plot) piePlot3D6, "");
        java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets2.createInsetRectangle(rectangle2D5);
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets2);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer16 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean17 = xYStepRenderer16.getDrawSeriesLineAsPath();
        xYStepRenderer16.setSeriesShapesVisible((int) (byte) 1, false);
        boolean boolean21 = legendTitle1.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesShapesVisible(0, (java.lang.Boolean) false);
        java.awt.Font font5 = xYStepRenderer0.getLegendTextFont(8);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        xYStepRenderer0.setSeriesStroke((int) (byte) 0, stroke7, true);
        boolean boolean11 = xYStepRenderer0.isSeriesItemLabelsVisible(15);
        java.awt.Font font13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        xYStepRenderer0.setSeriesItemLabelFont(255, font13);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesShapesVisible(0, (java.lang.Boolean) false);
        java.awt.Font font5 = xYStepRenderer0.getLegendTextFont(8);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        xYStepRenderer0.setSeriesStroke((int) (byte) 0, stroke7, true);
        xYStepRenderer0.setUseOutlinePaint(true);
        java.awt.Paint paint12 = xYStepRenderer0.getBaseItemLabelPaint();
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("0,0,1,1", font2, (org.jfree.chart.plot.Plot) polarPlot5, false);
        jFreeChart7.setTitle("red");
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int12 = color11.getGreen();
        java.awt.Color color13 = java.awt.Color.getColor("hi!", color11);
        jFreeChart7.setBorderPaint((java.awt.Paint) color13);
        org.jfree.chart.plot.Plot plot15 = jFreeChart7.getPlot();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(plot15);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.05d, "", false);
        org.jfree.chart.util.LogFormat logFormat8 = new org.jfree.chart.util.LogFormat(0.05d, "", false);
        java.lang.StringBuffer stringBuffer10 = null;
        java.text.FieldPosition fieldPosition11 = null;
        java.lang.StringBuffer stringBuffer12 = logFormat8.format((double) 1559372400000L, stringBuffer10, fieldPosition11);
        java.text.FieldPosition fieldPosition13 = null;
        java.lang.StringBuffer stringBuffer14 = logFormat3.format((double) 2019, stringBuffer12, fieldPosition13);
        java.lang.String str16 = logFormat3.format(900000L);
        java.text.ParsePosition parsePosition18 = null;
        java.lang.Object obj19 = logFormat3.parseObject("{0}: ({1}, {2})", parsePosition18);
        org.junit.Assert.assertNotNull(stringBuffer12);
        org.junit.Assert.assertNotNull(stringBuffer14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-4.58" + "'", str16.equals("-4.58"));
        org.junit.Assert.assertNull(obj19);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        java.lang.Comparable comparable1 = null;
        try {
            java.awt.Paint paint2 = paintMap0.getPaint(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean3 = xYStepRenderer0.getItemLineVisible((-1), 100);
        xYStepRenderer0.setSeriesShapesVisible(2019, (java.lang.Boolean) true);
        java.lang.Boolean boolean8 = xYStepRenderer0.getSeriesShapesFilled((int) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYStepRenderer0.getSeriesPositiveItemLabelPosition((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("series");
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.Object obj1 = null;
        boolean boolean2 = chartChangeEventType0.equals(obj1);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.util.Rotation rotation2 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer3.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer3.clearSeriesStrokes(false);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer3.setBaseLegendShape(shape9);
        boolean boolean11 = rotation2.equals((java.lang.Object) shape9);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint13 = xYAreaRenderer12.getBaseItemLabelPaint();
        boolean boolean14 = rotation2.equals((java.lang.Object) xYAreaRenderer12);
        java.lang.Boolean boolean16 = xYAreaRenderer12.getSeriesCreateEntities(6);
        java.awt.Paint paint17 = xYAreaRenderer12.getBasePaint();
        barRenderer0.setBaseFillPaint(paint17);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(rotation2);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        try {
            java.lang.Number number5 = xYSeriesCollection0.getEndX((int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean3 = xYStepRenderer0.getItemLineVisible((-1), 100);
        xYStepRenderer0.setSeriesLinesVisible((int) (short) 10, (java.lang.Boolean) true);
        try {
            xYStepRenderer0.setSeriesLinesVisible((-3047828), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("0,0,1,1", font2, (org.jfree.chart.plot.Plot) polarPlot5, false);
        polarPlot5.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = polarPlot5.getOrientation();
        java.awt.Paint paint11 = polarPlot5.getOutlinePaint();
        boolean boolean12 = polarPlot5.isAngleGridlinesVisible();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getRangeMinorGridlineStroke();
        boolean boolean10 = xYAreaRenderer0.hasListener((java.util.EventListener) combinedRangeXYPlot8);
        java.awt.Paint paint11 = combinedRangeXYPlot8.getBackgroundPaint();
        combinedRangeXYPlot8.clearRangeAxes();
        int int13 = combinedRangeXYPlot8.getRendererCount();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer14 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke16 = combinedRangeXYPlot15.getRangeMinorGridlineStroke();
        combinedRangeXYPlot15.clearAnnotations();
        combinedRangeXYPlot15.configureDomainAxes();
        xYAreaRenderer14.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot15);
        java.awt.Stroke stroke20 = xYAreaRenderer14.getBaseStroke();
        java.awt.Paint paint22 = xYAreaRenderer14.lookupSeriesOutlinePaint((-1));
        combinedRangeXYPlot8.setDomainGridlinePaint(paint22);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot1.getDataExtractOrder();
        java.awt.Shape shape3 = multiplePiePlot1.getLegendItemShape();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot1);
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(shape3);
    }
}

