import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 172800000L, (double) '4');
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedRangeXYPlot12.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        java.util.List list18 = combinedRangeXYPlot12.getAnnotations();
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = null;
        logAxis21.setStandardTickUnits(tickUnitSource22);
        boolean boolean24 = logAxis21.isNegativeArrowVisible();
        logAxis21.pan((double) (short) 1);
        combinedRangeXYPlot12.setDomainAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) logAxis21, false);
        int int29 = combinedRangeXYPlot12.getDatasetCount();
        boolean boolean30 = combinedRangeXYPlot12.isDomainPannable();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer1.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer1.clearSeriesStrokes(false);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer1.setBaseLegendShape(shape7);
        boolean boolean9 = rotation0.equals((java.lang.Object) shape7);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint11 = xYAreaRenderer10.getBaseItemLabelPaint();
        boolean boolean12 = rotation0.equals((java.lang.Object) xYAreaRenderer10);
        java.lang.Boolean boolean14 = xYAreaRenderer10.getSeriesCreateEntities(6);
        java.awt.Paint paint15 = xYAreaRenderer10.getBasePaint();
        java.awt.Shape shape16 = xYAreaRenderer10.getLegendArea();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = polarPlot1.getRenderer();
        java.awt.Font font3 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        polarPlot1.setAngleLabelFont(font3);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", font3);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo(entityCollection7);
        java.awt.geom.Rectangle2D rectangle2D9 = chartRenderingInfo8.getChartArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets6.createAdjustedRectangle(rectangle2D9, lengthAdjustmentType10, lengthAdjustmentType11);
        boolean boolean13 = textLine5.equals((java.lang.Object) rectangleInsets6);
        org.junit.Assert.assertNull(polarItemRenderer2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRangeZoomable();
        boolean boolean2 = polarPlot0.isRangeZoomable();
        polarPlot0.addCornerTextItem("{0}: ({1}, {2})");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean3 = xYStepRenderer0.getItemLineVisible((-1), 100);
        xYStepRenderer0.setSeriesLinesVisible((int) (short) 10, (java.lang.Boolean) true);
        java.awt.Shape shape8 = xYStepRenderer0.getLegendShape((int) (byte) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.clearRangeMarkers(0);
        java.awt.Stroke stroke13 = combinedRangeXYPlot10.getDomainGridlineStroke();
        xYStepRenderer0.setSeriesStroke(9, stroke13, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer5.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer5.clearSeriesStrokes(false);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer5.setBaseLegendShape(shape11);
        combinedRangeXYPlot0.setRenderer(15, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5, true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator16 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYAreaRenderer5.setSeriesToolTipGenerator((int) 'a', (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator16, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator16);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer0.setBase((double) (byte) 0);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint6 = xYAreaRenderer5.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYAreaRenderer5.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getRotationAnchor();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertNull(categoryToolTipGenerator2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNull(categoryURLGenerator10);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0, "HorizontalAlignment.CENTER", "Nearest");
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.chart.entity.EntityCollection entityCollection6 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo(entityCollection6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        boolean boolean9 = month5.equals((java.lang.Object) chartRenderingInfo7);
        long long10 = month5.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 0.025d);
        timeSeries3.add(timeSeriesDataItem12, true);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1559372400000L + "'", long10 == 1559372400000L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState1.updateCrosshairY(0.0d);
        crosshairState1.setDatasetIndex((-3047828));
        java.awt.Font font14 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color15 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("hi!", font14, (java.awt.Paint) color15);
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("0,0,1,1", font14, (org.jfree.chart.plot.Plot) polarPlot17, false);
        polarPlot17.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = polarPlot17.getOrientation();
        crosshairState1.updateCrosshairPoint((double) 15, (double) (short) 0, 11, 2019, 12.0d, (double) (short) 100, plotOrientation22);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(plotOrientation22);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        boolean boolean24 = legendItem15.isLineVisible();
        org.jfree.data.xy.XYSeries xYSeries27 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double28 = xYSeries27.getMinX();
        xYSeries27.add((double) 100.0f, 0.0d);
        boolean boolean32 = legendItem15.equals((java.lang.Object) xYSeries27);
        xYSeries27.add((double) (-2208960000000L), (java.lang.Number) 2019, false);
        int int38 = xYSeries27.indexOf((java.lang.Number) (-1));
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        xYSeries27.removePropertyChangeListener(propertyChangeListener39);
        org.jfree.chart.renderer.category.BarRenderer barRenderer41 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator43 = barRenderer41.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer41.setShadowYOffset((double) 100L);
        int int46 = barRenderer41.getRowCount();
        int int47 = barRenderer41.getRowCount();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator48 = null;
        barRenderer41.setBaseItemLabelGenerator(categoryItemLabelGenerator48, false);
        boolean boolean51 = xYSeries27.equals((java.lang.Object) false);
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        xYSeries27.removePropertyChangeListener(propertyChangeListener52);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNull(categoryToolTipGenerator43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        combinedRangeXYPlot7.setDomainAxisLocation((int) 'a', axisLocation9);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        boolean boolean12 = combinedRangeXYPlot7.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        logAxis14.setPositiveArrowVisible(false);
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        org.jfree.chart.entity.EntityCollection entityCollection19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo(entityCollection19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        boolean boolean22 = month18.equals((java.lang.Object) chartRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D23 = chartRenderingInfo20.getChartArea();
        xYAreaRenderer0.fillDomainGridBand(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis14, rectangle2D23, (double) '4', 100.0d);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        int int28 = combinedRangeXYPlot7.getRangeAxisIndex(valueAxis27);
        combinedRangeXYPlot7.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        logAxis1.setAxisLineVisible(true);
        boolean boolean4 = logAxis1.isNegativeArrowVisible();
        java.awt.Paint paint5 = logAxis1.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        combinedRangeXYPlot1.setDomainAxisLocation((int) 'a', axisLocation3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        boolean boolean6 = combinedRangeXYPlot1.isDomainZeroBaselineVisible();
        boolean boolean7 = combinedRangeXYPlot1.isRangeCrosshairLockedOnData();
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot1.getDataset(8);
        org.jfree.chart.entity.EntityCollection entityCollection10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo(entityCollection10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo11.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D13 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D13.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        piePlot3D13.notifyListeners(plotChangeEvent17);
        org.jfree.chart.entity.PlotEntity plotEntity20 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D12, (org.jfree.chart.plot.Plot) piePlot3D13, "");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke22 = combinedRangeXYPlot21.getRangeMinorGridlineStroke();
        combinedRangeXYPlot21.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection24 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = combinedRangeXYPlot21.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection24);
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D12, (org.jfree.chart.plot.Plot) combinedRangeXYPlot21, "");
        org.jfree.chart.axis.AxisSpace axisSpace28 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot21.setFixedDomainAxisSpace(axisSpace28);
        double double30 = axisSpace28.getBottom();
        axisSpace28.setTop(0.05d);
        combinedRangeXYPlot1.setFixedDomainAxisSpace(axisSpace28);
        boolean boolean34 = combinedRangeXYPlot1.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(xYItemRenderer25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.awt.geom.Rectangle2D rectangle2D2 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D3.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot3D3.notifyListeners(plotChangeEvent7);
        org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D2, (org.jfree.chart.plot.Plot) piePlot3D3, "");
        org.jfree.chart.LegendItemCollection legendItemCollection11 = piePlot3D3.getLegendItems();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = piePlot3D3.getLabelGenerator();
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator12);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("series");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis1.getTickUnit();
        double double3 = dateAxis1.getLowerBound();
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("HorizontalAlignment.CENTER");
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("0,0,1,1", timeZone1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        java.util.List list12 = logAxis7.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge11);
        java.awt.Color color13 = java.awt.Color.red;
        logAxis7.setTickMarkPaint((java.awt.Paint) color13);
        logAxis7.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape17 = logAxis7.getDownArrow();
        org.jfree.chart.entity.EntityCollection entityCollection18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo(entityCollection18);
        java.awt.geom.Rectangle2D rectangle2D20 = chartRenderingInfo19.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D21.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = null;
        piePlot3D21.notifyListeners(plotChangeEvent25);
        org.jfree.chart.entity.PlotEntity plotEntity28 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D20, (org.jfree.chart.plot.Plot) piePlot3D21, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity31 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis7, (java.awt.Shape) rectangle2D20, "", "");
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D20, (double) 900000L, (double) (byte) 1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot35 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke36 = combinedRangeXYPlot35.getRangeMinorGridlineStroke();
        combinedRangeXYPlot35.clearAnnotations();
        boolean boolean38 = combinedRangeXYPlot35.isDomainPannable();
        boolean boolean39 = combinedRangeXYPlot35.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = combinedRangeXYPlot35.getDomainAxisEdge();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke42 = combinedRangeXYPlot41.getRangeMinorGridlineStroke();
        combinedRangeXYPlot41.clearAnnotations();
        boolean boolean44 = combinedRangeXYPlot41.isDomainPannable();
        java.awt.Paint paint45 = combinedRangeXYPlot41.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.LogAxis logAxis47 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource48 = null;
        logAxis47.setStandardTickUnits(tickUnitSource48);
        boolean boolean50 = logAxis47.isNegativeArrowVisible();
        logAxis47.pan((double) (short) 1);
        java.lang.Object obj53 = logAxis47.clone();
        int int54 = combinedRangeXYPlot41.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis47);
        org.jfree.chart.entity.EntityCollection entityCollection57 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = new org.jfree.chart.ChartRenderingInfo(entityCollection57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo58);
        java.awt.geom.Rectangle2D rectangle2D60 = plotRenderingInfo59.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D61 = plotRenderingInfo59.getDataArea();
        combinedRangeXYPlot41.handleClick(10, 4, plotRenderingInfo59);
        try {
            org.jfree.chart.axis.AxisState axisState63 = dateAxis2.draw(graphics2D3, 0.0d, rectangle2D5, rectangle2D20, rectangleEdge40, plotRenderingInfo59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D61);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation2 = null;
        try {
            boolean boolean3 = combinedRangeXYPlot0.removeAnnotation(xYAnnotation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        boolean boolean4 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        logAxis6.setStandardTickUnits(tickUnitSource7);
        boolean boolean9 = logAxis6.isNegativeArrowVisible();
        logAxis6.pan((double) (short) 1);
        combinedRangeXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis6);
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = logAxis14.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        java.awt.Color color20 = java.awt.Color.red;
        logAxis14.setTickMarkPaint((java.awt.Paint) color20);
        logAxis14.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape24 = logAxis14.getDownArrow();
        org.jfree.chart.entity.EntityCollection entityCollection25 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = new org.jfree.chart.ChartRenderingInfo(entityCollection25);
        java.awt.geom.Rectangle2D rectangle2D27 = chartRenderingInfo26.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D28.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = null;
        piePlot3D28.notifyListeners(plotChangeEvent32);
        org.jfree.chart.entity.PlotEntity plotEntity35 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D27, (org.jfree.chart.plot.Plot) piePlot3D28, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity38 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis14, (java.awt.Shape) rectangle2D27, "", "");
        java.lang.String str39 = logAxis14.getLabel();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation43 = null;
        combinedRangeXYPlot41.setDomainAxisLocation((int) 'a', axisLocation43);
        org.jfree.chart.JFreeChart jFreeChart45 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot41);
        boolean boolean46 = combinedRangeXYPlot41.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.LogAxis logAxis49 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource50 = null;
        logAxis49.setStandardTickUnits(tickUnitSource50);
        logAxis49.setVisible(false);
        combinedRangeXYPlot41.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) logAxis49, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray56 = new org.jfree.chart.axis.ValueAxis[] { logAxis14, logAxis49 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray56);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = combinedRangeXYPlot0.getRenderer();
        combinedRangeXYPlot0.setDomainPannable(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(valueAxisArray56);
        org.junit.Assert.assertNull(xYItemRenderer58);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        boolean boolean24 = legendItem15.isLineVisible();
        org.jfree.data.xy.XYSeries xYSeries27 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double28 = xYSeries27.getMinX();
        xYSeries27.add((double) 100.0f, 0.0d);
        boolean boolean32 = legendItem15.equals((java.lang.Object) xYSeries27);
        xYSeries27.add((double) (-2208960000000L), (java.lang.Number) 2019, false);
        int int38 = xYSeries27.indexOf((java.lang.Number) (-1));
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        xYSeries27.removePropertyChangeListener(propertyChangeListener39);
        java.lang.Object obj41 = xYSeries27.clone();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(obj41);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double3 = xYSeries2.getMinX();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        xYSeries2.addPropertyChangeListener(propertyChangeListener4);
        int int6 = xYSeries2.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        xYSeries2.removePropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        org.jfree.chart.entity.EntityCollection entityCollection5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo(entityCollection5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo7.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D9 = plotRenderingInfo7.getDataArea();
        xYAreaRenderer0.setBaseShape((java.awt.Shape) rectangle2D9, false);
        java.awt.Font font15 = xYAreaRenderer0.getItemLabelFont(0, (-12566464), true);
        org.junit.Assert.assertNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        boolean boolean24 = legendItem15.isLineVisible();
        org.jfree.data.xy.XYSeries xYSeries27 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double28 = xYSeries27.getMinX();
        xYSeries27.add((double) 100.0f, 0.0d);
        boolean boolean32 = legendItem15.equals((java.lang.Object) xYSeries27);
        java.awt.Paint paint33 = legendItem15.getLabelPaint();
        org.jfree.chart.plot.PiePlot3D piePlot3D34 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D34.setCircular(true, true);
        piePlot3D34.setSimpleLabels(true);
        org.jfree.data.general.PieDataset pieDataset40 = null;
        piePlot3D34.setDataset(pieDataset40);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo(entityCollection43);
        java.awt.geom.Rectangle2D rectangle2D45 = chartRenderingInfo44.getChartArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType46 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets42.createAdjustedRectangle(rectangle2D45, lengthAdjustmentType46, lengthAdjustmentType47);
        piePlot3D34.setLabelPadding(rectangleInsets42);
        java.awt.Stroke stroke50 = piePlot3D34.getLabelOutlineStroke();
        legendItem15.setOutlineStroke(stroke50);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        piePlot3D0.markerChanged(markerChangeEvent6);
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        xYSeries10.setKey((java.lang.Comparable) year11);
        java.awt.Stroke stroke13 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) year11);
        long long14 = year11.getFirstMillisecond();
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        boolean boolean24 = legendItem15.isLineVisible();
        org.jfree.data.xy.XYSeries xYSeries27 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double28 = xYSeries27.getMinX();
        xYSeries27.add((double) 100.0f, 0.0d);
        boolean boolean32 = legendItem15.equals((java.lang.Object) xYSeries27);
        org.jfree.data.xy.XYDataItem xYDataItem35 = xYSeries27.addOrUpdate((java.lang.Number) (-1), (java.lang.Number) 12);
        xYSeries27.add((java.lang.Number) 0L, (java.lang.Number) 3);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(xYDataItem35);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getDomainUpperBound(false);
        java.lang.Object obj5 = xYSeriesCollection0.clone();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate6 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        try {
            int[] intArray10 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (int) (byte) -1, 0.05d, (double) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate4);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer0.setBase((double) (byte) 0);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = barRenderer0.getGradientPaintTransformer();
        org.junit.Assert.assertNull(categoryToolTipGenerator2);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 2147483647, (double) 10L);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        logAxis6.setStandardTickUnits(tickUnitSource7);
        boolean boolean9 = logAxis6.isNegativeArrowVisible();
        logAxis6.pan((double) (short) 1);
        java.lang.Object obj12 = logAxis6.clone();
        logAxis6.setLabelURL("");
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 8);
        java.lang.String str17 = valueMarker16.getLabel();
        org.jfree.chart.entity.EntityCollection entityCollection18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo(entityCollection18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo19.getChartArea();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D21);
        barRenderer3D2.drawRangeMarker(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) logAxis6, (org.jfree.chart.plot.Marker) valueMarker16, rectangle2D21);
        org.jfree.chart.plot.PiePlot3D piePlot3D24 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D24.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent28 = null;
        piePlot3D24.notifyListeners(plotChangeEvent28);
        org.jfree.data.general.DatasetGroup datasetGroup30 = piePlot3D24.getDatasetGroup();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle31 = piePlot3D24.getLabelLinkStyle();
        piePlot3D24.setCircular(false, false);
        piePlot3D24.clearSectionOutlinePaints(false);
        double double38 = piePlot3D24.getExplodePercent((java.lang.Comparable) "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.awt.Paint paint39 = piePlot3D24.getBaseSectionOutlinePaint();
        java.awt.Color color40 = java.awt.Color.YELLOW;
        java.awt.Color color41 = color40.darker();
        piePlot3D24.setLabelOutlinePaint((java.awt.Paint) color41);
        valueMarker16.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot3D24);
        double double45 = piePlot3D24.getExplodePercent((java.lang.Comparable) "[size=1]");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(datasetGroup30);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle31);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("0,0,1,1", timeZone1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean5 = segmentedTimeline3.containsDomainValue(date4);
        segmentedTimeline3.addException((long) (short) 100);
        segmentedTimeline3.addException((long) 255);
        long long10 = segmentedTimeline3.getStartTime();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType11 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType11, 4);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType14 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType14, 4);
        int int17 = dateTickUnit16.getMultiple();
        org.jfree.chart.plot.PiePlot3D piePlot3D18 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D18.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = null;
        piePlot3D18.notifyListeners(plotChangeEvent22);
        java.awt.Shape shape24 = piePlot3D18.getLegendItemShape();
        boolean boolean25 = dateTickUnit16.equals((java.lang.Object) piePlot3D18);
        double double26 = dateTickUnit16.getSize();
        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
        java.util.Date date29 = dateTickUnit16.rollDate(date27);
        java.util.Date date30 = dateTickUnit13.rollDate(date27);
        boolean boolean31 = segmentedTimeline3.containsDomainValue(date27);
        dateAxis2.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline3);
        boolean boolean33 = segmentedTimeline3.getAdjustForDaylightSaving();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2208960000000L) + "'", long10 == (-2208960000000L));
        org.junit.Assert.assertNotNull(dateTickUnitType11);
        org.junit.Assert.assertNotNull(dateTickUnitType14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4000.0d + "'", double26 == 4000.0d);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer(6.0d);
        java.awt.Paint paint6 = xYBarRenderer5.getBaseItemLabelPaint();
        combinedRangeXYPlot0.setRangeTickBandPaint(paint6);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        logAxis1.setStandardTickUnits(tickUnitSource2);
        boolean boolean4 = logAxis1.isNegativeArrowVisible();
        logAxis1.pan((double) (short) 1);
        java.lang.String str7 = logAxis1.getLabelURL();
        java.awt.Font font8 = logAxis1.getLabelFont();
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        org.jfree.chart.entity.EntityCollection entityCollection12 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo(entityCollection12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        boolean boolean15 = month11.equals((java.lang.Object) chartRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo13.getChartArea();
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "", "Combined Range XYPlot");
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D16, rectangleEdge20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("red");
        java.awt.Paint paint25 = categoryAxis23.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke30 = combinedRangeXYPlot29.getRangeMinorGridlineStroke();
        combinedRangeXYPlot29.clearAnnotations();
        boolean boolean32 = combinedRangeXYPlot29.isDomainPannable();
        boolean boolean33 = combinedRangeXYPlot29.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = combinedRangeXYPlot29.getDomainAxisEdge();
        org.jfree.chart.axis.AxisState axisState35 = null;
        categoryAxis23.drawTickMarks(graphics2D26, (double) (-1.0f), rectangle2D28, rectangleEdge34, axisState35);
        double double37 = logAxis1.exponentLengthToJava2D((double) (-1.0f), rectangle2D16, rectangleEdge34);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getDomainUpperBound(false);
        java.lang.Object obj5 = xYSeriesCollection0.clone();
        try {
            double double8 = xYSeriesCollection0.getStartYValue((int) (byte) 10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Paint paint16 = legendItem15.getFillPaint();
        legendItem15.setSeriesKey((java.lang.Comparable) 10.0f);
        java.awt.Shape shape19 = legendItem15.getShape();
        boolean boolean20 = legendItem15.isShapeFilled();
        java.lang.Comparable comparable21 = legendItem15.getSeriesKey();
        java.lang.String str22 = legendItem15.getURLText();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 10.0f + "'", comparable21.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        int int5 = xYSeriesCollection3.indexOf((java.lang.Comparable) '#');
        double double7 = xYSeriesCollection3.getDomainUpperBound(false);
        xYSeries2.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection3);
        org.jfree.chart.ui.ProjectInfo projectInfo9 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline10 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean12 = segmentedTimeline10.containsDomainValue(date11);
        java.util.List list13 = segmentedTimeline10.getExceptionSegments();
        projectInfo9.setContributors(list13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, list13, false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(projectInfo9);
        org.junit.Assert.assertNotNull(segmentedTimeline10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot3D0.getDatasetGroup();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = piePlot3D0.getLabelLinkStyle();
        piePlot3D0.setCircular(false, false);
        piePlot3D0.clearSectionOutlinePaints(false);
        double double14 = piePlot3D0.getExplodePercent((java.lang.Comparable) "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.awt.Paint paint15 = piePlot3D0.getBaseSectionOutlinePaint();
        piePlot3D0.setBackgroundAlpha((float) 11);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint2 = barRenderer0.getShadowPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = barRenderer0.getSeriesToolTipGenerator((int) (short) 100);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint6 = xYAreaRenderer5.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYAreaRenderer5.getBasePositiveItemLabelPosition();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition7);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer9.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer9.clearSeriesStrokes(false);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        combinedRangeXYPlot16.setDomainAxisLocation((int) 'a', axisLocation18);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot16);
        boolean boolean21 = combinedRangeXYPlot16.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        logAxis23.setPositiveArrowVisible(false);
        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
        org.jfree.chart.entity.EntityCollection entityCollection28 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = new org.jfree.chart.ChartRenderingInfo(entityCollection28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo29);
        boolean boolean31 = month27.equals((java.lang.Object) chartRenderingInfo29);
        java.awt.geom.Rectangle2D rectangle2D32 = chartRenderingInfo29.getChartArea();
        xYAreaRenderer9.fillDomainGridBand(graphics2D14, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot16, (org.jfree.chart.axis.ValueAxis) logAxis23, rectangle2D32, (double) '4', 100.0d);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        int int37 = combinedRangeXYPlot16.getRangeAxisIndex(valueAxis36);
        java.awt.Stroke stroke38 = combinedRangeXYPlot16.getDomainGridlineStroke();
        barRenderer0.setBaseStroke(stroke38);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.junit.Assert.assertNull(xYItemRenderer3);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange2);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint1.toRangeWidth((org.jfree.data.Range) dateRange3);
        boolean boolean6 = dateRange3.contains(3.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str1.equals("GradientPaintTransformType.CENTER_VERTICAL"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "hi!", "red", "red");
        projectInfo7.setLicenceText("SerialDate.weekInMonthToString(): invalid code.");
        projectInfo7.setLicenceName("[size=1]");
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.awt.Color color3 = java.awt.Color.getHSBColor(10.0f, 100.0f, (float) 1577865599999L);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.lang.String str2 = waferMapPlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "WMAP_Plot" + "'", str2.equals("WMAP_Plot"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean2 = timePeriodAnchor0.equals((java.lang.Object) xYAreaRenderer1);
        boolean boolean4 = timePeriodAnchor0.equals((java.lang.Object) 10);
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("DateTickUnitType.SECOND");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: DateTickUnitType.SECOND" + "'", str3.equals("org.jfree.data.general.SeriesException: DateTickUnitType.SECOND"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedRangeXYPlot12.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.chart.axis.LogAxis logAxis20 = new org.jfree.chart.axis.LogAxis("");
        logAxis20.setAutoRangeMinimumSize(100.0d, false);
        java.lang.String str24 = logAxis20.getLabelURL();
        combinedRangeXYPlot12.setRangeAxis((org.jfree.chart.axis.ValueAxis) logAxis20);
        logAxis20.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator1 = new org.jfree.chart.urls.StandardXYURLGenerator("WMAP_Plot");
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer(6.0d);
        xYBarRenderer1.setShadowXOffset(0.05d);
        java.lang.Object obj4 = xYBarRenderer1.clone();
        boolean boolean5 = xYBarRenderer1.getDataBoundsIncludesVisibleSeriesOnly();
        double double6 = xYBarRenderer1.getBase();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "hi!", "red", "red");
        projectInfo7.setLicenceText("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str10 = projectInfo7.getLicenceName();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "red" + "'", str10.equals("red"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        combinedRangeXYPlot0.plotChanged(plotChangeEvent5);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(xYItemRenderer4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Paint paint6 = xYAreaRenderer0.getSeriesPaint(15);
        boolean boolean8 = xYAreaRenderer0.isSeriesItemLabelsVisible(0);
        xYAreaRenderer0.setItemLabelAnchorOffset((double) 60000L);
        boolean boolean11 = xYAreaRenderer0.getPlotShapes();
        xYAreaRenderer0.setSeriesItemLabelsVisible(15, (java.lang.Boolean) false, false);
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 97, (double) ' ');
        size2D2.height = 2692525037755L;
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        int int5 = xYSeriesCollection3.indexOf((java.lang.Comparable) '#');
        double double7 = xYSeriesCollection3.getDomainUpperBound(false);
        xYSeries2.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection3);
        org.jfree.data.xy.XYSeries xYSeries11 = xYSeries2.createCopy((int) (short) 1, 255);
        xYSeries2.add((double) (short) -1, (java.lang.Number) (byte) -1, true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYSeries11);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer0.setBase((double) (byte) 0);
        barRenderer0.setShadowYOffset(4000.0d);
        barRenderer0.setItemMargin((double) 0L);
        org.junit.Assert.assertNull(categoryToolTipGenerator2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.5f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        long long3 = year1.getLastMillisecond();
        long long4 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.chart.entity.EntityCollection entityCollection10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo(entityCollection10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        boolean boolean13 = month9.equals((java.lang.Object) chartRenderingInfo11);
        long long14 = month9.getFirstMillisecond();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis16 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) year15);
        boolean boolean17 = periodAxis16.isMinorTickMarksVisible();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = periodAxis16.getFirst();
        boolean boolean19 = periodAxis16.isMinorTickMarksVisible();
        java.util.Locale locale20 = periodAxis16.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone6, locale20);
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo27);
        boolean boolean29 = month25.equals((java.lang.Object) chartRenderingInfo27);
        long long30 = month25.getFirstMillisecond();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis32 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month25, (org.jfree.data.time.RegularTimePeriod) year31);
        boolean boolean33 = periodAxis32.isMinorTickMarksVisible();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = periodAxis32.getFirst();
        boolean boolean35 = periodAxis32.isMinorTickMarksVisible();
        java.util.Locale locale36 = periodAxis32.getLocale();
        org.jfree.chart.axis.TickUnitSource tickUnitSource37 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone22, locale36);
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis38 = new org.jfree.chart.axis.PeriodAxis("0,0,1,1", (org.jfree.data.time.RegularTimePeriod) year1, regularTimePeriod5, timeZone6, locale36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1559372400000L + "'", long14 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(locale20);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1559372400000L + "'", long30 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(locale36);
        org.junit.Assert.assertNotNull(tickUnitSource37);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 2147483647;
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        int int4 = combinedRangeXYPlot0.getDatasetCount();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        combinedRangeXYPlot0.setRangeAxis(11, valueAxis6, true);
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke12 = combinedRangeXYPlot11.getRangeMinorGridlineStroke();
        combinedRangeXYPlot11.clearAnnotations();
        java.awt.Color color14 = java.awt.Color.red;
        boolean boolean16 = color14.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot11.setRangeCrosshairPaint((java.awt.Paint) color14);
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection19 = combinedRangeXYPlot11.getDomainMarkers(layer18);
        boolean boolean20 = combinedRangeXYPlot0.removeDomainMarker(0, marker10, layer18);
        org.junit.Assert.assertNull(xYItemRenderer3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer0.setBase((double) (byte) 0);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((double) ' ', (double) 0L, (double) 100L, 90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder9.getInsets();
        boolean boolean11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) barRenderer0, (java.lang.Object) rectangleInsets10);
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot12.setAngleGridlinePaint((java.awt.Paint) color13);
        java.awt.Color color15 = color13.darker();
        barRenderer0.setBasePaint((java.awt.Paint) color15);
        boolean boolean17 = barRenderer0.isDrawBarOutline();
        java.awt.Shape shape18 = null;
        barRenderer0.setBaseLegendShape(shape18);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = barRenderer0.getSeriesItemLabelGenerator(3);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer22 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint23 = xYAreaRenderer22.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = xYAreaRenderer22.getBasePositiveItemLabelPosition();
        java.lang.Boolean boolean26 = xYAreaRenderer22.getSeriesVisibleInLegend((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer27 = xYAreaRenderer22.getGradientTransformer();
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer27);
        org.junit.Assert.assertNull(categoryToolTipGenerator2);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(gradientPaintTransformer27);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        piePlot3D0.setSimpleLabels(true);
        piePlot3D0.clearSectionOutlinePaints(true);
        double double8 = piePlot3D0.getLabelLinkMargin();
        piePlot3D0.setDarkerSides(false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        java.lang.String str6 = piePlot3D0.getPlotType();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pie 3D Plot" + "'", str6.equals("Pie 3D Plot"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer(6.0d);
        xYBarRenderer1.setShadowXOffset(0.05d);
        java.lang.Object obj4 = xYBarRenderer1.clone();
        boolean boolean5 = xYBarRenderer1.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.LegendItem legendItem8 = xYBarRenderer1.getLegendItem((int) (short) 0, 9);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(legendItem8);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection24 = new org.jfree.data.xy.XYSeriesCollection();
        int int26 = xYSeriesCollection24.indexOf((java.lang.Comparable) '#');
        double double28 = xYSeriesCollection24.getDomainUpperBound(false);
        double double29 = xYSeriesCollection24.getIntervalPositionFactor();
        double double30 = xYSeriesCollection24.getIntervalPositionFactor();
        int int31 = xYSeriesCollection24.getSeriesCount();
        org.jfree.data.Range range33 = xYSeriesCollection24.getRangeBounds(true);
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection24);
        java.lang.String str35 = legendItem15.getToolTipText();
        legendItem15.setDescription("GradientPaintTransformType.CENTER_VERTICAL");
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.5d + "'", double29 == 0.5d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.5d + "'", double30 == 0.5d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot1.getDataExtractOrder();
        java.lang.Object obj3 = multiplePiePlot1.clone();
        org.jfree.chart.util.Rotation rotation4 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer5.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer5.clearSeriesStrokes(false);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer5.setBaseLegendShape(shape11);
        boolean boolean13 = rotation4.equals((java.lang.Object) shape11);
        multiplePiePlot1.setLegendItemShape(shape11);
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rotation4);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        boolean boolean4 = defaultXYDataset2.equals((java.lang.Object) (byte) 100);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        xYSeries8.setKey((java.lang.Comparable) year9);
        double[][] doubleArray11 = xYSeries8.toArray();
        defaultXYDataset2.addSeries((java.lang.Comparable) (byte) 100, doubleArray11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray11);
        org.jfree.data.general.PieDataset pieDataset15 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset13, (java.lang.Comparable) Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(pieDataset15);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("0,0,1,1", font2, (org.jfree.chart.plot.Plot) polarPlot5, false);
        jFreeChart7.setTitle("red");
        int int10 = jFreeChart7.getBackgroundImageAlignment();
        java.awt.Stroke stroke11 = jFreeChart7.getBorderStroke();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getDomainUpperBound(false);
        double double5 = xYSeriesCollection0.getIntervalPositionFactor();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate6 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        double double8 = intervalXYDelegate6.getDomainUpperBound(false);
        java.text.NumberFormat numberFormat10 = java.text.NumberFormat.getNumberInstance();
        java.text.NumberFormat numberFormat11 = java.text.NumberFormat.getNumberInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}: ({1}, {2})", numberFormat10, numberFormat11);
        numberFormat10.setMaximumFractionDigits((int) (short) -1);
        int int15 = numberFormat10.getMinimumFractionDigits();
        boolean boolean16 = intervalXYDelegate6.equals((java.lang.Object) int15);
        java.lang.Object obj17 = intervalXYDelegate6.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberFormat10);
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        polarPlot0.setRadiusGridlinePaint((java.awt.Paint) color1);
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = logAxis4.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        java.awt.Color color10 = java.awt.Color.red;
        logAxis4.setTickMarkPaint((java.awt.Paint) color10);
        logAxis4.setMinorTickMarkInsideLength((float) (short) -1);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis4);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        combinedRangeXYPlot16.setDomainAxisLocation((int) 'a', axisLocation18);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot16);
        boolean boolean21 = combinedRangeXYPlot16.isDomainZeroBaselineVisible();
        combinedRangeXYPlot16.setDomainPannable(false);
        org.jfree.data.xy.XYDataset xYDataset25 = combinedRangeXYPlot16.getDataset((int) '#');
        combinedDomainXYPlot14.remove((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot16);
        java.util.List list27 = combinedDomainXYPlot14.getSubplots();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 8);
        java.awt.Stroke stroke31 = null;
        valueMarker30.setOutlineStroke(stroke31);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker30);
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.axis.AxisState axisState37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        java.util.List list40 = logAxis35.refreshTicks(graphics2D36, axisState37, rectangle2D38, rectangleEdge39);
        java.awt.Color color41 = java.awt.Color.red;
        logAxis35.setTickMarkPaint((java.awt.Paint) color41);
        logAxis35.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis35.centerRange((double) 0L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot47 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis35);
        java.lang.String str48 = combinedRangeXYPlot47.getPlotType();
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker((double) 8);
        java.lang.String str52 = valueMarker51.getLabel();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot53 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke54 = combinedRangeXYPlot53.getRangeMinorGridlineStroke();
        combinedRangeXYPlot53.clearAnnotations();
        java.awt.Color color56 = java.awt.Color.red;
        boolean boolean58 = color56.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot53.setRangeCrosshairPaint((java.awt.Paint) color56);
        org.jfree.chart.util.Layer layer60 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection61 = combinedRangeXYPlot53.getDomainMarkers(layer60);
        java.lang.Object obj62 = null;
        boolean boolean63 = layer60.equals(obj62);
        boolean boolean64 = combinedRangeXYPlot47.removeRangeMarker(12, (org.jfree.chart.plot.Marker) valueMarker51, layer60);
        combinedDomainXYPlot14.addRangeMarker(2147483647, (org.jfree.chart.plot.Marker) valueMarker30, layer60, false);
        polarPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot14);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(xYDataset25);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Combined Range XYPlot" + "'", str48.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(layer60);
        org.junit.Assert.assertNull(collection61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) false);
        java.lang.String str2 = rendererChangeEvent1.toString();
        java.lang.Object obj3 = rendererChangeEvent1.getRenderer();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.chart.event.RendererChangeEvent[source=false]" + "'", str2.equals("org.jfree.chart.event.RendererChangeEvent[source=false]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + false + "'", obj3.equals(false));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator3 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "{0}: ({1}, {2})");
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = polarPlot4.getRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke7 = combinedRangeXYPlot6.getRangeMinorGridlineStroke();
        combinedRangeXYPlot6.clearAnnotations();
        java.awt.Color color9 = java.awt.Color.red;
        boolean boolean11 = color9.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot6.setRangeCrosshairPaint((java.awt.Paint) color9);
        polarPlot4.setAngleGridlinePaint((java.awt.Paint) color9);
        java.awt.Color color14 = java.awt.Color.gray;
        polarPlot4.setAngleLabelPaint((java.awt.Paint) color14);
        boolean boolean16 = standardXYURLGenerator3.equals((java.lang.Object) polarPlot4);
        polarPlot4.setAngleLabelsVisible(true);
        org.junit.Assert.assertNull(polarItemRenderer5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        java.lang.String str4 = piePlot3D0.getPlotType();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        java.util.List list11 = logAxis6.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
        java.awt.Color color12 = java.awt.Color.red;
        logAxis6.setTickMarkPaint((java.awt.Paint) color12);
        java.lang.String str14 = org.jfree.chart.util.PaintUtilities.colorToString(color12);
        piePlot3D0.setLabelOutlinePaint((java.awt.Paint) color12);
        piePlot3D0.clearSectionPaints(false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pie 3D Plot" + "'", str4.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "red" + "'", str14.equals("red"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("red");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getRangeMinorGridlineStroke();
        combinedRangeXYPlot7.clearAnnotations();
        boolean boolean10 = combinedRangeXYPlot7.isDomainPannable();
        boolean boolean11 = combinedRangeXYPlot7.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = combinedRangeXYPlot7.getDomainAxisEdge();
        org.jfree.chart.axis.AxisState axisState13 = null;
        categoryAxis1.drawTickMarks(graphics2D4, (double) (-1.0f), rectangle2D6, rectangleEdge12, axisState13);
        boolean boolean15 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge12);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge12);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = piePlot3D0.getLabelDistributor();
        piePlot3D0.setForegroundAlpha((float) (short) 0);
        java.awt.Paint paint9 = piePlot3D0.getShadowPaint();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        logAxis1.setStandardTickUnits(tickUnitSource2);
        boolean boolean4 = logAxis1.isNegativeArrowVisible();
        logAxis1.pan((double) (short) 1);
        java.lang.Object obj7 = logAxis1.clone();
        org.jfree.chart.event.AxisChangeListener axisChangeListener8 = null;
        logAxis1.removeChangeListener(axisChangeListener8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo(entityCollection11);
        java.awt.geom.Rectangle2D rectangle2D13 = chartRenderingInfo12.getChartArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets10.createAdjustedRectangle(rectangle2D13, lengthAdjustmentType14, lengthAdjustmentType15);
        logAxis1.setLabelInsets(rectangleInsets10, true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str21 = numberTickUnit19.valueToString((double) 8);
        logAxis1.setTickUnit(numberTickUnit19);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(numberTickUnit19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "8" + "'", str21.equals("8"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator3 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "{0}: ({1}, {2})");
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = polarPlot4.getRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke7 = combinedRangeXYPlot6.getRangeMinorGridlineStroke();
        combinedRangeXYPlot6.clearAnnotations();
        java.awt.Color color9 = java.awt.Color.red;
        boolean boolean11 = color9.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot6.setRangeCrosshairPaint((java.awt.Paint) color9);
        polarPlot4.setAngleGridlinePaint((java.awt.Paint) color9);
        java.awt.Color color14 = java.awt.Color.gray;
        polarPlot4.setAngleLabelPaint((java.awt.Paint) color14);
        boolean boolean16 = standardXYURLGenerator3.equals((java.lang.Object) polarPlot4);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = polarPlot4.getLegendItems();
        org.junit.Assert.assertNull(polarItemRenderer5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(legendItemCollection17);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint2 = barRenderer0.getShadowPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(itemLabelPosition3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        java.lang.Object obj1 = standardPieToolTipGenerator0.clone();
        java.lang.Object obj2 = standardPieToolTipGenerator0.clone();
        java.lang.String str3 = standardPieToolTipGenerator0.getLabelFormat();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}: ({1}, {2})" + "'", str3.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer1 = polarPlot0.getRenderer();
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo6.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        java.util.List list15 = logAxis10.refreshTicks(graphics2D11, axisState12, rectangle2D13, rectangleEdge14);
        java.awt.Color color16 = java.awt.Color.red;
        logAxis10.setTickMarkPaint((java.awt.Paint) color16);
        logAxis10.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape20 = logAxis10.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke22 = combinedRangeXYPlot21.getRangeMinorGridlineStroke();
        combinedRangeXYPlot21.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection24 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = combinedRangeXYPlot21.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection24);
        org.jfree.chart.entity.PlotEntity plotEntity26 = new org.jfree.chart.entity.PlotEntity(shape20, (org.jfree.chart.plot.Plot) combinedRangeXYPlot21);
        combinedRangeXYPlot21.clearAnnotations();
        java.awt.geom.Point2D point2D28 = combinedRangeXYPlot21.getQuadrantOrigin();
        polarPlot0.zoomDomainAxes((double) 1560668399999L, (double) (byte) -1, plotRenderingInfo6, point2D28);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo6);
        org.jfree.data.xy.XYSeries xYSeries33 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection34 = new org.jfree.data.xy.XYSeriesCollection();
        int int36 = xYSeriesCollection34.indexOf((java.lang.Comparable) '#');
        double double38 = xYSeriesCollection34.getDomainUpperBound(false);
        xYSeries33.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection34);
        state30.endSeriesPass((org.jfree.data.xy.XYDataset) xYSeriesCollection34, 97, 2147483647, 10, 6, 12);
        org.junit.Assert.assertNull(polarItemRenderer1);
        org.junit.Assert.assertNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(xYItemRenderer25);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        boolean boolean4 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        logAxis6.setStandardTickUnits(tickUnitSource7);
        boolean boolean9 = logAxis6.isNegativeArrowVisible();
        logAxis6.pan((double) (short) 1);
        combinedRangeXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis6);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        combinedRangeXYPlot0.plotChanged(plotChangeEvent13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace15);
        int int17 = combinedRangeXYPlot0.getDomainAxisCount();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot1.getDataExtractOrder();
        java.awt.Shape shape3 = multiplePiePlot1.getLegendItemShape();
        java.awt.Font font7 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color8 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("hi!", font7, (java.awt.Paint) color8);
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("0,0,1,1", font7, (org.jfree.chart.plot.Plot) polarPlot10, false);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("0,0,1,1", font7);
        textTitle13.setToolTipText("red");
        java.lang.String str16 = textTitle13.getID();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        textTitle13.setBackgroundPaint((java.awt.Paint) color17);
        textTitle13.setText("item");
        org.jfree.chart.entity.TitleEntity titleEntity21 = new org.jfree.chart.entity.TitleEntity(shape3, (org.jfree.chart.title.Title) textTitle13);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = textTitle13.getTextAlignment();
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "hi!", "red", "red");
        java.awt.Image image8 = projectInfo7.getLogo();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1L));
        boolean boolean11 = projectInfo7.equals((java.lang.Object) (-1L));
        projectInfo7.setName("TimePeriodAnchor.MIDDLE");
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("red");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.setMinorTickMarkOutsideLength((float) 15);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.entity.EntityCollection entityCollection7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo(entityCollection7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Rectangle2D rectangle2D10 = chartRenderingInfo8.getChartArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        org.jfree.chart.axis.AxisState axisState12 = new org.jfree.chart.axis.AxisState();
        axisState12.cursorDown((double) 12);
        categoryAxis1.drawTickMarks(graphics2D5, 10.0d, rectangle2D10, rectangleEdge11, axisState12);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis1.getLabelInsets();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("0,0,1,1", font2, (org.jfree.chart.plot.Plot) polarPlot5, false);
        polarPlot5.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = polarPlot5.getOrientation();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = polarPlot13.getRenderer();
        org.jfree.chart.entity.EntityCollection entityCollection17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = new org.jfree.chart.ChartRenderingInfo(entityCollection17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo19.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D21 = plotRenderingInfo19.getDataArea();
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.AxisState axisState25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        java.util.List list28 = logAxis23.refreshTicks(graphics2D24, axisState25, rectangle2D26, rectangleEdge27);
        java.awt.Color color29 = java.awt.Color.red;
        logAxis23.setTickMarkPaint((java.awt.Paint) color29);
        logAxis23.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape33 = logAxis23.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot34 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke35 = combinedRangeXYPlot34.getRangeMinorGridlineStroke();
        combinedRangeXYPlot34.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection37 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = combinedRangeXYPlot34.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection37);
        org.jfree.chart.entity.PlotEntity plotEntity39 = new org.jfree.chart.entity.PlotEntity(shape33, (org.jfree.chart.plot.Plot) combinedRangeXYPlot34);
        combinedRangeXYPlot34.clearAnnotations();
        java.awt.geom.Point2D point2D41 = combinedRangeXYPlot34.getQuadrantOrigin();
        polarPlot13.zoomDomainAxes((double) 1560668399999L, (double) (byte) -1, plotRenderingInfo19, point2D41);
        org.jfree.chart.plot.PlotState plotState43 = null;
        org.jfree.chart.entity.EntityCollection entityCollection44 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo45 = new org.jfree.chart.ChartRenderingInfo(entityCollection44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo45);
        java.lang.Object obj47 = plotRenderingInfo46.clone();
        try {
            polarPlot5.draw(graphics2D11, rectangle2D12, point2D41, plotState43, plotRenderingInfo46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNull(polarItemRenderer14);
        org.junit.Assert.assertNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNull(xYItemRenderer38);
        org.junit.Assert.assertNotNull(point2D41);
        org.junit.Assert.assertNotNull(obj47);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getDomainUpperBound(false);
        double double5 = xYSeriesCollection0.getIntervalPositionFactor();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate6 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        intervalXYDelegate6.setAutoWidth(false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer(6.0d);
        java.awt.Paint paint2 = xYBarRenderer1.getBaseItemLabelPaint();
        xYBarRenderer1.setBaseItemLabelsVisible(false, false);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = null;
        logAxis2.setStandardTickUnits(tickUnitSource3);
        boolean boolean5 = logAxis2.isNegativeArrowVisible();
        logAxis2.pan((double) (short) 1);
        java.lang.String str8 = logAxis2.getLabelURL();
        java.awt.Font font9 = logAxis2.getLabelFont();
        java.awt.Font font11 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("hi!", font11, (java.awt.Paint) color12);
        org.jfree.chart.text.TextFragment textFragment14 = textLine13.getLastTextFragment();
        java.awt.Paint paint15 = textFragment14.getPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer18 = null;
        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint15, (float) 255, (int) (byte) -1, textMeasurer18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.lang.String str24 = textBlockAnchor23.toString();
        java.awt.Shape shape28 = textBlock19.calculateBounds(graphics2D20, (float) 'a', (float) (short) 10, textBlockAnchor23, (float) 255, 1.0f, (double) 6);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor32 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.awt.Shape shape36 = textBlock19.calculateBounds(graphics2D29, (float) (-1L), (float) (short) 100, textBlockAnchor32, (float) 1, (float) (short) 10, (double) 86400000L);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("red");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor39 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        double double44 = categoryAxis38.getCategoryJava2DCoordinate(categoryAnchor39, 1, 8, rectangle2D42, rectangleEdge43);
        categoryAxis38.setLowerMargin((double) 10L);
        float float47 = categoryAxis38.getMaximumCategoryLabelWidthRatio();
        boolean boolean48 = textBlockAnchor32.equals((java.lang.Object) float47);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textFragment14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textBlock19);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TextBlockAnchor.CENTER_RIGHT" + "'", str24.equals("TextBlockAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(textBlockAnchor32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot1.clearRangeMarkers(0);
        boolean boolean4 = combinedRangeXYPlot1.isNotify();
        org.jfree.chart.axis.ValueAxis valueAxis6 = combinedRangeXYPlot1.getDomainAxis(2);
        boolean boolean7 = verticalAlignment0.equals((java.lang.Object) combinedRangeXYPlot1);
        java.lang.String str8 = verticalAlignment0.toString();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer9.getPositiveItemLabelPositionFallback();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        int int15 = color14.getAlpha();
        barRenderer9.setBaseItemLabelPaint((java.awt.Paint) color14);
        barRenderer9.setMaximumBarWidth((double) 1);
        int int19 = barRenderer9.getPassCount();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = null;
        barRenderer9.setBaseItemLabelGenerator(categoryItemLabelGenerator20, true);
        boolean boolean23 = verticalAlignment0.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "VerticalAlignment.CENTER" + "'", str8.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getLegendItemGraphicPadding();
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = logAxis4.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        java.awt.Color color10 = java.awt.Color.red;
        logAxis4.setTickMarkPaint((java.awt.Paint) color10);
        java.lang.String str12 = org.jfree.chart.util.PaintUtilities.colorToString(color10);
        legendTitle1.setBackgroundPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "red" + "'", str12.equals("red"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.jfree.chart.entity.EntityCollection entityCollection15 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo(entityCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        boolean boolean18 = month14.equals((java.lang.Object) chartRenderingInfo16);
        long long19 = month14.getFirstMillisecond();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) year20);
        java.util.Locale locale22 = periodAxis21.getLocale();
        double double23 = periodAxis21.getUpperMargin();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.Class<?> wildcardClass26 = rectangleAnchor25.getClass();
        java.io.InputStream inputStream27 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ChartChangeEventType.GENERAL", (java.lang.Class) wildcardClass26);
        periodAxis21.setMinorTickTimePeriodClass((java.lang.Class) wildcardClass26);
        org.jfree.data.Range range29 = combinedDomainXYPlot11.getDataRange((org.jfree.chart.axis.ValueAxis) periodAxis21);
        combinedDomainXYPlot11.setDomainCrosshairValue(0.0d, true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot34 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation36 = null;
        combinedRangeXYPlot34.setDomainAxisLocation((int) 'a', axisLocation36);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot34);
        boolean boolean39 = combinedRangeXYPlot34.isDomainZeroBaselineVisible();
        combinedRangeXYPlot34.setDomainPannable(false);
        org.jfree.data.xy.XYDataset xYDataset43 = combinedRangeXYPlot34.getDataset((int) '#');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot44 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke45 = combinedRangeXYPlot44.getRangeMinorGridlineStroke();
        combinedRangeXYPlot44.clearAnnotations();
        java.awt.Paint paint47 = combinedRangeXYPlot44.getDomainMinorGridlinePaint();
        combinedRangeXYPlot34.setDomainTickBandPaint(paint47);
        combinedDomainXYPlot11.remove((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot34);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1559372400000L + "'", long19 == 1559372400000L);
        org.junit.Assert.assertNotNull(locale22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(inputStream27);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(xYDataset43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean2 = segmentedTimeline0.containsDomainValue(date1);
        segmentedTimeline0.addException((long) (short) 100);
        long long6 = segmentedTimeline0.getTimeFromLong((long) (-1));
        long long8 = segmentedTimeline0.toTimelineValue(0L);
        long long10 = segmentedTimeline0.toTimelineValue((long) 255);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577836800000L + "'", long8 == 1577836800000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577836800000L + "'", long10 == 1577836800000L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getMax();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.05d, "", false);
        java.lang.StringBuffer stringBuffer5 = null;
        java.text.FieldPosition fieldPosition6 = null;
        java.lang.StringBuffer stringBuffer7 = logFormat3.format((double) 1559372400000L, stringBuffer5, fieldPosition6);
        java.lang.String str9 = logFormat3.format(8.0d);
        org.junit.Assert.assertNotNull(stringBuffer7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-0.69" + "'", str9.equals("-0.69"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double3 = xYSeries2.getMinX();
        xYSeries2.add((double) 100.0f, 0.0d);
        xYSeries2.setNotify(true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint10 = xYAreaRenderer9.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYAreaRenderer9.getBasePositiveItemLabelPosition();
        java.lang.Boolean boolean13 = xYAreaRenderer9.getSeriesVisibleInLegend((int) (byte) 100);
        boolean boolean14 = xYSeries2.equals((java.lang.Object) xYAreaRenderer9);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint17 = xYAreaRenderer16.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYAreaRenderer16.getBasePositiveItemLabelPosition();
        double double19 = itemLabelPosition18.getAngle();
        xYAreaRenderer9.setSeriesPositiveItemLabelPosition(13, itemLabelPosition18);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getDomainUpperBound(false);
        double double5 = xYSeriesCollection0.getIntervalPositionFactor();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate6 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        double double8 = intervalXYDelegate6.getDomainUpperBound(false);
        java.text.NumberFormat numberFormat10 = java.text.NumberFormat.getNumberInstance();
        java.text.NumberFormat numberFormat11 = java.text.NumberFormat.getNumberInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}: ({1}, {2})", numberFormat10, numberFormat11);
        numberFormat10.setMaximumFractionDigits((int) (short) -1);
        int int15 = numberFormat10.getMinimumFractionDigits();
        boolean boolean16 = intervalXYDelegate6.equals((java.lang.Object) int15);
        double double18 = intervalXYDelegate6.getDomainUpperBound(true);
        try {
            java.lang.Number number21 = intervalXYDelegate6.getEndX((int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberFormat10);
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "item", "[size=1]", "TextBlockAnchor.CENTER_RIGHT");
        timeSeries3.setMaximumItemAge(604800000L);
        timeSeries3.setRangeDescription("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=100.0]");
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "item", "[size=1]", "TextBlockAnchor.CENTER_RIGHT");
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.util.Date date13 = month12.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month12, (double) 0.5f);
        java.lang.Number number17 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month12);
        double double18 = timeSeries3.getMaxY();
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        boolean boolean24 = legendItem15.isShapeVisible();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        boolean boolean1 = xYStepAreaRenderer0.getPlotArea();
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color5 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color5);
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("0,0,1,1", font4, (org.jfree.chart.plot.Plot) polarPlot7, false);
        polarPlot7.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = polarPlot7.getOrientation();
        java.awt.Stroke stroke13 = polarPlot7.getRadiusGridlineStroke();
        boolean boolean14 = xYStepAreaRenderer0.equals((java.lang.Object) stroke13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        java.text.DateFormat dateFormat1 = null;
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat(0.05d, "", false);
        java.lang.StringBuffer stringBuffer7 = null;
        java.text.FieldPosition fieldPosition8 = null;
        java.lang.StringBuffer stringBuffer9 = logFormat5.format((double) 1559372400000L, stringBuffer7, fieldPosition8);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator10 = new org.jfree.chart.labels.StandardXYToolTipGenerator("604,800,000", dateFormat1, (java.text.NumberFormat) logFormat5);
        logFormat5.setParseIntegerOnly(false);
        int int13 = logFormat5.getMaximumIntegerDigits();
        org.junit.Assert.assertNotNull(stringBuffer9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 40 + "'", int13 == 40);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYAreaRenderer0.setSeriesURLGenerator(8, xYURLGenerator3, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator12 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "{0}: ({1}, {2})");
        xYAreaRenderer0.setSeriesURLGenerator(0, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator12, true);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        java.util.Locale locale10 = periodAxis9.getLocale();
        double double11 = periodAxis9.getUpperMargin();
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        java.util.List list18 = logAxis13.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge17);
        java.awt.Color color19 = java.awt.Color.red;
        logAxis13.setTickMarkPaint((java.awt.Paint) color19);
        logAxis13.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape23 = logAxis13.getDownArrow();
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity30 = new org.jfree.chart.entity.PieSectionEntity(shape23, pieDataset24, (int) 'a', 2019, (java.lang.Comparable) "red", "", "red");
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean32 = pieSectionEntity30.equals((java.lang.Object) range31);
        org.jfree.data.Range range35 = org.jfree.data.Range.shift(range31, 1.0E-8d, true);
        periodAxis9.setRange(range31, true, false);
        try {
            periodAxis9.setRangeWithMargins(Double.NEGATIVE_INFINITY, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (9.2233720367367516E18) <= upper (-9.2233720355559516E18).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertNotNull(locale10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(range35);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = barRenderer1.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer1.setBase((double) (byte) 0);
        boolean boolean6 = year0.equals((java.lang.Object) barRenderer1);
        barRenderer1.removeAnnotations();
        barRenderer1.setIncludeBaseInRange(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        barRenderer1.setBaseItemLabelGenerator(categoryItemLabelGenerator10, true);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        combinedRangeXYPlot0.setDomainMinorGridlinesVisible(false);
        java.lang.String str7 = combinedRangeXYPlot0.getPlotType();
        boolean boolean8 = combinedRangeXYPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Combined Range XYPlot" + "'", str7.equals("Combined Range XYPlot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer(6.0d);
        java.lang.Object obj2 = xYBarRenderer1.clone();
        xYBarRenderer1.setDrawBarOutline(false);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedRangeXYPlot12.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        combinedRangeXYPlot12.clearAnnotations();
        combinedRangeXYPlot12.setRangeGridlinesVisible(true);
        int int21 = combinedRangeXYPlot12.getWeight();
        java.awt.Paint paint22 = combinedRangeXYPlot12.getBackgroundPaint();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        piePlot3D0.setSimpleLabels(true);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        piePlot3D0.setDataset(pieDataset6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        java.awt.geom.Rectangle2D rectangle2D11 = chartRenderingInfo10.getChartArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets8.createAdjustedRectangle(rectangle2D11, lengthAdjustmentType12, lengthAdjustmentType13);
        piePlot3D0.setLabelPadding(rectangleInsets8);
        piePlot3D0.setAutoPopulateSectionPaint(true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangle2D14);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 4);
        int int3 = dateTickUnit2.getMultiple();
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        boolean boolean11 = dateTickUnit2.equals((java.lang.Object) piePlot3D4);
        double double12 = dateTickUnit2.getSize();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        java.util.Date date15 = dateTickUnit2.rollDate(date13);
        int int16 = dateTickUnit2.getCalendarField();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        combinedRangeXYPlot18.setDomainAxisLocation((int) 'a', axisLocation20);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot18);
        boolean boolean23 = combinedRangeXYPlot18.isDomainZeroBaselineVisible();
        combinedRangeXYPlot18.setDomainPannable(false);
        org.jfree.data.xy.XYDataset xYDataset27 = combinedRangeXYPlot18.getDataset((int) '#');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot28 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke29 = combinedRangeXYPlot28.getRangeMinorGridlineStroke();
        combinedRangeXYPlot28.clearAnnotations();
        java.awt.Paint paint31 = combinedRangeXYPlot28.getDomainMinorGridlinePaint();
        combinedRangeXYPlot18.setDomainTickBandPaint(paint31);
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot18);
        boolean boolean34 = dateTickUnit2.equals((java.lang.Object) legendTitle33);
        java.lang.String str35 = dateTickUnit2.toString();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4000.0d + "'", double12 == 4000.0d);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(xYDataset27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "DateTickUnit[DateTickUnitType.SECOND, 4]" + "'", str35.equals("DateTickUnit[DateTickUnitType.SECOND, 4]"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Object obj1 = null;
        boolean boolean2 = booleanList0.equals(obj1);
        java.lang.Object obj3 = null;
        boolean boolean4 = booleanList0.equals(obj3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(2147483647, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, xYURLGenerator2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.entity.EntityCollection entityCollection12 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo(entityCollection12);
        java.awt.geom.Rectangle2D rectangle2D14 = chartRenderingInfo13.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D15 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D15.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = null;
        piePlot3D15.notifyListeners(plotChangeEvent19);
        org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D14, (org.jfree.chart.plot.Plot) piePlot3D15, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity25 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis1, (java.awt.Shape) rectangle2D14, "", "");
        java.lang.String str26 = axisLabelEntity25.getToolTipText();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "item", "[size=1]", "TextBlockAnchor.CENTER_RIGHT");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.clear();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState1.updateCrosshairY(0.0d);
        crosshairState1.updateCrosshairX((double) (-2208960000000L), 15);
        java.awt.geom.Point2D point2D7 = crosshairState1.getAnchor();
        crosshairState1.setDatasetIndex(7);
        org.junit.Assert.assertNull(point2D7);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("0,0,1,1", font2, (org.jfree.chart.plot.Plot) polarPlot5, false);
        jFreeChart7.setTitle("red");
        int int10 = jFreeChart7.getBackgroundImageAlignment();
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNull(legendTitle11);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(4);
        int int3 = objectList1.indexOf((java.lang.Object) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.awt.geom.Rectangle2D rectangle2D2 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D3.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot3D3.notifyListeners(plotChangeEvent7);
        org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D2, (org.jfree.chart.plot.Plot) piePlot3D3, "");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke12 = combinedRangeXYPlot11.getRangeMinorGridlineStroke();
        combinedRangeXYPlot11.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedRangeXYPlot11.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection14);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D2, (org.jfree.chart.plot.Plot) combinedRangeXYPlot11, "");
        org.jfree.chart.axis.AxisSpace axisSpace18 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot11.setFixedDomainAxisSpace(axisSpace18);
        java.lang.String str20 = axisSpace18.toString();
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(xYItemRenderer15);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        java.awt.Color color3 = java.awt.Color.red;
        boolean boolean5 = color3.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot0.setRangeCrosshairPaint((java.awt.Paint) color3);
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection8 = combinedRangeXYPlot0.getDomainMarkers(layer7);
        boolean boolean9 = combinedRangeXYPlot0.isDomainPannable();
        java.awt.Stroke stroke10 = combinedRangeXYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer(6.0d);
        xYBarRenderer1.setBarAlignmentFactor((-1.0d));
        xYBarRenderer1.setShadowXOffset((double) 7);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRangeZoomable();
        java.awt.Paint paint2 = polarPlot0.getAngleGridlinePaint();
        boolean boolean3 = polarPlot0.isSubplot();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = logAxis2.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        boolean boolean8 = paintMap0.equals((java.lang.Object) list7);
        java.lang.Comparable comparable9 = null;
        try {
            java.awt.Paint paint10 = paintMap0.getPaint(comparable9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        java.lang.String str4 = piePlot3D0.getPlotType();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        java.util.List list11 = logAxis6.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
        java.awt.Color color12 = java.awt.Color.red;
        logAxis6.setTickMarkPaint((java.awt.Paint) color12);
        java.lang.String str14 = org.jfree.chart.util.PaintUtilities.colorToString(color12);
        piePlot3D0.setLabelOutlinePaint((java.awt.Paint) color12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer17.getPositiveItemLabelPositionFallback();
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot19.setAngleGridlinePaint((java.awt.Paint) color20);
        java.awt.Color color22 = color20.darker();
        int int23 = color22.getAlpha();
        barRenderer17.setBaseItemLabelPaint((java.awt.Paint) color22);
        java.awt.Color color25 = color22.brighter();
        piePlot3D0.setSectionPaint((java.lang.Comparable) "ClassContext", (java.awt.Paint) color22);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pie 3D Plot" + "'", str4.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "red" + "'", str14.equals("red"));
        org.junit.Assert.assertNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 255 + "'", int23 == 255);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        waferMapPlot0.setDataset(waferMapDataset1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = waferMapPlot0.getDataset();
        org.junit.Assert.assertNull(waferMapDataset3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        combinedRangeXYPlot4.setDomainAxisLocation((int) 'a', axisLocation6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer11.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke16 = barRenderer11.getItemOutlineStroke((int) '4', (int) (byte) 1, true);
        jFreeChart8.setBorderStroke(stroke16);
        barRenderer0.setSeriesStroke(0, stroke16);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = null;
        barRenderer0.setSeriesURLGenerator(12, categoryURLGenerator20, false);
        java.awt.Stroke stroke24 = barRenderer0.getSeriesOutlineStroke(12);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator25);
        java.awt.Stroke stroke28 = barRenderer0.lookupSeriesOutlineStroke((int) (byte) -1);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNull(legendTitle10);
        org.junit.Assert.assertNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        logAxis1.setAxisLineVisible(true);
        org.jfree.data.Range range4 = logAxis1.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean3 = barRenderer0.isSeriesVisible(100);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = barRenderer0.getDrawingSupplier();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(drawingSupplier4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = null;
        xYAreaRenderer0.setSeriesItemLabelGenerator(7, xYItemLabelGenerator7, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) false);
        xYAreaRenderer0.notifyListeners(rendererChangeEvent11);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("red");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getRangeMinorGridlineStroke();
        combinedRangeXYPlot7.clearAnnotations();
        boolean boolean10 = combinedRangeXYPlot7.isDomainPannable();
        boolean boolean11 = combinedRangeXYPlot7.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = combinedRangeXYPlot7.getDomainAxisEdge();
        org.jfree.chart.axis.AxisState axisState13 = null;
        categoryAxis1.drawTickMarks(graphics2D4, (double) (-1.0f), rectangle2D6, rectangleEdge12, axisState13);
        int int15 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("red");
        java.awt.Paint paint19 = categoryAxis17.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis17.setAxisLineStroke(stroke20);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions22 = categoryAxis17.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions22);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(categoryLabelPositions22);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Paint paint5 = xYAreaRenderer0.getBasePaint();
        java.awt.Font font6 = xYAreaRenderer0.getBaseLegendTextFont();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(font6);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        intervalXYDelegate4.datasetChanged(datasetChangeEvent5);
        double double8 = intervalXYDelegate4.getDomainLowerBound(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        intervalXYDelegate4.datasetChanged(datasetChangeEvent9);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        polarPlot0.setRadiusGridlinePaint((java.awt.Paint) color1);
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("hi!");
        polarPlot0.setAxis((org.jfree.chart.axis.ValueAxis) logAxis4);
        double double6 = logAxis4.getLabelAngle();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = null;
        logAxis2.setStandardTickUnits(tickUnitSource3);
        boolean boolean5 = logAxis2.isNegativeArrowVisible();
        logAxis2.pan((double) (short) 1);
        java.lang.String str8 = logAxis2.getLabelURL();
        java.awt.Font font9 = logAxis2.getLabelFont();
        java.awt.Font font11 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("hi!", font11, (java.awt.Paint) color12);
        org.jfree.chart.text.TextFragment textFragment14 = textLine13.getLastTextFragment();
        java.awt.Paint paint15 = textFragment14.getPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer18 = null;
        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint15, (float) 255, (int) (byte) -1, textMeasurer18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.lang.String str24 = textBlockAnchor23.toString();
        java.awt.Shape shape28 = textBlock19.calculateBounds(graphics2D20, (float) 'a', (float) (short) 10, textBlockAnchor23, (float) 255, 1.0f, (double) 6);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor32 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.awt.Shape shape36 = textBlock19.calculateBounds(graphics2D29, (float) (-1L), (float) (short) 100, textBlockAnchor32, (float) 1, (float) (short) 10, (double) 86400000L);
        java.awt.Font font40 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color41 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine42 = new org.jfree.chart.text.TextLine("hi!", font40, (java.awt.Paint) color41);
        org.jfree.chart.plot.PolarPlot polarPlot43 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart45 = new org.jfree.chart.JFreeChart("0,0,1,1", font40, (org.jfree.chart.plot.Plot) polarPlot43, false);
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("0,0,1,1", font40);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment47 = textTitle46.getTextAlignment();
        java.lang.String str48 = horizontalAlignment47.toString();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot49 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke50 = combinedRangeXYPlot49.getRangeMinorGridlineStroke();
        combinedRangeXYPlot49.clearAnnotations();
        java.awt.Paint paint52 = combinedRangeXYPlot49.getDomainMinorGridlinePaint();
        java.awt.Color color53 = java.awt.Color.YELLOW;
        combinedRangeXYPlot49.setDomainGridlinePaint((java.awt.Paint) color53);
        boolean boolean55 = horizontalAlignment47.equals((java.lang.Object) color53);
        textBlock19.setLineAlignment(horizontalAlignment47);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textFragment14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textBlock19);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TextBlockAnchor.CENTER_RIGHT" + "'", str24.equals("TextBlockAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(textBlockAnchor32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(horizontalAlignment47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "HorizontalAlignment.CENTER" + "'", str48.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        boolean boolean4 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        logAxis6.setStandardTickUnits(tickUnitSource7);
        boolean boolean9 = logAxis6.isNegativeArrowVisible();
        logAxis6.pan((double) (short) 1);
        combinedRangeXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis6);
        boolean boolean13 = logAxis6.isTickMarksVisible();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer1 = polarPlot0.getRenderer();
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo6.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        java.util.List list15 = logAxis10.refreshTicks(graphics2D11, axisState12, rectangle2D13, rectangleEdge14);
        java.awt.Color color16 = java.awt.Color.red;
        logAxis10.setTickMarkPaint((java.awt.Paint) color16);
        logAxis10.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape20 = logAxis10.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke22 = combinedRangeXYPlot21.getRangeMinorGridlineStroke();
        combinedRangeXYPlot21.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection24 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = combinedRangeXYPlot21.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection24);
        org.jfree.chart.entity.PlotEntity plotEntity26 = new org.jfree.chart.entity.PlotEntity(shape20, (org.jfree.chart.plot.Plot) combinedRangeXYPlot21);
        combinedRangeXYPlot21.clearAnnotations();
        java.awt.geom.Point2D point2D28 = combinedRangeXYPlot21.getQuadrantOrigin();
        polarPlot0.zoomDomainAxes((double) 1560668399999L, (double) (byte) -1, plotRenderingInfo6, point2D28);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo6);
        org.jfree.chart.entity.EntityCollection entityCollection31 = state30.getEntityCollection();
        java.awt.geom.GeneralPath generalPath32 = state30.seriesPath;
        org.junit.Assert.assertNull(polarItemRenderer1);
        org.junit.Assert.assertNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(xYItemRenderer25);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertNull(entityCollection31);
        org.junit.Assert.assertNull(generalPath32);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        textTitle9.setToolTipText("red");
        java.lang.String str12 = textTitle9.getID();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        textTitle9.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.block.BlockBorder blockBorder15 = org.jfree.chart.block.BlockBorder.NONE;
        textTitle9.setFrame((org.jfree.chart.block.BlockFrame) blockBorder15);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(blockBorder15);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, serialDate2);
        serialDate3.setDescription("");
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        java.awt.Color color7 = java.awt.Color.CYAN;
        xYAreaRenderer0.setSeriesPaint((int) (short) 10, (java.awt.Paint) color7);
        java.util.Collection collection9 = xYAreaRenderer0.getAnnotations();
        java.util.Collection collection10 = org.jfree.chart.util.ObjectUtilities.deepClone(collection9);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(collection10);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, false);
        java.awt.Shape shape4 = xYLineAndShapeRenderer2.getSeriesShape((int) (short) 0);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity18 = new org.jfree.chart.entity.PieSectionEntity(shape11, pieDataset12, (int) 'a', 2019, (java.lang.Comparable) "red", "", "red");
        int int19 = pieSectionEntity18.getSectionIndex();
        int int20 = pieSectionEntity18.getSectionIndex();
        pieSectionEntity18.setSectionKey((java.lang.Comparable) 1.0E-8d);
        java.lang.Comparable comparable23 = null;
        pieSectionEntity18.setSectionKey(comparable23);
        java.lang.String str25 = pieSectionEntity18.getShapeType();
        pieSectionEntity18.setSectionKey((java.lang.Comparable) 1L);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "poly" + "'", str25.equals("poly"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("0,0,1,1", font2, (org.jfree.chart.plot.Plot) polarPlot5, false);
        polarPlot5.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = polarPlot5.getOrientation();
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        java.util.List list17 = logAxis12.refreshTicks(graphics2D13, axisState14, rectangle2D15, rectangleEdge16);
        java.awt.Color color18 = java.awt.Color.red;
        logAxis12.setTickMarkPaint((java.awt.Paint) color18);
        logAxis12.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis12.centerRange((double) 0L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis12);
        java.lang.String str25 = combinedRangeXYPlot24.getPlotType();
        java.awt.Paint paint26 = combinedRangeXYPlot24.getDomainZeroBaselinePaint();
        boolean boolean27 = polarPlot5.equals((java.lang.Object) paint26);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Combined Range XYPlot" + "'", str25.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.CLOCKWISE" + "'", str1.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity18 = new org.jfree.chart.entity.PieSectionEntity(shape11, pieDataset12, (int) 'a', 2019, (java.lang.Comparable) "red", "", "red");
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean20 = pieSectionEntity18.equals((java.lang.Object) range19);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset21 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline22 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date23 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean24 = segmentedTimeline22.containsDomainValue(date23);
        int int25 = defaultPieDataset21.getIndex((java.lang.Comparable) date23);
        boolean boolean26 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset21);
        pieSectionEntity18.setDataset((org.jfree.data.general.PieDataset) defaultPieDataset21);
        java.lang.String str28 = pieSectionEntity18.getShapeCoords();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0,0,-2,-2,2,-2,2,-2" + "'", str28.equals("0,0,-2,-2,2,-2,2,-2"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        boolean boolean7 = month3.equals((java.lang.Object) chartRenderingInfo5);
        long long8 = month3.getFirstMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month3, (org.jfree.data.time.RegularTimePeriod) year9);
        boolean boolean11 = periodAxis10.isMinorTickMarksVisible();
        java.util.Locale locale12 = periodAxis10.getLocale();
        try {
            java.util.ResourceBundle resourceBundle13 = java.util.ResourceBundle.getBundle("java.awt.Color[r=255,g=255,b=255]", locale12);
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name java.awt.Color[r=255,g=255,b=255], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559372400000L + "'", long8 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(locale12);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = barRenderer1.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer1.setBase((double) (byte) 0);
        boolean boolean6 = year0.equals((java.lang.Object) barRenderer1);
        barRenderer1.setShadowXOffset((double) 172800000L);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity18 = new org.jfree.chart.entity.PieSectionEntity(shape11, pieDataset12, (int) 'a', 2019, (java.lang.Comparable) "red", "", "red");
        int int19 = pieSectionEntity18.getSectionIndex();
        int int20 = pieSectionEntity18.getPieIndex();
        pieSectionEntity18.setPieIndex(3);
        boolean boolean24 = pieSectionEntity18.equals((java.lang.Object) 3.0d);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 97 + "'", int20 == 97);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("red");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor2, 1, 8, rectangle2D5, rectangleEdge6);
        categoryAxis1.setLowerMargin((double) 10L);
        categoryAxis1.configure();
        categoryAxis1.setLowerMargin(1.0E-8d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis1.setAutoTickUnitSelection(true, true);
        java.lang.String str14 = logAxis1.getLabel();
        logAxis1.setFixedAutoRange((double) ' ');
        logAxis1.setInverted(false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis1.centerRange((double) 0L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean18 = segmentedTimeline16.containsDomainValue(date17);
        java.util.List list19 = segmentedTimeline16.getExceptionSegments();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeZone21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = combinedRangeXYPlot20.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection22);
        org.jfree.chart.axis.LogAxis logAxis25 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.AxisState axisState27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        java.util.List list30 = logAxis25.refreshTicks(graphics2D26, axisState27, rectangle2D28, rectangleEdge29);
        org.jfree.data.time.DateRange dateRange31 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange32 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange31);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection22, list30, (org.jfree.data.Range) dateRange31, false);
        segmentedTimeline16.addExceptions(list30);
        combinedRangeXYPlot13.drawDomainTickBands(graphics2D14, rectangle2D15, list30);
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D37.setCircular(true, true);
        piePlot3D37.setSimpleLabels(true);
        org.jfree.data.general.PieDataset pieDataset43 = null;
        piePlot3D37.setDataset(pieDataset43);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection46 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = new org.jfree.chart.ChartRenderingInfo(entityCollection46);
        java.awt.geom.Rectangle2D rectangle2D48 = chartRenderingInfo47.getChartArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets45.createAdjustedRectangle(rectangle2D48, lengthAdjustmentType49, lengthAdjustmentType50);
        piePlot3D37.setLabelPadding(rectangleInsets45);
        java.awt.Stroke stroke53 = piePlot3D37.getLabelOutlineStroke();
        combinedRangeXYPlot13.setDomainGridlineStroke(stroke53);
        org.jfree.chart.block.BlockBorder blockBorder59 = new org.jfree.chart.block.BlockBorder((double) ' ', (double) 0L, (double) 100L, 90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = blockBorder59.getInsets();
        combinedRangeXYPlot13.setAxisOffset(rectangleInsets60);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(segmentedTimeline16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(xYItemRenderer23);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(rectangleInsets60);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("PlotEntity: tooltip = ");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name PlotEntity: tooltip = , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.lang.Object obj1 = standardXYToolTipGenerator0.clone();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        numberFormat0.setMaximumFractionDigits((-1));
        java.lang.String str4 = numberFormat0.format(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "∞" + "'", str4.equals("∞"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        boolean boolean4 = piePlot3D0.getAutoPopulateSectionPaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot3D0.getLabelDistributor();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) '#', (double) (short) 0, (double) 10, (double) (-1.0f));
        piePlot3D0.setSimpleLabelOffset(rectangleInsets10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.Font font16 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color17 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine18 = new org.jfree.chart.text.TextLine("hi!", font16, (java.awt.Paint) color17);
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("0,0,1,1", font16, (org.jfree.chart.plot.Plot) polarPlot19, false);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("0,0,1,1", font16);
        textTitle22.setToolTipText("red");
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot25.setAngleGridlinePaint((java.awt.Paint) color26);
        java.awt.Color color28 = color26.darker();
        textTitle22.setPaint((java.awt.Paint) color26);
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.jfree.chart.entity.EntityCollection entityCollection32 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = new org.jfree.chart.ChartRenderingInfo(entityCollection32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo33);
        boolean boolean35 = month31.equals((java.lang.Object) chartRenderingInfo33);
        java.awt.geom.Rectangle2D rectangle2D36 = chartRenderingInfo33.getChartArea();
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D36, "", "Combined Range XYPlot");
        textTitle22.setBounds(rectangle2D36);
        org.jfree.data.xy.XYSeries xYSeries43 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection44 = new org.jfree.data.xy.XYSeriesCollection();
        int int46 = xYSeriesCollection44.indexOf((java.lang.Comparable) '#');
        double double48 = xYSeriesCollection44.getDomainUpperBound(false);
        xYSeries43.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection44);
        org.jfree.data.Range range50 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection44);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot51 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke52 = combinedRangeXYPlot51.getRangeMinorGridlineStroke();
        combinedRangeXYPlot51.clearAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace54 = null;
        combinedRangeXYPlot51.setFixedRangeAxisSpace(axisSpace54, true);
        xYSeriesCollection44.addChangeListener((org.jfree.data.general.DatasetChangeListener) combinedRangeXYPlot51);
        org.jfree.chart.entity.EntityCollection entityCollection59 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo60 = new org.jfree.chart.ChartRenderingInfo(entityCollection59);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo60);
        java.awt.geom.Rectangle2D rectangle2D62 = plotRenderingInfo61.getPlotArea();
        org.jfree.chart.axis.LogAxis logAxis64 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D65 = null;
        org.jfree.chart.axis.AxisState axisState66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
        java.util.List list69 = logAxis64.refreshTicks(graphics2D65, axisState66, rectangle2D67, rectangleEdge68);
        java.awt.Color color70 = java.awt.Color.red;
        logAxis64.setTickMarkPaint((java.awt.Paint) color70);
        logAxis64.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape74 = logAxis64.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot75 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke76 = combinedRangeXYPlot75.getRangeMinorGridlineStroke();
        combinedRangeXYPlot75.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection78 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer79 = combinedRangeXYPlot75.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection78);
        org.jfree.chart.entity.PlotEntity plotEntity80 = new org.jfree.chart.entity.PlotEntity(shape74, (org.jfree.chart.plot.Plot) combinedRangeXYPlot75);
        combinedRangeXYPlot75.clearAnnotations();
        java.awt.geom.Point2D point2D82 = combinedRangeXYPlot75.getQuadrantOrigin();
        combinedRangeXYPlot51.zoomDomainAxes((double) 100.0f, plotRenderingInfo61, point2D82);
        org.jfree.chart.plot.PlotState plotState84 = null;
        org.jfree.chart.entity.EntityCollection entityCollection85 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo86 = new org.jfree.chart.ChartRenderingInfo(entityCollection85);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo87 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo86);
        java.awt.geom.Rectangle2D rectangle2D88 = plotRenderingInfo87.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D89 = plotRenderingInfo87.getDataArea();
        try {
            piePlot3D0.draw(graphics2D12, rectangle2D36, point2D82, plotState84, plotRenderingInfo87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(rectangle2D62);
        org.junit.Assert.assertNotNull(list69);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(shape74);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNull(xYItemRenderer79);
        org.junit.Assert.assertNotNull(point2D82);
        org.junit.Assert.assertNull(rectangle2D88);
        org.junit.Assert.assertNotNull(rectangle2D89);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100L, (float) (short) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        combinedRangeXYPlot4.setDomainAxisLocation((int) 'a', axisLocation6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend(100);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity13 = new org.jfree.chart.entity.JFreeChartEntity(shape2, jFreeChart8, "", "0,0,1,1");
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int16 = color15.getGreen();
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color15);
        boolean boolean18 = jFreeChart8.equals((java.lang.Object) color17);
        boolean boolean19 = jFreeChart8.getAntiAlias();
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection23 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = new org.jfree.chart.ChartRenderingInfo(entityCollection23);
        java.awt.geom.Rectangle2D rectangle2D25 = chartRenderingInfo24.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D26 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D26.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent30 = null;
        piePlot3D26.notifyListeners(plotChangeEvent30);
        org.jfree.chart.entity.PlotEntity plotEntity33 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D25, (org.jfree.chart.plot.Plot) piePlot3D26, "");
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets22.createInsetRectangle(rectangle2D25);
        legendTitle21.setLegendItemGraphicPadding(rectangleInsets22);
        java.awt.geom.Rectangle2D rectangle2D36 = legendTitle21.getBounds();
        jFreeChart8.addLegend(legendTitle21);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(legendTitle10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D36);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) ' ', (float) 86400000L, 10.0f);
        java.lang.Object obj4 = null;
        boolean boolean5 = color3.equals(obj4);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedRangeXYPlot12.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        java.util.List list18 = combinedRangeXYPlot12.getAnnotations();
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = null;
        logAxis21.setStandardTickUnits(tickUnitSource22);
        boolean boolean24 = logAxis21.isNegativeArrowVisible();
        logAxis21.pan((double) (short) 1);
        combinedRangeXYPlot12.setDomainAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) logAxis21, false);
        double double30 = logAxis21.calculateValue((double) 1559372400000L);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator31 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.text.NumberFormat numberFormat32 = standardXYToolTipGenerator31.getYFormat();
        logAxis21.setNumberFormatOverride(numberFormat32);
        float float34 = logAxis21.getMinorTickMarkInsideLength();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.POSITIVE_INFINITY + "'", double30 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(numberFormat32);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.0f + "'", float34 == 0.0f);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getDomainUpperBound(false);
        java.lang.Object obj5 = xYSeriesCollection0.clone();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate6 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        boolean boolean7 = intervalXYDelegate6.isAutoWidth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = xYAreaRenderer0.getBasePositiveItemLabelPosition();
        java.lang.Boolean boolean4 = xYAreaRenderer0.getSeriesVisibleInLegend((int) (byte) 100);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = xYAreaRenderer0.getSeriesToolTipGenerator((int) (short) 10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(xYToolTipGenerator6);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = null;
        logAxis2.setStandardTickUnits(tickUnitSource3);
        boolean boolean5 = logAxis2.isNegativeArrowVisible();
        logAxis2.pan((double) (short) 1);
        java.lang.String str8 = logAxis2.getLabelURL();
        java.awt.Font font9 = logAxis2.getLabelFont();
        java.awt.Font font11 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("hi!", font11, (java.awt.Paint) color12);
        org.jfree.chart.text.TextFragment textFragment14 = textLine13.getLastTextFragment();
        java.awt.Paint paint15 = textFragment14.getPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer18 = null;
        org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint15, (float) 255, (int) (byte) -1, textMeasurer18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.lang.String str24 = textBlockAnchor23.toString();
        java.awt.Shape shape28 = textBlock19.calculateBounds(graphics2D20, (float) 'a', (float) (short) 10, textBlockAnchor23, (float) 255, 1.0f, (double) 6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = textBlock19.getLineAlignment();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor33 = null;
        textBlock19.draw(graphics2D30, (float) 7, (float) 900000L, textBlockAnchor33, (float) 255, (float) 2, (double) (short) 100);
        boolean boolean39 = textBlock19.equals((java.lang.Object) 0.025d);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor43 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.lang.String str44 = textBlockAnchor43.toString();
        java.awt.Shape shape48 = textBlock19.calculateBounds(graphics2D40, (float) (short) 1, (float) (byte) 1, textBlockAnchor43, (float) 604800000L, 0.0f, (double) 3);
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor52 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        textBlock19.draw(graphics2D49, (float) '#', (float) 7, textBlockAnchor52, (float) (-1), 0.0f, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textFragment14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textBlock19);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "TextBlockAnchor.CENTER_RIGHT" + "'", str24.equals("TextBlockAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "TextBlockAnchor.CENTER_RIGHT" + "'", str44.equals("TextBlockAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(textBlockAnchor52);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        combinedRangeXYPlot1.setDomainAxisLocation((int) 'a', axisLocation3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        boolean boolean6 = combinedRangeXYPlot1.isDomainZeroBaselineVisible();
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.chart.entity.EntityCollection entityCollection11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo(entityCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        boolean boolean14 = month10.equals((java.lang.Object) chartRenderingInfo12);
        long long15 = month10.getFirstMillisecond();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) year16);
        java.lang.Class class18 = periodAxis17.getMinorTickTimePeriodClass();
        boolean boolean19 = periodAxis17.isMinorTickMarksVisible();
        combinedRangeXYPlot1.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) periodAxis17);
        boolean boolean21 = combinedRangeXYPlot1.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        combinedRangeXYPlot1.setDomainAxisLocation((int) 'a', axisLocation3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        boolean boolean6 = combinedRangeXYPlot1.isDomainZeroBaselineVisible();
        combinedRangeXYPlot1.setDomainPannable(false);
        org.jfree.data.xy.XYDataset xYDataset10 = combinedRangeXYPlot1.getDataset((int) '#');
        java.lang.String str11 = combinedRangeXYPlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Combined Range XYPlot" + "'", str11.equals("Combined Range XYPlot"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        combinedRangeXYPlot1.setDomainAxisLocation((int) 'a', axisLocation3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        boolean boolean6 = combinedRangeXYPlot1.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = null;
        logAxis9.setStandardTickUnits(tickUnitSource10);
        logAxis9.setVisible(false);
        combinedRangeXYPlot1.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) logAxis9, false);
        org.jfree.chart.entity.EntityCollection entityCollection16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo(entityCollection16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        java.awt.geom.Rectangle2D rectangle2D19 = chartRenderingInfo17.getChartArea();
        logAxis9.setUpArrow((java.awt.Shape) rectangle2D19);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean2 = segmentedTimeline0.containsDomainValue(date1);
        segmentedTimeline0.addException((long) (short) 100);
        java.util.Date date6 = segmentedTimeline0.getDate((long) (short) 10);
        long long7 = segmentedTimeline0.getSegmentsIncludedSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 432000000L + "'", long7 == 432000000L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity18 = new org.jfree.chart.entity.PieSectionEntity(shape11, pieDataset12, (int) 'a', 2019, (java.lang.Comparable) "red", "", "red");
        int int19 = pieSectionEntity18.getSectionIndex();
        int int20 = pieSectionEntity18.getPieIndex();
        java.lang.String str21 = pieSectionEntity18.getShapeCoords();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 97 + "'", int20 == 97);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0,0,-2,-2,2,-2,2,-2" + "'", str21.equals("0,0,-2,-2,2,-2,2,-2"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        java.util.TimeZone timeZone7 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("0,0,1,1", timeZone7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("AxisLabelEntity: label = hi!", timeZone7);
        java.util.Locale locale10 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("AxisLocation.BOTTOM_OR_LEFT", regularTimePeriod2, (org.jfree.data.time.RegularTimePeriod) year3, timeZone7, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator2 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator4);
        org.junit.Assert.assertNull(itemLabelPosition1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Paint paint6 = xYAreaRenderer0.getSeriesPaint(15);
        boolean boolean7 = xYAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator9 = null;
        xYAreaRenderer0.setSeriesItemLabelGenerator((int) ' ', xYItemLabelGenerator9, false);
        xYAreaRenderer0.setBaseSeriesVisible(false, true);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        xYAreaRenderer0.setAutoPopulateSeriesShape(true);
        int int7 = xYAreaRenderer0.getPassCount();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator8);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "DateTickUnitType.SECOND");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator3 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "", "{0}: ({1}, {2})");
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = polarPlot4.getRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke7 = combinedRangeXYPlot6.getRangeMinorGridlineStroke();
        combinedRangeXYPlot6.clearAnnotations();
        java.awt.Color color9 = java.awt.Color.red;
        boolean boolean11 = color9.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot6.setRangeCrosshairPaint((java.awt.Paint) color9);
        polarPlot4.setAngleGridlinePaint((java.awt.Paint) color9);
        java.awt.Color color14 = java.awt.Color.gray;
        polarPlot4.setAngleLabelPaint((java.awt.Paint) color14);
        boolean boolean16 = standardXYURLGenerator3.equals((java.lang.Object) polarPlot4);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection19 = new org.jfree.data.time.TimeSeriesCollection(timeZone18);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = combinedRangeXYPlot17.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection19);
        org.jfree.chart.axis.LogAxis logAxis22 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.axis.AxisState axisState24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        java.util.List list27 = logAxis22.refreshTicks(graphics2D23, axisState24, rectangle2D25, rectangleEdge26);
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange28);
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection19, list27, (org.jfree.data.Range) dateRange28, false);
        timeSeriesCollection19.removeAllSeries();
        java.lang.String str35 = standardXYURLGenerator3.generateURL((org.jfree.data.xy.XYDataset) timeSeriesCollection19, (int) (byte) -1, 8);
        try {
            timeSeriesCollection19.setSelected(2019, (int) (byte) 10, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (2019).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(polarItemRenderer5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(xYItemRenderer20);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!?=-1&amp;{0}: ({1}, {2})=8" + "'", str35.equals("hi!?=-1&amp;{0}: ({1}, {2})=8"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        crosshairState1.updateCrosshairY(0.0d);
        crosshairState1.updateCrosshairX((double) (-2208960000000L), 15);
        crosshairState1.updateCrosshairY((double) 255);
        crosshairState1.updateCrosshairX((double) (byte) 10);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        boolean boolean24 = legendItem15.isLineVisible();
        org.jfree.data.xy.XYSeries xYSeries27 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double28 = xYSeries27.getMinX();
        xYSeries27.add((double) 100.0f, 0.0d);
        boolean boolean32 = legendItem15.equals((java.lang.Object) xYSeries27);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer33 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer33.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer33.clearSeriesStrokes(false);
        xYAreaRenderer33.setAutoPopulateSeriesShape(true);
        java.awt.Shape shape40 = xYAreaRenderer33.getBaseShape();
        legendItem15.setLine(shape40);
        java.awt.Font font46 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color47 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine48 = new org.jfree.chart.text.TextLine("hi!", font46, (java.awt.Paint) color47);
        org.jfree.chart.plot.PolarPlot polarPlot49 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart51 = new org.jfree.chart.JFreeChart("0,0,1,1", font46, (org.jfree.chart.plot.Plot) polarPlot49, false);
        org.jfree.chart.title.TextTitle textTitle52 = new org.jfree.chart.title.TextTitle("0,0,1,1", font46);
        org.jfree.chart.text.TextLine textLine53 = new org.jfree.chart.text.TextLine("DateTickUnitType.SECOND", font46);
        legendItem15.setLabelFont(font46);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(color47);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getDomainUpperBound(false);
        double double5 = xYSeriesCollection0.getIntervalPositionFactor();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate6 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        double double8 = intervalXYDelegate6.getDomainUpperBound(false);
        java.text.NumberFormat numberFormat10 = java.text.NumberFormat.getNumberInstance();
        java.text.NumberFormat numberFormat11 = java.text.NumberFormat.getNumberInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}: ({1}, {2})", numberFormat10, numberFormat11);
        numberFormat10.setMaximumFractionDigits((int) (short) -1);
        int int15 = numberFormat10.getMinimumFractionDigits();
        boolean boolean16 = intervalXYDelegate6.equals((java.lang.Object) int15);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        intervalXYDelegate6.datasetChanged(datasetChangeEvent17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberFormat10);
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        legendItem15.setURLText("item");
        boolean boolean26 = legendItem15.isLineVisible();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Paint paint6 = xYAreaRenderer0.getSeriesPaint(15);
        boolean boolean8 = xYAreaRenderer0.isSeriesItemLabelsVisible(0);
        xYAreaRenderer0.setItemLabelAnchorOffset((double) 60000L);
        boolean boolean11 = xYAreaRenderer0.getPlotShapes();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer13 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer13.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer13.clearSeriesStrokes(false);
        xYAreaRenderer13.setAutoPopulateSeriesShape(true);
        java.awt.Shape shape20 = xYAreaRenderer13.getBaseShape();
        xYAreaRenderer0.setSeriesShape(5, shape20);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer0.getItemLabelPaint((int) (short) 0, 0, true);
        barRenderer0.setDrawBarOutline(false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 2147483647, (double) 10L);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("red");
        float float7 = categoryAxis6.getMaximumCategoryLabelWidthRatio();
        categoryAxis6.setMinorTickMarkOutsideLength((float) 15);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.entity.EntityCollection entityCollection12 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo(entityCollection12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = chartRenderingInfo13.getChartArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        org.jfree.chart.axis.AxisState axisState17 = new org.jfree.chart.axis.AxisState();
        axisState17.cursorDown((double) 12);
        categoryAxis6.drawTickMarks(graphics2D10, 10.0d, rectangle2D15, rectangleEdge16, axisState17);
        try {
            barRenderer3D2.drawOutline(graphics2D3, categoryPlot4, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(rectangle2D15);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = polarPlot1.getRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke4 = combinedRangeXYPlot3.getRangeMinorGridlineStroke();
        combinedRangeXYPlot3.clearAnnotations();
        java.awt.Color color6 = java.awt.Color.red;
        boolean boolean8 = color6.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot3.setRangeCrosshairPaint((java.awt.Paint) color6);
        polarPlot1.setAngleGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = polarPlot1.getRenderer();
        boolean boolean12 = chartChangeEventType0.equals((java.lang.Object) polarPlot1);
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = plotRenderingInfo16.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D18 = plotRenderingInfo16.getDataArea();
        java.awt.geom.Point2D point2D19 = null;
        polarPlot1.zoomDomainAxes((double) 2019, plotRenderingInfo16, point2D19);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNull(polarItemRenderer2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(polarItemRenderer11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D18);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        logAxis1.setStandardTickUnits(tickUnitSource2);
        boolean boolean4 = logAxis1.isNegativeArrowVisible();
        logAxis1.pan((double) (short) 1);
        java.lang.String str7 = logAxis1.getLabelURL();
        java.awt.Font font8 = logAxis1.getLabelFont();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str11 = numberTickUnit9.valueToString((double) 8);
        logAxis1.setTickUnit(numberTickUnit9, false, false);
        java.awt.Paint paint15 = logAxis1.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "8" + "'", str11.equals("8"));
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        timeSeriesCollection1.removeAllSeries();
        timeSeriesCollection1.removeAllSeries();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset5 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot((org.jfree.data.general.PieDataset) defaultPieDataset5);
        timeSeriesCollection1.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot6);
        java.awt.Font font8 = piePlot6.getNoDataMessageFont();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("red");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.setCategoryLabelPositionOffset(8);
        java.lang.Object obj5 = categoryAxis1.clone();
        double double6 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot3D0.getDatasetGroup();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = piePlot3D0.getLabelLinkStyle();
        piePlot3D0.setCircular(false, false);
        piePlot3D0.clearSectionOutlinePaints(false);
        double double14 = piePlot3D0.getExplodePercent((java.lang.Comparable) "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        piePlot3D0.setLabelLinksVisible(true);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        boolean boolean5 = xYAreaRenderer0.getItemVisible((int) (byte) -1, 13);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        int int3 = xYSeriesCollection1.indexOf((java.lang.Comparable) '#');
        double double5 = xYSeriesCollection1.getDomainUpperBound(false);
        double double6 = xYSeriesCollection1.getIntervalPositionFactor();
        org.jfree.data.Range range7 = xYStepRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1);
        xYSeriesCollection1.validateObject();
        java.lang.Object obj9 = xYSeriesCollection1.clone();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setBaseShapesVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) false);
        xYStepRenderer0.notifyListeners(rendererChangeEvent4);
        java.awt.Stroke stroke7 = xYStepRenderer0.getSeriesStroke(1);
        java.awt.Shape shape9 = xYStepRenderer0.lookupSeriesShape((int) (byte) 0);
        xYStepRenderer0.setSeriesShapesVisible((int) (short) 100, (java.lang.Boolean) false);
        xYStepRenderer0.setUseFillPaint(false);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        piePlot3D0.setMinimumArcAngleToDraw((double) (short) 0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot3D0.getLegendLabelURLGenerator();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset9 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset9);
        piePlot3D0.setDataset((org.jfree.data.general.PieDataset) defaultPieDataset9);
        org.junit.Assert.assertNull(pieURLGenerator8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot3D0.getDatasetGroup();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = piePlot3D0.getLabelLinkStyle();
        piePlot3D0.setCircular(false, false);
        piePlot3D0.clearSectionOutlinePaints(false);
        double double14 = piePlot3D0.getExplodePercent((java.lang.Comparable) "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.awt.Paint paint15 = piePlot3D0.getBaseSectionOutlinePaint();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer17 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer17.setSeriesShapesVisible(0, (java.lang.Boolean) false);
        java.awt.Font font22 = xYStepRenderer17.getLegendTextFont(8);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        xYStepRenderer17.setSeriesStroke((int) (byte) 0, stroke24, true);
        piePlot3D0.setSectionOutlineStroke((java.lang.Comparable) (-1.0f), stroke24);
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D28.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = null;
        piePlot3D28.notifyListeners(plotChangeEvent32);
        java.awt.Shape shape34 = piePlot3D28.getLegendItemShape();
        java.awt.Paint paint35 = piePlot3D28.getBaseSectionOutlinePaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator36 = piePlot3D28.getLegendLabelGenerator();
        piePlot3D0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator36);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(font22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator36);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.plot.CrosshairState crosshairState13 = new org.jfree.chart.plot.CrosshairState(true);
        java.awt.Font font22 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color23 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine24 = new org.jfree.chart.text.TextLine("hi!", font22, (java.awt.Paint) color23);
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("0,0,1,1", font22, (org.jfree.chart.plot.Plot) polarPlot25, false);
        polarPlot25.setAngleGridlinesVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = polarPlot25.getOrientation();
        crosshairState13.updateCrosshairPoint(0.12d, (double) 2.0f, 8, 1, (double) 13, (double) (short) 10, plotOrientation30);
        combinedDomainXYPlot11.setOrientation(plotOrientation30);
        double double33 = combinedDomainXYPlot11.getRangeCrosshairValue();
        double double34 = combinedDomainXYPlot11.getGap();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 5.0d + "'", double34 == 5.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(3, 4, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(7);
        java.lang.String str2 = pieLabelDistributor1.toString();
        pieLabelDistributor1.distributeLabels(0.0d, 1.0E-100d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection1.addAll(legendItemCollection2);
        java.lang.Object obj4 = legendItemCollection2.clone();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        combinedRangeXYPlot1.setDomainAxisLocation((int) 'a', axisLocation3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        boolean boolean6 = combinedRangeXYPlot1.isDomainZeroBaselineVisible();
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.chart.entity.EntityCollection entityCollection11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo(entityCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        boolean boolean14 = month10.equals((java.lang.Object) chartRenderingInfo12);
        long long15 = month10.getFirstMillisecond();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) year16);
        java.lang.Class class18 = periodAxis17.getMinorTickTimePeriodClass();
        boolean boolean19 = periodAxis17.isMinorTickMarksVisible();
        combinedRangeXYPlot1.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) periodAxis17);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot21.clearRangeMarkers(0);
        boolean boolean24 = combinedRangeXYPlot21.isNotify();
        java.awt.Paint paint25 = combinedRangeXYPlot21.getDomainZeroBaselinePaint();
        combinedRangeXYPlot1.setRangeTickBandPaint(paint25);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean2 = segmentedTimeline0.containsDomainValue(date1);
        long long3 = segmentedTimeline0.getSegmentSize();
        long long4 = segmentedTimeline0.getSegmentSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 86400000L + "'", long3 == 86400000L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 86400000L + "'", long4 == 86400000L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        java.awt.Shape shape6 = piePlot3D0.getLegendItemShape();
        java.awt.Paint paint7 = piePlot3D0.getBaseSectionOutlinePaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot3D0.getLegendLabelGenerator();
        org.jfree.chart.block.Arrangement arrangement9 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement();
        try {
            org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D0, arrangement9, (org.jfree.chart.block.Arrangement) columnArrangement10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        java.util.Locale locale10 = periodAxis9.getLocale();
        double double11 = periodAxis9.getUpperMargin();
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        java.util.List list18 = logAxis13.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge17);
        java.awt.Color color19 = java.awt.Color.red;
        logAxis13.setTickMarkPaint((java.awt.Paint) color19);
        logAxis13.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape23 = logAxis13.getDownArrow();
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity30 = new org.jfree.chart.entity.PieSectionEntity(shape23, pieDataset24, (int) 'a', 2019, (java.lang.Comparable) "red", "", "red");
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean32 = pieSectionEntity30.equals((java.lang.Object) range31);
        org.jfree.data.Range range35 = org.jfree.data.Range.shift(range31, 1.0E-8d, true);
        periodAxis9.setRange(range31, true, false);
        double double39 = range31.getCentralValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertNotNull(locale10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.5d + "'", double39 == 0.5d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = xYAreaRenderer0.getBasePositiveItemLabelPosition();
        java.lang.Boolean boolean4 = xYAreaRenderer0.getSeriesVisibleInLegend((int) (byte) 100);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer6 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean9 = xYStepRenderer6.getItemLineVisible((-1), 100);
        xYStepRenderer6.setSeriesLinesVisible((int) (short) 10, (java.lang.Boolean) true);
        java.awt.Shape shape14 = xYStepRenderer6.getLegendShape((int) (byte) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer16.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint18 = barRenderer16.getShadowPaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint20 = xYAreaRenderer19.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = xYAreaRenderer19.getBasePositiveItemLabelPosition();
        barRenderer16.setPositiveItemLabelPositionFallback(itemLabelPosition21);
        xYStepRenderer6.setSeriesNegativeItemLabelPosition(0, itemLabelPosition21, false);
        xYAreaRenderer0.setSeriesNegativeItemLabelPosition(3, itemLabelPosition21, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(shape14);
        org.junit.Assert.assertNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        java.awt.Color color3 = java.awt.Color.red;
        boolean boolean5 = color3.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot0.setRangeCrosshairPaint((java.awt.Paint) color3);
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection8 = combinedRangeXYPlot0.getDomainMarkers(layer7);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 8);
        java.lang.String str11 = valueMarker10.getLabel();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = valueMarker10.getLabelOffsetType();
        boolean boolean13 = combinedRangeXYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker10);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, serialDate2);
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getPreviousDayOfWeek((int) (byte) 1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(255);
        try {
            xYStepAreaRenderer1.setSeriesItemLabelsVisible((int) (short) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(2);
        java.awt.Paint paint5 = xYStepAreaRenderer1.getItemPaint(8, 3, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer1.getSeriesPositiveItemLabelPosition(0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo(entityCollection2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        boolean boolean5 = month1.equals((java.lang.Object) chartRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D6 = chartRenderingInfo3.getChartArea();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = chartRenderingInfo3.getPlotInfo();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(plotRenderingInfo7);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = xYAreaRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor3 = itemLabelPosition2.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor4 = itemLabelPosition2.getTextAnchor();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "hi!", "red", "red");
        java.util.List list8 = projectInfo7.getContributors();
        java.lang.String str9 = projectInfo7.getVersion();
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat(0.05d, "", false);
        logFormat3.setParseIntegerOnly(false);
        boolean boolean7 = logFormat3.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        int int5 = xYSeriesCollection3.indexOf((java.lang.Comparable) '#');
        double double7 = xYSeriesCollection3.getDomainUpperBound(false);
        xYSeries2.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection3);
        org.jfree.data.xy.XYSeries xYSeries11 = xYSeries2.createCopy((int) (short) 1, 255);
        boolean boolean12 = xYSeries2.isEmpty();
        int int14 = xYSeries2.indexOf((java.lang.Number) 86400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYSeries11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Stroke stroke2 = xYStepAreaRenderer1.getBaseOutlineStroke();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        boolean boolean4 = xYStepAreaRenderer1.removeAnnotation(xYAnnotation3);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean2 = segmentedTimeline0.containsDomainValue(date1);
        segmentedTimeline0.addException((long) (short) 100);
        segmentedTimeline0.addException((long) 255);
        long long7 = segmentedTimeline0.getSegmentSize();
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.chart.entity.EntityCollection entityCollection11 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo(entityCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        boolean boolean14 = month10.equals((java.lang.Object) chartRenderingInfo12);
        long long15 = month10.getFirstMillisecond();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month10, (org.jfree.data.time.RegularTimePeriod) year16);
        boolean boolean18 = periodAxis17.isMinorTickMarksVisible();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = periodAxis17.getFirst();
        periodAxis17.setInverted(true);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline22 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date23 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean24 = segmentedTimeline22.containsDomainValue(date23);
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        segmentedTimeline22.addException(date25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25);
        boolean boolean28 = periodAxis17.equals((java.lang.Object) date25);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment29 = segmentedTimeline0.getSegment(date25);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 86400000L + "'", long7 == 86400000L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(segmentedTimeline22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(segment29);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = barRenderer1.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer1.setBase((double) (byte) 0);
        boolean boolean6 = year0.equals((java.lang.Object) barRenderer1);
        barRenderer1.removeAnnotations();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer1.setSeriesToolTipGenerator((int) (byte) 10, categoryToolTipGenerator9);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        java.awt.Color color4 = java.awt.Color.red;
        boolean boolean6 = color4.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot1.setRangeCrosshairPaint((java.awt.Paint) color4);
        defaultXYDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) combinedRangeXYPlot1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getRangeMinorGridlineStroke();
        boolean boolean10 = xYAreaRenderer0.hasListener((java.util.EventListener) combinedRangeXYPlot8);
        java.awt.Paint paint11 = combinedRangeXYPlot8.getBackgroundPaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = combinedRangeXYPlot8.getSeriesRenderingOrder();
        java.awt.Stroke stroke13 = combinedRangeXYPlot8.getRangeMinorGridlineStroke();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        java.lang.Object obj2 = standardPieToolTipGenerator1.clone();
        boolean boolean3 = timePeriodAnchor0.equals((java.lang.Object) standardPieToolTipGenerator1);
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        textTitle9.setToolTipText("red");
        java.lang.String str12 = textTitle9.getID();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        textTitle9.setBackgroundPaint((java.awt.Paint) color13);
        textTitle9.setURLText("TextBlockAnchor.CENTER_RIGHT");
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorRight((double) 1559372400000L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
        java.lang.Object obj3 = plotRenderingInfo2.clone();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        plotRenderingInfo2.setPlotArea(rectangle2D4);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis1.centerRange((double) 0L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean18 = segmentedTimeline16.containsDomainValue(date17);
        java.util.List list19 = segmentedTimeline16.getExceptionSegments();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeZone21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = combinedRangeXYPlot20.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection22);
        org.jfree.chart.axis.LogAxis logAxis25 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.AxisState axisState27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        java.util.List list30 = logAxis25.refreshTicks(graphics2D26, axisState27, rectangle2D28, rectangleEdge29);
        org.jfree.data.time.DateRange dateRange31 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange32 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange31);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection22, list30, (org.jfree.data.Range) dateRange31, false);
        segmentedTimeline16.addExceptions(list30);
        combinedRangeXYPlot13.drawDomainTickBands(graphics2D14, rectangle2D15, list30);
        java.lang.String str37 = combinedRangeXYPlot13.getPlotType();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(segmentedTimeline16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(xYItemRenderer23);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Combined Range XYPlot" + "'", str37.equals("Combined Range XYPlot"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        java.awt.Stroke stroke6 = xYAreaRenderer0.getBaseStroke();
        boolean boolean10 = xYAreaRenderer0.isItemLabelVisible((int) (byte) 0, (int) ' ', true);
        boolean boolean11 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Stroke stroke12 = xYAreaRenderer0.getBaseStroke();
        boolean boolean13 = xYAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "item", "[size=1]", "TextBlockAnchor.CENTER_RIGHT");
        timeSeries3.setMaximumItemAge(604800000L);
        timeSeries3.clear();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        timeSeries3.add(regularTimePeriod8, (java.lang.Number) (short) 1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getTimePeriod(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("0,0,1,1", timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("AxisLabelEntity: label = hi!", timeZone2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone2);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(tickUnitSource5);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Paint paint6 = xYAreaRenderer0.getSeriesPaint(15);
        boolean boolean8 = xYAreaRenderer0.isSeriesItemLabelsVisible(0);
        xYAreaRenderer0.setItemLabelAnchorOffset((double) 60000L);
        boolean boolean11 = xYAreaRenderer0.getPlotShapes();
        java.awt.Paint paint13 = xYAreaRenderer0.getLegendTextPaint(0);
        try {
            xYAreaRenderer0.setSeriesVisible((-1), (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100L, (float) (short) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        combinedRangeXYPlot4.setDomainAxisLocation((int) 'a', axisLocation6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend(100);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity13 = new org.jfree.chart.entity.JFreeChartEntity(shape2, jFreeChart8, "", "0,0,1,1");
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int16 = color15.getGreen();
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color15);
        boolean boolean18 = jFreeChart8.equals((java.lang.Object) color17);
        boolean boolean19 = jFreeChart8.getAntiAlias();
        org.jfree.chart.event.ChartChangeListener chartChangeListener20 = null;
        try {
            jFreeChart8.removeChangeListener(chartChangeListener20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(legendTitle10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        double double7 = logAxis1.getFixedAutoRange();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getRangeMinorGridlineStroke();
        combinedRangeXYPlot8.clearAnnotations();
        java.awt.Stroke stroke11 = combinedRangeXYPlot8.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer12.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer12.clearSeriesStrokes(false);
        java.awt.Paint paint18 = xYAreaRenderer12.getSeriesPaint(15);
        boolean boolean20 = xYAreaRenderer12.isSeriesItemLabelsVisible(0);
        int int21 = combinedRangeXYPlot8.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer12);
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.AxisState axisState25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        java.util.List list28 = logAxis23.refreshTicks(graphics2D24, axisState25, rectangle2D26, rectangleEdge27);
        java.awt.Color color29 = java.awt.Color.red;
        logAxis23.setTickMarkPaint((java.awt.Paint) color29);
        logAxis23.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape33 = logAxis23.getDownArrow();
        org.jfree.chart.entity.EntityCollection entityCollection34 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = new org.jfree.chart.ChartRenderingInfo(entityCollection34);
        java.awt.geom.Rectangle2D rectangle2D36 = chartRenderingInfo35.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D37.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent41 = null;
        piePlot3D37.notifyListeners(plotChangeEvent41);
        org.jfree.chart.entity.PlotEntity plotEntity44 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D36, (org.jfree.chart.plot.Plot) piePlot3D37, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity47 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis23, (java.awt.Shape) rectangle2D36, "", "");
        java.lang.String str48 = logAxis23.getLabel();
        int int49 = combinedRangeXYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis23);
        org.jfree.data.Range range50 = logAxis23.getDefaultAutoRange();
        logAxis1.setDefaultAutoRange(range50);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(range50);
    }
}

