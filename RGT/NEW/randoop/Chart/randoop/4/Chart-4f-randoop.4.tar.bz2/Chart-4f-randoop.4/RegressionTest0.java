import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Shape shape0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity4 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart1, "hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Shape shape7 = null;
        try {
            logAxis1.setDownArrow(shape7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) color0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        double double1 = piePlot3D0.getStartAngle();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries(comparable0, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieToolTipGenerator.DEFAULT_TOOLTIP_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}: ({1}, {2})" + "'", str0.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.util.Rotation rotation4 = null;
        try {
            piePlot3D0.setDirection(rotation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.Plot plot2 = combinedRangeXYPlot0.getRootPlot();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        java.awt.geom.Rectangle2D rectangle2D6 = chartRenderingInfo5.getChartArea();
        java.awt.geom.Point2D point2D7 = null;
        org.jfree.chart.plot.PlotState plotState8 = null;
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        try {
            combinedRangeXYPlot0.draw(graphics2D3, rectangle2D6, point2D7, plotState8, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(plot2);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearRangeMarkers(0);
        boolean boolean3 = combinedRangeXYPlot0.isNotify();
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            combinedRangeXYPlot0.addRangeMarker((int) ' ', marker5, layer6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(layer6);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        try {
            org.jfree.data.xy.XYSeries xYSeries6 = xYSeriesCollection3.getSeries((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(xYItemRenderer4);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        logAxis1.setStandardTickUnits(tickUnitSource2);
        boolean boolean4 = logAxis1.isNegativeArrowVisible();
        logAxis1.pan((double) (short) 1);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = null;
        try {
            logAxis1.setTickUnit(numberTickUnit7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10, (int) (short) 100, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Paint paint2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke4 = combinedRangeXYPlot3.getRangeMinorGridlineStroke();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        java.util.List list11 = logAxis6.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
        java.awt.Color color12 = java.awt.Color.red;
        logAxis6.setTickMarkPaint((java.awt.Paint) color12);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke15 = combinedRangeXYPlot14.getRangeMinorGridlineStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 1, (double) (short) 100, paint2, stroke4, (java.awt.Paint) color12, stroke15, (float) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = combinedRangeXYPlot1.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        try {
            org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement0, (org.jfree.data.general.Dataset) xYSeriesCollection4, (java.lang.Comparable) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(xYItemRenderer5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.awt.geom.Rectangle2D rectangle2D2 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D3.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot3D3.notifyListeners(plotChangeEvent7);
        org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D2, (org.jfree.chart.plot.Plot) piePlot3D3, "");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle11 = null;
        try {
            piePlot3D3.setLabelLinkStyle(pieLabelLinkStyle11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'style' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.geom.Line2D line2D0 = null;
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo(entityCollection1);
        java.awt.geom.Rectangle2D rectangle2D3 = chartRenderingInfo2.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        org.jfree.chart.entity.PlotEntity plotEntity11 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D3, (org.jfree.chart.plot.Plot) piePlot3D4, "");
        try {
            boolean boolean12 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-1L));
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        try {
            org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem(attributedString0, "", "{0}: ({1}, {2})", "red", shape5, (java.awt.Paint) color6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 1;
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.awt.geom.Rectangle2D rectangle2D2 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D3.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot3D3.notifyListeners(plotChangeEvent7);
        org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D2, (org.jfree.chart.plot.Plot) piePlot3D3, "");
        java.lang.String str11 = plotEntity10.getShapeCoords();
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0,0,1,1" + "'", str11.equals("0,0,1,1"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.text.NumberFormat numberFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("{0}: ({1}, {2})", numberFormat1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'xFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) 10.0f, numberFormat1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        java.awt.Paint paint6 = null;
        try {
            xYAreaRenderer0.setBaseOutlinePaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double3 = xYSeries2.getMinX();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        xYSeries2.addPropertyChangeListener(propertyChangeListener4);
        xYSeries2.setMaximumItemCount((int) (short) 0);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.data.Range range4 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint3.toRangeWidth(range4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        org.jfree.data.Range range11 = null;
        try {
            logAxis1.setRangeWithMargins(range11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        int int5 = xYSeriesCollection3.indexOf((java.lang.Comparable) '#');
        double double7 = xYSeriesCollection3.getDomainUpperBound(false);
        xYSeries2.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection3);
        org.jfree.data.xy.XYSeries xYSeries11 = xYSeries2.createCopy((int) (short) 1, 255);
        boolean boolean12 = xYSeries2.isEmpty();
        try {
            xYSeries2.updateByIndex(10, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYSeries11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer7 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font2, paint5, (float) (short) -1, textMeasurer7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.util.Iterator iterator1 = legendItemCollection0.iterator();
        org.junit.Assert.assertNotNull(iterator1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo(entityCollection1);
        java.awt.geom.Rectangle2D rectangle2D3 = chartRenderingInfo2.getChartArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createAdjustedRectangle(rectangle2D3, lengthAdjustmentType4, lengthAdjustmentType5);
        double double7 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        try {
            boolean boolean6 = timeSeriesCollection2.isSelected((int) (short) -1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (-1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        java.awt.Paint paint3 = combinedRangeXYPlot0.getDomainMinorGridlinePaint();
        java.awt.Stroke stroke4 = null;
        try {
            combinedRangeXYPlot0.setRangeGridlineStroke(stroke4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        try {
            java.awt.Paint paint3 = combinedRangeXYPlot0.getQuadrantPaint((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-1) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        combinedRangeXYPlot1.setDomainAxisLocation((int) 'a', axisLocation3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        org.jfree.chart.title.LegendTitle legendTitle7 = jFreeChart5.getLegend(100);
        org.jfree.chart.title.LegendTitle legendTitle9 = jFreeChart5.getLegend((int) ' ');
        org.junit.Assert.assertNull(legendTitle7);
        org.junit.Assert.assertNull(legendTitle9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        piePlot3D0.setSimpleLabels(true);
        piePlot3D0.setPieIndex((int) (byte) 10);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        java.awt.Graphics2D graphics2D5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.chart.entity.EntityCollection entityCollection8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo(entityCollection8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        boolean boolean11 = month7.equals((java.lang.Object) chartRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo9.getChartArea();
        try {
            combinedRangeXYPlot0.drawBackground(graphics2D5, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        org.jfree.chart.entity.EntityCollection entityCollection7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo(entityCollection7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Point2D point2D10 = null;
        try {
            combinedRangeXYPlot1.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            int[] intArray6 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) timeSeriesCollection1, (int) (byte) 0, (double) (short) 1, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo4.getChartArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = logAxis9.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        java.awt.Color color15 = java.awt.Color.red;
        logAxis9.setTickMarkPaint((java.awt.Paint) color15);
        logAxis9.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis9.centerRange((double) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        try {
            barRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D5, categoryPlot6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) logAxis9, categoryDataset21, 0, (int) '#', false, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedRangeXYPlot12.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            combinedRangeXYPlot12.addRangeMarker(marker18, layer19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertNotNull(layer19);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) -1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo(entityCollection2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        boolean boolean5 = month1.equals((java.lang.Object) chartRenderingInfo3);
        long long6 = month1.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month1.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("0,0,1,1", graphics2D1, (float) 0, (float) (byte) 100, textAnchor4, (double) (-1.0f), (float) (short) 0, (float) 86400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedRangeXYPlot12.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.chart.plot.Marker marker19 = null;
        try {
            boolean boolean20 = combinedRangeXYPlot12.removeRangeMarker(marker19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYItemRenderer16);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.awt.geom.Rectangle2D rectangle2D2 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D3.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot3D3.notifyListeners(plotChangeEvent7);
        org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D2, (org.jfree.chart.plot.Plot) piePlot3D3, "");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator11 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator12 = null;
        java.lang.String str13 = plotEntity10.getImageMapAreaTag(toolTipTagFragmentGenerator11, uRLTagFragmentGenerator12);
        java.lang.String str14 = plotEntity10.getURLText();
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        try {
            int[] intArray5 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) timeSeriesCollection1, (int) (short) 1, 0.0d, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires xLow < xHigh.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        int int5 = xYSeriesCollection3.indexOf((java.lang.Comparable) '#');
        double double7 = xYSeriesCollection3.getDomainUpperBound(false);
        xYSeries2.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection3);
        try {
            xYSeriesCollection3.removeSeries((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = null;
        try {
            org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'type' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (byte) 100, (float) 0L, textAnchor4, (double) (byte) 0, 0.0f, (float) 60000L);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        combinedRangeXYPlot0.setNotify(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", class1);
        org.junit.Assert.assertNotNull(inputStream2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.awt.geom.Rectangle2D rectangle2D2 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D3.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot3D3.notifyListeners(plotChangeEvent7);
        org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D2, (org.jfree.chart.plot.Plot) piePlot3D3, "");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke12 = combinedRangeXYPlot11.getRangeMinorGridlineStroke();
        combinedRangeXYPlot11.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedRangeXYPlot11.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection14);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D2, (org.jfree.chart.plot.Plot) combinedRangeXYPlot11, "");
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        try {
            combinedRangeXYPlot11.setRangeAxisLocation(0, axisLocation19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(xYItemRenderer15);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        org.jfree.chart.text.TextFragment textFragment4 = textLine3.getLastTextFragment();
        java.awt.Paint paint5 = textFragment4.getPaint();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            textFragment4.draw(graphics2D6, (float) 5, (float) 2, textAnchor9, (float) 100L, 1.0f, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textFragment4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer5.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer5.clearSeriesStrokes(false);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer5.setBaseLegendShape(shape11);
        combinedRangeXYPlot0.setRenderer(15, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator15 = null;
        try {
            xYAreaRenderer5.setLegendItemLabelGenerator(xYSeriesLabelGenerator15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        try {
            double double5 = xYSeriesCollection0.getStartXValue((int) (short) 100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getRangeMinorGridlineStroke();
        boolean boolean10 = xYAreaRenderer0.hasListener((java.util.EventListener) combinedRangeXYPlot8);
        org.jfree.chart.plot.Marker marker11 = null;
        try {
            combinedRangeXYPlot8.addRangeMarker(marker11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        xYAreaRenderer0.setAutoPopulateSeriesShape(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        try {
            xYAreaRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 4);
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        java.util.TimeZone timeZone5 = null;
        try {
            java.util.Date date6 = dateTickUnit2.rollDate(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.Plot plot2 = combinedRangeXYPlot0.getRootPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = null;
        try {
            combinedRangeXYPlot0.setOrientation(plotOrientation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(plot2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
        java.lang.StringBuffer stringBuffer6 = null;
        java.text.FieldPosition fieldPosition7 = null;
        try {
            java.lang.StringBuffer stringBuffer8 = numberFormat0.format((java.lang.Object) "hi!", stringBuffer6, fieldPosition7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double3 = xYSeries2.getMinX();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        xYSeries2.addPropertyChangeListener(propertyChangeListener4);
        try {
            java.lang.Number number7 = xYSeries2.getX(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) '#', "red", textAnchor3, textAnchor4, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_ITEM_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "item" + "'", str0.equals("item"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = xYAreaRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint3 = null;
        try {
            xYAreaRenderer0.setBaseItemLabelPaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("red", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearRangeMarkers(0);
        boolean boolean3 = combinedRangeXYPlot0.isNotify();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.Font font8 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color9 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("hi!", font8, (java.awt.Paint) color9);
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("0,0,1,1", font8, (org.jfree.chart.plot.Plot) polarPlot11, false);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("0,0,1,1", font8);
        textTitle14.setToolTipText("red");
        java.lang.String str17 = textTitle14.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo(entityCollection19);
        java.awt.geom.Rectangle2D rectangle2D21 = chartRenderingInfo20.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D22 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D22.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = null;
        piePlot3D22.notifyListeners(plotChangeEvent26);
        org.jfree.chart.entity.PlotEntity plotEntity29 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D21, (org.jfree.chart.plot.Plot) piePlot3D22, "");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke31 = combinedRangeXYPlot30.getRangeMinorGridlineStroke();
        combinedRangeXYPlot30.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection33 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = combinedRangeXYPlot30.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection33);
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D21, (org.jfree.chart.plot.Plot) combinedRangeXYPlot30, "");
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets18.createOutsetRectangle(rectangle2D21);
        textTitle14.setBounds(rectangle2D21);
        try {
            combinedRangeXYPlot0.drawBackground(graphics2D4, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(xYItemRenderer34);
        org.junit.Assert.assertNotNull(rectangle2D37);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Color color0 = java.awt.Color.darkGray;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-12566464) + "'", int1 == (-12566464));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        java.lang.String str1 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str1.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("0,0,1,1", font2, (org.jfree.chart.plot.Plot) polarPlot5, false);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        polarPlot5.setAxis(valueAxis8);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        java.io.ObjectOutputStream objectOutputStream2 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke1, objectOutputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 10.0d, (double) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) ' ', 0, 255);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        textTitle9.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        double double13 = textTitle9.getHeight();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        int int5 = xYSeriesCollection3.indexOf((java.lang.Comparable) '#');
        double double7 = xYSeriesCollection3.getDomainUpperBound(false);
        xYSeries2.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection3);
        org.jfree.data.xy.XYSeries xYSeries11 = xYSeries2.createCopy((int) (short) 1, 255);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        xYSeries2.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYSeries11);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            java.lang.Number number3 = xYSeriesCollection0.getEndX(8, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10, 255, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            combinedRangeXYPlot0.addRangeMarker((int) ' ', marker5, layer6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(layer6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 1, (double) 10, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getDomainUpperBound(false);
        double double5 = xYSeriesCollection0.getIntervalPositionFactor();
        double double6 = xYSeriesCollection0.getIntervalPositionFactor();
        try {
            int[] intArray10 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (int) (short) 0, 0.0d, (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("PieLabelLinkStyle.STANDARD", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedRangeXYPlot12.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        java.lang.String str18 = plotEntity17.getURLText();
        java.lang.String str19 = plotEntity17.toString();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PlotEntity: tooltip = null" + "'", str19.equals("PlotEntity: tooltip = null"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedRangeXYPlot12.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        java.util.List list18 = combinedRangeXYPlot12.getAnnotations();
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = null;
        logAxis21.setStandardTickUnits(tickUnitSource22);
        boolean boolean24 = logAxis21.isNegativeArrowVisible();
        logAxis21.pan((double) (short) 1);
        combinedRangeXYPlot12.setDomainAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) logAxis21, false);
        logAxis21.setVisible(true);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        java.awt.Shape shape6 = piePlot3D0.getLegendItemShape();
        double double8 = piePlot3D0.getExplodePercent((java.lang.Comparable) 15);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_ALTERNATE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.Font font0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        combinedRangeXYPlot0.setDomainAxisLocation((int) 'a', axisLocation2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        try {
            combinedRangeXYPlot0.setDomainAxisLocation(0, axisLocation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        boolean boolean4 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        logAxis6.setStandardTickUnits(tickUnitSource7);
        boolean boolean9 = logAxis6.isNegativeArrowVisible();
        logAxis6.pan((double) (short) 1);
        combinedRangeXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis6);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle13 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        boolean boolean14 = logAxis6.equals((java.lang.Object) pieLabelLinkStyle13);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(4);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = chartRenderingInfo4.getChartArea();
        org.jfree.chart.RenderingSource renderingSource7 = chartRenderingInfo4.getRenderingSource();
        objectList1.set((int) ' ', (java.lang.Object) renderingSource7);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNull(renderingSource7);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedRangeXYPlot12.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        org.jfree.chart.plot.XYPlot xYPlot18 = null;
        try {
            combinedRangeXYPlot12.add(xYPlot18, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYItemRenderer16);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.KeyedValues keyedValues0 = null;
        try {
            org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset(keyedValues0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'data' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke5 = barRenderer0.getItemOutlineStroke((int) '4', (int) (byte) 1, true);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = null;
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.chart.entity.EntityCollection entityCollection10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo(entityCollection10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        boolean boolean13 = month9.equals((java.lang.Object) chartRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D14 = chartRenderingInfo11.getChartArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("red");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = categoryAxis17.getCategoryJava2DCoordinate(categoryAnchor18, 1, 8, rectangle2D21, rectangleEdge22);
        org.jfree.chart.axis.LogAxis logAxis25 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.AxisState axisState27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        java.util.List list30 = logAxis25.refreshTicks(graphics2D26, axisState27, rectangle2D28, rectangleEdge29);
        java.awt.Color color31 = java.awt.Color.red;
        logAxis25.setTickMarkPaint((java.awt.Paint) color31);
        logAxis25.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis25.centerRange((double) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        try {
            barRenderer0.drawItem(graphics2D6, categoryItemRendererState7, rectangle2D14, categoryPlot15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) logAxis25, categoryDataset37, (int) (byte) 100, (int) (short) 1, false, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getNumberInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}: ({1}, {2})", numberFormat1, numberFormat2);
        java.text.NumberFormat numberFormat4 = standardPieSectionLabelGenerator3.getPercentFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        textTitle9.setToolTipText("red");
        java.lang.String str12 = textTitle9.getID();
        java.awt.Graphics2D graphics2D13 = null;
        try {
            org.jfree.chart.util.Size2D size2D14 = textTitle9.arrange(graphics2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        try {
            xYAreaRenderer0.addAnnotation(xYAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        try {
            int int5 = timeSeriesCollection2.getItemCount(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimWidth(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.0d) + "'", double2 == (-2.0d));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("0,0,1,1");
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = null;
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = logAxis5.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
        java.awt.Color color11 = java.awt.Color.red;
        logAxis5.setTickMarkPaint((java.awt.Paint) color11);
        org.jfree.data.Range range13 = logAxis5.getRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (org.jfree.data.Range) dateRange1, lengthConstraintType2, (double) (byte) 0, range13, lengthConstraintType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(range13);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.util.Date date2 = regularTimePeriod1.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            int int4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection0, 0, (double) '4', 90.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '#', (double) (short) 0, (double) 10, (double) (-1.0f));
        double double6 = rectangleInsets4.trimWidth((double) 5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.0d + "'", double6 == 6.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        try {
            int int7 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) timeSeriesCollection2, 255, (double) (byte) 1, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (255).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer3);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        java.lang.String str4 = rectangleConstraint3.toString();
        org.jfree.data.Range range5 = rectangleConstraint3.getHeightRange();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str4.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        java.awt.Color color7 = java.awt.Color.CYAN;
        xYAreaRenderer0.setSeriesPaint((int) (short) 10, (java.awt.Paint) color7);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation9 = null;
        boolean boolean10 = xYAreaRenderer0.removeAnnotation(xYAnnotation9);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 0.05d, (double) (-2208960000000L), 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Paint paint1 = null;
        try {
            xYStepRenderer0.setBaseOutlinePaint(paint1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = xYAreaRenderer0.getBasePositiveItemLabelPosition();
        java.lang.Boolean boolean4 = xYAreaRenderer0.getSeriesVisibleInLegend((int) (byte) 100);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation5 = null;
        try {
            xYAreaRenderer0.addAnnotation(xYAnnotation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        java.util.Currency currency1 = null;
        try {
            numberFormat0.setCurrency(currency1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("0,0,1,1", font2, (org.jfree.chart.plot.Plot) polarPlot5, false);
        jFreeChart7.setTitle("red");
        org.jfree.chart.event.ChartChangeListener chartChangeListener10 = null;
        try {
            jFreeChart7.addChangeListener(chartChangeListener10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        textTitle9.setToolTipText("red");
        java.lang.String str12 = textTitle9.getID();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo15.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D17.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        piePlot3D17.notifyListeners(plotChangeEvent21);
        org.jfree.chart.entity.PlotEntity plotEntity24 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D16, (org.jfree.chart.plot.Plot) piePlot3D17, "");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke26 = combinedRangeXYPlot25.getRangeMinorGridlineStroke();
        combinedRangeXYPlot25.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection28 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = combinedRangeXYPlot25.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection28);
        org.jfree.chart.entity.PlotEntity plotEntity31 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D16, (org.jfree.chart.plot.Plot) combinedRangeXYPlot25, "");
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets13.createOutsetRectangle(rectangle2D16);
        textTitle9.setBounds(rectangle2D16);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        textTitle9.draw(graphics2D34, rectangle2D35);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(xYItemRenderer29);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.awt.Color color1 = java.awt.Color.getColor("PieLabelLinkStyle.STANDARD");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100L, (float) (short) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        combinedRangeXYPlot4.setDomainAxisLocation((int) 'a', axisLocation6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend(100);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity13 = new org.jfree.chart.entity.JFreeChartEntity(shape2, jFreeChart8, "", "0,0,1,1");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator14 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator15 = null;
        try {
            java.lang.String str16 = jFreeChartEntity13.getImageMapAreaTag(toolTipTagFragmentGenerator14, uRLTagFragmentGenerator15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(legendTitle10);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 4);
        double double3 = dateTickUnit2.getSize();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4000.0d + "'", double3 == 4000.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        java.lang.String str2 = rectangleConstraint0.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str2.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        java.util.TimeZone timeZone10 = null;
        try {
            periodAxis9.setTimeZone(timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES_AND_LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange0);
        boolean boolean4 = dateRange1.intersects((double) ' ', (double) 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        logAxis1.setStandardTickUnits(tickUnitSource2);
        logAxis1.setVisible(false);
        logAxis1.setLabelAngle((double) 0L);
        double double8 = logAxis1.getSmallestValue();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0E-100d + "'", double8 == 1.0E-100d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getRangeMinorGridlineStroke();
        boolean boolean10 = xYAreaRenderer0.hasListener((java.util.EventListener) combinedRangeXYPlot8);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint13 = xYAreaRenderer12.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYAreaRenderer12.getBasePositiveItemLabelPosition();
        double double15 = itemLabelPosition14.getAngle();
        try {
            xYAreaRenderer0.setSeriesNegativeItemLabelPosition((-12566464), itemLabelPosition14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        java.lang.String str2 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.CENTER_RIGHT" + "'", str1.equals("TextBlockAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextBlockAnchor.CENTER_RIGHT" + "'", str2.equals("TextBlockAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        xYAreaRenderer0.setAutoPopulateSeriesShape(true);
        int int7 = xYAreaRenderer0.getPassCount();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint10 = xYAreaRenderer9.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYAreaRenderer9.getBasePositiveItemLabelPosition();
        try {
            xYAreaRenderer0.setSeriesPositiveItemLabelPosition((int) (short) -1, itemLabelPosition11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        int int5 = xYSeriesCollection3.indexOf((java.lang.Comparable) '#');
        double double7 = xYSeriesCollection3.getDomainUpperBound(false);
        xYSeries2.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection3);
        org.jfree.data.xy.XYSeries xYSeries11 = xYSeries2.createCopy((int) (short) 1, 255);
        xYSeries11.setDescription("{0}: ({1}, {2})");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYSeries11);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        java.awt.Shape shape9 = xYAreaRenderer0.getItemShape(5, 0, false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedRangeXYPlot12.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = null;
        combinedRangeXYPlot12.axisChanged(axisChangeEvent19);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYItemRenderer16);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.Marker marker4 = null;
        try {
            boolean boolean5 = combinedRangeXYPlot0.removeRangeMarker(marker4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        combinedRangeXYPlot1.clearDomainAxes();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange0);
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange1, (double) 86400000L);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        boolean boolean4 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        logAxis6.setStandardTickUnits(tickUnitSource7);
        boolean boolean9 = logAxis6.isNegativeArrowVisible();
        logAxis6.pan((double) (short) 1);
        combinedRangeXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis6);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        combinedRangeXYPlot0.plotChanged(plotChangeEvent13);
        try {
            combinedRangeXYPlot0.setBackgroundImageAlpha((float) 86400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "hi!", "red", "red");
        projectInfo7.setLicenceText("hi!");
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange0);
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange2);
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange0, (-1.0d));
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle1 = piePlot3D0.getLabelLinkStyle();
        java.awt.Paint paint2 = null;
        try {
            piePlot3D0.setLabelPaint(paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieLabelLinkStyle1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeZone2);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = combinedRangeXYPlot1.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        java.util.List list11 = logAxis6.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange12);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3, list11, (org.jfree.data.Range) dateRange12, false);
        boolean boolean16 = day0.equals((java.lang.Object) false);
        java.util.Calendar calendar17 = null;
        try {
            long long18 = day0.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setLabel("red");
        logAxis1.setFixedAutoRange((double) (byte) 10);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(2);
        java.awt.Paint paint5 = xYStepAreaRenderer1.getItemPaint(8, 3, true);
        xYStepAreaRenderer1.setShapesVisible(true);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean3 = segmentedTimeline1.containsDomainValue(date2);
        java.util.List list4 = segmentedTimeline1.getExceptionSegments();
        segmentedTimeline0.addExceptions(list4);
        long long6 = segmentedTimeline0.getSegmentsGroupSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604800000L + "'", long6 == 604800000L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range(4.0d, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (4.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer0.setShadowYOffset((double) 100L);
        boolean boolean5 = barRenderer0.getBaseItemLabelsVisible();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = null;
        logAxis9.setStandardTickUnits(tickUnitSource10);
        boolean boolean12 = logAxis9.isNegativeArrowVisible();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer13 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer13.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer13.clearSeriesStrokes(false);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        combinedRangeXYPlot20.setDomainAxisLocation((int) 'a', axisLocation22);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot20);
        boolean boolean25 = combinedRangeXYPlot20.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.LogAxis logAxis27 = new org.jfree.chart.axis.LogAxis("");
        logAxis27.setPositiveArrowVisible(false);
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.jfree.chart.entity.EntityCollection entityCollection32 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = new org.jfree.chart.ChartRenderingInfo(entityCollection32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo33);
        boolean boolean35 = month31.equals((java.lang.Object) chartRenderingInfo33);
        java.awt.geom.Rectangle2D rectangle2D36 = chartRenderingInfo33.getChartArea();
        xYAreaRenderer13.fillDomainGridBand(graphics2D18, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot20, (org.jfree.chart.axis.ValueAxis) logAxis27, rectangle2D36, (double) '4', 100.0d);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke42 = combinedRangeXYPlot41.getRangeMinorGridlineStroke();
        combinedRangeXYPlot41.clearAnnotations();
        boolean boolean44 = combinedRangeXYPlot41.isDomainPannable();
        boolean boolean45 = combinedRangeXYPlot41.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis47 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource48 = null;
        logAxis47.setStandardTickUnits(tickUnitSource48);
        boolean boolean50 = logAxis47.isNegativeArrowVisible();
        logAxis47.pan((double) (short) 1);
        combinedRangeXYPlot41.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis47);
        java.awt.Paint paint54 = logAxis47.getAxisLinePaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer55 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke57 = combinedRangeXYPlot56.getRangeMinorGridlineStroke();
        combinedRangeXYPlot56.clearAnnotations();
        combinedRangeXYPlot56.configureDomainAxes();
        xYAreaRenderer55.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot56);
        java.awt.Stroke stroke61 = xYAreaRenderer55.getBaseStroke();
        try {
            barRenderer0.drawRangeLine(graphics2D6, categoryPlot7, (org.jfree.chart.axis.ValueAxis) logAxis9, rectangle2D36, 0.0d, paint54, stroke61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(stroke61);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesShapesVisible(0, (java.lang.Boolean) false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            xYStepRenderer0.addAnnotation(xYAnnotation4, layer5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer5);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getNumberInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}: ({1}, {2})", numberFormat1, numberFormat2);
        java.math.RoundingMode roundingMode4 = numberFormat2.getRoundingMode();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode4.equals(java.math.RoundingMode.HALF_EVEN));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        try {
            java.lang.Number number2 = defaultPieDataset0.getValue((java.lang.Comparable) 4);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 4");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        java.lang.String str9 = org.jfree.chart.util.PaintUtilities.colorToString(color7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        boolean boolean11 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color7, (java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "red" + "'", str9.equals("red"));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint3.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toFixedHeight((double) 100);
        try {
            org.jfree.chart.util.Size2D size2D7 = columnArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        xYSeries3.setKey((java.lang.Comparable) year4);
        try {
            org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) year4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        combinedRangeXYPlot0.setDomainMinorGridlinesVisible(false);
        java.lang.String str7 = combinedRangeXYPlot0.getPlotType();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo10.getChartArea();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D12);
        org.jfree.chart.axis.LogAxis logAxis15 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.AxisState axisState17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        java.util.List list20 = logAxis15.refreshTicks(graphics2D16, axisState17, rectangle2D18, rectangleEdge19);
        java.awt.Color color21 = java.awt.Color.red;
        logAxis15.setTickMarkPaint((java.awt.Paint) color21);
        logAxis15.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape25 = logAxis15.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke27 = combinedRangeXYPlot26.getRangeMinorGridlineStroke();
        combinedRangeXYPlot26.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection29 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = combinedRangeXYPlot26.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection29);
        org.jfree.chart.entity.PlotEntity plotEntity31 = new org.jfree.chart.entity.PlotEntity(shape25, (org.jfree.chart.plot.Plot) combinedRangeXYPlot26);
        combinedRangeXYPlot26.clearAnnotations();
        java.awt.geom.Point2D point2D33 = combinedRangeXYPlot26.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState34 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        try {
            combinedRangeXYPlot0.draw(graphics2D8, rectangle2D12, point2D33, plotState34, plotRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Combined Range XYPlot" + "'", str7.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(xYItemRenderer30);
        org.junit.Assert.assertNotNull(point2D33);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        piePlot3D0.markerChanged(markerChangeEvent6);
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        xYSeries10.setKey((java.lang.Comparable) year11);
        java.awt.Stroke stroke13 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) year11);
        float float14 = piePlot3D0.getBackgroundImageAlpha();
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot3D0.getDatasetGroup();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = piePlot3D0.getLabelLinkStyle();
        piePlot3D0.setCircular(false, false);
        int int11 = piePlot3D0.getBackgroundImageAlignment();
        double double12 = piePlot3D0.getShadowXOffset();
        org.jfree.chart.plot.PiePlot3D piePlot3D13 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D13.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        piePlot3D13.notifyListeners(plotChangeEvent17);
        java.awt.Shape shape19 = piePlot3D13.getLegendItemShape();
        java.awt.Paint paint20 = piePlot3D13.getBaseSectionOutlinePaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator21 = piePlot3D13.getLegendLabelGenerator();
        piePlot3D0.setLegendLabelGenerator(pieSectionLabelGenerator21);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator21);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        boolean boolean4 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        int int5 = combinedRangeXYPlot0.getWeight();
        combinedRangeXYPlot0.clearSelection();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        boolean boolean4 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        int int5 = combinedRangeXYPlot0.getWeight();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        combinedRangeXYPlot7.setDomainAxisLocation((int) 'a', axisLocation9);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        org.jfree.chart.title.LegendTitle legendTitle13 = jFreeChart11.getLegend(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer14.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke19 = barRenderer14.getItemOutlineStroke((int) '4', (int) (byte) 1, true);
        jFreeChart11.setBorderStroke(stroke19);
        combinedRangeXYPlot0.setRangeMinorGridlineStroke(stroke19);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(legendTitle13);
        org.junit.Assert.assertNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        xYAreaRenderer0.setAutoPopulateSeriesShape(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        combinedRangeXYPlot8.setDomainAxisLocation((int) 'a', axisLocation10);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart12.getLegend(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer15.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke20 = barRenderer15.getItemOutlineStroke((int) '4', (int) (byte) 1, true);
        jFreeChart12.setBorderStroke(stroke20);
        xYAreaRenderer0.setBaseStroke(stroke20);
        org.junit.Assert.assertNull(legendTitle14);
        org.junit.Assert.assertNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint1.toFixedHeight((double) 100);
        java.lang.String str4 = rectangleConstraint3.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=100.0]" + "'", str4.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=100.0]"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
        java.awt.Image image8 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "{0}: ({1}, {2})", image8, "hi!", "0,0,1,1", "");
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) projectInfo12);
        java.lang.String str14 = basicProjectInfo4.getVersion();
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 4);
        int int3 = dateTickUnit2.getMultiple();
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        boolean boolean11 = dateTickUnit2.equals((java.lang.Object) piePlot3D4);
        double double12 = dateTickUnit2.getSize();
        org.jfree.data.xy.XYSeries xYSeries15 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) double12, true, true);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4000.0d + "'", double12 == 4000.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Image image1 = org.jfree.chart.util.SerialUtilities.readImage(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getPlotShapes();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean3 = segmentedTimeline1.containsDomainValue(date2);
        java.util.List list4 = segmentedTimeline1.getExceptionSegments();
        segmentedTimeline0.addExceptions(list4);
        java.util.Date date6 = null;
        try {
            segmentedTimeline0.addBaseTimelineException(date6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot3D0.getDatasetGroup();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = piePlot3D0.getLabelLinkStyle();
        piePlot3D0.setCircular(false, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        piePlot3D0.setDrawingSupplier(drawingSupplier11);
        piePlot3D0.setCircular(true);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        try {
            xYAreaRenderer0.setLegendItemLabelGenerator(xYSeriesLabelGenerator8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo(entityCollection5);
        java.awt.geom.Rectangle2D rectangle2D7 = chartRenderingInfo6.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D8.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        piePlot3D8.notifyListeners(plotChangeEvent12);
        org.jfree.chart.entity.PlotEntity plotEntity15 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D7, (org.jfree.chart.plot.Plot) piePlot3D8, "");
        java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets4.createInsetRectangle(rectangle2D7);
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D17.setCircular(true, true);
        piePlot3D17.setSimpleLabels(true);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        piePlot3D17.setDataset(pieDataset23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        java.awt.geom.Rectangle2D rectangle2D28 = chartRenderingInfo27.getChartArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets25.createAdjustedRectangle(rectangle2D28, lengthAdjustmentType29, lengthAdjustmentType30);
        piePlot3D17.setLabelPadding(rectangleInsets25);
        java.awt.Stroke stroke33 = piePlot3D17.getLabelOutlineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot34 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke35 = combinedRangeXYPlot34.getRangeMinorGridlineStroke();
        combinedRangeXYPlot34.clearAnnotations();
        boolean boolean37 = combinedRangeXYPlot34.isDomainPannable();
        boolean boolean38 = combinedRangeXYPlot34.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis40 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource41 = null;
        logAxis40.setStandardTickUnits(tickUnitSource41);
        boolean boolean43 = logAxis40.isNegativeArrowVisible();
        logAxis40.pan((double) (short) 1);
        combinedRangeXYPlot34.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis40);
        java.awt.Paint paint47 = logAxis40.getAxisLinePaint();
        try {
            org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem(attributedString0, "Combined Range XYPlot", "HorizontalAlignment.CENTER", "PlotEntity: tooltip = null", (java.awt.Shape) rectangle2D16, stroke33, paint47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState3 = xYSeriesCollection0.getSelectionState();
        try {
            java.lang.Number number6 = xYSeriesCollection0.getStartX(2, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(xYDatasetSelectionState3);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        legendItem15.setURLText("item");
        legendItem15.setDescription("hi!");
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        piePlot3D0.setSimpleLabels(true);
        piePlot3D0.clearSectionOutlinePaints(true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = null;
        piePlot3D0.setDrawingSupplier(drawingSupplier8);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        combinedRangeXYPlot1.setDomainAxisLocation((int) 'a', axisLocation3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        jFreeChart5.setBackgroundImageAlignment(100);
        jFreeChart5.setBorderVisible(true);
        jFreeChart5.setTitle("Combined Range XYPlot");
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        org.jfree.chart.text.TextFragment textFragment4 = textLine3.getLastTextFragment();
        java.awt.Paint paint5 = textFragment4.getPaint();
        float float6 = textFragment4.getBaselineOffset();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            float float9 = textFragment4.calculateBaselineOffset(graphics2D7, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textFragment4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        boolean boolean7 = month3.equals((java.lang.Object) chartRenderingInfo5);
        long long8 = month3.getFirstMillisecond();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month3, (org.jfree.data.time.RegularTimePeriod) year9);
        java.util.Locale locale11 = periodAxis10.getLocale();
        java.lang.ClassLoader classLoader12 = null;
        try {
            java.util.ResourceBundle resourceBundle13 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", locale11, classLoader12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559372400000L + "'", long8 == 1559372400000L);
        org.junit.Assert.assertNotNull(locale11);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYAreaRenderer0.setSeriesURLGenerator(8, xYURLGenerator3, false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        combinedRangeXYPlot8.setDomainAxisLocation((int) 'a', axisLocation10);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        boolean boolean13 = combinedRangeXYPlot8.isDomainZeroBaselineVisible();
        combinedRangeXYPlot8.setDomainPannable(false);
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.AxisState axisState19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        java.util.List list22 = logAxis17.refreshTicks(graphics2D18, axisState19, rectangle2D20, rectangleEdge21);
        java.awt.Color color23 = java.awt.Color.red;
        logAxis17.setTickMarkPaint((java.awt.Paint) color23);
        logAxis17.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape27 = logAxis17.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot28 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke29 = combinedRangeXYPlot28.getRangeMinorGridlineStroke();
        combinedRangeXYPlot28.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection31 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = combinedRangeXYPlot28.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection31);
        org.jfree.chart.entity.PlotEntity plotEntity33 = new org.jfree.chart.entity.PlotEntity(shape27, (org.jfree.chart.plot.Plot) combinedRangeXYPlot28);
        java.util.List list34 = combinedRangeXYPlot28.getAnnotations();
        org.jfree.chart.axis.LogAxis logAxis37 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = null;
        logAxis37.setStandardTickUnits(tickUnitSource38);
        boolean boolean40 = logAxis37.isNegativeArrowVisible();
        logAxis37.pan((double) (short) 1);
        combinedRangeXYPlot28.setDomainAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) logAxis37, false);
        double double46 = logAxis37.calculateValue((double) 1559372400000L);
        org.jfree.chart.plot.Marker marker47 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection49 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = new org.jfree.chart.ChartRenderingInfo(entityCollection49);
        java.awt.geom.Rectangle2D rectangle2D51 = chartRenderingInfo50.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D52 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D52.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent56 = null;
        piePlot3D52.notifyListeners(plotChangeEvent56);
        org.jfree.chart.entity.PlotEntity plotEntity59 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D51, (org.jfree.chart.plot.Plot) piePlot3D52, "");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot60 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke61 = combinedRangeXYPlot60.getRangeMinorGridlineStroke();
        combinedRangeXYPlot60.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection63 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer64 = combinedRangeXYPlot60.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection63);
        org.jfree.chart.entity.PlotEntity plotEntity66 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D51, (org.jfree.chart.plot.Plot) combinedRangeXYPlot60, "");
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets48.createOutsetRectangle(rectangle2D51);
        xYAreaRenderer0.drawDomainMarker(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot8, (org.jfree.chart.axis.ValueAxis) logAxis37, marker47, rectangle2D51);
        try {
            combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) -1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(xYItemRenderer32);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + Double.POSITIVE_INFINITY + "'", double46 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNull(xYItemRenderer64);
        org.junit.Assert.assertNotNull(rectangle2D67);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setMaximumLabelWidth(0.0d);
        java.awt.Paint paint4 = piePlot3D0.getSectionPaint((java.lang.Comparable) "RectangleAnchor.BOTTOM_LEFT");
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate4 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, false);
        try {
            double double7 = intervalXYDelegate4.getEndXValue(15, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "", image3, "hi!", "red", "red");
        java.util.List list8 = projectInfo7.getContributors();
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo7.getLibraries();
        org.junit.Assert.assertNull(list8);
        org.junit.Assert.assertNotNull(libraryArray9);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = null;
        logAxis2.setStandardTickUnits(tickUnitSource3);
        boolean boolean5 = logAxis2.isNegativeArrowVisible();
        logAxis2.pan((double) (short) 1);
        java.lang.String str8 = logAxis2.getLabelURL();
        java.awt.Font font9 = logAxis2.getLabelFont();
        java.awt.Color color10 = java.awt.Color.YELLOW;
        java.awt.Color color11 = color10.darker();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer14 = new org.jfree.chart.text.G2TextMeasurer(graphics2D13);
        try {
            org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("Combined Range XYPlot", font9, (java.awt.Paint) color11, (float) 8, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = logAxis2.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = java.awt.Color.red;
        logAxis2.setTickMarkPaint((java.awt.Paint) color8);
        logAxis2.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape12 = logAxis2.getDownArrow();
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        java.awt.geom.Rectangle2D rectangle2D15 = chartRenderingInfo14.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D16 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D16.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = null;
        piePlot3D16.notifyListeners(plotChangeEvent20);
        org.jfree.chart.entity.PlotEntity plotEntity23 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D15, (org.jfree.chart.plot.Plot) piePlot3D16, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity26 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis2, (java.awt.Shape) rectangle2D15, "", "");
        boolean boolean27 = standardPieSectionLabelGenerator0.equals((java.lang.Object) logAxis2);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset28 = new org.jfree.data.general.DefaultPieDataset();
        defaultPieDataset28.setValue((java.lang.Comparable) 255, 12.0d);
        java.util.Date date33 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
        org.jfree.chart.entity.EntityCollection entityCollection35 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = new org.jfree.chart.ChartRenderingInfo(entityCollection35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        boolean boolean38 = month34.equals((java.lang.Object) chartRenderingInfo36);
        long long39 = month34.getFirstMillisecond();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis41 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month34, (org.jfree.data.time.RegularTimePeriod) year40);
        try {
            java.lang.String str42 = standardPieSectionLabelGenerator0.generateSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset28, (java.lang.Comparable) month34);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: June 2019");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1559372400000L + "'", long39 == 1559372400000L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean3 = xYStepRenderer0.getItemLineVisible((-1), 100);
        int int4 = xYStepRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("0,0,1,1", font2, (org.jfree.chart.plot.Plot) polarPlot5, false);
        jFreeChart7.setTitle("red");
        java.awt.RenderingHints renderingHints10 = null;
        try {
            jFreeChart7.setRenderingHints(renderingHints10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        combinedRangeXYPlot0.configureDomainAxes();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        try {
            combinedRangeXYPlot0.addAnnotation(xYAnnotation4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100L, (float) (short) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        combinedRangeXYPlot5.setDomainAxisLocation((int) 'a', axisLocation7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot5);
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart9.getLegend(100);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity14 = new org.jfree.chart.entity.JFreeChartEntity(shape3, jFreeChart9, "", "0,0,1,1");
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int17 = color16.getGreen();
        java.awt.Color color18 = java.awt.Color.getColor("hi!", color16);
        boolean boolean19 = jFreeChart9.equals((java.lang.Object) color18);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str21 = chartChangeEventType20.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItemCollection0, jFreeChart9, chartChangeEventType20);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = jFreeChart9.getPadding();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(legendTitle11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str21.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertNotNull(rectangleInsets23);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint2 = barRenderer0.getShadowPaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint4 = xYAreaRenderer3.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYAreaRenderer3.getBasePositiveItemLabelPosition();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition5);
        barRenderer0.setBase((double) 60000L);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        combinedRangeXYPlot0.plotChanged(plotChangeEvent6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = combinedRangeXYPlot0.getRenderer();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(xYItemRenderer8);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.util.SortOrder sortOrder1 = null;
        try {
            defaultPieDataset0.sortByValues(sortOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("red");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) ' ', (double) 0L, (double) 100L, 90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        org.jfree.chart.entity.EntityCollection entityCollection14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo(entityCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = chartRenderingInfo15.getChartArea();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D17);
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets13.createInsetRectangle(rectangle2D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        try {
            double double21 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) month4, (java.lang.Comparable) 0L, categoryDataset6, 100.0d, rectangle2D17, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        logAxis1.setAutoRangeMinimumSize(100.0d, false);
        java.lang.String str5 = logAxis1.getLabelURL();
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = logAxis1.getStandardTickUnits();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(tickUnitSource6);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearRangeMarkers(0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke4 = combinedRangeXYPlot3.getRangeMinorGridlineStroke();
        combinedRangeXYPlot3.clearAnnotations();
        combinedRangeXYPlot3.configureDomainAxes();
        combinedRangeXYPlot3.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation8 = combinedRangeXYPlot3.getDomainAxisLocation();
        combinedRangeXYPlot0.setRangeAxisLocation(axisLocation8, true);
        combinedRangeXYPlot0.setBackgroundImageAlignment(3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
//        java.util.TimeZone timeZone2 = null;
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeZone2);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = combinedRangeXYPlot1.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
//        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
//        java.awt.Graphics2D graphics2D7 = null;
//        org.jfree.chart.axis.AxisState axisState8 = null;
//        java.awt.geom.Rectangle2D rectangle2D9 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
//        java.util.List list11 = logAxis6.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge10);
//        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange();
//        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange12);
//        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3, list11, (org.jfree.data.Range) dateRange12, false);
//        boolean boolean16 = day0.equals((java.lang.Object) false);
//        java.lang.String str17 = day0.toString();
//        org.junit.Assert.assertNull(xYItemRenderer4);
//        org.junit.Assert.assertNotNull(list11);
//        org.junit.Assert.assertNull(range15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        java.awt.Stroke stroke6 = xYAreaRenderer0.getBaseStroke();
        java.awt.Shape shape8 = null;
        xYAreaRenderer0.setSeriesShape(10, shape8);
        java.awt.Shape shape11 = xYAreaRenderer0.getLegendShape((int) (short) -1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(shape11);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer1.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer1.clearSeriesStrokes(false);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer1.setBaseLegendShape(shape7);
        boolean boolean9 = rotation0.equals((java.lang.Object) shape7);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint11 = xYAreaRenderer10.getBaseItemLabelPaint();
        boolean boolean12 = rotation0.equals((java.lang.Object) xYAreaRenderer10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = xYAreaRenderer10.getSeriesToolTipGenerator((int) 'a');
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(xYToolTipGenerator14);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.ASCENDING;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint1.toFixedHeight((double) 100);
        org.jfree.data.Range range4 = rectangleConstraint1.getWidthRange();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (-12566464));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.geom.Line2D line2D0 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo(entityCollection2);
        java.awt.geom.Rectangle2D rectangle2D4 = chartRenderingInfo3.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D5.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        piePlot3D5.notifyListeners(plotChangeEvent9);
        org.jfree.chart.entity.PlotEntity plotEntity12 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D4, (org.jfree.chart.plot.Plot) piePlot3D5, "");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke14 = combinedRangeXYPlot13.getRangeMinorGridlineStroke();
        combinedRangeXYPlot13.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection16 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = combinedRangeXYPlot13.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection16);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D4, (org.jfree.chart.plot.Plot) combinedRangeXYPlot13, "");
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets1.createOutsetRectangle(rectangle2D4);
        try {
            boolean boolean21 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(xYItemRenderer17);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color10);
        textTitle9.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.jfree.chart.entity.EntityCollection entityCollection15 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo(entityCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        boolean boolean18 = month14.equals((java.lang.Object) chartRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D19 = chartRenderingInfo16.getChartArea();
        textTitle9.setBounds(rectangle2D19);
        textTitle9.setMaximumLinesToDisplay((int) (short) 100);
        double double23 = textTitle9.getWidth();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean2 = segmentedTimeline0.containsDomainValue(date1);
        java.util.List list3 = segmentedTimeline0.getExceptionSegments();
        long long5 = segmentedTimeline0.getTimeFromLong(0L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = null;
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        long long4 = year2.getLastMillisecond();
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("RectangleAnchor.BOTTOM_LEFT", regularTimePeriod1, (org.jfree.data.time.RegularTimePeriod) year2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.awt.Color color0 = java.awt.Color.magenta;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer0.setBaseLegendShape(shape6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke9 = combinedRangeXYPlot8.getRangeMinorGridlineStroke();
        boolean boolean10 = xYAreaRenderer0.hasListener((java.util.EventListener) combinedRangeXYPlot8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        boolean boolean15 = combinedRangeXYPlot12.isDomainPannable();
        boolean boolean16 = combinedRangeXYPlot12.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = null;
        logAxis18.setStandardTickUnits(tickUnitSource19);
        boolean boolean21 = logAxis18.isNegativeArrowVisible();
        logAxis18.pan((double) (short) 1);
        combinedRangeXYPlot12.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis18);
        org.jfree.chart.axis.LogAxis logAxis26 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.AxisState axisState28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        java.util.List list31 = logAxis26.refreshTicks(graphics2D27, axisState28, rectangle2D29, rectangleEdge30);
        java.awt.Color color32 = java.awt.Color.red;
        logAxis26.setTickMarkPaint((java.awt.Paint) color32);
        logAxis26.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape36 = logAxis26.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot37 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke38 = combinedRangeXYPlot37.getRangeMinorGridlineStroke();
        combinedRangeXYPlot37.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection40 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = combinedRangeXYPlot37.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection40);
        org.jfree.chart.entity.PlotEntity plotEntity42 = new org.jfree.chart.entity.PlotEntity(shape36, (org.jfree.chart.plot.Plot) combinedRangeXYPlot37);
        java.util.List list43 = combinedRangeXYPlot37.getAnnotations();
        org.jfree.chart.axis.LogAxis logAxis46 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource47 = null;
        logAxis46.setStandardTickUnits(tickUnitSource47);
        boolean boolean49 = logAxis46.isNegativeArrowVisible();
        logAxis46.pan((double) (short) 1);
        combinedRangeXYPlot37.setDomainAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) logAxis46, false);
        org.jfree.chart.plot.PiePlot3D piePlot3D54 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D54.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent58 = null;
        piePlot3D54.notifyListeners(plotChangeEvent58);
        logAxis46.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D54);
        org.jfree.chart.plot.Marker marker61 = null;
        org.jfree.chart.block.BlockBorder blockBorder66 = new org.jfree.chart.block.BlockBorder((double) ' ', (double) 0L, (double) 100L, 90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = blockBorder66.getInsets();
        org.jfree.chart.entity.EntityCollection entityCollection68 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo69 = new org.jfree.chart.ChartRenderingInfo(entityCollection68);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo69);
        java.awt.geom.Rectangle2D rectangle2D71 = chartRenderingInfo69.getChartArea();
        java.awt.Shape shape72 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D71);
        java.awt.geom.Rectangle2D rectangle2D73 = rectangleInsets67.createInsetRectangle(rectangle2D71);
        xYAreaRenderer0.drawDomainMarker(graphics2D11, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot12, (org.jfree.chart.axis.ValueAxis) logAxis46, marker61, rectangle2D71);
        logAxis46.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNull(xYItemRenderer41);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertNotNull(shape72);
        org.junit.Assert.assertNotNull(rectangle2D73);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator2 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator2);
        barRenderer0.setMaximumBarWidth((double) (short) 1);
        org.junit.Assert.assertNull(itemLabelPosition1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getNumberInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}: ({1}, {2})", numberFormat1, numberFormat2);
        numberFormat1.setMaximumFractionDigits((int) (short) -1);
        int int6 = numberFormat1.getMaximumFractionDigits();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = barRenderer0.getLegendItemToolTipGenerator();
        java.awt.Paint paint2 = null;
        try {
            barRenderer0.setShadowPaint(paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        int int3 = xYSeriesCollection1.indexOf((java.lang.Comparable) '#');
        double double5 = xYSeriesCollection1.getDomainUpperBound(false);
        double double6 = xYSeriesCollection1.getIntervalPositionFactor();
        org.jfree.data.Range range7 = xYStepRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1);
        try {
            java.lang.Comparable comparable9 = xYSeriesCollection1.getSeriesKey((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 4);
        java.lang.String str3 = dateTickUnitType0.toString();
        java.text.DateFormat dateFormat5 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit6 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (byte) 0, dateFormat5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DateTickUnitType.SECOND" + "'", str3.equals("DateTickUnitType.SECOND"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.awt.geom.Rectangle2D rectangle2D2 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D3.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot3D3.notifyListeners(plotChangeEvent7);
        org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D2, (org.jfree.chart.plot.Plot) piePlot3D3, "");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke12 = combinedRangeXYPlot11.getRangeMinorGridlineStroke();
        combinedRangeXYPlot11.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedRangeXYPlot11.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection14);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D2, (org.jfree.chart.plot.Plot) combinedRangeXYPlot11, "");
        java.lang.String str18 = plotEntity17.toString();
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PlotEntity: tooltip = " + "'", str18.equals("PlotEntity: tooltip = "));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getDomainUpperBound(false);
        double double5 = xYSeriesCollection0.getIntervalPositionFactor();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate6 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        try {
            java.lang.Number number9 = xYSeriesCollection0.getStartX(2, (-12566464));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getRangeUpperBound(true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        xYSeries3.setKey((java.lang.Comparable) year4);
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(0, year4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "First" + "'", str1.equals("First"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        java.awt.Color color7 = java.awt.Color.CYAN;
        xYAreaRenderer0.setSeriesPaint((int) (short) 10, (java.awt.Paint) color7);
        java.awt.Paint paint9 = xYAreaRenderer0.getBaseFillPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getDomainUpperBound(false);
        double double5 = xYSeriesCollection0.getIntervalPositionFactor();
        double double6 = xYSeriesCollection0.getIntervalPositionFactor();
        int int7 = xYSeriesCollection0.getSeriesCount();
        org.jfree.data.Range range9 = xYSeriesCollection0.getRangeBounds(true);
        org.jfree.data.DomainOrder domainOrder10 = xYSeriesCollection0.getDomainOrder();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(domainOrder10);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo(entityCollection1);
        java.awt.geom.Rectangle2D rectangle2D3 = chartRenderingInfo2.getChartArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createAdjustedRectangle(rectangle2D3, lengthAdjustmentType4, lengthAdjustmentType5);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleInsets0);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getDomainUpperBound(false);
        double double5 = xYSeriesCollection0.getIntervalPositionFactor();
        double double6 = xYSeriesCollection0.getIntervalPositionFactor();
        int int7 = xYSeriesCollection0.getSeriesCount();
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        boolean boolean4 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        logAxis6.setStandardTickUnits(tickUnitSource7);
        boolean boolean9 = logAxis6.isNegativeArrowVisible();
        logAxis6.pan((double) (short) 1);
        combinedRangeXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis6);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        combinedRangeXYPlot0.plotChanged(plotChangeEvent13);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation15 = null;
        try {
            boolean boolean17 = combinedRangeXYPlot0.removeAnnotation(xYAnnotation15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        java.awt.Paint paint4 = combinedRangeXYPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        logAxis6.setStandardTickUnits(tickUnitSource7);
        boolean boolean9 = logAxis6.isNegativeArrowVisible();
        logAxis6.pan((double) (short) 1);
        java.lang.Object obj12 = logAxis6.clone();
        int int13 = combinedRangeXYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis6);
        org.jfree.chart.axis.AxisSpace axisSpace14 = combinedRangeXYPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNull(axisSpace14);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = xYAreaRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D3.setCircular(true, true);
        boolean boolean7 = itemLabelPosition2.equals((java.lang.Object) piePlot3D3);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearRangeMarkers(0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke4 = combinedRangeXYPlot3.getRangeMinorGridlineStroke();
        combinedRangeXYPlot3.clearAnnotations();
        combinedRangeXYPlot3.configureDomainAxes();
        combinedRangeXYPlot3.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation8 = combinedRangeXYPlot3.getDomainAxisLocation();
        combinedRangeXYPlot0.setRangeAxisLocation(axisLocation8, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = null;
        combinedRangeXYPlot0.notifyListeners(plotChangeEvent11);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.Class<?> wildcardClass1 = rectangleAnchor0.getClass();
        try {
            java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) wildcardClass1);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        combinedRangeXYPlot0.markerChanged(markerChangeEvent4);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1559372400000L, (int) (byte) 10, 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeMinorGridlineStroke();
        combinedRangeXYPlot2.clearAnnotations();
        boolean boolean5 = combinedRangeXYPlot2.isDomainPannable();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer7.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer7.clearSeriesStrokes(false);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer7.setBaseLegendShape(shape13);
        combinedRangeXYPlot2.setRenderer(15, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer7, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("red");
        java.awt.Paint paint20 = categoryAxis18.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        combinedRangeXYPlot2.setDomainTickBandPaint(paint20);
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("First", font1, paint20);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getShadowXOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = xYAreaRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = xYAreaRenderer0.getSeriesURLGenerator((int) (byte) 1);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertNull(xYURLGenerator4);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getNumberInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}: ({1}, {2})", numberFormat1, numberFormat2);
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        org.jfree.data.general.DatasetGroup datasetGroup10 = piePlot3D4.getDatasetGroup();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle11 = piePlot3D4.getLabelLinkStyle();
        piePlot3D4.setCircular(false, false);
        piePlot3D4.clearSectionOutlinePaints(false);
        double double18 = piePlot3D4.getExplodePercent((java.lang.Comparable) "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.awt.Paint paint19 = piePlot3D4.getBaseSectionOutlinePaint();
        try {
            java.lang.String str20 = numberFormat2.format((java.lang.Object) paint19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNull(datasetGroup10);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle11);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        int int5 = xYSeriesCollection3.indexOf((java.lang.Comparable) '#');
        double double7 = xYSeriesCollection3.getDomainUpperBound(false);
        xYSeries2.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection3);
        org.jfree.data.xy.XYDataItem xYDataItem9 = null;
        try {
            xYSeries2.add(xYDataItem9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        java.awt.geom.Rectangle2D rectangle2D6 = chartRenderingInfo5.getChartArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets3.createAdjustedRectangle(rectangle2D6, lengthAdjustmentType7, lengthAdjustmentType8);
        try {
            barRenderer3D0.drawBackground(graphics2D1, categoryPlot2, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D9);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo(entityCollection1);
        java.awt.geom.Rectangle2D rectangle2D3 = chartRenderingInfo2.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        org.jfree.chart.entity.PlotEntity plotEntity11 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D3, (org.jfree.chart.plot.Plot) piePlot3D4, "");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedRangeXYPlot12.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D3, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12, "");
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets0.createOutsetRectangle(rectangle2D3);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            boolean boolean21 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D3, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("ChartChangeEventType.GENERAL");
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity18 = new org.jfree.chart.entity.PieSectionEntity(shape11, pieDataset12, (int) 'a', 2019, (java.lang.Comparable) "red", "", "red");
        int int19 = pieSectionEntity18.getSectionIndex();
        int int20 = pieSectionEntity18.getSectionIndex();
        pieSectionEntity18.setSectionKey((java.lang.Comparable) 1.0E-8d);
        pieSectionEntity18.setSectionKey((java.lang.Comparable) "0,0,1,1");
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month2.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("0,0,1,1");
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str1 = numberTickUnit0.toString();
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[size=1]" + "'", str1.equals("[size=1]"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("0,0,1,1", (java.awt.Paint) color1);
        java.awt.Shape shape3 = legendItem2.getLine();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = logAxis5.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, list10, (org.jfree.data.Range) dateRange11, false);
        timeSeriesCollection2.removeAllSeries();
        try {
            boolean boolean18 = timeSeriesCollection2.isSelected(100, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (100).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer3);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(range14);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("PlotEntity: tooltip = null");
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.util.LineUtilities lineUtilities0 = new org.jfree.chart.util.LineUtilities();
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        java.awt.Paint paint4 = combinedRangeXYPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        logAxis6.setStandardTickUnits(tickUnitSource7);
        boolean boolean9 = logAxis6.isNegativeArrowVisible();
        logAxis6.pan((double) (short) 1);
        java.lang.Object obj12 = logAxis6.clone();
        int int13 = combinedRangeXYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis6);
        org.jfree.chart.ui.ProjectInfo projectInfo15 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean18 = segmentedTimeline16.containsDomainValue(date17);
        java.util.List list19 = segmentedTimeline16.getExceptionSegments();
        projectInfo15.setContributors(list19);
        try {
            combinedRangeXYPlot0.mapDatasetToRangeAxes(6, list19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(projectInfo15);
        org.junit.Assert.assertNotNull(segmentedTimeline16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("red");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        categoryAxis1.setCategoryLabelPositionOffset(8);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        try {
            java.util.List list9 = categoryAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        try {
            java.lang.Number number6 = timeSeriesCollection2.getEndY((int) '4', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer3);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        boolean boolean1 = polarPlot0.isRangeZoomable();
        java.awt.Paint paint2 = polarPlot0.getAngleGridlinePaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke5 = combinedRangeXYPlot4.getRangeMinorGridlineStroke();
        combinedRangeXYPlot4.clearAnnotations();
        java.awt.Stroke stroke7 = combinedRangeXYPlot4.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer8.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer8.clearSeriesStrokes(false);
        java.awt.Paint paint14 = xYAreaRenderer8.getSeriesPaint(15);
        boolean boolean16 = xYAreaRenderer8.isSeriesItemLabelsVisible(0);
        int int17 = combinedRangeXYPlot4.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer8);
        org.jfree.chart.entity.EntityCollection entityCollection18 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = new org.jfree.chart.ChartRenderingInfo(entityCollection18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = plotRenderingInfo20.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D22 = plotRenderingInfo20.getDataArea();
        org.jfree.chart.axis.LogAxis logAxis24 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.AxisState axisState26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        java.util.List list29 = logAxis24.refreshTicks(graphics2D25, axisState26, rectangle2D27, rectangleEdge28);
        java.awt.Color color30 = java.awt.Color.red;
        logAxis24.setTickMarkPaint((java.awt.Paint) color30);
        logAxis24.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape34 = logAxis24.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot35 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke36 = combinedRangeXYPlot35.getRangeMinorGridlineStroke();
        combinedRangeXYPlot35.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection38 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = combinedRangeXYPlot35.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection38);
        org.jfree.chart.entity.PlotEntity plotEntity40 = new org.jfree.chart.entity.PlotEntity(shape34, (org.jfree.chart.plot.Plot) combinedRangeXYPlot35);
        combinedRangeXYPlot35.clearAnnotations();
        java.awt.geom.Point2D point2D42 = combinedRangeXYPlot35.getQuadrantOrigin();
        org.jfree.chart.plot.XYPlot xYPlot43 = combinedRangeXYPlot4.findSubplot(plotRenderingInfo20, point2D42);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot44 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke45 = combinedRangeXYPlot44.getRangeMinorGridlineStroke();
        combinedRangeXYPlot44.clearAnnotations();
        java.awt.Stroke stroke47 = combinedRangeXYPlot44.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer48 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer48.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer48.clearSeriesStrokes(false);
        java.awt.Paint paint54 = xYAreaRenderer48.getSeriesPaint(15);
        boolean boolean56 = xYAreaRenderer48.isSeriesItemLabelsVisible(0);
        int int57 = combinedRangeXYPlot44.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer48);
        org.jfree.chart.entity.EntityCollection entityCollection58 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo59 = new org.jfree.chart.ChartRenderingInfo(entityCollection58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo59);
        java.awt.geom.Rectangle2D rectangle2D61 = plotRenderingInfo60.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D62 = plotRenderingInfo60.getDataArea();
        org.jfree.chart.axis.LogAxis logAxis64 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D65 = null;
        org.jfree.chart.axis.AxisState axisState66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
        java.util.List list69 = logAxis64.refreshTicks(graphics2D65, axisState66, rectangle2D67, rectangleEdge68);
        java.awt.Color color70 = java.awt.Color.red;
        logAxis64.setTickMarkPaint((java.awt.Paint) color70);
        logAxis64.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape74 = logAxis64.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot75 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke76 = combinedRangeXYPlot75.getRangeMinorGridlineStroke();
        combinedRangeXYPlot75.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection78 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer79 = combinedRangeXYPlot75.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection78);
        org.jfree.chart.entity.PlotEntity plotEntity80 = new org.jfree.chart.entity.PlotEntity(shape74, (org.jfree.chart.plot.Plot) combinedRangeXYPlot75);
        combinedRangeXYPlot75.clearAnnotations();
        java.awt.geom.Point2D point2D82 = combinedRangeXYPlot75.getQuadrantOrigin();
        org.jfree.chart.plot.XYPlot xYPlot83 = combinedRangeXYPlot44.findSubplot(plotRenderingInfo60, point2D82);
        try {
            polarPlot0.zoomRangeAxes((double) 604800000L, plotRenderingInfo20, point2D82, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(xYItemRenderer39);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertNull(xYPlot43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNull(paint54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNull(rectangle2D61);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(list69);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(shape74);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNull(xYItemRenderer79);
        org.junit.Assert.assertNotNull(point2D82);
        org.junit.Assert.assertNull(xYPlot83);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getRangeUpperBound(false);
        try {
            java.lang.Number number7 = xYSeriesCollection0.getStartX(2019, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        logAxis1.setSmallestValue(Double.NaN);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = logAxis5.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
        java.awt.Color color11 = java.awt.Color.red;
        logAxis5.setTickMarkPaint((java.awt.Paint) color11);
        logAxis5.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape15 = logAxis5.getDownArrow();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity22 = new org.jfree.chart.entity.PieSectionEntity(shape15, pieDataset16, (int) 'a', 2019, (java.lang.Comparable) "red", "", "red");
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D23.setCircular(true, true);
        piePlot3D23.setSimpleLabels(true);
        org.jfree.data.general.PieDataset pieDataset29 = null;
        piePlot3D23.setDataset(pieDataset29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection32 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = new org.jfree.chart.ChartRenderingInfo(entityCollection32);
        java.awt.geom.Rectangle2D rectangle2D34 = chartRenderingInfo33.getChartArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType35 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets31.createAdjustedRectangle(rectangle2D34, lengthAdjustmentType35, lengthAdjustmentType36);
        piePlot3D23.setLabelPadding(rectangleInsets31);
        java.awt.Stroke stroke39 = piePlot3D23.getLabelOutlineStroke();
        org.jfree.chart.plot.PiePlot3D piePlot3D40 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D40.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent44 = null;
        piePlot3D40.notifyListeners(plotChangeEvent44);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent46 = null;
        piePlot3D40.markerChanged(markerChangeEvent46);
        org.jfree.chart.plot.PiePlot3D piePlot3D52 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D52.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent56 = null;
        piePlot3D52.notifyListeners(plotChangeEvent56);
        java.awt.Shape shape58 = piePlot3D52.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot59 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color60 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot59.setAngleGridlinePaint((java.awt.Paint) color60);
        java.awt.Color color62 = color60.darker();
        org.jfree.chart.LegendItem legendItem63 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape58, (java.awt.Paint) color62);
        piePlot3D40.setBaseSectionPaint((java.awt.Paint) color62);
        try {
            org.jfree.chart.LegendItem legendItem65 = new org.jfree.chart.LegendItem(attributedString0, "TextBlockAnchor.CENTER_RIGHT", "", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=100.0]", shape15, stroke39, (java.awt.Paint) color62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(color62);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        xYAreaRenderer0.setBaseLegendShape(shape6);
        java.awt.Shape shape9 = xYAreaRenderer0.getLegendShape((int) (short) 10);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(shape9);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        combinedRangeXYPlot7.setDomainAxisLocation((int) 'a', axisLocation9);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        boolean boolean12 = combinedRangeXYPlot7.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        logAxis14.setPositiveArrowVisible(false);
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        org.jfree.chart.entity.EntityCollection entityCollection19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo(entityCollection19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        boolean boolean22 = month18.equals((java.lang.Object) chartRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D23 = chartRenderingInfo20.getChartArea();
        xYAreaRenderer0.fillDomainGridBand(graphics2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) logAxis14, rectangle2D23, (double) '4', 100.0d);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        int int28 = combinedRangeXYPlot7.getRangeAxisIndex(valueAxis27);
        java.awt.Stroke stroke29 = combinedRangeXYPlot7.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        combinedRangeXYPlot7.setRenderer(xYItemRenderer30);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        java.util.Locale locale10 = periodAxis9.getLocale();
        java.util.TimeZone timeZone11 = null;
        try {
            periodAxis9.setTimeZone(timeZone11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertNotNull(locale10);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        double double3 = logAxis1.calculateLog(0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.NEGATIVE_INFINITY + "'", double3 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        combinedRangeXYPlot0.configureDomainAxes();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) 0);
        java.awt.Paint paint7 = combinedRangeXYPlot0.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        boolean boolean4 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        logAxis6.setStandardTickUnits(tickUnitSource7);
        boolean boolean9 = logAxis6.isNegativeArrowVisible();
        logAxis6.pan((double) (short) 1);
        combinedRangeXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis6);
        java.awt.Paint paint13 = logAxis6.getAxisLinePaint();
        boolean boolean14 = logAxis6.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot2.setAngleGridlinePaint((java.awt.Paint) color3);
        java.awt.Color color5 = color3.darker();
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        java.util.List list12 = logAxis7.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge11);
        java.awt.Color color13 = java.awt.Color.red;
        logAxis7.setTickMarkPaint((java.awt.Paint) color13);
        logAxis7.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape17 = logAxis7.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke19 = combinedRangeXYPlot18.getRangeMinorGridlineStroke();
        combinedRangeXYPlot18.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection21 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = combinedRangeXYPlot18.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection21);
        org.jfree.chart.entity.PlotEntity plotEntity23 = new org.jfree.chart.entity.PlotEntity(shape17, (org.jfree.chart.plot.Plot) combinedRangeXYPlot18);
        combinedRangeXYPlot18.clearAnnotations();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        combinedRangeXYPlot26.setDomainAxisLocation((int) 'a', axisLocation28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot26);
        org.jfree.chart.title.LegendTitle legendTitle32 = jFreeChart30.getLegend(100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = barRenderer33.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke38 = barRenderer33.getItemOutlineStroke((int) '4', (int) (byte) 1, true);
        jFreeChart30.setBorderStroke(stroke38);
        combinedRangeXYPlot18.setDomainZeroBaselineStroke(stroke38);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke42 = combinedRangeXYPlot41.getRangeMinorGridlineStroke();
        combinedRangeXYPlot41.clearAnnotations();
        java.awt.Paint paint44 = combinedRangeXYPlot41.getDomainMinorGridlinePaint();
        org.jfree.chart.axis.LogAxis logAxis46 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.axis.AxisState axisState48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = null;
        java.util.List list51 = logAxis46.refreshTicks(graphics2D47, axisState48, rectangle2D49, rectangleEdge50);
        java.awt.Color color52 = java.awt.Color.red;
        logAxis46.setTickMarkPaint((java.awt.Paint) color52);
        logAxis46.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis46.setAutoTickUnitSelection(true, true);
        logAxis46.resizeRange2(4.0d, (double) 'a');
        java.awt.Stroke stroke62 = logAxis46.getTickMarkStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker64 = new org.jfree.chart.plot.IntervalMarker((double) (-1.0f), (double) 604800000L, (java.awt.Paint) color5, stroke38, paint44, stroke62, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertNull(legendTitle32);
        org.junit.Assert.assertNull(itemLabelPosition34);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(list51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(stroke62);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter0 = null;
        try {
            org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(xYBarPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        combinedRangeXYPlot1.setDomainAxisLocation((int) 'a', axisLocation3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot1);
        boolean boolean6 = combinedRangeXYPlot1.isDomainZeroBaselineVisible();
        boolean boolean7 = combinedRangeXYPlot1.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            combinedRangeXYPlot1.addDomainMarker((int) (short) 10, marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(layer10);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("red");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor2, 1, 8, rectangle2D5, rectangleEdge6);
        categoryAxis1.setLowerMargin((double) 10L);
        org.jfree.chart.entity.EntityCollection entityCollection12 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo(entityCollection12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = chartRenderingInfo13.getChartArea();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("red");
        java.awt.Paint paint20 = categoryAxis18.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke25 = combinedRangeXYPlot24.getRangeMinorGridlineStroke();
        combinedRangeXYPlot24.clearAnnotations();
        boolean boolean27 = combinedRangeXYPlot24.isDomainPannable();
        boolean boolean28 = combinedRangeXYPlot24.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = combinedRangeXYPlot24.getDomainAxisEdge();
        org.jfree.chart.axis.AxisState axisState30 = null;
        categoryAxis18.drawTickMarks(graphics2D21, (double) (-1.0f), rectangle2D23, rectangleEdge29, axisState30);
        try {
            double double32 = categoryAxis1.getCategoryMiddle(15, (int) (byte) 10, rectangle2D15, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 15");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        long long10 = month2.getMiddleMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month2.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560668399999L + "'", long10 == 1560668399999L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 100, (double) 5, (double) 86400000L, (double) 1.0f);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean7 = segmentedTimeline5.containsDomainValue(date6);
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        segmentedTimeline5.addException(date8);
        boolean boolean10 = blockBorder4.equals((java.lang.Object) date8);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        java.awt.Stroke stroke5 = combinedRangeXYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(xYItemRenderer4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("RectangleAnchor.BOTTOM_LEFT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name RectangleAnchor.BOTTOM_LEFT, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis1.centerRange((double) 0L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean18 = segmentedTimeline16.containsDomainValue(date17);
        java.util.List list19 = segmentedTimeline16.getExceptionSegments();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeZone21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = combinedRangeXYPlot20.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection22);
        org.jfree.chart.axis.LogAxis logAxis25 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.AxisState axisState27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        java.util.List list30 = logAxis25.refreshTicks(graphics2D26, axisState27, rectangle2D28, rectangleEdge29);
        org.jfree.data.time.DateRange dateRange31 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange32 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange31);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection22, list30, (org.jfree.data.Range) dateRange31, false);
        segmentedTimeline16.addExceptions(list30);
        combinedRangeXYPlot13.drawDomainTickBands(graphics2D14, rectangle2D15, list30);
        combinedRangeXYPlot13.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(segmentedTimeline16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(xYItemRenderer23);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNull(range34);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        boolean boolean5 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        xYAreaRenderer0.setBaseOutlinePaint((java.awt.Paint) color6, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
        double double2 = crosshairState1.getAnchorX();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        xYAreaRenderer0.setAutoPopulateSeriesShape(true);
        java.awt.Shape shape7 = xYAreaRenderer0.getBaseShape();
        java.io.ObjectOutputStream objectOutputStream8 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape7, objectOutputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("red");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("red");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color1);
        java.awt.Color color3 = color1.darker();
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { color3 };
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100L, (float) (short) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        combinedRangeXYPlot9.setDomainAxisLocation((int) 'a', axisLocation11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot9);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart13.getLegend(100);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity18 = new org.jfree.chart.entity.JFreeChartEntity(shape7, jFreeChart13, "", "0,0,1,1");
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int21 = color20.getGreen();
        java.awt.Color color22 = java.awt.Color.getColor("hi!", color20);
        boolean boolean23 = jFreeChart13.equals((java.lang.Object) color22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color22, color24 };
        java.awt.Stroke[] strokeArray26 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray27 = null;
        java.awt.Shape[] shapeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray25, strokeArray26, strokeArray27, shapeArray28);
        try {
            java.awt.Stroke stroke30 = defaultDrawingSupplier29.getNextOutlineStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(legendTitle15);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(shapeArray28);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(5);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.entity.EntityCollection entityCollection12 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo(entityCollection12);
        java.awt.geom.Rectangle2D rectangle2D14 = chartRenderingInfo13.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D15 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D15.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = null;
        piePlot3D15.notifyListeners(plotChangeEvent19);
        org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D14, (org.jfree.chart.plot.Plot) piePlot3D15, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity25 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis1, (java.awt.Shape) rectangle2D14, "", "");
        java.lang.String str26 = logAxis1.getLabel();
        double double27 = logAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Stroke stroke7 = logAxis1.getTickMarkStroke();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = piePlot3D0.getLabelDistributor();
        java.awt.Paint paint7 = piePlot3D0.getShadowPaint();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100L, (float) (short) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        combinedRangeXYPlot12.setDomainAxisLocation((int) 'a', axisLocation14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        org.jfree.chart.title.LegendTitle legendTitle18 = jFreeChart16.getLegend(100);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity21 = new org.jfree.chart.entity.JFreeChartEntity(shape10, jFreeChart16, "", "0,0,1,1");
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int24 = color23.getGreen();
        java.awt.Color color25 = java.awt.Color.getColor("hi!", color23);
        boolean boolean26 = jFreeChart16.equals((java.lang.Object) color25);
        piePlot3D0.setLabelLinkPaint((java.awt.Paint) color25);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(legendTitle18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.entity.EntityCollection entityCollection12 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo(entityCollection12);
        java.awt.geom.Rectangle2D rectangle2D14 = chartRenderingInfo13.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D15 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D15.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = null;
        piePlot3D15.notifyListeners(plotChangeEvent19);
        org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D14, (org.jfree.chart.plot.Plot) piePlot3D15, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity25 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis1, (java.awt.Shape) rectangle2D14, "", "");
        java.lang.String str26 = axisLabelEntity25.toString();
        org.jfree.chart.axis.Axis axis27 = axisLabelEntity25.getAxis();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "AxisLabelEntity: label = hi!" + "'", str26.equals("AxisLabelEntity: label = hi!"));
        org.junit.Assert.assertNotNull(axis27);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100L, (float) (short) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        combinedRangeXYPlot4.setDomainAxisLocation((int) 'a', axisLocation6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend(100);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity13 = new org.jfree.chart.entity.JFreeChartEntity(shape2, jFreeChart8, "", "0,0,1,1");
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo(entityCollection16);
        java.awt.geom.Rectangle2D rectangle2D18 = chartRenderingInfo17.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D19 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D19.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        piePlot3D19.notifyListeners(plotChangeEvent23);
        org.jfree.chart.entity.PlotEntity plotEntity26 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D18, (org.jfree.chart.plot.Plot) piePlot3D19, "");
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets15.createInsetRectangle(rectangle2D18);
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.axis.AxisState axisState31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        java.util.List list34 = logAxis29.refreshTicks(graphics2D30, axisState31, rectangle2D32, rectangleEdge33);
        java.awt.Color color35 = java.awt.Color.red;
        logAxis29.setTickMarkPaint((java.awt.Paint) color35);
        logAxis29.setMinorTickMarkInsideLength((float) (short) -1);
        org.jfree.chart.entity.AxisEntity axisEntity40 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D27, (org.jfree.chart.axis.Axis) logAxis29, "PieLabelLinkStyle.STANDARD");
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.axis.AxisState axisState44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        java.util.List list47 = logAxis42.refreshTicks(graphics2D43, axisState44, rectangle2D45, rectangleEdge46);
        java.awt.Color color48 = java.awt.Color.red;
        logAxis42.setTickMarkPaint((java.awt.Paint) color48);
        logAxis42.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape52 = logAxis42.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot53 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke54 = combinedRangeXYPlot53.getRangeMinorGridlineStroke();
        combinedRangeXYPlot53.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection56 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = combinedRangeXYPlot53.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection56);
        org.jfree.chart.entity.PlotEntity plotEntity58 = new org.jfree.chart.entity.PlotEntity(shape52, (org.jfree.chart.plot.Plot) combinedRangeXYPlot53);
        combinedRangeXYPlot53.clearAnnotations();
        java.awt.geom.Point2D point2D60 = combinedRangeXYPlot53.getQuadrantOrigin();
        org.jfree.chart.entity.EntityCollection entityCollection61 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo62 = new org.jfree.chart.ChartRenderingInfo(entityCollection61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo62);
        org.jfree.chart.RenderingSource renderingSource64 = chartRenderingInfo62.getRenderingSource();
        try {
            jFreeChart8.draw(graphics2D14, rectangle2D27, point2D60, chartRenderingInfo62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(legendTitle10);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(list47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNull(xYItemRenderer57);
        org.junit.Assert.assertNotNull(point2D60);
        org.junit.Assert.assertNull(renderingSource64);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("0,0,1,1", font2, (org.jfree.chart.plot.Plot) polarPlot5, false);
        jFreeChart7.setTitle("red");
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer10.getPositiveItemLabelPositionFallback();
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot12.setAngleGridlinePaint((java.awt.Paint) color13);
        java.awt.Color color15 = color13.darker();
        int int16 = color15.getAlpha();
        barRenderer10.setBaseItemLabelPaint((java.awt.Paint) color15);
        java.awt.Color color18 = color15.brighter();
        jFreeChart7.setBorderPaint((java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("red");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getRangeMinorGridlineStroke();
        combinedRangeXYPlot7.clearAnnotations();
        boolean boolean10 = combinedRangeXYPlot7.isDomainPannable();
        boolean boolean11 = combinedRangeXYPlot7.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = combinedRangeXYPlot7.getDomainAxisEdge();
        org.jfree.chart.axis.AxisState axisState13 = null;
        categoryAxis1.drawTickMarks(graphics2D4, (double) (-1.0f), rectangle2D6, rectangleEdge12, axisState13);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline16 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean18 = segmentedTimeline16.containsDomainValue(date17);
        java.util.List list19 = segmentedTimeline16.getExceptionSegments();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer20 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint21 = xYAreaRenderer20.getBaseItemLabelPaint();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = null;
        xYAreaRenderer20.setSeriesURLGenerator(8, xYURLGenerator23, false);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot28 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation30 = null;
        combinedRangeXYPlot28.setDomainAxisLocation((int) 'a', axisLocation30);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot28);
        boolean boolean33 = combinedRangeXYPlot28.isDomainZeroBaselineVisible();
        combinedRangeXYPlot28.setDomainPannable(false);
        org.jfree.chart.axis.LogAxis logAxis37 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.AxisState axisState39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        java.util.List list42 = logAxis37.refreshTicks(graphics2D38, axisState39, rectangle2D40, rectangleEdge41);
        java.awt.Color color43 = java.awt.Color.red;
        logAxis37.setTickMarkPaint((java.awt.Paint) color43);
        logAxis37.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape47 = logAxis37.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot48 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke49 = combinedRangeXYPlot48.getRangeMinorGridlineStroke();
        combinedRangeXYPlot48.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection51 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = combinedRangeXYPlot48.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection51);
        org.jfree.chart.entity.PlotEntity plotEntity53 = new org.jfree.chart.entity.PlotEntity(shape47, (org.jfree.chart.plot.Plot) combinedRangeXYPlot48);
        java.util.List list54 = combinedRangeXYPlot48.getAnnotations();
        org.jfree.chart.axis.LogAxis logAxis57 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource58 = null;
        logAxis57.setStandardTickUnits(tickUnitSource58);
        boolean boolean60 = logAxis57.isNegativeArrowVisible();
        logAxis57.pan((double) (short) 1);
        combinedRangeXYPlot48.setDomainAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) logAxis57, false);
        double double66 = logAxis57.calculateValue((double) 1559372400000L);
        org.jfree.chart.plot.Marker marker67 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection69 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo70 = new org.jfree.chart.ChartRenderingInfo(entityCollection69);
        java.awt.geom.Rectangle2D rectangle2D71 = chartRenderingInfo70.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D72 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D72.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent76 = null;
        piePlot3D72.notifyListeners(plotChangeEvent76);
        org.jfree.chart.entity.PlotEntity plotEntity79 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D71, (org.jfree.chart.plot.Plot) piePlot3D72, "");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot80 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke81 = combinedRangeXYPlot80.getRangeMinorGridlineStroke();
        combinedRangeXYPlot80.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection83 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer84 = combinedRangeXYPlot80.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection83);
        org.jfree.chart.entity.PlotEntity plotEntity86 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D71, (org.jfree.chart.plot.Plot) combinedRangeXYPlot80, "");
        java.awt.geom.Rectangle2D rectangle2D87 = rectangleInsets68.createOutsetRectangle(rectangle2D71);
        xYAreaRenderer20.drawDomainMarker(graphics2D26, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot28, (org.jfree.chart.axis.ValueAxis) logAxis57, marker67, rectangle2D71);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot89 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke90 = combinedRangeXYPlot89.getRangeMinorGridlineStroke();
        combinedRangeXYPlot89.clearAnnotations();
        boolean boolean92 = combinedRangeXYPlot89.isDomainPannable();
        boolean boolean93 = combinedRangeXYPlot89.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge94 = combinedRangeXYPlot89.getDomainAxisEdge();
        try {
            double double95 = categoryAxis1.getCategoryMiddle((java.lang.Comparable) 90.0d, list19, rectangle2D71, rectangleEdge94);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(segmentedTimeline16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNull(xYItemRenderer52);
        org.junit.Assert.assertNotNull(list54);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + Double.POSITIVE_INFINITY + "'", double66 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNotNull(rectangle2D71);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNull(xYItemRenderer84);
        org.junit.Assert.assertNotNull(rectangle2D87);
        org.junit.Assert.assertNotNull(stroke90);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(rectangleEdge94);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        org.jfree.chart.text.TextFragment textFragment4 = textLine3.getLastTextFragment();
        java.lang.String str5 = textFragment4.getText();
        float float6 = textFragment4.getBaselineOffset();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = null;
        try {
            float float9 = textFragment4.calculateBaselineOffset(graphics2D7, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textFragment4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity18 = new org.jfree.chart.entity.PieSectionEntity(shape11, pieDataset12, (int) 'a', 2019, (java.lang.Comparable) "red", "", "red");
        int int19 = pieSectionEntity18.getSectionIndex();
        int int20 = pieSectionEntity18.getPieIndex();
        int int21 = pieSectionEntity18.getSectionIndex();
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 97 + "'", int20 == 97);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Paint paint2 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = logAxis4.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        java.awt.Color color10 = java.awt.Color.red;
        logAxis4.setTickMarkPaint((java.awt.Paint) color10);
        logAxis4.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape14 = logAxis4.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke16 = combinedRangeXYPlot15.getRangeMinorGridlineStroke();
        combinedRangeXYPlot15.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection18 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = combinedRangeXYPlot15.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection18);
        org.jfree.chart.entity.PlotEntity plotEntity20 = new org.jfree.chart.entity.PlotEntity(shape14, (org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        combinedRangeXYPlot15.clearAnnotations();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent22 = null;
        combinedRangeXYPlot15.axisChanged(axisChangeEvent22);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray24 = new org.jfree.chart.LegendItemSource[] { combinedRangeXYPlot15 };
        legendTitle1.setSources(legendItemSourceArray24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = legendTitle1.getLegendItemGraphicPadding();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNotNull(legendItemSourceArray24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("0,0,1,1", font2, (org.jfree.chart.plot.Plot) polarPlot5, false);
        jFreeChart7.setTitle("red");
        org.jfree.chart.plot.PiePlot3D piePlot3D10 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D10.setCircular(true, true);
        boolean boolean14 = piePlot3D10.getAutoPopulateSectionPaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor15 = piePlot3D10.getLabelDistributor();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) '#', (double) (short) 0, (double) 10, (double) (-1.0f));
        piePlot3D10.setSimpleLabelOffset(rectangleInsets20);
        jFreeChart7.setPadding(rectangleInsets20);
        try {
            java.awt.image.BufferedImage bufferedImage25 = jFreeChart7.createBufferedImage((int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (100) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor15);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke5 = barRenderer0.getItemOutlineStroke((int) '4', (int) (byte) 1, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = barRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = logAxis5.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, list10, (org.jfree.data.Range) dateRange11, false);
        timeSeriesCollection2.removeAllSeries();
        double double17 = timeSeriesCollection2.getDomainUpperBound(true);
        try {
            java.lang.Number number20 = timeSeriesCollection2.getY((int) '4', 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer3);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        java.lang.String str3 = waferMapPlot2.getPlotType();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "WMAP_Plot" + "'", str3.equals("WMAP_Plot"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = logAxis5.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
        java.awt.Color color11 = java.awt.Color.red;
        logAxis5.setTickMarkPaint((java.awt.Paint) color11);
        java.lang.String str13 = org.jfree.chart.util.PaintUtilities.colorToString(color11);
        piePlot3D0.setShadowPaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "red" + "'", str13.equals("red"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
        java.awt.Image image8 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "{0}: ({1}, {2})", image8, "hi!", "0,0,1,1", "");
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) projectInfo12);
        java.lang.String str14 = projectInfo12.getVersion();
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str14.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        logAxis1.centerRange((double) 0L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) ' ', (double) 0L, (double) 100L, 90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockBorder20.getInsets();
        org.jfree.chart.entity.EntityCollection entityCollection22 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo(entityCollection22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        java.awt.geom.Rectangle2D rectangle2D25 = chartRenderingInfo23.getChartArea();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D25);
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets21.createInsetRectangle(rectangle2D25);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D25, (double) 10.0f, (float) 7, (float) (byte) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("red");
        java.awt.Paint paint35 = categoryAxis33.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke40 = combinedRangeXYPlot39.getRangeMinorGridlineStroke();
        combinedRangeXYPlot39.clearAnnotations();
        boolean boolean42 = combinedRangeXYPlot39.isDomainPannable();
        boolean boolean43 = combinedRangeXYPlot39.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = combinedRangeXYPlot39.getDomainAxisEdge();
        org.jfree.chart.axis.AxisState axisState45 = null;
        categoryAxis33.drawTickMarks(graphics2D36, (double) (-1.0f), rectangle2D38, rectangleEdge44, axisState45);
        try {
            java.util.List list47 = logAxis1.refreshTicks(graphics2D14, axisState15, rectangle2D25, rectangleEdge44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color2);
        org.jfree.chart.text.TextFragment textFragment4 = textLine3.getLastTextFragment();
        java.awt.Paint paint5 = textFragment4.getPaint();
        java.lang.String str6 = textFragment4.getText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textFragment4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        boolean boolean24 = legendItem15.isLineVisible();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer25 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendItem15.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer25);
        boolean boolean27 = legendItem15.isShapeFilled();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateBottomInset(0.0d);
        double double4 = rectangleInsets0.extendHeight((double) (-12566464));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.2566462E7d) + "'", double4 == (-1.2566462E7d));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType1, 4);
        int int4 = dateTickUnit3.getMultiple();
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D5.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        piePlot3D5.notifyListeners(plotChangeEvent9);
        java.awt.Shape shape11 = piePlot3D5.getLegendItemShape();
        boolean boolean12 = dateTickUnit3.equals((java.lang.Object) piePlot3D5);
        double double13 = dateTickUnit3.getSize();
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        java.util.Date date16 = dateTickUnit3.rollDate(date14);
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit3);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot20.clearRangeMarkers(0);
        java.awt.Stroke stroke23 = combinedRangeXYPlot20.getDomainGridlineStroke();
        org.jfree.chart.entity.EntityCollection entityCollection25 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = new org.jfree.chart.ChartRenderingInfo(entityCollection25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        java.awt.geom.Rectangle2D rectangle2D28 = plotRenderingInfo27.getPlotArea();
        java.awt.geom.Point2D point2D29 = null;
        combinedRangeXYPlot20.panDomainAxes((double) 8, plotRenderingInfo27, point2D29);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke32 = combinedRangeXYPlot31.getRangeMinorGridlineStroke();
        combinedRangeXYPlot31.clearAnnotations();
        java.awt.Stroke stroke34 = combinedRangeXYPlot31.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer35 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer35.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer35.clearSeriesStrokes(false);
        java.awt.Paint paint41 = xYAreaRenderer35.getSeriesPaint(15);
        boolean boolean43 = xYAreaRenderer35.isSeriesItemLabelsVisible(0);
        int int44 = combinedRangeXYPlot31.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer35);
        org.jfree.chart.entity.EntityCollection entityCollection45 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = new org.jfree.chart.ChartRenderingInfo(entityCollection45);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo46);
        java.awt.geom.Rectangle2D rectangle2D48 = plotRenderingInfo47.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D49 = plotRenderingInfo47.getDataArea();
        org.jfree.chart.axis.LogAxis logAxis51 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.axis.AxisState axisState53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        java.util.List list56 = logAxis51.refreshTicks(graphics2D52, axisState53, rectangle2D54, rectangleEdge55);
        java.awt.Color color57 = java.awt.Color.red;
        logAxis51.setTickMarkPaint((java.awt.Paint) color57);
        logAxis51.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape61 = logAxis51.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot62 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke63 = combinedRangeXYPlot62.getRangeMinorGridlineStroke();
        combinedRangeXYPlot62.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection65 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = combinedRangeXYPlot62.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection65);
        org.jfree.chart.entity.PlotEntity plotEntity67 = new org.jfree.chart.entity.PlotEntity(shape61, (org.jfree.chart.plot.Plot) combinedRangeXYPlot62);
        combinedRangeXYPlot62.clearAnnotations();
        java.awt.geom.Point2D point2D69 = combinedRangeXYPlot62.getQuadrantOrigin();
        org.jfree.chart.plot.XYPlot xYPlot70 = combinedRangeXYPlot31.findSubplot(plotRenderingInfo47, point2D69);
        try {
            polarPlot0.zoomRangeAxes((double) 255, (double) (-2208960000000L), plotRenderingInfo27, point2D69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4000.0d + "'", double13 == 4000.0d);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(rectangle2D28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(list56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNull(xYItemRenderer66);
        org.junit.Assert.assertNotNull(point2D69);
        org.junit.Assert.assertNull(xYPlot70);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer0.setShadowYOffset((double) 100L);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNull(categoryToolTipGenerator2);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        boolean boolean9 = xYAreaRenderer0.isSeriesVisible(8);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = null;
        try {
            org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        boolean boolean24 = legendItem15.isLineVisible();
        org.jfree.data.xy.XYSeries xYSeries27 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double28 = xYSeries27.getMinX();
        xYSeries27.add((double) 100.0f, 0.0d);
        boolean boolean32 = legendItem15.equals((java.lang.Object) xYSeries27);
        xYSeries27.add((java.lang.Number) 0L, (java.lang.Number) 1);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("red");
        java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (-1.0d));
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getRangeMinorGridlineStroke();
        combinedRangeXYPlot7.clearAnnotations();
        boolean boolean10 = combinedRangeXYPlot7.isDomainPannable();
        boolean boolean11 = combinedRangeXYPlot7.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = combinedRangeXYPlot7.getDomainAxisEdge();
        org.jfree.chart.axis.AxisState axisState13 = null;
        categoryAxis1.drawTickMarks(graphics2D4, (double) (-1.0f), rectangle2D6, rectangleEdge12, axisState13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge12);
        boolean boolean16 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge12);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        java.lang.Comparable comparable6 = null;
        try {
            java.awt.Paint paint7 = piePlot3D0.getSectionOutlinePaint(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = logAxis2.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        java.awt.Color color8 = java.awt.Color.red;
        logAxis2.setTickMarkPaint((java.awt.Paint) color8);
        logAxis2.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape12 = logAxis2.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke14 = combinedRangeXYPlot13.getRangeMinorGridlineStroke();
        combinedRangeXYPlot13.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection16 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = combinedRangeXYPlot13.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection16);
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape12, (org.jfree.chart.plot.Plot) combinedRangeXYPlot13);
        java.util.List list19 = combinedRangeXYPlot13.getAnnotations();
        boolean boolean20 = lengthAdjustmentType0.equals((java.lang.Object) combinedRangeXYPlot13);
        boolean boolean21 = combinedRangeXYPlot13.isDomainZoomable();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(xYItemRenderer17);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.awt.Paint paint0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        boolean boolean4 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        logAxis6.setStandardTickUnits(tickUnitSource7);
        boolean boolean9 = logAxis6.isNegativeArrowVisible();
        logAxis6.pan((double) (short) 1);
        combinedRangeXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) logAxis6);
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = logAxis14.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        java.awt.Color color20 = java.awt.Color.red;
        logAxis14.setTickMarkPaint((java.awt.Paint) color20);
        logAxis14.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape24 = logAxis14.getDownArrow();
        org.jfree.chart.entity.EntityCollection entityCollection25 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = new org.jfree.chart.ChartRenderingInfo(entityCollection25);
        java.awt.geom.Rectangle2D rectangle2D27 = chartRenderingInfo26.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D28.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = null;
        piePlot3D28.notifyListeners(plotChangeEvent32);
        org.jfree.chart.entity.PlotEntity plotEntity35 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D27, (org.jfree.chart.plot.Plot) piePlot3D28, "");
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity38 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis14, (java.awt.Shape) rectangle2D27, "", "");
        java.lang.String str39 = logAxis14.getLabel();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation43 = null;
        combinedRangeXYPlot41.setDomainAxisLocation((int) 'a', axisLocation43);
        org.jfree.chart.JFreeChart jFreeChart45 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot41);
        boolean boolean46 = combinedRangeXYPlot41.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.LogAxis logAxis49 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource50 = null;
        logAxis49.setStandardTickUnits(tickUnitSource50);
        logAxis49.setVisible(false);
        combinedRangeXYPlot41.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) logAxis49, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray56 = new org.jfree.chart.axis.ValueAxis[] { logAxis14, logAxis49 };
        combinedRangeXYPlot0.setRangeAxes(valueAxisArray56);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = combinedRangeXYPlot0.getRenderer();
        org.jfree.chart.plot.Marker marker60 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot61 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke62 = combinedRangeXYPlot61.getRangeMinorGridlineStroke();
        combinedRangeXYPlot61.clearAnnotations();
        java.awt.Color color64 = java.awt.Color.red;
        boolean boolean66 = color64.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot61.setRangeCrosshairPaint((java.awt.Paint) color64);
        org.jfree.chart.util.Layer layer68 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection69 = combinedRangeXYPlot61.getDomainMarkers(layer68);
        try {
            combinedRangeXYPlot0.addDomainMarker((int) (byte) 10, marker60, layer68, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(valueAxisArray56);
        org.junit.Assert.assertNull(xYItemRenderer58);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(layer68);
        org.junit.Assert.assertNull(collection69);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double3 = xYSeries2.getMinX();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        xYSeries2.addPropertyChangeListener(propertyChangeListener4);
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeZone6);
        xYSeries2.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection7);
        try {
            double double11 = timeSeriesCollection7.getXValue((int) (short) 10, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.lang.Object obj2 = xYStepAreaRenderer1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(2);
        boolean boolean2 = xYStepAreaRenderer1.getShapesVisible();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = null;
        xYStepAreaRenderer1.setSeriesItemLabelGenerator(12, xYItemLabelGenerator4, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        try {
            xYStepAreaRenderer1.setLegendItemLabelGenerator(xYSeriesLabelGenerator7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 100.0f, (double) 1546329600000L, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        xYAreaRenderer0.clearSeriesStrokes(false);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        xYAreaRenderer0.setSeriesFillPaint((int) ' ', (java.awt.Paint) color6, true);
        java.awt.Paint paint10 = xYAreaRenderer0.getSeriesOutlinePaint((int) (short) -1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = logAxis5.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, list10, (org.jfree.data.Range) dateRange11, false);
        timeSeriesCollection2.removeAllSeries();
        double double17 = timeSeriesCollection2.getDomainUpperBound(true);
        try {
            timeSeriesCollection2.setSelected(2019, (int) (byte) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (2019).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer3);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) false);
        boolean boolean2 = rendererChangeEvent1.getSeriesVisibilityChanged();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot2.setAngleGridlinePaint((java.awt.Paint) color3);
        java.awt.Color color5 = color3.darker();
        int int6 = color5.getAlpha();
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        barRenderer0.setMaximumBarWidth((double) 1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = barRenderer0.getToolTipGenerator((int) (short) 100, (int) '4', true);
        java.awt.Font font15 = barRenderer0.getLegendTextFont((int) '4');
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNull(font15);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        int int5 = xYSeriesCollection3.indexOf((java.lang.Comparable) '#');
        double double7 = xYSeriesCollection3.getDomainUpperBound(false);
        xYSeries2.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection3);
        xYSeries2.add((double) 86400000L, (java.lang.Number) 4.0d, true);
        xYSeries2.add((double) 0L, (java.lang.Number) (byte) 10, true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        java.lang.String str4 = piePlot3D0.getPlotType();
        piePlot3D0.clearSectionPaints(true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pie 3D Plot" + "'", str4.equals("Pie 3D Plot"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        boolean boolean24 = legendItem15.isLineVisible();
        java.awt.Paint paint25 = legendItem15.getLinePaint();
        java.awt.Color color26 = java.awt.Color.pink;
        int int27 = color26.getRed();
        legendItem15.setFillPaint((java.awt.Paint) color26);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 255 + "'", int27 == 255);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        textTitle9.setToolTipText("red");
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot12.setAngleGridlinePaint((java.awt.Paint) color13);
        java.awt.Color color15 = color13.darker();
        textTitle9.setPaint((java.awt.Paint) color13);
        java.awt.Graphics2D graphics2D17 = null;
        try {
            org.jfree.chart.util.Size2D size2D18 = textTitle9.arrange(graphics2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 0L);
        java.awt.Color color8 = java.awt.Color.red;
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("0,0,1,1", (java.awt.Paint) color11);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke14 = combinedRangeXYPlot13.getRangeMinorGridlineStroke();
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) ' ', (double) 0L, (double) 100L, 90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = blockBorder20.getInsets();
        org.jfree.chart.entity.EntityCollection entityCollection22 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo(entityCollection22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        java.awt.geom.Rectangle2D rectangle2D25 = chartRenderingInfo23.getChartArea();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D25);
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets21.createInsetRectangle(rectangle2D25);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer28 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer28.setSeriesShapesVisible(0, (java.lang.Boolean) false);
        java.awt.Font font33 = xYStepRenderer28.getLegendTextFont(8);
        java.awt.Stroke stroke35 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        xYStepRenderer28.setSeriesStroke((int) (byte) 0, stroke35, true);
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer39 = polarPlot38.getRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke41 = combinedRangeXYPlot40.getRangeMinorGridlineStroke();
        combinedRangeXYPlot40.clearAnnotations();
        java.awt.Color color43 = java.awt.Color.red;
        boolean boolean45 = color43.equals((java.lang.Object) (short) 100);
        combinedRangeXYPlot40.setRangeCrosshairPaint((java.awt.Paint) color43);
        polarPlot38.setAngleGridlinePaint((java.awt.Paint) color43);
        java.awt.Color color48 = java.awt.Color.gray;
        polarPlot38.setAngleLabelPaint((java.awt.Paint) color48);
        try {
            org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem(attributedString0, "DateTickUnitType.SECOND", "First", "PieLabelLinkStyle.STANDARD", false, shape6, false, (java.awt.Paint) color8, false, (java.awt.Paint) color11, stroke14, false, (java.awt.Shape) rectangle2D27, stroke35, (java.awt.Paint) color48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNull(font33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNull(polarItemRenderer39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(color48);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        int int5 = xYSeriesCollection3.indexOf((java.lang.Comparable) '#');
        double double7 = xYSeriesCollection3.getDomainUpperBound(false);
        xYSeries2.addChangeListener((org.jfree.data.general.SeriesChangeListener) xYSeriesCollection3);
        org.jfree.data.xy.XYSeries xYSeries11 = xYSeries2.createCopy((int) (short) 1, 255);
        boolean boolean12 = xYSeries11.isEmpty();
        double double13 = xYSeries11.getMaxX();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYSeries11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getDomainUpperBound(false);
        double double5 = xYSeriesCollection0.getIntervalPositionFactor();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate6 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        try {
            double double9 = intervalXYDelegate6.getStartXValue((int) '4', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 97);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries(comparable0, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getRangeCrosshairPaint();
        combinedRangeXYPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        combinedRangeXYPlot1.clearAnnotations();
        combinedRangeXYPlot1.configureDomainAxes();
        xYAreaRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot1);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = null;
        xYAreaRenderer0.setSeriesItemLabelGenerator(7, xYItemLabelGenerator7, false);
        java.awt.Stroke stroke10 = xYAreaRenderer0.getBaseStroke();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        java.lang.String str4 = rectangleConstraint3.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint3.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str4.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint5);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100L, (float) (short) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        combinedRangeXYPlot4.setDomainAxisLocation((int) 'a', axisLocation6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend(100);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity13 = new org.jfree.chart.entity.JFreeChartEntity(shape2, jFreeChart8, "", "0,0,1,1");
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int16 = color15.getGreen();
        java.awt.Color color17 = java.awt.Color.getColor("hi!", color15);
        boolean boolean18 = jFreeChart8.equals((java.lang.Object) color17);
        int int19 = jFreeChart8.getSubtitleCount();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(legendTitle10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = null;
        logAxis1.setStandardTickUnits(tickUnitSource2);
        boolean boolean4 = logAxis1.isNegativeArrowVisible();
        logAxis1.pan((double) (short) 1);
        java.lang.String str7 = logAxis1.getLabelURL();
        java.awt.Font font8 = logAxis1.getLabelFont();
        java.text.NumberFormat numberFormat9 = logAxis1.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(numberFormat9);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
        boolean boolean6 = dateTickMarkPosition0.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(2);
        boolean boolean2 = xYStepAreaRenderer1.getShapesVisible();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = null;
        xYStepAreaRenderer1.setSeriesItemLabelGenerator(12, xYItemLabelGenerator4, false);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100L, (float) (short) 10);
        xYStepAreaRenderer1.setSeriesShape(0, shape10, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        int int3 = xYSeriesCollection1.indexOf((java.lang.Comparable) '#');
        double double5 = xYSeriesCollection1.getDomainUpperBound(false);
        double double6 = xYSeriesCollection1.getIntervalPositionFactor();
        org.jfree.data.Range range7 = xYStepRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1);
        xYSeriesCollection1.validateObject();
        java.lang.Object obj9 = xYSeriesCollection1.clone();
        xYSeriesCollection1.clearSelection();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        boolean boolean4 = piePlot3D0.getAutoPopulateSectionPaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot3D0.getLabelDistributor();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) '#', (double) (short) 0, (double) 10, (double) (-1.0f));
        piePlot3D0.setSimpleLabelOffset(rectangleInsets10);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = null;
        try {
            piePlot3D0.setLegendLabelGenerator(pieSectionLabelGenerator12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("PlotEntity: tooltip = ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot2.setAngleGridlinePaint((java.awt.Paint) color3);
        java.awt.Color color5 = color3.darker();
        int int6 = color5.getAlpha();
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color5);
        int int8 = color5.getTransparency();
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint2 = barRenderer0.getShadowPaint();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.entity.EntityCollection entityCollection5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo(entityCollection5);
        java.awt.geom.Rectangle2D rectangle2D7 = chartRenderingInfo6.getChartArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets4.createAdjustedRectangle(rectangle2D7, lengthAdjustmentType8, lengthAdjustmentType9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.entity.EntityCollection entityCollection13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo(entityCollection13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        java.awt.geom.Rectangle2D rectangle2D16 = plotRenderingInfo15.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D17 = plotRenderingInfo15.getDataArea();
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState18 = barRenderer0.initialise(graphics2D3, rectangle2D10, categoryPlot11, 0, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getNumberInstance();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("{0}: ({1}, {2})", numberFormat1, numberFormat2);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke6 = combinedRangeXYPlot5.getRangeMinorGridlineStroke();
        combinedRangeXYPlot5.clearAnnotations();
        combinedRangeXYPlot5.configureDomainAxes();
        xYAreaRenderer4.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot5);
        java.awt.Stroke stroke10 = xYAreaRenderer4.getBaseStroke();
        java.awt.Paint paint12 = xYAreaRenderer4.lookupSeriesOutlinePaint((-1));
        try {
            java.lang.String str13 = numberFormat1.format((java.lang.Object) paint12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.awt.geom.Rectangle2D rectangle2D2 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D3.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot3D3.notifyListeners(plotChangeEvent7);
        org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D2, (org.jfree.chart.plot.Plot) piePlot3D3, "");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke12 = combinedRangeXYPlot11.getRangeMinorGridlineStroke();
        combinedRangeXYPlot11.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = combinedRangeXYPlot11.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection14);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity((java.awt.Shape) rectangle2D2, (org.jfree.chart.plot.Plot) combinedRangeXYPlot11, "");
        org.jfree.chart.axis.AxisSpace axisSpace18 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot11.setFixedDomainAxisSpace(axisSpace18);
        axisSpace18.setBottom(0.0d);
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(xYItemRenderer15);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        boolean boolean6 = month2.equals((java.lang.Object) chartRenderingInfo4);
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("hi!", (org.jfree.data.time.RegularTimePeriod) month2, (org.jfree.data.time.RegularTimePeriod) year8);
        java.util.Locale locale10 = periodAxis9.getLocale();
        double double11 = periodAxis9.getUpperMargin();
        java.util.TimeZone timeZone12 = null;
        try {
            periodAxis9.setTimeZone(timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1559372400000L + "'", long7 == 1559372400000L);
        org.junit.Assert.assertNotNull(locale10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = xYAreaRenderer0.getToolTipGenerator(8, 2019, false);
        boolean boolean6 = xYAreaRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(xYToolTipGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean2 = barRenderer0.getAutoPopulateSeriesFillPaint();
        boolean boolean3 = barRenderer0.getShadowsVisible();
        boolean boolean4 = barRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "ERROR : Relative To String", (double) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        int int2 = xYSeriesCollection0.indexOf((java.lang.Comparable) '#');
        double double4 = xYSeriesCollection0.getDomainUpperBound(false);
        double double5 = xYSeriesCollection0.getIntervalPositionFactor();
        double double6 = xYSeriesCollection0.getIntervalPositionFactor();
        int int7 = xYSeriesCollection0.getSeriesCount();
        org.jfree.data.Range range9 = xYSeriesCollection0.getRangeBounds(true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection();
        xYSeriesCollection0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection10);
        try {
            boolean boolean14 = xYSeriesCollection0.isSelected(100, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean2 = barRenderer0.getAutoPopulateSeriesFillPaint();
        boolean boolean3 = barRenderer0.getShadowsVisible();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = barRenderer0.getSeriesToolTipGenerator((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer6.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint8 = barRenderer6.getShadowPaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint10 = xYAreaRenderer9.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYAreaRenderer9.getBasePositiveItemLabelPosition();
        barRenderer6.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
        org.junit.Assert.assertNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        int int2 = legendItemCollection1.getItemCount();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D4.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot3D4.notifyListeners(plotChangeEvent8);
        java.awt.Shape shape10 = piePlot3D4.getLegendItemShape();
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot11.setAngleGridlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = color12.darker();
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("Combined Range XYPlot", "", "hi!", "hi!", shape10, (java.awt.Paint) color14);
        java.awt.Shape shape16 = legendItem15.getShape();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        int int19 = xYSeriesCollection17.indexOf((java.lang.Comparable) '#');
        double double21 = xYSeriesCollection17.getDomainUpperBound(false);
        double double22 = xYSeriesCollection17.getIntervalPositionFactor();
        legendItem15.setDataset((org.jfree.data.general.Dataset) xYSeriesCollection17);
        boolean boolean24 = legendItem15.isLineVisible();
        org.jfree.data.xy.XYSeries xYSeries27 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double28 = xYSeries27.getMinX();
        xYSeries27.add((double) 100.0f, 0.0d);
        boolean boolean32 = legendItem15.equals((java.lang.Object) xYSeries27);
        java.awt.Paint paint33 = legendItem15.getLabelPaint();
        java.awt.Stroke stroke34 = legendItem15.getOutlineStroke();
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = combinedRangeXYPlot0.getRendererForDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = logAxis5.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange11);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, list10, (org.jfree.data.Range) dateRange11, false);
        java.util.List list15 = timeSeriesCollection2.getSeries();
        double double17 = timeSeriesCollection2.getDomainUpperBound(true);
        org.junit.Assert.assertNull(xYItemRenderer3);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity18 = new org.jfree.chart.entity.PieSectionEntity(shape11, pieDataset12, (int) 'a', 2019, (java.lang.Comparable) "red", "", "red");
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean20 = pieSectionEntity18.equals((java.lang.Object) range19);
        org.jfree.data.Range range23 = org.jfree.data.Range.shift(range19, 1.0E-8d, true);
        org.jfree.data.Range range26 = new org.jfree.data.Range((double) (short) 0, (double) 100L);
        boolean boolean27 = range19.intersects(range26);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.util.List list6 = logAxis1.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = java.awt.Color.red;
        logAxis1.setTickMarkPaint((java.awt.Paint) color7);
        logAxis1.setMinorTickMarkInsideLength((float) (short) -1);
        java.awt.Shape shape11 = logAxis1.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke13 = combinedRangeXYPlot12.getRangeMinorGridlineStroke();
        combinedRangeXYPlot12.clearAnnotations();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection15 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = combinedRangeXYPlot12.getRendererForDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection15);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        java.util.List list18 = combinedRangeXYPlot12.getAnnotations();
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = null;
        logAxis21.setStandardTickUnits(tickUnitSource22);
        boolean boolean24 = logAxis21.isNegativeArrowVisible();
        logAxis21.pan((double) (short) 1);
        combinedRangeXYPlot12.setDomainAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) logAxis21, false);
        java.awt.Stroke stroke29 = null;
        try {
            combinedRangeXYPlot12.setRangeCrosshairStroke(stroke29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(xYItemRenderer16);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setCircular(true, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot3D0.notifyListeners(plotChangeEvent4);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = piePlot3D0.getLabelDistributor();
        piePlot3D0.setForegroundAlpha((float) (short) 0);
        double double9 = piePlot3D0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-5d + "'", double9 == 1.0E-5d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        try {
            defaultPieDataset0.remove((java.lang.Comparable) "DateTickUnitType.SECOND");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (DateTickUnitType.SECOND) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean2 = segmentedTimeline0.containsDomainValue(date1);
        long long3 = segmentedTimeline0.getSegmentSize();
        long long4 = segmentedTimeline0.getSegmentsExcludedSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 86400000L + "'", long3 == 86400000L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 172800000L + "'", long4 == 172800000L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = textTitle9.getTextAlignment();
        java.lang.Object obj11 = textTitle9.clone();
        java.lang.String str12 = textTitle9.getToolTipText();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color1);
        java.awt.Color color3 = color1.darker();
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { color3 };
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100L, (float) (short) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        combinedRangeXYPlot9.setDomainAxisLocation((int) 'a', axisLocation11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot9);
        org.jfree.chart.title.LegendTitle legendTitle15 = jFreeChart13.getLegend(100);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity18 = new org.jfree.chart.entity.JFreeChartEntity(shape7, jFreeChart13, "", "0,0,1,1");
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int21 = color20.getGreen();
        java.awt.Color color22 = java.awt.Color.getColor("hi!", color20);
        boolean boolean23 = jFreeChart13.equals((java.lang.Object) color22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color22, color24 };
        java.awt.Stroke[] strokeArray26 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray27 = null;
        java.awt.Shape[] shapeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray25, strokeArray26, strokeArray27, shapeArray28);
        java.lang.Object obj30 = defaultDrawingSupplier29.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(legendTitle15);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(shapeArray28);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (-1.0d), false);
        double double3 = xYSeries2.getMinX();
        xYSeries2.add((double) 100.0f, 0.0d);
        xYSeries2.setNotify(true);
        boolean boolean9 = xYSeries2.getAllowDuplicateXValues();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        combinedRangeXYPlot0.setDomainMinorGridlinesVisible(false);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.YELLOW;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color4);
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("0,0,1,1", font3, (org.jfree.chart.plot.Plot) polarPlot6, false);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("0,0,1,1", font3);
        textTitle9.setToolTipText("red");
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        polarPlot12.setAngleGridlinePaint((java.awt.Paint) color13);
        java.awt.Color color15 = color13.darker();
        textTitle9.setPaint((java.awt.Paint) color13);
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        org.jfree.chart.entity.EntityCollection entityCollection19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo(entityCollection19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        boolean boolean22 = month18.equals((java.lang.Object) chartRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D23 = chartRenderingInfo20.getChartArea();
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D23, "", "Combined Range XYPlot");
        textTitle9.setBounds(rectangle2D23);
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100L, (float) (short) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        combinedRangeXYPlot32.setDomainAxisLocation((int) 'a', axisLocation34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) combinedRangeXYPlot32);
        org.jfree.chart.title.LegendTitle legendTitle38 = jFreeChart36.getLegend(100);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity41 = new org.jfree.chart.entity.JFreeChartEntity(shape30, jFreeChart36, "", "0,0,1,1");
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int44 = color43.getGreen();
        java.awt.Color color45 = java.awt.Color.getColor("hi!", color43);
        boolean boolean46 = jFreeChart36.equals((java.lang.Object) color45);
        boolean boolean47 = jFreeChart36.getAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textTitle9, jFreeChart36);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNull(legendTitle38);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 255 + "'", int44 == 255);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }
}

