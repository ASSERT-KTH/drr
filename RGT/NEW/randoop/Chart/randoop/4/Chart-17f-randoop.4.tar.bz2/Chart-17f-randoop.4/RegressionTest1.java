import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) "ClassContext");
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560439277328L + "'", long6 == 1560439277328L);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        timeSeries1.setKey((java.lang.Comparable) ' ');
        timeSeries1.fireSeriesChanged();
        java.util.List list8 = timeSeries1.getItems();
        timeSeries1.removeAgedItems(false);
        java.lang.Comparable comparable11 = timeSeries1.getKey();
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy((int) (byte) -1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + ' ' + "'", comparable11.equals(' '));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        timeSeries2.setRangeDescription("hi!");
        java.util.Collection collection5 = timeSeries2.getTimePeriods();
        int int6 = fixedMillisecond0.compareTo((java.lang.Object) collection5);
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int6, "", "First", class9);
        try {
            org.jfree.data.time.TimeSeries timeSeries13 = timeSeries10.createCopy((int) '4', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener8);
//        boolean boolean10 = timeSeries1.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number12 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, number12);
//        java.lang.String str14 = fixedMillisecond11.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 100);
//        long long17 = fixedMillisecond11.getFirstMillisecond();
//        java.util.Date date18 = fixedMillisecond11.getTime();
//        long long19 = fixedMillisecond11.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Thu Jun 13 08:21:17 PDT 2019" + "'", str14.equals("Thu Jun 13 08:21:17 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560439277379L + "'", long17 == 1560439277379L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560439277379L + "'", long19 == 1560439277379L);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = timeSeries4.getRangeDescription();
        int int9 = month0.compareTo((java.lang.Object) timeSeries4);
        java.util.Calendar calendar10 = null;
        try {
            month0.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month10);
        java.lang.String str13 = timeSeries9.getRangeDescription();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        int int16 = month14.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (short) 0);
        timeSeries9.setKey((java.lang.Comparable) timeSeriesDataItem18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getMonth();
        java.util.Date date23 = month21.getEnd();
        java.util.Date date24 = month21.getStart();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) month21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 10L);
        java.lang.Class class28 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        int int30 = month29.getMonth();
        java.util.Date date31 = month29.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date31);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date31, timeZone35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month10);
        java.lang.String str13 = timeSeries9.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries9.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int17 = month16.getMonth();
        java.util.Date date18 = month16.getEnd();
        java.util.Date date19 = month16.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) 0L);
        int int22 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month16);
        timeSeries1.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        long long25 = timeSeries1.getMaximumItemAge();
        timeSeries1.setKey((java.lang.Comparable) 1560439234660L);
        java.lang.Object obj28 = null;
        boolean boolean29 = timeSeries1.equals(obj28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemCount(10);
        timeSeries1.setKey((java.lang.Comparable) (-1.0d));
        boolean boolean11 = timeSeries1.getNotify();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        int int13 = month12.getMonth();
        java.util.Date date14 = month12.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
        java.lang.String str17 = serialDate16.toString();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate16);
        int int19 = day18.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        int int27 = month26.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries25.getDataItem((org.jfree.data.time.RegularTimePeriod) month26);
        java.lang.String str29 = timeSeries25.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries25.removePropertyChangeListener(propertyChangeListener30);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries25.removeChangeListener(seriesChangeListener32);
        boolean boolean34 = timeSeries25.getNotify();
        java.lang.Class class35 = timeSeries25.getTimePeriodClass();
        java.net.URL uRL36 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 08:20:28 PDT 2019", class35);
        java.net.URL uRL37 = org.jfree.chart.util.ObjectUtilities.getResource("", class35);
        int int38 = day18.compareTo((java.lang.Object) class35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day18.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "30-June-2019" + "'", str17.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Value" + "'", str29.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNull(uRL36);
        org.junit.Assert.assertNotNull(uRL37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        java.util.Date date4 = month2.getEnd();
        boolean boolean5 = year0.equals((java.lang.Object) date4);
        long long6 = year0.getFirstMillisecond();
        long long7 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.next();
        long long9 = year0.getLastMillisecond();
        int int10 = year0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        timeSeries1.setKey((java.lang.Comparable) ' ');
        timeSeries1.fireSeriesChanged();
        java.util.List list8 = timeSeries1.getItems();
        timeSeries1.removeAgedItems(false);
        timeSeries1.setDomainDescription("ClassContext");
        int int13 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.String str3 = fixedMillisecond0.toString();
//        long long4 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 0L);
//        int int8 = fixedMillisecond0.compareTo((java.lang.Object) 1560439233258L);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond0.getFirstMillisecond(calendar9);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Thu Jun 13 08:21:18 PDT 2019" + "'", str3.equals("Thu Jun 13 08:21:18 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560439278125L + "'", long4 == 1560439278125L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560439278125L + "'", long10 == 1560439278125L);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (short) 0);
        java.lang.String str5 = month0.toString();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        java.util.Date date8 = month6.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        int int12 = month0.compareTo((java.lang.Object) day11);
        int int13 = month0.getYearValue();
        long long14 = month0.getFirstMillisecond();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = month0.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1559372400000L + "'", long14 == 1559372400000L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month10);
        java.lang.String str13 = timeSeries9.getRangeDescription();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        int int16 = month14.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (short) 0);
        timeSeries9.setKey((java.lang.Comparable) timeSeriesDataItem18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getMonth();
        java.util.Date date23 = month21.getEnd();
        java.util.Date date24 = month21.getStart();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) year20, (org.jfree.data.time.RegularTimePeriod) month21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 10L);
        java.lang.String str28 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Time" + "'", str28.equals("Time"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.setDescription("ThreadContext");
        timeSeries1.setDescription("30-June-2018");
        timeSeries1.setDescription("org.jfree.data.time.TimePeriodFormatException: Thu Jun 13 08:20:22 PDT 2019");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) ' ', 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Date date3 = fixedMillisecond0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.previous();
//        long long5 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 5);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond0.getFirstMillisecond(calendar8);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560439278883L + "'", long5 == 1560439278883L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560439278883L + "'", long9 == 1560439278883L);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        timeSeries1.setRangeDescription("hi!");
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        int int5 = timeSeries1.getMaximumItemCount();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries1.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        long long12 = year10.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.previous();
        int int14 = month9.compareTo((java.lang.Object) year10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 1560439248159L);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        int int2 = year0.getYear();
        int int3 = year0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560439278976L + "'", long4 == 1560439278976L);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        long long6 = day5.getFirstMillisecond();
        long long7 = day5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Object obj11 = timeSeries10.clone();
        java.lang.Object obj12 = timeSeries10.clone();
        boolean boolean13 = day5.equals(obj12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) 1560439239079L);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem15);
        java.lang.Object obj17 = timeSeriesDataItem15.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561878000000L + "'", long6 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        long long6 = day5.getFirstMillisecond();
        long long7 = day5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Object obj11 = timeSeries10.clone();
        java.lang.Object obj12 = timeSeries10.clone();
        boolean boolean13 = day5.equals(obj12);
        int int14 = day5.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561878000000L + "'", long6 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.String str3 = fixedMillisecond0.toString();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        int int9 = month8.getMonth();
//        java.util.Date date10 = month8.getEnd();
//        boolean boolean11 = year6.equals((java.lang.Object) date10);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        int int13 = month12.getMonth();
//        java.util.Date date14 = month12.getEnd();
//        int int15 = year6.compareTo((java.lang.Object) date14);
//        int int16 = fixedMillisecond0.compareTo((java.lang.Object) date14);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond0);
//        java.lang.Object obj18 = seriesChangeEvent17.getSource();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Thu Jun 13 08:21:20 PDT 2019" + "'", str3.equals("Thu Jun 13 08:21:20 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560439280023L + "'", long5 == 1560439280023L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(obj18);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        timeSeries1.setKey((java.lang.Comparable) ' ');
        boolean boolean7 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemCount(0);
        java.lang.String str10 = timeSeries1.getRangeDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        java.util.Date date10 = month8.getEnd();
        java.util.Date date11 = month8.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (double) 0L);
        java.lang.Class class14 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str20 = month15.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month15.previous();
        java.util.Date date22 = regularTimePeriod21.getEnd();
        java.util.TimeZone timeZone23 = null;
        try {
            org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemCount(10);
        timeSeries1.setKey((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month11);
        timeSeries1.clear();
        timeSeries1.setMaximumItemCount(2958465);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.fireSeriesChanged();
        java.util.Collection collection7 = timeSeries1.getTimePeriods();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(collection7);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener8);
//        boolean boolean10 = timeSeries1.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        timeSeries12.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, number16);
//        long long18 = fixedMillisecond15.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 1560439220158L);
//        long long21 = fixedMillisecond15.getSerialIndex();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        int int25 = month24.getMonth();
//        java.util.Date date26 = month24.getEnd();
//        boolean boolean27 = year22.equals((java.lang.Object) date26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        int int29 = month28.getMonth();
//        java.util.Date date30 = month28.getEnd();
//        int int31 = year22.compareTo((java.lang.Object) date30);
//        long long32 = year22.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) year22);
//        java.lang.String str34 = year22.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 1560439223659L);
//        java.beans.PropertyChangeListener propertyChangeListener37 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener37);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560439280227L + "'", long18 == 1560439280227L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560439280227L + "'", long21 == 1560439280227L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        java.util.Date date5 = month3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date5);
        java.lang.String str8 = serialDate7.toString();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate7);
        java.lang.String str10 = serialDate9.toString();
        boolean boolean11 = spreadsheetDate1.isOn(serialDate9);
        int int12 = spreadsheetDate1.getMonth();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        int int15 = month14.getMonth();
        java.util.Date date16 = month14.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date16);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears(0, serialDate18);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
        boolean boolean22 = spreadsheetDate1.isOn(serialDate20);
        int int23 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "30-June-2019" + "'", str8.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "30-June-2018" + "'", str10.equals("30-June-2018"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((-572));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        long long6 = day5.getFirstMillisecond();
        long long7 = day5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Object obj11 = timeSeries10.clone();
        java.lang.Object obj12 = timeSeries10.clone();
        boolean boolean13 = day5.equals(obj12);
        java.util.Date date14 = day5.getStart();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        java.lang.String str20 = timeSeries16.getRangeDescription();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int23 = month21.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (short) 0);
        timeSeries16.setKey((java.lang.Comparable) timeSeriesDataItem25);
        int int27 = day5.compareTo((java.lang.Object) timeSeries16);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561878000000L + "'", long6 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number7 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, number7);
//        java.lang.String str9 = fixedMillisecond6.toString();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond6.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getMonth();
//        java.util.Date date16 = month14.getEnd();
//        boolean boolean17 = year12.equals((java.lang.Object) date16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        int int19 = month18.getMonth();
//        java.util.Date date20 = month18.getEnd();
//        int int21 = year12.compareTo((java.lang.Object) date20);
//        int int22 = fixedMillisecond6.compareTo((java.lang.Object) date20);
//        long long23 = fixedMillisecond6.getMiddleMillisecond();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 100, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Thu Jun 13 08:21:20 PDT 2019" + "'", str9.equals("Thu Jun 13 08:21:20 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560439280840L + "'", long11 == 1560439280840L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560439280840L + "'", long23 == 1560439280840L);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        java.lang.String str9 = timeSeries5.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries5.removeChangeListener(seriesChangeListener10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        int int13 = month12.getMonth();
        java.util.Date date14 = month12.getEnd();
        java.util.Date date15 = month12.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month12, (double) 0L);
        java.lang.Class class18 = timeSeries5.getTimePeriodClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize(class18);
        java.net.URL uRL20 = org.jfree.chart.util.ObjectUtilities.getResource("ClassContext", class19);
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:20:27 PDT 2019", class19);
        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResource("ClassContext", class19);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        int int26 = month25.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) month25);
        java.lang.String str28 = timeSeries24.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries24.removePropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int34 = month33.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        java.lang.String str36 = timeSeries32.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries32.removeChangeListener(seriesChangeListener37);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        int int40 = month39.getMonth();
        java.util.Date date41 = month39.getEnd();
        java.util.Date date42 = month39.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month39, (double) 0L);
        int int45 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) month39);
        java.util.Date date46 = month39.getEnd();
        long long47 = month39.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        int int56 = month55.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries54.getDataItem((org.jfree.data.time.RegularTimePeriod) month55);
        java.lang.String str58 = timeSeries54.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener59 = null;
        timeSeries54.removeChangeListener(seriesChangeListener59);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month();
        int int62 = month61.getMonth();
        java.util.Date date63 = month61.getEnd();
        java.util.Date date64 = month61.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries54.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month61, (double) 0L);
        java.lang.Class class67 = timeSeries54.getTimePeriodClass();
        java.lang.Class class68 = org.jfree.data.time.RegularTimePeriod.downsize(class67);
        java.net.URL uRL69 = org.jfree.chart.util.ObjectUtilities.getResource("ClassContext", class68);
        java.lang.Object obj70 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:20:27 PDT 2019", class68);
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month();
        int int74 = month73.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries72.getDataItem((org.jfree.data.time.RegularTimePeriod) month73);
        java.lang.String str76 = timeSeries72.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener77 = null;
        timeSeries72.removeChangeListener(seriesChangeListener77);
        org.jfree.data.time.Month month79 = new org.jfree.data.time.Month();
        int int80 = month79.getMonth();
        java.util.Date date81 = month79.getEnd();
        java.util.Date date82 = month79.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = timeSeries72.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month79, (double) 0L);
        java.lang.Class class85 = timeSeries72.getTimePeriodClass();
        java.lang.Class class86 = org.jfree.data.time.RegularTimePeriod.downsize(class85);
        java.lang.Object obj87 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:20:28 PDT 2019", class68, class86);
        org.jfree.data.time.TimeSeries timeSeries88 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month39, "Thu Jun 13 08:20:41 PDT 2019", "Thu Jun 13 08:20:35 PDT 2019", class68);
        java.lang.Object obj89 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:20:47 PDT 2019", class19, class68);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNull(uRL20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNull(uRL22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Value" + "'", str36.equals("Value"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 24234L + "'", long47 == 24234L);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 6 + "'", int56 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Value" + "'", str58.equals("Value"));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 6 + "'", int62 == 6);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertNotNull(class67);
        org.junit.Assert.assertNotNull(class68);
        org.junit.Assert.assertNull(uRL69);
        org.junit.Assert.assertNull(obj70);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 6 + "'", int74 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "Value" + "'", str76.equals("Value"));
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 6 + "'", int80 == 6);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNull(timeSeriesDataItem84);
        org.junit.Assert.assertNotNull(class85);
        org.junit.Assert.assertNotNull(class86);
        org.junit.Assert.assertNull(obj87);
        org.junit.Assert.assertNull(obj89);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        timeSeries1.setKey((java.lang.Comparable) ' ');
//        timeSeries1.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        timeSeries9.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number13 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number13);
//        long long15 = fixedMillisecond12.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 1560439220158L);
//        long long18 = fixedMillisecond12.getSerialIndex();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        int int22 = month21.getMonth();
//        java.util.Date date23 = month21.getEnd();
//        boolean boolean24 = year19.equals((java.lang.Object) date23);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        int int26 = month25.getMonth();
//        java.util.Date date27 = month25.getEnd();
//        int int28 = year19.compareTo((java.lang.Object) date27);
//        long long29 = year19.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) year19);
//        java.lang.String str31 = year19.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year19, (-1.0d));
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        int int35 = month34.getMonth();
//        java.util.Date date36 = month34.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date36);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(serialDate38);
//        long long40 = day39.getFirstMillisecond();
//        long long41 = day39.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day39.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) 1560439263905L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560439281780L + "'", long15 == 1560439281780L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560439281780L + "'", long18 == 1560439281780L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1561878000000L + "'", long40 == 1561878000000L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1561964399999L + "'", long41 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year7 = month6.getYear();
        java.lang.String str8 = month6.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "June 2019" + "'", str8.equals("June 2019"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        boolean boolean5 = timeSeries1.getNotify();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        java.util.Date date8 = month6.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        long long12 = day11.getFirstMillisecond();
        long long13 = day11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int17 = month15.compareTo((java.lang.Object) "hi!");
        boolean boolean18 = day11.equals((java.lang.Object) month15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) 1560439278297L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561878000000L + "'", long12 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1560439240880L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        long long6 = day5.getFirstMillisecond();
        long long7 = day5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.previous();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) "hi!");
        boolean boolean12 = day5.equals((java.lang.Object) month9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month9.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561878000000L + "'", long6 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.Number number3 = timeSeriesDataItem2.getValue();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, number5);
//        long long7 = fixedMillisecond4.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 1560439220158L);
//        boolean boolean10 = timeSeriesDataItem2.equals((java.lang.Object) fixedMillisecond4);
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond4.peg(calendar11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond4.next();
//        java.util.Calendar calendar14 = null;
//        fixedMillisecond4.peg(calendar14);
//        org.junit.Assert.assertNull(number3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560439282399L + "'", long7 == 1560439282399L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        int int4 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.next();
        java.util.Calendar calendar6 = null;
        try {
            month0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month10);
        java.lang.String str13 = timeSeries9.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries9.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int17 = month16.getMonth();
        java.util.Date date18 = month16.getEnd();
        java.util.Date date19 = month16.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) 0L);
        int int22 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month16);
        java.util.Date date23 = month16.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.lang.Object obj2 = null;
        boolean boolean3 = fixedMillisecond1.equals(obj2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (short) 0);
        timeSeriesDataItem4.setValue((java.lang.Number) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) month9);
        java.lang.String str12 = timeSeries8.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries8.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries8.removeChangeListener(seriesChangeListener15);
        java.lang.String str17 = timeSeries8.getRangeDescription();
        timeSeries8.setDescription("");
        boolean boolean20 = timeSeriesDataItem4.equals((java.lang.Object) "");
        java.lang.Number number21 = timeSeriesDataItem4.getValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 100.0f + "'", number21.equals(100.0f));
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.String str3 = fixedMillisecond0.toString();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getMiddleMillisecond(calendar4);
//        long long6 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getMiddleMillisecond(calendar7);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Thu Jun 13 08:21:22 PDT 2019" + "'", str3.equals("Thu Jun 13 08:21:22 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560439282644L + "'", long5 == 1560439282644L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560439282644L + "'", long6 == 1560439282644L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560439282644L + "'", long8 == 1560439282644L);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        boolean boolean8 = year3.equals((java.lang.Object) date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date7, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date2, timeZone9);
        java.lang.String str12 = day11.toString();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day11.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "30-June-2019" + "'", str12.equals("30-June-2019"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        long long6 = day5.getFirstMillisecond();
        int int7 = day5.getYear();
        java.lang.Class<?> wildcardClass8 = day5.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561878000000L + "'", long6 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        int int11 = month10.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month10);
//        java.lang.String str13 = timeSeries9.getRangeDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener14);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        int int17 = month16.getMonth();
//        java.util.Date date18 = month16.getEnd();
//        java.util.Date date19 = month16.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) 0L);
//        int int22 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month16);
//        timeSeries1.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        long long25 = timeSeries1.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        int int29 = month28.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries27.getDataItem((org.jfree.data.time.RegularTimePeriod) month28);
//        java.lang.String str31 = timeSeries27.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timeSeries27.removePropertyChangeListener(propertyChangeListener32);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
//        timeSeries27.removeChangeListener(seriesChangeListener34);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        int int39 = month38.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) month38);
//        java.lang.String str41 = timeSeries37.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener42 = null;
//        timeSeries37.removePropertyChangeListener(propertyChangeListener42);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries37.removeChangeListener(seriesChangeListener44);
//        boolean boolean46 = timeSeries37.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number48 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, number48);
//        java.lang.String str50 = fixedMillisecond47.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (java.lang.Number) 100);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries27.addAndOrUpdate(timeSeries37);
//        java.lang.Comparable comparable54 = timeSeries37.getKey();
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries1.addAndOrUpdate(timeSeries37);
//        java.util.List list56 = timeSeries55.getItems();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Value" + "'", str41.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Thu Jun 13 08:21:22 PDT 2019" + "'", str50.equals("Thu Jun 13 08:21:22 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem52);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + comparable54 + "' != '" + (short) 100 + "'", comparable54.equals((short) 100));
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertNotNull(list56);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.fireSeriesChanged();
        java.lang.String str11 = timeSeries1.getRangeDescription();
        timeSeries1.setMaximumItemCount(716968);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560439220158L);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        timeSeries7.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number11 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
//        long long13 = fixedMillisecond10.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 1560439220158L);
//        long long16 = fixedMillisecond10.getSerialIndex();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        int int20 = month19.getMonth();
//        java.util.Date date21 = month19.getEnd();
//        boolean boolean22 = year17.equals((java.lang.Object) date21);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        int int24 = month23.getMonth();
//        java.util.Date date25 = month23.getEnd();
//        int int26 = year17.compareTo((java.lang.Object) date25);
//        long long27 = year17.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (org.jfree.data.time.RegularTimePeriod) year17);
//        boolean boolean29 = timeSeriesDataItem5.equals((java.lang.Object) year17);
//        long long30 = year17.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560439283407L + "'", long3 == 1560439283407L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560439283430L + "'", long13 == 1560439283430L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560439283430L + "'", long16 == 1560439283430L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Nearest");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: Nearest" + "'", str2.equals("org.jfree.data.general.SeriesException: Nearest"));
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        int int13 = month12.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) month12);
//        java.lang.String str15 = timeSeries11.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener18);
//        boolean boolean20 = timeSeries11.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, number22);
//        java.lang.String str24 = fixedMillisecond21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 100);
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries1.addAndOrUpdate(timeSeries11);
//        java.util.Collection collection28 = timeSeries27.getTimePeriods();
//        java.lang.Object obj29 = timeSeries27.clone();
//        java.lang.Class class30 = timeSeries27.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Thu Jun 13 08:21:23 PDT 2019" + "'", str24.equals("Thu Jun 13 08:21:23 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertNotNull(obj29);
//        org.junit.Assert.assertNotNull(class30);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        java.util.Date date5 = month3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(0, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((int) (short) 10, serialDate7);
        try {
            org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 10, serialDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(7, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jul" + "'", str2.equals("Jul"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        java.util.Date date4 = month2.getEnd();
        boolean boolean5 = year0.equals((java.lang.Object) date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4, timeZone6);
        org.jfree.data.time.Year year8 = month7.getYear();
        java.lang.Object obj9 = null;
        int int10 = year8.compareTo(obj9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 1561964399999L);
        timeSeriesDataItem12.setValue((java.lang.Number) 8);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        boolean boolean10 = timeSeries1.getNotify();
        java.lang.Class class11 = timeSeries1.getTimePeriodClass();
        java.lang.Comparable comparable12 = timeSeries1.getKey();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = null;
        try {
            timeSeries1.add(regularTimePeriod13, (double) 1560439244001L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + (short) 100 + "'", comparable12.equals((short) 100));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Object obj2 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = timeSeries4.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries4.removeChangeListener(seriesChangeListener9);
        timeSeries4.setDescription("Thu Jun 13 08:20:26 PDT 2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries4.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries4);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries15);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        long long6 = day5.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate7 = day5.getSerialDate();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        java.util.Date date4 = month2.getEnd();
        boolean boolean5 = year0.equals((java.lang.Object) date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4, timeZone6);
        org.jfree.data.time.Year year8 = month7.getYear();
        java.lang.Object obj9 = null;
        int int10 = year8.compareTo(obj9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 1561964399999L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        java.lang.Number number14 = timeSeriesDataItem12.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1561964399999L + "'", number14.equals(1561964399999L));
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        int int13 = month12.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) month12);
//        java.lang.String str15 = timeSeries11.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener18);
//        boolean boolean20 = timeSeries11.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, number22);
//        java.lang.String str24 = fixedMillisecond21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 100);
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries1.addAndOrUpdate(timeSeries11);
//        java.lang.Comparable comparable28 = timeSeries1.getKey();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Thu Jun 13 08:21:23 PDT 2019" + "'", str24.equals("Thu Jun 13 08:21:23 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (short) 100 + "'", comparable28.equals((short) 100));
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemCount(10);
        timeSeries1.setKey((java.lang.Comparable) (-1.0d));
        boolean boolean11 = timeSeries1.getNotify();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        int int13 = month12.getMonth();
        java.util.Date date14 = month12.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
        java.lang.String str17 = serialDate16.toString();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate16);
        int int19 = day18.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) 100.0f);
        timeSeries1.clear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "30-June-2019" + "'", str17.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) 'a');
        java.lang.String str3 = month2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January 97" + "'", str3.equals("January 97"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        java.util.Date date4 = month2.getEnd();
        boolean boolean5 = year0.equals((java.lang.Object) date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4, timeZone6);
        org.jfree.data.time.Year year8 = month7.getYear();
        java.lang.Object obj9 = null;
        int int10 = year8.compareTo(obj9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 1561964399999L);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str18 = timeSeries14.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries14.removePropertyChangeListener(propertyChangeListener19);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries14.removeChangeListener(seriesChangeListener21);
        timeSeries14.fireSeriesChanged();
        java.lang.String str24 = timeSeries14.getRangeDescription();
        boolean boolean25 = timeSeriesDataItem12.equals((java.lang.Object) timeSeries14);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        int int6 = month2.compareTo((java.lang.Object) 1560439225257L);
        int int7 = month2.getYearValue();
        long long8 = month2.getFirstMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month2.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559372400000L + "'", long8 == 1559372400000L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        long long6 = day5.getFirstMillisecond();
        long long7 = day5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.previous();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) "hi!");
        boolean boolean12 = day5.equals((java.lang.Object) month9);
        long long13 = day5.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561878000000L + "'", long6 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month10);
        java.lang.String str13 = timeSeries9.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries9.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int17 = month16.getMonth();
        java.util.Date date18 = month16.getEnd();
        java.util.Date date19 = month16.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) 0L);
        int int22 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month16);
        timeSeries1.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener25);
        java.lang.Object obj27 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        java.lang.Number number3 = timeSeriesDataItem2.getValue();
        java.lang.Number number4 = timeSeriesDataItem2.getValue();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        long long7 = year5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.previous();
        int int9 = timeSeriesDataItem2.compareTo((java.lang.Object) regularTimePeriod8);
        java.lang.Object obj10 = null;
        int int11 = timeSeriesDataItem2.compareTo(obj10);
        timeSeriesDataItem2.setValue((java.lang.Number) 9223372036854775807L);
        java.lang.Object obj14 = timeSeriesDataItem2.clone();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Thu Jun 13 08:20:22 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener8);
//        boolean boolean10 = timeSeries1.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number12 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, number12);
//        java.lang.String str14 = fixedMillisecond11.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 100);
//        long long17 = fixedMillisecond11.getFirstMillisecond();
//        long long18 = fixedMillisecond11.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond11.next();
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond11.getFirstMillisecond(calendar20);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond11.getLastMillisecond(calendar22);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond11.getMiddleMillisecond(calendar24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Thu Jun 13 08:21:24 PDT 2019" + "'", str14.equals("Thu Jun 13 08:21:24 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560439284549L + "'", long17 == 1560439284549L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560439284549L + "'", long18 == 1560439284549L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560439284549L + "'", long21 == 1560439284549L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560439284549L + "'", long23 == 1560439284549L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560439284549L + "'", long25 == 1560439284549L);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        int int2 = month1.getMonth();
        java.util.Date date3 = month1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears(0, serialDate5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        long long9 = day8.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1561878000000L + "'", long9 == 1561878000000L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        java.util.Date date4 = month2.getEnd();
        boolean boolean5 = year0.equals((java.lang.Object) date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        java.util.Date date10 = month8.getEnd();
        boolean boolean11 = year6.equals((java.lang.Object) date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10, timeZone12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date4, timeZone12);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = month14.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(timeZone12);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        long long6 = day5.getFirstMillisecond();
        long long7 = day5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.previous();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) "hi!");
        boolean boolean12 = day5.equals((java.lang.Object) month9);
        java.lang.String str13 = month9.toString();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = month9.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561878000000L + "'", long6 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener8);
//        boolean boolean10 = timeSeries1.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number12 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, number12);
//        java.lang.String str14 = fixedMillisecond11.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 100);
//        long long17 = fixedMillisecond11.getFirstMillisecond();
//        java.util.Date date18 = fixedMillisecond11.getTime();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond11.getFirstMillisecond(calendar19);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Thu Jun 13 08:21:24 PDT 2019" + "'", str14.equals("Thu Jun 13 08:21:24 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560439284700L + "'", long17 == 1560439284700L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560439284700L + "'", long20 == 1560439284700L);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.String str3 = fixedMillisecond0.toString();
//        long long4 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek(6);
//        try {
//            org.jfree.data.time.SerialDate serialDate10 = serialDate8.getNearestDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Thu Jun 13 08:21:24 PDT 2019" + "'", str3.equals("Thu Jun 13 08:21:24 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560439284723L + "'", long4 == 1560439284723L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener8);
//        java.lang.String str10 = timeSeries1.getRangeDescription();
//        timeSeries1.setDescription("");
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        int int14 = month13.getMonth();
//        java.util.Date date15 = month13.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
//        long long19 = day18.getFirstMillisecond();
//        long long20 = day18.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
//        timeSeries1.add(regularTimePeriod21, (double) 10.0f, true);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener25);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
//        int int30 = month29.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) month29);
//        java.lang.String str32 = timeSeries28.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timeSeries28.removePropertyChangeListener(propertyChangeListener33);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
//        timeSeries28.removeChangeListener(seriesChangeListener35);
//        timeSeries28.fireSeriesChanged();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries28.addChangeListener(seriesChangeListener38);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
//        int int41 = month40.getMonth();
//        java.util.Date date42 = month40.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(date42);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(serialDate44);
//        long long46 = day45.getFirstMillisecond();
//        long long47 = day45.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = day45.previous();
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
//        int int51 = month49.compareTo((java.lang.Object) "hi!");
//        boolean boolean52 = day45.equals((java.lang.Object) month49);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number54 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, number54);
//        int int57 = fixedMillisecond53.compareTo((java.lang.Object) "ClassContext");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (double) 0.0f);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number61 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, number61);
//        long long63 = fixedMillisecond60.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, (java.lang.Number) 1560439220158L);
//        int int66 = timeSeriesDataItem59.compareTo((java.lang.Object) 1560439220158L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = timeSeriesDataItem59.getPeriod();
//        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) day45, regularTimePeriod67);
//        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month();
//        int int70 = month69.getMonth();
//        java.util.Date date71 = month69.getEnd();
//        java.util.Date date72 = month69.getStart();
//        int int73 = month69.getYearValue();
//        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month();
//        int int75 = month74.getMonth();
//        java.util.Date date76 = month74.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = month74.previous();
//        int int78 = month74.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month74, (double) 6);
//        long long81 = month74.getSerialIndex();
//        boolean boolean82 = month69.equals((java.lang.Object) month74);
//        int int83 = day45.compareTo((java.lang.Object) month74);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day45, (java.lang.Number) 2147483647);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561878000000L + "'", long19 == 1561878000000L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Value" + "'", str32.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1561878000000L + "'", long46 == 1561878000000L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1561964399999L + "'", long47 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560439284768L + "'", long63 == 1560439284768L);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(timeSeries68);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 6 + "'", int70 == 6);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 6 + "'", int75 == 6);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2019 + "'", int78 == 2019);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 24234L + "'", long81 == 24234L);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
//        org.junit.Assert.assertNull(timeSeriesDataItem85);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) "ClassContext");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 0.0f);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, number8);
//        long long10 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 1560439220158L);
//        int int13 = timeSeriesDataItem6.compareTo((java.lang.Object) 1560439220158L);
//        timeSeriesDataItem6.setValue((java.lang.Number) 10.0f);
//        java.lang.Number number16 = timeSeriesDataItem6.getValue();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560439285578L + "'", long10 == 1560439285578L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 10.0f + "'", number16.equals(10.0f));
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = timeSeries4.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries4.removeChangeListener(seriesChangeListener11);
        boolean boolean13 = timeSeries4.getNotify();
        java.lang.Class class14 = timeSeries4.getTimePeriodClass();
        java.lang.Class class15 = null;
        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class14, class15);
        java.net.URL uRL17 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", class14);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        int int24 = month23.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) month23);
        java.lang.String str26 = timeSeries22.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries22.removePropertyChangeListener(propertyChangeListener27);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries22.removeChangeListener(seriesChangeListener29);
        boolean boolean31 = timeSeries22.getNotify();
        java.lang.Class class32 = timeSeries22.getTimePeriodClass();
        java.net.URL uRL33 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 08:20:28 PDT 2019", class32);
        java.net.URL uRL34 = org.jfree.chart.util.ObjectUtilities.getResource("", class32);
        java.net.URL uRL35 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("First", class32);
        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize(class32);
        java.lang.Object obj37 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", class14, class32);
        java.lang.ClassLoader classLoader38 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class32);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader38);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader38);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNull(uRL17);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(class32);
        org.junit.Assert.assertNull(uRL33);
        org.junit.Assert.assertNotNull(uRL34);
        org.junit.Assert.assertNull(uRL35);
        org.junit.Assert.assertNotNull(class36);
        org.junit.Assert.assertNull(obj37);
        org.junit.Assert.assertNotNull(classLoader38);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        java.lang.Class<?> wildcardClass3 = month0.getClass();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        int int13 = month12.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) month12);
//        java.lang.String str15 = timeSeries11.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener18);
//        boolean boolean20 = timeSeries11.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, number22);
//        java.lang.String str24 = fixedMillisecond21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 100);
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries1.addAndOrUpdate(timeSeries11);
//        java.lang.Comparable comparable28 = timeSeries11.getKey();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        int int32 = month31.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) month31);
//        java.lang.String str34 = timeSeries30.getRangeDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
//        timeSeries30.removeChangeListener(seriesChangeListener35);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        int int38 = month37.getMonth();
//        java.util.Date date39 = month37.getEnd();
//        java.util.Date date40 = month37.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month37, (double) 0L);
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
//        int int46 = month45.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries44.getDataItem((org.jfree.data.time.RegularTimePeriod) month45);
//        java.lang.String str48 = timeSeries44.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timeSeries44.removePropertyChangeListener(propertyChangeListener49);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener51 = null;
//        timeSeries44.removeChangeListener(seriesChangeListener51);
//        boolean boolean53 = timeSeries44.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number55 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, number55);
//        java.lang.String str57 = fixedMillisecond54.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (java.lang.Number) 100);
//        long long60 = fixedMillisecond54.getFirstMillisecond();
//        timeSeries30.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (java.lang.Number) 6);
//        java.util.Date date63 = fixedMillisecond54.getTime();
//        java.util.Date date64 = fixedMillisecond54.getTime();
//        try {
//            timeSeries11.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (java.lang.Number) 7);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Thu Jun 13 08:21:25 PDT 2019" + "'", str24.equals("Thu Jun 13 08:21:25 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (short) 100 + "'", comparable28.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Value" + "'", str34.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Value" + "'", str48.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Thu Jun 13 08:21:25 PDT 2019" + "'", str57.equals("Thu Jun 13 08:21:25 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560439285732L + "'", long60 == 1560439285732L);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(date64);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.fireSeriesChanged();
        java.util.Collection collection7 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        java.lang.String str16 = timeSeries12.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries12.removePropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) month21);
        java.lang.String str24 = timeSeries20.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries20.removeChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int28 = month27.getMonth();
        java.util.Date date29 = month27.getEnd();
        java.util.Date date30 = month27.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month27, (double) 0L);
        int int33 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (double) 1560439259151L);
        try {
            timeSeries1.add(timeSeriesDataItem35, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.setDescription("ThreadContext");
        timeSeries1.setDescription("Thu Jun 13 08:20:22 PDT 2019");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        java.lang.String str3 = fixedMillisecond0.toString();
//        long long4 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        int int11 = month10.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month10);
//        java.lang.String str13 = timeSeries9.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timeSeries9.removePropertyChangeListener(propertyChangeListener14);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        int int19 = month18.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) month18);
//        java.lang.String str21 = timeSeries17.getRangeDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries17.removeChangeListener(seriesChangeListener22);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
//        int int25 = month24.getMonth();
//        java.util.Date date26 = month24.getEnd();
//        java.util.Date date27 = month24.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, (double) 0L);
//        int int30 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month24);
//        java.util.Date date31 = month24.getEnd();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.previous();
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        int int36 = month35.getMonth();
//        java.util.Date date37 = month35.getEnd();
//        boolean boolean38 = year33.equals((java.lang.Object) date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.previous();
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        int int42 = month41.getMonth();
//        java.util.Date date43 = month41.getEnd();
//        boolean boolean44 = year39.equals((java.lang.Object) date43);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43, timeZone45);
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date37, timeZone45);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date31, timeZone45);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date5, timeZone45);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Thu Jun 13 08:21:26 PDT 2019" + "'", str3.equals("Thu Jun 13 08:21:26 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560439286877L + "'", long4 == 1560439286877L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(timeZone45);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        int int9 = month8.getMonth();
//        java.util.Date date10 = month8.getEnd();
//        java.util.Date date11 = month8.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (double) 0L);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        int int17 = month16.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) month16);
//        java.lang.String str19 = timeSeries15.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries15.removePropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries15.removeChangeListener(seriesChangeListener22);
//        boolean boolean24 = timeSeries15.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number26 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number26);
//        java.lang.String str28 = fixedMillisecond25.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) 100);
//        long long31 = fixedMillisecond25.getFirstMillisecond();
//        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) 6);
//        long long34 = fixedMillisecond25.getFirstMillisecond();
//        long long35 = fixedMillisecond25.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Thu Jun 13 08:21:27 PDT 2019" + "'", str28.equals("Thu Jun 13 08:21:27 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560439287786L + "'", long31 == 1560439287786L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560439287786L + "'", long34 == 1560439287786L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560439287786L + "'", long35 == 1560439287786L);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) month9);
        java.lang.String str12 = timeSeries8.getRangeDescription();
        timeSeries8.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.addAndOrUpdate(timeSeries8);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int17 = month15.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (short) 0);
        java.lang.String str20 = month15.toString();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getMonth();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date23);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate25);
        int int27 = month15.compareTo((java.lang.Object) day26);
        int int28 = day26.getMonth();
        int int29 = day26.getMonth();
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) day26, (double) 1560439260413L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = timeSeries4.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        java.lang.String str16 = timeSeries12.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries12.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        int int20 = month19.getMonth();
        java.util.Date date21 = month19.getEnd();
        java.util.Date date22 = month19.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month19, (double) 0L);
        int int25 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        java.util.Date date26 = month19.getEnd();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        java.lang.String str28 = serialDate27.toString();
        boolean boolean29 = spreadsheetDate2.isOnOrAfter(serialDate27);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, serialDate27);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "30-June-2019" + "'", str28.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate30);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        int int7 = month6.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
//        java.lang.String str9 = timeSeries5.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries5.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries5.removeChangeListener(seriesChangeListener12);
//        boolean boolean14 = timeSeries5.getNotify();
//        java.lang.Class class15 = timeSeries5.getTimePeriodClass();
//        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 08:20:28 PDT 2019", class15);
//        java.net.URL uRL17 = org.jfree.chart.util.ObjectUtilities.getResource("", class15);
//        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("First", class15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number21 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, number21);
//        java.util.Date date23 = fixedMillisecond20.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond20.previous();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond20.getLastMillisecond(calendar25);
//        java.lang.Class<?> wildcardClass27 = fixedMillisecond20.getClass();
//        java.io.InputStream inputStream28 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Thu Jun 13 08:20:57 PDT 2019", (java.lang.Class) wildcardClass27);
//        java.lang.Object obj29 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:20:29 PDT 2019", class15, (java.lang.Class) wildcardClass27);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNull(uRL16);
//        org.junit.Assert.assertNotNull(uRL17);
//        org.junit.Assert.assertNull(uRL18);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560439288117L + "'", long26 == 1560439288117L);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNull(inputStream28);
//        org.junit.Assert.assertNull(obj29);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        timeSeries1.setRangeDescription("hi!");
//        java.util.Collection collection4 = timeSeries1.getTimePeriods();
//        timeSeries1.clear();
//        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries1, (java.lang.Object) 100.0f);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number9 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, number9);
//        java.lang.String str11 = fixedMillisecond8.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond8.previous();
//        java.lang.Number number13 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, number16);
//        java.lang.String str18 = fixedMillisecond15.toString();
//        long long19 = fixedMillisecond15.getFirstMillisecond();
//        java.util.Date date20 = fixedMillisecond15.getTime();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date20);
//        serialDate22.setDescription("");
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays((-460), serialDate22);
//        boolean boolean26 = fixedMillisecond8.equals((java.lang.Object) serialDate22);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Thu Jun 13 08:21:28 PDT 2019" + "'", str11.equals("Thu Jun 13 08:21:28 PDT 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Thu Jun 13 08:21:28 PDT 2019" + "'", str18.equals("Thu Jun 13 08:21:28 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560439288191L + "'", long19 == 1560439288191L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener8);
//        timeSeries1.fireSeriesChanged();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries1.addChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        int int14 = month13.getMonth();
//        java.util.Date date15 = month13.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
//        long long19 = day18.getFirstMillisecond();
//        long long20 = day18.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        int int24 = month22.compareTo((java.lang.Object) "hi!");
//        boolean boolean25 = day18.equals((java.lang.Object) month22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number27 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, number27);
//        int int30 = fixedMillisecond26.compareTo((java.lang.Object) "ClassContext");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (double) 0.0f);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number34 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, number34);
//        long long36 = fixedMillisecond33.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) 1560439220158L);
//        int int39 = timeSeriesDataItem32.compareTo((java.lang.Object) 1560439220158L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = timeSeriesDataItem32.getPeriod();
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day18, regularTimePeriod40);
//        try {
//            timeSeries41.delete(0, (-572));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561878000000L + "'", long19 == 1561878000000L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560439288300L + "'", long36 == 1560439288300L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(timeSeries41);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        java.util.Date date5 = month3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date5);
        java.lang.String str8 = serialDate7.toString();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate7);
        java.lang.String str10 = serialDate9.toString();
        boolean boolean11 = spreadsheetDate1.isOn(serialDate9);
        java.util.Date date12 = spreadsheetDate1.toDate();
        int int13 = spreadsheetDate1.getYYYY();
        spreadsheetDate1.setDescription("June 2019");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "30-June-2019" + "'", str8.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "30-June-2018" + "'", str10.equals("30-June-2018"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        int int11 = month10.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month10);
//        java.lang.String str13 = timeSeries9.getRangeDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener14);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        int int17 = month16.getMonth();
//        java.util.Date date18 = month16.getEnd();
//        java.util.Date date19 = month16.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) 0L);
//        int int22 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month16);
//        timeSeries1.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        long long25 = timeSeries1.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        int int29 = month28.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries27.getDataItem((org.jfree.data.time.RegularTimePeriod) month28);
//        java.lang.String str31 = timeSeries27.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timeSeries27.removePropertyChangeListener(propertyChangeListener32);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
//        timeSeries27.removeChangeListener(seriesChangeListener34);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        int int39 = month38.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) month38);
//        java.lang.String str41 = timeSeries37.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener42 = null;
//        timeSeries37.removePropertyChangeListener(propertyChangeListener42);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries37.removeChangeListener(seriesChangeListener44);
//        boolean boolean46 = timeSeries37.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number48 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, number48);
//        java.lang.String str50 = fixedMillisecond47.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (java.lang.Number) 100);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries27.addAndOrUpdate(timeSeries37);
//        java.lang.Comparable comparable54 = timeSeries37.getKey();
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries1.addAndOrUpdate(timeSeries37);
//        int int56 = timeSeries55.getMaximumItemCount();
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
//        int int58 = month57.getMonth();
//        java.util.Date date59 = month57.getEnd();
//        java.util.Date date60 = month57.getStart();
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year61.previous();
//        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month();
//        int int64 = month63.getMonth();
//        java.util.Date date65 = month63.getEnd();
//        boolean boolean66 = year61.equals((java.lang.Object) date65);
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year67.previous();
//        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month();
//        int int70 = month69.getMonth();
//        java.util.Date date71 = month69.getEnd();
//        boolean boolean72 = year67.equals((java.lang.Object) date71);
//        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date71, timeZone73);
//        org.jfree.data.time.Month month75 = new org.jfree.data.time.Month(date65, timeZone73);
//        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = year76.previous();
//        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month();
//        int int79 = month78.getMonth();
//        java.util.Date date80 = month78.getEnd();
//        boolean boolean81 = year76.equals((java.lang.Object) date80);
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year(date80, timeZone82);
//        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year(date65, timeZone82);
//        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(date60, timeZone82);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem87 = timeSeries55.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year85, (java.lang.Number) 1560439278976L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Value" + "'", str41.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Thu Jun 13 08:21:28 PDT 2019" + "'", str50.equals("Thu Jun 13 08:21:28 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem52);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + comparable54 + "' != '" + (short) 100 + "'", comparable54.equals((short) 100));
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2147483647 + "'", int56 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 6 + "'", int64 == 6);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 6 + "'", int70 == 6);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(timeZone73);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 6 + "'", int79 == 6);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertNull(timeSeriesDataItem87);
//    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        int int4 = month3.getMonth();
//        java.util.Date date5 = month3.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date5);
//        java.lang.String str8 = serialDate7.getDescription();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate7);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        int int12 = month11.getMonth();
//        java.util.Date date13 = month11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date13);
//        java.lang.String str16 = serialDate15.toString();
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate15);
//        java.lang.String str18 = serialDate17.toString();
//        org.jfree.data.time.SerialDate serialDate19 = serialDate7.getEndOfCurrentMonth(serialDate17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number21 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, number21);
//        java.lang.String str23 = fixedMillisecond20.toString();
//        long long24 = fixedMillisecond20.getFirstMillisecond();
//        java.util.Date date25 = fixedMillisecond20.getTime();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.SerialDate serialDate27 = serialDate7.getEndOfCurrentMonth(serialDate26);
//        org.jfree.data.time.SerialDate serialDate29 = serialDate7.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean30 = spreadsheetDate1.isOnOrBefore(serialDate7);
//        int int31 = spreadsheetDate1.getMonth();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "30-June-2019" + "'", str16.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "30-June-2018" + "'", str18.equals("30-June-2018"));
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Thu Jun 13 08:21:29 PDT 2019" + "'", str23.equals("Thu Jun 13 08:21:29 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560439289542L + "'", long24 == 1560439289542L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener6);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        int int9 = month8.getMonth();
//        java.util.Date date10 = month8.getEnd();
//        java.util.Date date11 = month8.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (double) 0L);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        int int17 = month16.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) month16);
//        java.lang.String str19 = timeSeries15.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries15.removePropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries15.removeChangeListener(seriesChangeListener22);
//        boolean boolean24 = timeSeries15.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number26 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number26);
//        java.lang.String str28 = fixedMillisecond25.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) 100);
//        long long31 = fixedMillisecond25.getFirstMillisecond();
//        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) 6);
//        java.util.Date date34 = fixedMillisecond25.getTime();
//        java.util.Date date35 = fixedMillisecond25.getTime();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
//        int int37 = month36.getMonth();
//        java.util.Date date38 = month36.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(date38);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year40.previous();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
//        int int43 = month42.getMonth();
//        java.util.Date date44 = month42.getEnd();
//        boolean boolean45 = year40.equals((java.lang.Object) date44);
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date44, timeZone46);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date38, timeZone46);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date35, timeZone46);
//        long long50 = day49.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Thu Jun 13 08:21:29 PDT 2019" + "'", str28.equals("Thu Jun 13 08:21:29 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560439289733L + "'", long31 == 1560439289733L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560452399999L + "'", long50 == 1560452399999L);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.fireSeriesChanged();
        java.util.Collection collection7 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries9);
        try {
            timeSeries10.delete(9, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        java.util.Date date4 = month2.getEnd();
//        boolean boolean5 = year0.equals((java.lang.Object) date4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4, timeZone6);
//        org.jfree.data.time.Year year8 = month7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
//        java.lang.String str10 = year8.toString();
//        int int12 = year8.compareTo((java.lang.Object) (-80218310400000L));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number14 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, number14);
//        java.lang.String str16 = fixedMillisecond13.toString();
//        long long17 = fixedMillisecond13.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond13.next();
//        int int19 = year8.compareTo((java.lang.Object) regularTimePeriod18);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Thu Jun 13 08:21:30 PDT 2019" + "'", str16.equals("Thu Jun 13 08:21:30 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560439290012L + "'", long17 == 1560439290012L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int8 = month6.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (short) 0);
        timeSeries1.setKey((java.lang.Comparable) timeSeriesDataItem10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        java.util.Date date16 = month13.getStart();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year12, (org.jfree.data.time.RegularTimePeriod) month13);
        java.lang.String str18 = year12.toString();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Object obj21 = timeSeries20.clone();
        java.lang.Object obj22 = timeSeries20.clone();
        int int23 = year12.compareTo(obj22);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = year12.getLastMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "Nearest");
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + "Nearest" + "'", obj2.equals("Nearest"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, (int) '4', 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        int int11 = month10.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month10);
//        java.lang.String str13 = timeSeries9.getRangeDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener14);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        int int17 = month16.getMonth();
//        java.util.Date date18 = month16.getEnd();
//        java.util.Date date19 = month16.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) 0L);
//        int int22 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month16);
//        timeSeries1.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        long long25 = timeSeries1.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        int int29 = month28.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries27.getDataItem((org.jfree.data.time.RegularTimePeriod) month28);
//        java.lang.String str31 = timeSeries27.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timeSeries27.removePropertyChangeListener(propertyChangeListener32);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
//        timeSeries27.removeChangeListener(seriesChangeListener34);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        int int39 = month38.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) month38);
//        java.lang.String str41 = timeSeries37.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener42 = null;
//        timeSeries37.removePropertyChangeListener(propertyChangeListener42);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries37.removeChangeListener(seriesChangeListener44);
//        boolean boolean46 = timeSeries37.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number48 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, number48);
//        java.lang.String str50 = fixedMillisecond47.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (java.lang.Number) 100);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries27.addAndOrUpdate(timeSeries37);
//        java.lang.Comparable comparable54 = timeSeries37.getKey();
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries1.addAndOrUpdate(timeSeries37);
//        java.lang.String str56 = timeSeries55.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Value" + "'", str41.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Thu Jun 13 08:21:31 PDT 2019" + "'", str50.equals("Thu Jun 13 08:21:31 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem52);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + comparable54 + "' != '" + (short) 100 + "'", comparable54.equals((short) 100));
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Time" + "'", str56.equals("Time"));
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Following");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        int int4 = fixedMillisecond0.compareTo((java.lang.Object) "ClassContext");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.previous();
        java.util.Date date8 = regularTimePeriod7.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1900);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        int int2 = month1.getMonth();
        java.util.Date date3 = month1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears(0, serialDate5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        int int9 = day8.getYear();
        int int10 = day8.getDayOfMonth();
        java.lang.String str11 = day8.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 30 + "'", int10 == 30);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "30-June-2019" + "'", str11.equals("30-June-2019"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Thu Jun 13 08:20:21 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Thu Jun 13 08:21:22 PDT 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Thu Jun 13 08:21:22 PDT 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Thu Jun 13 08:21:22 PDT 2019"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        java.util.Date date4 = month2.getEnd();
        boolean boolean5 = year0.equals((java.lang.Object) date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4, timeZone6);
        org.jfree.data.time.Year year8 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        long long10 = year8.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy(0, 716968);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) month9);
        java.lang.String str12 = timeSeries8.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries8.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        java.lang.String str20 = timeSeries16.getRangeDescription();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int23 = month21.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) (short) 0);
        timeSeries16.setKey((java.lang.Comparable) timeSeriesDataItem25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        int int29 = month28.getMonth();
        java.util.Date date30 = month28.getEnd();
        java.util.Date date31 = month28.getStart();
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) year27, (org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 10L);
        int int35 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year27.next();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.removeChangeListener(seriesChangeListener10);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries1.createCopy(0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries14);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
        int int5 = month0.compareTo((java.lang.Object) year1);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        boolean boolean10 = timeSeries1.getNotify();
        java.lang.Class class11 = timeSeries1.getTimePeriodClass();
        timeSeries1.setDescription("Thu Jun 13 08:20:27 PDT 2019");
        int int14 = timeSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        java.util.Date date4 = month2.getEnd();
        boolean boolean5 = year0.equals((java.lang.Object) date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4, timeZone6);
        org.jfree.data.time.Year year8 = month7.getYear();
        int int9 = year8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.previous();
        long long11 = year8.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        timeSeries1.setRangeDescription("hi!");
        java.lang.String str4 = timeSeries1.getDomainDescription();
        timeSeries1.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        long long6 = day5.getLastMillisecond();
        int int7 = day5.getYear();
        int int8 = day5.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9999, (int) (short) -1, 716968);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        timeSeries1.setKey((java.lang.Comparable) ' ');
        timeSeries1.fireSeriesChanged();
        java.util.List list8 = timeSeries1.getItems();
        java.util.List list9 = timeSeries1.getItems();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Thu Jun 13 08:21:24 PDT 2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        timeSeries1.setRangeDescription("hi!");
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.next();
        long long12 = fixedMillisecond10.getMiddleMillisecond();
        timeSeries1.setKey((java.lang.Comparable) fixedMillisecond10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemCount(10);
        timeSeries1.setKey((java.lang.Comparable) (-1.0d));
        boolean boolean11 = timeSeries1.getNotify();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        int int13 = month12.getMonth();
        java.util.Date date14 = month12.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
        java.lang.String str17 = serialDate16.toString();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate16);
        int int19 = day18.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) 100.0f);
        org.jfree.data.time.SerialDate serialDate22 = day18.getSerialDate();
        long long23 = day18.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "30-June-2019" + "'", str17.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43646L + "'", long23 == 43646L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        timeSeries2.setRangeDescription("hi!");
        java.util.Collection collection5 = timeSeries2.getTimePeriods();
        int int6 = fixedMillisecond0.compareTo((java.lang.Object) collection5);
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int6, "", "First", class9);
        timeSeries10.fireSeriesChanged();
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener8);
//        java.lang.String str10 = timeSeries1.getRangeDescription();
//        timeSeries1.removeAgedItems(1560439245630L, false);
//        timeSeries1.removeAgedItems(0L, true);
//        long long17 = timeSeries1.getMaximumItemAge();
//        java.lang.Comparable comparable18 = timeSeries1.getKey();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        int int22 = month21.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) month21);
//        java.lang.String str24 = timeSeries20.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener25 = null;
//        timeSeries20.removePropertyChangeListener(propertyChangeListener25);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries20.removeChangeListener(seriesChangeListener27);
//        boolean boolean29 = timeSeries20.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number31 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, number31);
//        java.lang.String str33 = fixedMillisecond30.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 100);
//        long long36 = fixedMillisecond30.getFirstMillisecond();
//        long long37 = fixedMillisecond30.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries1.getDataItem(regularTimePeriod39);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (short) 100 + "'", comparable18.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Thu Jun 13 08:21:33 PDT 2019" + "'", str33.equals("Thu Jun 13 08:21:33 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560439293374L + "'", long36 == 1560439293374L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560439293374L + "'", long37 == 1560439293374L);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Year year7 = month6.getYear();
        long long8 = month6.getLastMillisecond();
        long long9 = month6.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number3 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, number3);
//        java.util.Date date5 = fixedMillisecond2.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond2.previous();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond2.getLastMillisecond(calendar7);
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond2.getClass();
//        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Thu Jun 13 08:20:57 PDT 2019", (java.lang.Class) wildcardClass9);
//        java.lang.Object obj11 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:21:12 PDT 2019", (java.lang.Class) wildcardClass9);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560439293439L + "'", long8 == 1560439293439L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNull(inputStream10);
//        org.junit.Assert.assertNull(obj11);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        java.lang.String str5 = serialDate4.toString();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate4);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) month9);
        java.lang.String str12 = timeSeries8.getRangeDescription();
        timeSeries8.fireSeriesChanged();
        timeSeries8.setMaximumItemCount(10);
        int int16 = day6.compareTo((java.lang.Object) timeSeries8);
        int int17 = timeSeries8.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "30-June-2019" + "'", str5.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        int int4 = month3.getMonth();
//        java.util.Date date5 = month3.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date5);
//        java.lang.String str8 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate7);
//        java.lang.String str10 = serialDate9.toString();
//        boolean boolean11 = spreadsheetDate1.isOn(serialDate9);
//        java.util.Date date12 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        int int17 = month16.getMonth();
//        java.util.Date date18 = month16.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date18);
//        java.lang.String str21 = serialDate20.toString();
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate20);
//        java.lang.String str23 = serialDate22.toString();
//        boolean boolean24 = spreadsheetDate14.isOn(serialDate22);
//        boolean boolean25 = spreadsheetDate1.isOnOrAfter(serialDate22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number28 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, number28);
//        java.lang.String str30 = fixedMillisecond27.toString();
//        long long31 = fixedMillisecond27.getFirstMillisecond();
//        java.util.Date date32 = fixedMillisecond27.getTime();
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date32);
//        serialDate34.setDescription("");
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addDays((-460), serialDate34);
//        boolean boolean38 = spreadsheetDate1.isAfter(serialDate34);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "30-June-2019" + "'", str8.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "30-June-2018" + "'", str10.equals("30-June-2018"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "30-June-2019" + "'", str21.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "30-June-2018" + "'", str23.equals("30-June-2018"));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Thu Jun 13 08:21:33 PDT 2019" + "'", str30.equals("Thu Jun 13 08:21:33 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560439293534L + "'", long31 == 1560439293534L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.lang.Object obj0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        int int3 = month1.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month1, (java.lang.Number) (short) 0);
        timeSeriesDataItem5.setValue((java.lang.Number) 100.0f);
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal(obj0, (java.lang.Object) timeSeriesDataItem5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem5.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem5.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (double) 1560439234660L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemCount(10);
        timeSeries1.setKey((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int17 = month16.getMonth();
        java.util.Date date18 = month16.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date18);
        java.lang.String str21 = serialDate20.toString();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate20);
        java.lang.String str23 = serialDate22.toString();
        boolean boolean24 = spreadsheetDate14.isOn(serialDate22);
        java.util.Date date25 = spreadsheetDate14.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        int int30 = month29.getMonth();
        java.util.Date date31 = month29.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date31);
        java.lang.String str34 = serialDate33.toString();
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate33);
        java.lang.String str36 = serialDate35.toString();
        boolean boolean37 = spreadsheetDate27.isOn(serialDate35);
        boolean boolean38 = spreadsheetDate14.isOnOrAfter(serialDate35);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        int int41 = month40.getMonth();
        java.util.Date date42 = month40.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(date42);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, serialDate44);
        boolean boolean46 = spreadsheetDate14.isOn(serialDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        int int51 = month50.getMonth();
        java.util.Date date52 = month50.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(date52);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(date52);
        java.lang.String str55 = serialDate54.toString();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate54);
        java.lang.String str57 = serialDate56.toString();
        boolean boolean58 = spreadsheetDate48.isOn(serialDate56);
        boolean boolean59 = spreadsheetDate14.isOn(serialDate56);
        timeSeries1.setKey((java.lang.Comparable) spreadsheetDate14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "30-June-2019" + "'", str21.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "30-June-2018" + "'", str23.equals("30-June-2018"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "30-June-2019" + "'", str34.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "30-June-2018" + "'", str36.equals("30-June-2018"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 6 + "'", int51 == 6);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "30-June-2019" + "'", str55.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "30-June-2018" + "'", str57.equals("30-June-2018"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month3);
        java.lang.String str6 = timeSeries2.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month11);
        java.lang.String str14 = timeSeries10.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries10.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getMonth();
        java.util.Date date19 = month17.getEnd();
        java.util.Date date20 = month17.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month17, (double) 0L);
        int int23 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) month17);
        java.util.Date date24 = month17.getEnd();
        long long25 = month17.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int34 = month33.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        java.lang.String str36 = timeSeries32.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries32.removeChangeListener(seriesChangeListener37);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        int int40 = month39.getMonth();
        java.util.Date date41 = month39.getEnd();
        java.util.Date date42 = month39.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month39, (double) 0L);
        java.lang.Class class45 = timeSeries32.getTimePeriodClass();
        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize(class45);
        java.net.URL uRL47 = org.jfree.chart.util.ObjectUtilities.getResource("ClassContext", class46);
        java.lang.Object obj48 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:20:27 PDT 2019", class46);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        int int52 = month51.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries50.getDataItem((org.jfree.data.time.RegularTimePeriod) month51);
        java.lang.String str54 = timeSeries50.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries50.removeChangeListener(seriesChangeListener55);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
        int int58 = month57.getMonth();
        java.util.Date date59 = month57.getEnd();
        java.util.Date date60 = month57.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries50.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month57, (double) 0L);
        java.lang.Class class63 = timeSeries50.getTimePeriodClass();
        java.lang.Class class64 = org.jfree.data.time.RegularTimePeriod.downsize(class63);
        java.lang.Object obj65 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:20:28 PDT 2019", class46, class64);
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "Thu Jun 13 08:20:41 PDT 2019", "Thu Jun 13 08:20:35 PDT 2019", class46);
        java.net.URL uRL67 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 08:20:43 PDT 2019", class46);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Value" + "'", str36.equals("Value"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNotNull(class46);
        org.junit.Assert.assertNull(uRL47);
        org.junit.Assert.assertNull(obj48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 6 + "'", int52 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Value" + "'", str54.equals("Value"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNull(timeSeriesDataItem62);
        org.junit.Assert.assertNotNull(class63);
        org.junit.Assert.assertNotNull(class64);
        org.junit.Assert.assertNull(obj65);
        org.junit.Assert.assertNull(uRL67);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = timeSeries4.getRangeDescription();
        int int9 = month0.compareTo((java.lang.Object) timeSeries4);
        boolean boolean10 = timeSeries4.isEmpty();
        timeSeries4.setRangeDescription("ThreadContext");
        int int13 = timeSeries4.getMaximumItemCount();
        timeSeries4.fireSeriesChanged();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = null;
        try {
            timeSeries4.add(timeSeriesDataItem15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.next();
        long long7 = fixedMillisecond5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        java.lang.String str2 = serialDate1.getDescription();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        java.util.Date date5 = month3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(0, serialDate7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number12 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, number12);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = month18.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) month18);
        java.lang.String str21 = timeSeries17.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries17.removeChangeListener(seriesChangeListener22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        java.util.Date date26 = month24.getEnd();
        java.util.Date date27 = month24.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, (double) 0L);
        java.lang.Class class30 = timeSeries17.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem13, "Thu Jun 13 08:20:23 PDT 2019", "Thu Jun 13 08:20:29 PDT 2019", class30);
        java.net.URL uRL32 = org.jfree.chart.util.ObjectUtilities.getResource("SerialDate.weekInMonthToString(): invalid code.", class30);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0, class30);
        java.net.URL uRL34 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("30-June-2019", class30);
        java.io.InputStream inputStream35 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("SerialDate.weekInMonthToString(): invalid code.", class30);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNull(uRL32);
        org.junit.Assert.assertNull(uRL34);
        org.junit.Assert.assertNull(inputStream35);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener8);
//        boolean boolean10 = timeSeries1.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number12 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, number12);
//        java.lang.String str14 = fixedMillisecond11.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 100);
//        long long17 = fixedMillisecond11.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        int int21 = month20.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) month20);
//        java.lang.String str23 = timeSeries19.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timeSeries19.removePropertyChangeListener(propertyChangeListener24);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        int int29 = month28.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries27.getDataItem((org.jfree.data.time.RegularTimePeriod) month28);
//        java.lang.String str31 = timeSeries27.getRangeDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries27.removeChangeListener(seriesChangeListener32);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        int int35 = month34.getMonth();
//        java.util.Date date36 = month34.getEnd();
//        java.util.Date date37 = month34.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, (double) 0L);
//        int int40 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) month34);
//        java.util.Date date41 = month34.getEnd();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
//        boolean boolean43 = fixedMillisecond11.equals((java.lang.Object) date41);
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond11.getMiddleMillisecond(calendar44);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Thu Jun 13 08:21:34 PDT 2019" + "'", str14.equals("Thu Jun 13 08:21:34 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560439294945L + "'", long17 == 1560439294945L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Value" + "'", str23.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560439294945L + "'", long45 == 1560439294945L);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month3);
        java.lang.String str6 = timeSeries2.getRangeDescription();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int9 = month7.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (short) 0);
        timeSeries2.setKey((java.lang.Comparable) timeSeriesDataItem11);
        java.lang.Number number13 = timeSeriesDataItem11.getValue();
        java.lang.Object obj14 = timeSeriesDataItem11.clone();
        java.lang.Object obj15 = timeSeriesDataItem11.clone();
        java.lang.Number number16 = timeSeriesDataItem11.getValue();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = month18.getMonth();
        java.util.Date date20 = month18.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date20);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(0, serialDate22);
        int int24 = timeSeriesDataItem11.compareTo((java.lang.Object) serialDate22);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears((int) (byte) 1, serialDate22);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 0 + "'", number13.equals((short) 0));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (short) 0 + "'", number16.equals((short) 0));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(serialDate25);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        java.util.Date date4 = month2.getEnd();
        boolean boolean5 = year0.equals((java.lang.Object) date4);
        long long6 = year0.getFirstMillisecond();
        long long7 = year0.getLastMillisecond();
        java.util.Date date8 = year0.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) 1560439240880L);
        boolean boolean12 = year0.equals((java.lang.Object) 1560439240880L);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        int int11 = month10.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month10);
//        java.lang.String str13 = timeSeries9.getRangeDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener14);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        int int17 = month16.getMonth();
//        java.util.Date date18 = month16.getEnd();
//        java.util.Date date19 = month16.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) 0L);
//        int int22 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month16);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        int int26 = month25.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) month25);
//        java.lang.String str28 = timeSeries24.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timeSeries24.removePropertyChangeListener(propertyChangeListener29);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries24.removeChangeListener(seriesChangeListener31);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        int int36 = month35.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
//        java.lang.String str38 = timeSeries34.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener39 = null;
//        timeSeries34.removePropertyChangeListener(propertyChangeListener39);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
//        timeSeries34.removeChangeListener(seriesChangeListener41);
//        boolean boolean43 = timeSeries34.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number45 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, number45);
//        java.lang.String str47 = fixedMillisecond44.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (java.lang.Number) 100);
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries24.addAndOrUpdate(timeSeries34);
//        java.util.Collection collection51 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries34);
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
//        int int53 = month52.getMonth();
//        java.util.Date date54 = month52.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond(date54);
//        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date54);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond(date54);
//        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(date54);
//        org.jfree.data.time.Year year59 = month58.getYear();
//        int int60 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month58);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Value" + "'", str28.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Value" + "'", str38.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Thu Jun 13 08:21:35 PDT 2019" + "'", str47.equals("Thu Jun 13 08:21:35 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(timeSeries50);
//        org.junit.Assert.assertNotNull(collection51);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNotNull(year59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) (-80218310400000L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month10);
        java.lang.String str13 = timeSeries9.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries9.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int17 = month16.getMonth();
        java.util.Date date18 = month16.getEnd();
        java.util.Date date19 = month16.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) 0L);
        int int22 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month16);
        timeSeries1.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        long long25 = timeSeries1.getMaximumItemAge();
        java.lang.Comparable comparable26 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + (short) 100 + "'", comparable26.equals((short) 100));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        int int2 = month1.getMonth();
        java.util.Date date3 = month1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears(0, serialDate5);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date11);
        java.lang.String str14 = serialDate13.toString();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate13);
        java.lang.String str16 = serialDate15.toString();
        org.jfree.data.time.SerialDate serialDate17 = serialDate7.getEndOfCurrentMonth(serialDate15);
        org.jfree.data.time.SerialDate serialDate19 = serialDate17.getFollowingDayOfWeek(4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "30-June-2019" + "'", str14.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "30-June-2018" + "'", str16.equals("30-June-2018"));
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        timeSeries1.setRangeDescription("hi!");
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        timeSeries1.setDomainDescription("");
        timeSeries1.setDomainDescription("");
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        java.util.Date date4 = month2.getEnd();
        boolean boolean5 = year0.equals((java.lang.Object) date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        java.util.Date date8 = month6.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        java.util.Date date13 = month11.getEnd();
        boolean boolean14 = year9.equals((java.lang.Object) date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date8, timeZone15);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date4, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
        java.lang.String str20 = year18.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date7);
        java.lang.String str10 = serialDate9.toString();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate9);
        java.lang.String str12 = serialDate11.toString();
        boolean boolean13 = spreadsheetDate3.isOn(serialDate11);
        java.util.Date date14 = spreadsheetDate3.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = month18.getMonth();
        java.util.Date date20 = month18.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date20);
        java.lang.String str23 = serialDate22.toString();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate22);
        java.lang.String str25 = serialDate24.toString();
        boolean boolean26 = spreadsheetDate16.isOn(serialDate24);
        boolean boolean27 = spreadsheetDate3.isOnOrAfter(serialDate24);
        int int28 = spreadsheetDate1.compare(serialDate24);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "30-June-2019" + "'", str10.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "30-June-2018" + "'", str12.equals("30-June-2018"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "30-June-2019" + "'", str23.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "30-June-2018" + "'", str25.equals("30-June-2018"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-43181) + "'", int28 == (-43181));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        boolean boolean9 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 100 + "'", comparable8.equals((short) 100));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) "hi!");
        java.lang.Object obj3 = null;
        boolean boolean4 = month0.equals(obj3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month3);
        java.lang.String str6 = timeSeries2.getRangeDescription();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int9 = month7.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (short) 0);
        timeSeries2.setKey((java.lang.Comparable) timeSeriesDataItem11);
        java.lang.Number number13 = timeSeriesDataItem11.getValue();
        java.lang.Object obj14 = timeSeriesDataItem11.clone();
        java.lang.Object obj15 = timeSeriesDataItem11.clone();
        java.lang.Number number16 = timeSeriesDataItem11.getValue();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = month18.getMonth();
        java.util.Date date20 = month18.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears(0, serialDate22);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        int int26 = timeSeriesDataItem11.compareTo((java.lang.Object) serialDate24);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears((int) (short) 0, serialDate24);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 0 + "'", number13.equals((short) 0));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (short) 0 + "'", number16.equals((short) 0));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(serialDate27);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        long long6 = day5.getFirstMillisecond();
        long long7 = day5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.previous();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) "hi!");
        boolean boolean12 = day5.equals((java.lang.Object) month9);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month9.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561878000000L + "'", long6 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries1.getRangeDescription();
        timeSeries1.setDescription("");
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        long long19 = day18.getFirstMillisecond();
        long long20 = day18.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
        timeSeries1.add(regularTimePeriod21, (double) 10.0f, true);
        java.lang.Object obj25 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561878000000L + "'", long19 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(obj25);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = month4.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month4);
//        java.lang.String str7 = timeSeries3.getRangeDescription();
//        timeSeries3.fireSeriesChanged();
//        timeSeries3.setMaximumItemCount(10);
//        timeSeries3.setKey((java.lang.Comparable) (-1.0d));
//        boolean boolean13 = timeSeries3.getNotify();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getMonth();
//        java.util.Date date16 = month14.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date16);
//        java.lang.String str19 = serialDate18.toString();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate18);
//        int int21 = day20.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (double) 100.0f);
//        org.jfree.data.time.SerialDate serialDate24 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays((int) '4', serialDate24);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        int int28 = month27.getMonth();
//        java.util.Date date29 = month27.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date29);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date29);
//        java.lang.String str32 = serialDate31.getDescription();
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate31);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        int int36 = month35.getMonth();
//        java.util.Date date37 = month35.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date37);
//        java.lang.String str40 = serialDate39.toString();
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate39);
//        java.lang.String str42 = serialDate41.toString();
//        org.jfree.data.time.SerialDate serialDate43 = serialDate31.getEndOfCurrentMonth(serialDate41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number45 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, number45);
//        java.lang.String str47 = fixedMillisecond44.toString();
//        long long48 = fixedMillisecond44.getFirstMillisecond();
//        java.util.Date date49 = fixedMillisecond44.getTime();
//        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date49);
//        org.jfree.data.time.SerialDate serialDate51 = serialDate31.getEndOfCurrentMonth(serialDate50);
//        org.jfree.data.time.SerialDate serialDate53 = serialDate31.getPreviousDayOfWeek((int) (byte) 1);
//        org.jfree.data.time.SerialDate serialDate54 = serialDate24.getEndOfCurrentMonth(serialDate31);
//        try {
//            org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addDays(2147483647, serialDate31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "30-June-2019" + "'", str19.equals("30-June-2019"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNull(str32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "30-June-2019" + "'", str40.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "30-June-2018" + "'", str42.equals("30-June-2018"));
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Thu Jun 13 08:21:37 PDT 2019" + "'", str47.equals("Thu Jun 13 08:21:37 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560439297686L + "'", long48 == 1560439297686L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate54);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) "hi!");
        boolean boolean4 = month0.equals((java.lang.Object) 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener8);
//        timeSeries1.fireSeriesChanged();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries1.addChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        int int14 = month13.getMonth();
//        java.util.Date date15 = month13.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
//        long long19 = day18.getFirstMillisecond();
//        long long20 = day18.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        int int24 = month22.compareTo((java.lang.Object) "hi!");
//        boolean boolean25 = day18.equals((java.lang.Object) month22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number27 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, number27);
//        int int30 = fixedMillisecond26.compareTo((java.lang.Object) "ClassContext");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (double) 0.0f);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number34 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, number34);
//        long long36 = fixedMillisecond33.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) 1560439220158L);
//        int int39 = timeSeriesDataItem32.compareTo((java.lang.Object) 1560439220158L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = timeSeriesDataItem32.getPeriod();
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day18, regularTimePeriod40);
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
//        int int43 = month42.getMonth();
//        java.util.Date date44 = month42.getEnd();
//        java.util.Date date45 = month42.getStart();
//        int int46 = month42.getYearValue();
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        int int48 = month47.getMonth();
//        java.util.Date date49 = month47.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month47.previous();
//        int int51 = month47.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month47, (double) 6);
//        long long54 = month47.getSerialIndex();
//        boolean boolean55 = month42.equals((java.lang.Object) month47);
//        int int56 = day18.compareTo((java.lang.Object) month47);
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        timeSeries58.setRangeDescription("hi!");
//        java.util.Collection collection61 = timeSeries58.getTimePeriods();
//        int int62 = timeSeries58.getMaximumItemCount();
//        java.util.Collection collection63 = timeSeries58.getTimePeriods();
//        int int64 = day18.compareTo((java.lang.Object) timeSeries58);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561878000000L + "'", long19 == 1561878000000L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560439297758L + "'", long36 == 1560439297758L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 24234L + "'", long54 == 24234L);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertNotNull(collection61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2147483647 + "'", int62 == 2147483647);
//        org.junit.Assert.assertNotNull(collection63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        timeSeries1.setDescription("Thu Jun 13 08:20:26 PDT 2019");
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy(2, 2);
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries12);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        int int13 = month12.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) month12);
//        java.lang.String str15 = timeSeries11.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries11.removePropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener18);
//        boolean boolean20 = timeSeries11.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number22 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, number22);
//        java.lang.String str24 = fixedMillisecond21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 100);
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries1.addAndOrUpdate(timeSeries11);
//        java.lang.Comparable comparable28 = timeSeries11.getKey();
//        java.lang.Number number30 = timeSeries11.getValue(0);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        int int34 = month33.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
//        java.lang.String str36 = timeSeries32.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener37 = null;
//        timeSeries32.removePropertyChangeListener(propertyChangeListener37);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
//        int int42 = month41.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries40.getDataItem((org.jfree.data.time.RegularTimePeriod) month41);
//        java.lang.String str44 = timeSeries40.getRangeDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener45 = null;
//        timeSeries40.removeChangeListener(seriesChangeListener45);
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        int int48 = month47.getMonth();
//        java.util.Date date49 = month47.getEnd();
//        java.util.Date date50 = month47.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month47, (double) 0L);
//        int int53 = timeSeries32.getIndex((org.jfree.data.time.RegularTimePeriod) month47);
//        timeSeries32.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.util.Collection collection56 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries32);
//        java.lang.Class class57 = timeSeries32.getTimePeriodClass();
//        try {
//            java.lang.Number number59 = timeSeries32.getValue((-457));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Thu Jun 13 08:21:38 PDT 2019" + "'", str24.equals("Thu Jun 13 08:21:38 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (short) 100 + "'", comparable28.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 100 + "'", number30.equals(100));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Value" + "'", str36.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Value" + "'", str44.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNull(timeSeriesDataItem52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
//        org.junit.Assert.assertNotNull(collection56);
//        org.junit.Assert.assertNotNull(class57);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "December" + "'", str1.equals("December"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Thu Jun 13 08:21:03 PDT 2019");
        java.lang.String str2 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.removeAgedItems(0L, true);
        timeSeries1.setNotify(false);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date17);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        long long21 = day20.getFirstMillisecond();
        long long22 = day20.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day20.previous();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int26 = month24.compareTo((java.lang.Object) "hi!");
        boolean boolean27 = day20.equals((java.lang.Object) month24);
        java.lang.String str28 = month24.toString();
        long long29 = month24.getMiddleMillisecond();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        int int31 = month30.getMonth();
        java.util.Date date32 = month30.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(date32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date32);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(serialDate34);
        long long36 = day35.getFirstMillisecond();
        int int37 = day35.getDayOfMonth();
        int int38 = day35.getDayOfMonth();
        int int39 = day35.getDayOfMonth();
        int int40 = month24.compareTo((java.lang.Object) day35);
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 1560439244202L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561878000000L + "'", long21 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561964399999L + "'", long22 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "June 2019" + "'", str28.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560668399999L + "'", long29 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1561878000000L + "'", long36 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 30 + "'", int37 == 30);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 30 + "'", int38 == 30);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 30 + "'", int39 == 30);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        long long6 = day5.getFirstMillisecond();
        int int7 = day5.getDayOfMonth();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day5.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561878000000L + "'", long6 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 30 + "'", int7 == 30);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        timeSeriesDataItem2.setValue((java.lang.Number) (byte) 10);
        java.lang.Object obj5 = timeSeriesDataItem2.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem2.getPeriod();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        int int4 = month3.getMonth();
//        java.util.Date date5 = month3.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date5);
//        java.lang.String str8 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate7);
//        java.lang.String str10 = serialDate9.toString();
//        boolean boolean11 = spreadsheetDate1.isOn(serialDate9);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        int int14 = month13.getMonth();
//        java.util.Date date15 = month13.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
//        java.lang.String str18 = serialDate17.getDescription();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate17);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        int int22 = month21.getMonth();
//        java.util.Date date23 = month21.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date23);
//        java.lang.String str26 = serialDate25.toString();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate25);
//        java.lang.String str28 = serialDate27.toString();
//        org.jfree.data.time.SerialDate serialDate29 = serialDate17.getEndOfCurrentMonth(serialDate27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number31 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, number31);
//        java.lang.String str33 = fixedMillisecond30.toString();
//        long long34 = fixedMillisecond30.getFirstMillisecond();
//        java.util.Date date35 = fixedMillisecond30.getTime();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
//        org.jfree.data.time.SerialDate serialDate37 = serialDate17.getEndOfCurrentMonth(serialDate36);
//        org.jfree.data.time.SerialDate serialDate39 = serialDate17.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean40 = spreadsheetDate1.isOnOrBefore(serialDate17);
//        java.util.Date date41 = spreadsheetDate1.toDate();
//        int int42 = spreadsheetDate1.toSerial();
//        spreadsheetDate1.setDescription("");
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
//        int int47 = month46.getMonth();
//        java.util.Date date48 = month46.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond(date48);
//        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date48);
//        java.lang.String str51 = serialDate50.toString();
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate50);
//        boolean boolean53 = spreadsheetDate1.isOn(serialDate50);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "30-June-2019" + "'", str8.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "30-June-2018" + "'", str10.equals("30-June-2018"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "30-June-2019" + "'", str26.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "30-June-2018" + "'", str28.equals("30-June-2018"));
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Thu Jun 13 08:21:38 PDT 2019" + "'", str33.equals("Thu Jun 13 08:21:38 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560439298928L + "'", long34 == 1560439298928L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "30-June-2019" + "'", str51.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        java.util.Date date4 = month2.getEnd();
        boolean boolean5 = year0.equals((java.lang.Object) date4);
        long long6 = year0.getFirstMillisecond();
        long long7 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.next();
        long long9 = year0.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) 1560439245028L);
        java.lang.Number number12 = timeSeriesDataItem11.getValue();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1.560439245028E12d + "'", number12.equals(1.560439245028E12d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        java.util.Date date4 = month2.getEnd();
        boolean boolean5 = year0.equals((java.lang.Object) date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4, timeZone6);
        org.jfree.data.time.Year year8 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.next();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date12);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getFirstMillisecond();
        int int17 = day15.getYear();
        java.lang.Class<?> wildcardClass18 = day15.getClass();
        boolean boolean19 = month7.equals((java.lang.Object) wildcardClass18);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561878000000L + "'", long16 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Thu Jun 13 08:20:28 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        long long2 = year0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        int int7 = month6.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
//        java.lang.String str9 = timeSeries5.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries5.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries5.removeChangeListener(seriesChangeListener12);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        int int17 = month16.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) month16);
//        java.lang.String str19 = timeSeries15.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries15.removePropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries15.removeChangeListener(seriesChangeListener22);
//        boolean boolean24 = timeSeries15.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number26 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number26);
//        java.lang.String str28 = fixedMillisecond25.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) 100);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries5.addAndOrUpdate(timeSeries15);
//        boolean boolean32 = year0.equals((java.lang.Object) timeSeries15);
//        java.lang.String str33 = year0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Thu Jun 13 08:21:39 PDT 2019" + "'", str28.equals("Thu Jun 13 08:21:39 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2019" + "'", str33.equals("2019"));
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, 5);
        int int4 = month2.compareTo((java.lang.Object) "Thu Jun 13 08:20:27 PDT 2019");
        int int5 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month3);
        java.lang.String str6 = timeSeries2.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month11);
        java.lang.String str14 = timeSeries10.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries10.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getMonth();
        java.util.Date date19 = month17.getEnd();
        java.util.Date date20 = month17.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month17, (double) 0L);
        int int23 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) month17);
        java.util.Date date24 = month17.getEnd();
        long long25 = month17.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int34 = month33.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        java.lang.String str36 = timeSeries32.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries32.removeChangeListener(seriesChangeListener37);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        int int40 = month39.getMonth();
        java.util.Date date41 = month39.getEnd();
        java.util.Date date42 = month39.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month39, (double) 0L);
        java.lang.Class class45 = timeSeries32.getTimePeriodClass();
        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize(class45);
        java.net.URL uRL47 = org.jfree.chart.util.ObjectUtilities.getResource("ClassContext", class46);
        java.lang.Object obj48 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:20:27 PDT 2019", class46);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        int int52 = month51.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries50.getDataItem((org.jfree.data.time.RegularTimePeriod) month51);
        java.lang.String str54 = timeSeries50.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries50.removeChangeListener(seriesChangeListener55);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month();
        int int58 = month57.getMonth();
        java.util.Date date59 = month57.getEnd();
        java.util.Date date60 = month57.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries50.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month57, (double) 0L);
        java.lang.Class class63 = timeSeries50.getTimePeriodClass();
        java.lang.Class class64 = org.jfree.data.time.RegularTimePeriod.downsize(class63);
        java.lang.Object obj65 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:20:28 PDT 2019", class46, class64);
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "Thu Jun 13 08:20:41 PDT 2019", "Thu Jun 13 08:20:35 PDT 2019", class46);
        java.lang.Class class67 = null;
        java.lang.Object obj68 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Thu Jun 13 08:20:31 PDT 2019", class46, class67);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Value" + "'", str36.equals("Value"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNotNull(class46);
        org.junit.Assert.assertNull(uRL47);
        org.junit.Assert.assertNull(obj48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 6 + "'", int52 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Value" + "'", str54.equals("Value"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNull(timeSeriesDataItem62);
        org.junit.Assert.assertNotNull(class63);
        org.junit.Assert.assertNotNull(class64);
        org.junit.Assert.assertNull(obj65);
        org.junit.Assert.assertNull(obj68);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "March" + "'", str1.equals("March"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        java.util.Date date5 = month3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date5);
        java.lang.String str8 = serialDate7.toString();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate7);
        java.lang.String str10 = serialDate9.toString();
        boolean boolean11 = spreadsheetDate1.isOn(serialDate9);
        java.util.Date date12 = spreadsheetDate1.toDate();
        int int13 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "30-June-2019" + "'", str8.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "30-June-2018" + "'", str10.equals("30-June-2018"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        timeSeries1.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries1.createCopy(0, 716968);
        java.lang.String str7 = timeSeries6.getDomainDescription();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        java.util.Date date4 = month2.getEnd();
        boolean boolean5 = year0.equals((java.lang.Object) date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        java.util.Date date8 = month6.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        java.util.Date date13 = month11.getEnd();
        boolean boolean14 = year9.equals((java.lang.Object) date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date8, timeZone15);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date4, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
        java.util.Calendar calendar20 = null;
        try {
            year18.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (short) 0);
        java.lang.String str5 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month0.next();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = regularTimePeriod7.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = timeSeries4.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries4.removeChangeListener(seriesChangeListener11);
        boolean boolean13 = timeSeries4.getNotify();
        java.lang.Class class14 = timeSeries4.getTimePeriodClass();
        java.lang.Class class15 = null;
        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class14, class15);
        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", class14);
        java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class14);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNull(inputStream17);
        org.junit.Assert.assertNull(obj18);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("June 2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("June 2019");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("Thu Jun 13 08:20:22 PDT 2019");
        java.lang.String str7 = timePeriodFormatException6.toString();
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str9 = seriesException3.toString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Thu Jun 13 08:20:22 PDT 2019" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: Thu Jun 13 08:20:22 PDT 2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: June 2019" + "'", str9.equals("org.jfree.data.general.SeriesException: June 2019"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560439242558L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        long long6 = day5.getFirstMillisecond();
        int int7 = day5.getDayOfMonth();
        int int8 = day5.getDayOfMonth();
        int int9 = day5.getMonth();
        java.util.Calendar calendar10 = null;
        try {
            day5.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561878000000L + "'", long6 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 30 + "'", int7 == 30);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        int int4 = month3.getMonth();
//        java.util.Date date5 = month3.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date5);
//        java.lang.String str8 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate7);
//        java.lang.String str10 = serialDate9.toString();
//        boolean boolean11 = spreadsheetDate1.isOn(serialDate9);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        int int14 = month13.getMonth();
//        java.util.Date date15 = month13.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
//        java.lang.String str18 = serialDate17.getDescription();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate17);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        int int22 = month21.getMonth();
//        java.util.Date date23 = month21.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date23);
//        java.lang.String str26 = serialDate25.toString();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate25);
//        java.lang.String str28 = serialDate27.toString();
//        org.jfree.data.time.SerialDate serialDate29 = serialDate17.getEndOfCurrentMonth(serialDate27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number31 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, number31);
//        java.lang.String str33 = fixedMillisecond30.toString();
//        long long34 = fixedMillisecond30.getFirstMillisecond();
//        java.util.Date date35 = fixedMillisecond30.getTime();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
//        org.jfree.data.time.SerialDate serialDate37 = serialDate17.getEndOfCurrentMonth(serialDate36);
//        org.jfree.data.time.SerialDate serialDate39 = serialDate17.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean40 = spreadsheetDate1.isOnOrBefore(serialDate17);
//        int int41 = spreadsheetDate1.getMonth();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "30-June-2019" + "'", str8.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "30-June-2018" + "'", str10.equals("30-June-2018"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "30-June-2019" + "'", str26.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "30-June-2018" + "'", str28.equals("30-June-2018"));
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Thu Jun 13 08:21:40 PDT 2019" + "'", str33.equals("Thu Jun 13 08:21:40 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560439300740L + "'", long34 == 1560439300740L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2958465, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = month4.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month4);
//        java.lang.String str7 = timeSeries3.getRangeDescription();
//        timeSeries3.fireSeriesChanged();
//        timeSeries3.setMaximumItemCount(10);
//        timeSeries3.setKey((java.lang.Comparable) (-1.0d));
//        boolean boolean13 = timeSeries3.getNotify();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        int int15 = month14.getMonth();
//        java.util.Date date16 = month14.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date16);
//        java.lang.String str19 = serialDate18.toString();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate18);
//        int int21 = day20.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (double) 100.0f);
//        org.jfree.data.time.SerialDate serialDate24 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays((int) '4', serialDate24);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
//        int int28 = month27.getMonth();
//        java.util.Date date29 = month27.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date29);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date29);
//        java.lang.String str32 = serialDate31.getDescription();
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate31);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        int int36 = month35.getMonth();
//        java.util.Date date37 = month35.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date37);
//        java.lang.String str40 = serialDate39.toString();
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate39);
//        java.lang.String str42 = serialDate41.toString();
//        org.jfree.data.time.SerialDate serialDate43 = serialDate31.getEndOfCurrentMonth(serialDate41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number45 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, number45);
//        java.lang.String str47 = fixedMillisecond44.toString();
//        long long48 = fixedMillisecond44.getFirstMillisecond();
//        java.util.Date date49 = fixedMillisecond44.getTime();
//        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date49);
//        org.jfree.data.time.SerialDate serialDate51 = serialDate31.getEndOfCurrentMonth(serialDate50);
//        org.jfree.data.time.SerialDate serialDate53 = serialDate31.getPreviousDayOfWeek((int) (byte) 1);
//        org.jfree.data.time.SerialDate serialDate54 = serialDate24.getEndOfCurrentMonth(serialDate31);
//        try {
//            org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addYears(716968, serialDate54);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "30-June-2019" + "'", str19.equals("30-June-2019"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNull(str32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "30-June-2019" + "'", str40.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "30-June-2018" + "'", str42.equals("30-June-2018"));
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Thu Jun 13 08:21:41 PDT 2019" + "'", str47.equals("Thu Jun 13 08:21:41 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560439301019L + "'", long48 == 1560439301019L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate54);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month3);
        java.lang.String str6 = timeSeries2.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries2.removeChangeListener(seriesChangeListener9);
        boolean boolean11 = timeSeries2.getNotify();
        java.lang.Class class12 = timeSeries2.getTimePeriodClass();
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 08:20:28 PDT 2019", class12);
        java.lang.ClassLoader classLoader14 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNull(uRL13);
        org.junit.Assert.assertNotNull(classLoader14);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        java.lang.String str7 = serialDate6.getDescription();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date12);
        java.lang.String str15 = serialDate14.toString();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate14);
        java.lang.String str17 = serialDate16.toString();
        org.jfree.data.time.SerialDate serialDate18 = serialDate6.getEndOfCurrentMonth(serialDate16);
        try {
            org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1900, serialDate16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "30-June-2019" + "'", str15.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "30-June-2018" + "'", str17.equals("30-June-2018"));
        org.junit.Assert.assertNotNull(serialDate18);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        java.util.Date date4 = month2.getEnd();
        boolean boolean5 = year0.equals((java.lang.Object) date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4, timeZone6);
        org.jfree.data.time.Year year8 = month7.getYear();
        java.lang.Object obj9 = null;
        int int10 = year8.compareTo(obj9);
        long long11 = year8.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        long long6 = day5.getFirstMillisecond();
        long long7 = day5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.previous();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Object obj11 = timeSeries10.clone();
        java.lang.Object obj12 = timeSeries10.clone();
        boolean boolean13 = day5.equals(obj12);
        java.util.Date date14 = day5.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date14, timeZone15);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561878000000L + "'", long6 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemCount(10);
        timeSeries1.setKey((java.lang.Comparable) (-1.0d));
        boolean boolean11 = timeSeries1.getNotify();
        int int12 = timeSeries1.getItemCount();
        java.lang.String str13 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number1 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) month7);
        java.lang.String str10 = timeSeries6.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries6.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        java.util.Date date16 = month13.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month13, (double) 0L);
        java.lang.Class class19 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "Thu Jun 13 08:20:23 PDT 2019", "Thu Jun 13 08:20:29 PDT 2019", class19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number22 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, number22);
        java.lang.Number number24 = timeSeriesDataItem23.getValue();
        java.lang.Number number25 = timeSeriesDataItem23.getValue();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        int int29 = month28.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries27.getDataItem((org.jfree.data.time.RegularTimePeriod) month28);
        java.lang.String str31 = timeSeries27.getRangeDescription();
        timeSeries27.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        int int36 = month35.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        java.lang.String str38 = timeSeries34.getRangeDescription();
        timeSeries34.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries27.addAndOrUpdate(timeSeries34);
        int int41 = timeSeriesDataItem23.compareTo((java.lang.Object) timeSeries40);
        try {
            timeSeries20.add(timeSeriesDataItem23, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNull(number24);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Value" + "'", str38.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        boolean boolean8 = year3.equals((java.lang.Object) date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date7, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date2, timeZone9);
        long long12 = day11.getSerialIndex();
        int int13 = day11.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43646L + "'", long12 == 43646L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener8);
//        timeSeries1.fireSeriesChanged();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries1.addChangeListener(seriesChangeListener11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        int int14 = month13.getMonth();
//        java.util.Date date15 = month13.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
//        long long19 = day18.getFirstMillisecond();
//        long long20 = day18.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.previous();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
//        int int24 = month22.compareTo((java.lang.Object) "hi!");
//        boolean boolean25 = day18.equals((java.lang.Object) month22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number27 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, number27);
//        int int30 = fixedMillisecond26.compareTo((java.lang.Object) "ClassContext");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (double) 0.0f);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number34 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, number34);
//        long long36 = fixedMillisecond33.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) 1560439220158L);
//        int int39 = timeSeriesDataItem32.compareTo((java.lang.Object) 1560439220158L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = timeSeriesDataItem32.getPeriod();
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day18, regularTimePeriod40);
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
//        int int43 = month42.getMonth();
//        java.util.Date date44 = month42.getEnd();
//        java.util.Date date45 = month42.getStart();
//        int int46 = month42.getYearValue();
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        int int48 = month47.getMonth();
//        java.util.Date date49 = month47.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month47.previous();
//        int int51 = month47.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month47, (double) 6);
//        long long54 = month47.getSerialIndex();
//        boolean boolean55 = month42.equals((java.lang.Object) month47);
//        int int56 = day18.compareTo((java.lang.Object) month47);
//        int int57 = day18.getYear();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561878000000L + "'", long19 == 1561878000000L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560439301375L + "'", long36 == 1560439301375L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 24234L + "'", long54 == 24234L);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        try {
            timeSeries1.delete(8, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) month3);
        java.lang.String str6 = timeSeries2.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries2.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        java.util.Date date11 = month9.getEnd();
        java.util.Date date12 = month9.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month9, (double) 0L);
        java.lang.Class class15 = timeSeries2.getTimePeriodClass();
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResource("Thu Jun 13 08:20:47 PDT 2019", class15);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNull(uRL16);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemCount(10);
        timeSeries1.setKey((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month11);
        boolean boolean14 = month11.equals((java.lang.Object) "Thu Jun 13 08:20:26 PDT 2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 1560668399999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        java.util.Date date5 = month3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date5);
        java.lang.String str8 = serialDate7.toString();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate7);
        java.lang.String str10 = serialDate9.toString();
        boolean boolean11 = spreadsheetDate1.isOn(serialDate9);
        java.util.Date date12 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int17 = month16.getMonth();
        java.util.Date date18 = month16.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date18);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date18);
        java.lang.String str21 = serialDate20.toString();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate20);
        java.lang.String str23 = serialDate22.toString();
        boolean boolean24 = spreadsheetDate14.isOn(serialDate22);
        boolean boolean25 = spreadsheetDate1.isOnOrAfter(serialDate22);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int28 = month27.getMonth();
        java.util.Date date29 = month27.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date29);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date29);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, serialDate31);
        boolean boolean33 = spreadsheetDate1.isOn(serialDate31);
        org.jfree.data.time.SerialDate serialDate35 = spreadsheetDate1.getFollowingDayOfWeek((int) (short) 1);
        org.jfree.data.time.SerialDate serialDate36 = null;
        try {
            int int37 = spreadsheetDate1.compare(serialDate36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "30-June-2019" + "'", str8.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "30-June-2018" + "'", str10.equals("30-June-2018"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "30-June-2019" + "'", str21.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "30-June-2018" + "'", str23.equals("30-June-2018"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(serialDate35);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number1 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number1);
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) "ClassContext");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 0.0f);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, number8);
//        long long10 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 1560439220158L);
//        int int13 = timeSeriesDataItem6.compareTo((java.lang.Object) 1560439220158L);
//        timeSeriesDataItem6.setValue((java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        int int19 = month18.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) month18);
//        java.lang.String str21 = timeSeries17.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries17.removePropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
//        timeSeries17.removeChangeListener(seriesChangeListener24);
//        java.lang.String str26 = timeSeries17.getRangeDescription();
//        timeSeries17.setDescription("");
//        int int29 = timeSeriesDataItem6.compareTo((java.lang.Object) "");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeriesDataItem6.getPeriod();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560439301838L + "'", long10 == 1560439301838L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Value" + "'", str21.equals("Value"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("June 2019");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("June 2019");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException5);
        boolean boolean7 = month0.equals((java.lang.Object) seriesException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("Thu Jun 13 08:20:35 PDT 2019");
        seriesException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) month5);
        java.lang.String str8 = timeSeries4.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries4.removeChangeListener(seriesChangeListener11);
        boolean boolean13 = timeSeries4.getNotify();
        java.lang.Class class14 = timeSeries4.getTimePeriodClass();
        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 08:20:28 PDT 2019", class14);
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResource("", class14);
        java.net.URL uRL17 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 08:21:27 PDT 2019", class14);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNull(uRL15);
        org.junit.Assert.assertNotNull(uRL16);
        org.junit.Assert.assertNull(uRL17);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener8);
//        boolean boolean10 = timeSeries1.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number12 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, number12);
//        java.lang.String str14 = fixedMillisecond11.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 100);
//        long long17 = fixedMillisecond11.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        int int21 = month20.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) month20);
//        java.lang.String str23 = timeSeries19.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timeSeries19.removePropertyChangeListener(propertyChangeListener24);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        int int29 = month28.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries27.getDataItem((org.jfree.data.time.RegularTimePeriod) month28);
//        java.lang.String str31 = timeSeries27.getRangeDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries27.removeChangeListener(seriesChangeListener32);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        int int35 = month34.getMonth();
//        java.util.Date date36 = month34.getEnd();
//        java.util.Date date37 = month34.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, (double) 0L);
//        int int40 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) month34);
//        java.util.Date date41 = month34.getEnd();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
//        boolean boolean43 = fixedMillisecond11.equals((java.lang.Object) date41);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
//        int int47 = month46.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries45.getDataItem((org.jfree.data.time.RegularTimePeriod) month46);
//        java.lang.String str49 = timeSeries45.getRangeDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener50 = null;
//        timeSeries45.removeChangeListener(seriesChangeListener50);
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
//        int int53 = month52.getMonth();
//        java.util.Date date54 = month52.getEnd();
//        java.util.Date date55 = month52.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month52, (double) 0L);
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
//        int int61 = month60.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries59.getDataItem((org.jfree.data.time.RegularTimePeriod) month60);
//        java.lang.String str63 = timeSeries59.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener64 = null;
//        timeSeries59.removePropertyChangeListener(propertyChangeListener64);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener66 = null;
//        timeSeries59.removeChangeListener(seriesChangeListener66);
//        boolean boolean68 = timeSeries59.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number70 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69, number70);
//        java.lang.String str72 = fixedMillisecond69.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries59.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69, (java.lang.Number) 100);
//        long long75 = fixedMillisecond69.getFirstMillisecond();
//        timeSeries45.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69, (java.lang.Number) 6);
//        java.util.Date date78 = fixedMillisecond69.getTime();
//        java.util.Date date79 = fixedMillisecond69.getTime();
//        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month();
//        int int81 = month80.getMonth();
//        java.util.Date date82 = month80.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond(date82);
//        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = year84.previous();
//        org.jfree.data.time.Month month86 = new org.jfree.data.time.Month();
//        int int87 = month86.getMonth();
//        java.util.Date date88 = month86.getEnd();
//        boolean boolean89 = year84.equals((java.lang.Object) date88);
//        java.util.TimeZone timeZone90 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month91 = new org.jfree.data.time.Month(date88, timeZone90);
//        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date82, timeZone90);
//        org.jfree.data.time.Day day93 = new org.jfree.data.time.Day(date79, timeZone90);
//        org.jfree.data.time.Day day94 = new org.jfree.data.time.Day(date41, timeZone90);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Thu Jun 13 08:21:41 PDT 2019" + "'", str14.equals("Thu Jun 13 08:21:41 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560439301938L + "'", long17 == 1560439301938L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Value" + "'", str23.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Value" + "'", str49.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNull(timeSeriesDataItem57);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 6 + "'", int61 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Value" + "'", str63.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "Thu Jun 13 08:21:41 PDT 2019" + "'", str72.equals("Thu Jun 13 08:21:41 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem74);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1560439301973L + "'", long75 == 1560439301973L);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 6 + "'", int81 == 6);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(regularTimePeriod85);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 6 + "'", int87 == 6);
//        org.junit.Assert.assertNotNull(date88);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertNotNull(timeZone90);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        long long6 = day5.getFirstMillisecond();
        int int7 = day5.getYear();
        java.lang.Class<?> wildcardClass8 = day5.getClass();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        java.util.Date date11 = month9.getEnd();
        java.util.Date date12 = month9.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        boolean boolean18 = year13.equals((java.lang.Object) date17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getMonth();
        java.util.Date date23 = month21.getEnd();
        boolean boolean24 = year19.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date23, timeZone25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date17, timeZone25);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        int int31 = month30.getMonth();
        java.util.Date date32 = month30.getEnd();
        boolean boolean33 = year28.equals((java.lang.Object) date32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date32, timeZone34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date17, timeZone34);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date12, timeZone34);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.previous();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        int int41 = month40.getMonth();
        java.util.Date date42 = month40.getEnd();
        boolean boolean43 = year38.equals((java.lang.Object) date42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year44.previous();
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
        int int47 = month46.getMonth();
        java.util.Date date48 = month46.getEnd();
        boolean boolean49 = year44.equals((java.lang.Object) date48);
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date48, timeZone50);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date42, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year53.previous();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        int int56 = month55.getMonth();
        java.util.Date date57 = month55.getEnd();
        boolean boolean58 = year53.equals((java.lang.Object) date57);
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date57, timeZone59);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date42, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone59);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561878000000L + "'", long6 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 6 + "'", int56 == 6);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        long long6 = day5.getFirstMillisecond();
        long long7 = day5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.previous();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int11 = month9.compareTo((java.lang.Object) "hi!");
        boolean boolean12 = day5.equals((java.lang.Object) month9);
        java.lang.String str13 = month9.toString();
        long long14 = month9.getMiddleMillisecond();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date17);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        long long21 = day20.getFirstMillisecond();
        int int22 = day20.getDayOfMonth();
        int int23 = day20.getDayOfMonth();
        int int24 = day20.getDayOfMonth();
        int int25 = month9.compareTo((java.lang.Object) day20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, 0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561878000000L + "'", long6 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560668399999L + "'", long14 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561878000000L + "'", long21 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 30 + "'", int22 == 30);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 30 + "'", int23 == 30);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 30 + "'", int24 == 30);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        java.util.Date date3 = month0.getStart();
        int int4 = month0.getYearValue();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        java.util.Date date10 = month8.getEnd();
        java.util.Date date11 = month8.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (double) 0L);
        java.lang.Class class14 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        timeSeries1.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries23.getDataItem((org.jfree.data.time.RegularTimePeriod) month24);
        java.lang.String str27 = timeSeries23.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries23.removePropertyChangeListener(propertyChangeListener28);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries23.removeChangeListener(seriesChangeListener30);
        boolean boolean32 = timeSeries23.getNotify();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int35 = month33.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        int int39 = month38.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) month38);
        java.lang.String str41 = timeSeries37.getRangeDescription();
        int int42 = month33.compareTo((java.lang.Object) timeSeries37);
        org.jfree.data.time.Year year43 = month33.getYear();
        long long44 = month33.getMiddleMillisecond();
        java.util.Date date45 = month33.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) 1560439230019L);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) (-80218310400000L), true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Value" + "'", str41.equals("Value"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(year43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560668399999L + "'", long44 == 1560668399999L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, (int) 'a');
        timeSeries1.setKey((java.lang.Comparable) 'a');
        java.lang.String str6 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        java.util.Date date5 = month3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date5);
        java.lang.String str8 = serialDate7.toString();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate7);
        java.lang.String str10 = serialDate9.toString();
        boolean boolean11 = spreadsheetDate1.isOn(serialDate9);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
        java.lang.String str18 = serialDate17.getDescription();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate17);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getMonth();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date23);
        java.lang.String str26 = serialDate25.toString();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate25);
        java.lang.String str28 = serialDate27.toString();
        org.jfree.data.time.SerialDate serialDate29 = serialDate17.getEndOfCurrentMonth(serialDate27);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        int int32 = month31.getMonth();
        java.util.Date date33 = month31.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date33);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addYears(0, serialDate35);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        int int40 = month39.getMonth();
        java.util.Date date41 = month39.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(date41);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date41);
        java.lang.String str44 = serialDate43.toString();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate43);
        org.jfree.data.time.SerialDate serialDate46 = serialDate35.getEndOfCurrentMonth(serialDate45);
        boolean boolean47 = spreadsheetDate1.isInRange(serialDate29, serialDate46);
        java.lang.String str48 = serialDate46.getDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "30-June-2019" + "'", str8.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "30-June-2018" + "'", str10.equals("30-June-2018"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "30-June-2019" + "'", str26.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "30-June-2018" + "'", str28.equals("30-June-2018"));
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "30-June-2019" + "'", str44.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(str48);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        java.util.Date date8 = month6.getEnd();
        boolean boolean9 = year4.equals((java.lang.Object) date8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date8, timeZone10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date2, timeZone10);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        boolean boolean18 = year13.equals((java.lang.Object) date17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getMonth();
        java.util.Date date23 = month21.getEnd();
        boolean boolean24 = year19.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date23, timeZone25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date17, timeZone25);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        int int31 = month30.getMonth();
        java.util.Date date32 = month30.getEnd();
        boolean boolean33 = year28.equals((java.lang.Object) date32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date32, timeZone34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date17, timeZone34);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        int int40 = month39.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries38.getDataItem((org.jfree.data.time.RegularTimePeriod) month39);
        java.lang.String str42 = timeSeries38.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries38.removePropertyChangeListener(propertyChangeListener43);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        int int48 = month47.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries46.getDataItem((org.jfree.data.time.RegularTimePeriod) month47);
        java.lang.String str50 = timeSeries46.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries46.removeChangeListener(seriesChangeListener51);
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        int int54 = month53.getMonth();
        java.util.Date date55 = month53.getEnd();
        java.util.Date date56 = month53.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month53, (double) 0L);
        int int59 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) month53);
        java.util.Date date60 = month53.getEnd();
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year62.previous();
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
        int int65 = month64.getMonth();
        java.util.Date date66 = month64.getEnd();
        boolean boolean67 = year62.equals((java.lang.Object) date66);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year68.previous();
        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month();
        int int71 = month70.getMonth();
        java.util.Date date72 = month70.getEnd();
        boolean boolean73 = year68.equals((java.lang.Object) date72);
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year(date72, timeZone74);
        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month(date66, timeZone74);
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date60, timeZone74);
        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month(date17, timeZone74);
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date2, timeZone74);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Value" + "'", str42.equals("Value"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Value" + "'", str50.equals("Value"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 6 + "'", int54 == 6);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 6 + "'", int71 == 6);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(timeZone74);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        int int2 = month1.getMonth();
        java.util.Date date3 = month1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears(0, serialDate5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        int int9 = day8.getYear();
        int int10 = day8.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month10);
        java.lang.String str13 = timeSeries9.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries9.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int17 = month16.getMonth();
        java.util.Date date18 = month16.getEnd();
        java.util.Date date19 = month16.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) 0L);
        int int22 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month16);
        java.util.Date date23 = month16.getEnd();
        long long24 = month16.getSerialIndex();
        long long25 = month16.getFirstMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month16);
        java.util.Calendar calendar27 = null;
        try {
            month16.peg(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 24234L + "'", long24 == 24234L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1559372400000L + "'", long25 == 1559372400000L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(100, (int) (short) 1, (-43181));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries1.getRangeDescription();
        timeSeries1.removeAgedItems(1560439245630L, false);
        timeSeries1.removeAgedItems(0L, true);
        long long17 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = month18.getMonth();
        java.util.Date date20 = month18.getEnd();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        int int24 = month23.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) month23);
        java.lang.String str26 = timeSeries22.getRangeDescription();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int29 = month27.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (short) 0);
        timeSeries22.setKey((java.lang.Comparable) timeSeriesDataItem31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        int int35 = month34.getMonth();
        java.util.Date date36 = month34.getEnd();
        java.util.Date date37 = month34.getStart();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) year33, (org.jfree.data.time.RegularTimePeriod) month34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year33.previous();
        java.util.Date date40 = regularTimePeriod39.getEnd();
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month18, regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeSeries41);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(0, serialDate6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number11 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        java.lang.String str20 = timeSeries16.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries16.removeChangeListener(seriesChangeListener21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        int int24 = month23.getMonth();
        java.util.Date date25 = month23.getEnd();
        java.util.Date date26 = month23.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month23, (double) 0L);
        java.lang.Class class29 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "Thu Jun 13 08:20:23 PDT 2019", "Thu Jun 13 08:20:29 PDT 2019", class29);
        java.net.URL uRL31 = org.jfree.chart.util.ObjectUtilities.getResource("SerialDate.weekInMonthToString(): invalid code.", class29);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0, class29);
        java.lang.Class class33 = null;
        java.lang.Object obj34 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", class29, class33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Value" + "'", str20.equals("Value"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNull(uRL31);
        org.junit.Assert.assertNull(obj34);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        long long2 = year0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
//        int int7 = month6.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
//        java.lang.String str9 = timeSeries5.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries5.removePropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries5.removeChangeListener(seriesChangeListener12);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        int int17 = month16.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) month16);
//        java.lang.String str19 = timeSeries15.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timeSeries15.removePropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries15.removeChangeListener(seriesChangeListener22);
//        boolean boolean24 = timeSeries15.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number26 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number26);
//        java.lang.String str28 = fixedMillisecond25.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) 100);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries5.addAndOrUpdate(timeSeries15);
//        boolean boolean32 = year0.equals((java.lang.Object) timeSeries15);
//        java.lang.Number number34 = timeSeries15.getValue((int) (byte) 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Thu Jun 13 08:21:50 PDT 2019" + "'", str28.equals("Thu Jun 13 08:21:50 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 100 + "'", number34.equals(100));
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Thu Jun 13 08:20:22 PDT 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=Thu Jun 13 08:20:46 PDT 2019]");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException6);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        java.util.Date date10 = month8.getEnd();
        java.util.Date date11 = month8.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (double) 0L);
        java.lang.Class class14 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("Thu Jun 13 08:20:38 PDT 2019");
        boolean boolean17 = timeSeries1.getNotify();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        long long21 = year19.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        int int23 = month18.compareTo((java.lang.Object) year19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year19.next();
        int int25 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) month6);
        java.lang.String str9 = timeSeries5.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries5.removeChangeListener(seriesChangeListener12);
        boolean boolean14 = timeSeries5.getNotify();
        java.lang.Class class15 = timeSeries5.getTimePeriodClass();
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 08:20:28 PDT 2019", class15);
        java.net.URL uRL17 = org.jfree.chart.util.ObjectUtilities.getResource("", class15);
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("First", class15);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize(class15);
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Thu Jun 13 08:20:40 PDT 2019", class15);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getMonth();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date23);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        int int27 = month26.getMonth();
        java.util.Date date28 = month26.getEnd();
        java.util.Date date29 = month26.getStart();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        int int33 = month32.getMonth();
        java.util.Date date34 = month32.getEnd();
        boolean boolean35 = year30.equals((java.lang.Object) date34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.previous();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        int int39 = month38.getMonth();
        java.util.Date date40 = month38.getEnd();
        boolean boolean41 = year36.equals((java.lang.Object) date40);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date40, timeZone42);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date34, timeZone42);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.previous();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        int int48 = month47.getMonth();
        java.util.Date date49 = month47.getEnd();
        boolean boolean50 = year45.equals((java.lang.Object) date49);
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date49, timeZone51);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date34, timeZone51);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date29, timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone51);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNull(uRL16);
        org.junit.Assert.assertNotNull(uRL17);
        org.junit.Assert.assertNull(uRL18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNull(inputStream20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        java.util.Date date10 = month8.getEnd();
        java.util.Date date11 = month8.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (double) 0L);
        java.lang.Class class14 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        timeSeries1.setNotify(false);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
        long long24 = year22.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year22.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year22, (java.lang.Number) 100L);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        int int32 = month31.getMonth();
        java.util.Date date33 = month31.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date33);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addYears(0, serialDate35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number40 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, number40);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month();
        int int47 = month46.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries45.getDataItem((org.jfree.data.time.RegularTimePeriod) month46);
        java.lang.String str49 = timeSeries45.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener50 = null;
        timeSeries45.removeChangeListener(seriesChangeListener50);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        int int53 = month52.getMonth();
        java.util.Date date54 = month52.getEnd();
        java.util.Date date55 = month52.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month52, (double) 0L);
        java.lang.Class class58 = timeSeries45.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem41, "Thu Jun 13 08:20:23 PDT 2019", "Thu Jun 13 08:20:29 PDT 2019", class58);
        java.net.URL uRL60 = org.jfree.chart.util.ObjectUtilities.getResource("SerialDate.weekInMonthToString(): invalid code.", class58);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0, class58);
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L, "Thu Jun 13 08:21:02 PDT 2019", "Thu Jun 13 08:21:51 PDT 2019", class58);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Value" + "'", str49.equals("Value"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(class58);
        org.junit.Assert.assertNull(uRL60);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.fireSeriesChanged();
        java.util.Collection collection7 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries1.addAndOrUpdate(timeSeries9);
        try {
            org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.createCopy((int) (byte) 100, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        timeSeries1.fireSeriesChanged();
        timeSeries1.setMaximumItemCount(10);
        timeSeries1.setKey((java.lang.Comparable) (-1.0d));
        timeSeries1.clear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
        try {
            timeSeries1.add(regularTimePeriod12, (java.lang.Number) 1560439276921L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries1.getRangeDescription();
        timeSeries1.removeAgedItems(1560439245630L, false);
        timeSeries1.removeAgedItems(0L, true);
        timeSeries1.clear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(12);
        java.lang.String str2 = serialDate1.toString();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "11-January-1900" + "'", str2.equals("11-January-1900"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(2147483647, (-457), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
//        int int4 = month3.getMonth();
//        java.util.Date date5 = month3.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date5);
//        java.lang.String str8 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate7);
//        java.lang.String str10 = serialDate9.toString();
//        boolean boolean11 = spreadsheetDate1.isOn(serialDate9);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        int int14 = month13.getMonth();
//        java.util.Date date15 = month13.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
//        java.lang.String str18 = serialDate17.getDescription();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate17);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        int int22 = month21.getMonth();
//        java.util.Date date23 = month21.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date23);
//        java.lang.String str26 = serialDate25.toString();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate25);
//        java.lang.String str28 = serialDate27.toString();
//        org.jfree.data.time.SerialDate serialDate29 = serialDate17.getEndOfCurrentMonth(serialDate27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number31 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, number31);
//        java.lang.String str33 = fixedMillisecond30.toString();
//        long long34 = fixedMillisecond30.getFirstMillisecond();
//        java.util.Date date35 = fixedMillisecond30.getTime();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
//        org.jfree.data.time.SerialDate serialDate37 = serialDate17.getEndOfCurrentMonth(serialDate36);
//        org.jfree.data.time.SerialDate serialDate39 = serialDate17.getPreviousDayOfWeek((int) (byte) 1);
//        boolean boolean40 = spreadsheetDate1.isOnOrBefore(serialDate17);
//        java.util.Date date41 = spreadsheetDate1.toDate();
//        int int42 = spreadsheetDate1.toSerial();
//        spreadsheetDate1.setDescription("");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        int int48 = month47.getMonth();
//        java.util.Date date49 = month47.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(date49);
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(date49);
//        java.lang.String str52 = serialDate51.getDescription();
//        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate51);
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
//        int int56 = month55.getMonth();
//        java.util.Date date57 = month55.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond(date57);
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance(date57);
//        java.lang.String str60 = serialDate59.toString();
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate59);
//        java.lang.String str62 = serialDate61.toString();
//        org.jfree.data.time.SerialDate serialDate63 = serialDate51.getEndOfCurrentMonth(serialDate61);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number65 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, number65);
//        java.lang.String str67 = fixedMillisecond64.toString();
//        long long68 = fixedMillisecond64.getFirstMillisecond();
//        java.util.Date date69 = fixedMillisecond64.getTime();
//        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.createInstance(date69);
//        org.jfree.data.time.SerialDate serialDate71 = serialDate51.getEndOfCurrentMonth(serialDate70);
//        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(5, serialDate71);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number75 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond74, number75);
//        java.lang.String str77 = fixedMillisecond74.toString();
//        long long78 = fixedMillisecond74.getFirstMillisecond();
//        java.util.Date date79 = fixedMillisecond74.getTime();
//        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.createInstance(date79);
//        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.createInstance(date79);
//        serialDate81.setDescription("");
//        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.addDays((-460), serialDate81);
//        java.lang.String str85 = serialDate84.toString();
//        boolean boolean86 = spreadsheetDate1.isInRange(serialDate71, serialDate84);
//        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day(serialDate84);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "30-June-2019" + "'", str8.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "30-June-2018" + "'", str10.equals("30-June-2018"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNull(str18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "30-June-2019" + "'", str26.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "30-June-2018" + "'", str28.equals("30-June-2018"));
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Thu Jun 13 08:21:54 PDT 2019" + "'", str33.equals("Thu Jun 13 08:21:54 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560439314763L + "'", long34 == 1560439314763L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNull(str52);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 6 + "'", int56 == 6);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "30-June-2019" + "'", str60.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "30-June-2018" + "'", str62.equals("30-June-2018"));
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Thu Jun 13 08:21:54 PDT 2019" + "'", str67.equals("Thu Jun 13 08:21:54 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560439314793L + "'", long68 == 1560439314793L);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertNotNull(serialDate71);
//        org.junit.Assert.assertNotNull(serialDate72);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "Thu Jun 13 08:21:54 PDT 2019" + "'", str77.equals("Thu Jun 13 08:21:54 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1560439314794L + "'", long78 == 1560439314794L);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNotNull(serialDate80);
//        org.junit.Assert.assertNotNull(serialDate81);
//        org.junit.Assert.assertNotNull(serialDate84);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "10-March-2018" + "'", str85.equals("10-March-2018"));
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
//        java.lang.String str5 = timeSeries1.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        int int11 = month10.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month10);
//        java.lang.String str13 = timeSeries9.getRangeDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener14);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
//        int int17 = month16.getMonth();
//        java.util.Date date18 = month16.getEnd();
//        java.util.Date date19 = month16.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) 0L);
//        int int22 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month16);
//        timeSeries1.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        long long25 = timeSeries1.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        int int29 = month28.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries27.getDataItem((org.jfree.data.time.RegularTimePeriod) month28);
//        java.lang.String str31 = timeSeries27.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timeSeries27.removePropertyChangeListener(propertyChangeListener32);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
//        timeSeries27.removeChangeListener(seriesChangeListener34);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
//        int int39 = month38.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) month38);
//        java.lang.String str41 = timeSeries37.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener42 = null;
//        timeSeries37.removePropertyChangeListener(propertyChangeListener42);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries37.removeChangeListener(seriesChangeListener44);
//        boolean boolean46 = timeSeries37.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number48 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, number48);
//        java.lang.String str50 = fixedMillisecond47.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (java.lang.Number) 100);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries27.addAndOrUpdate(timeSeries37);
//        java.lang.Comparable comparable54 = timeSeries37.getKey();
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries1.addAndOrUpdate(timeSeries37);
//        boolean boolean56 = timeSeries1.isEmpty();
//        int int57 = timeSeries1.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Value" + "'", str31.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Value" + "'", str41.equals("Value"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Thu Jun 13 08:21:56 PDT 2019" + "'", str50.equals("Thu Jun 13 08:21:56 PDT 2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem52);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + comparable54 + "' != '" + (short) 100 + "'", comparable54.equals((short) 100));
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2147483647 + "'", int57 == 2147483647);
//    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        timeSeries1.setRangeDescription("hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number5 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, number5);
//        long long7 = fixedMillisecond4.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 1560439220158L);
//        long long10 = fixedMillisecond4.getSerialIndex();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        int int14 = month13.getMonth();
//        java.util.Date date15 = month13.getEnd();
//        boolean boolean16 = year11.equals((java.lang.Object) date15);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        int int18 = month17.getMonth();
//        java.util.Date date19 = month17.getEnd();
//        int int20 = year11.compareTo((java.lang.Object) date19);
//        long long21 = year11.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (org.jfree.data.time.RegularTimePeriod) year11);
//        long long23 = year11.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        int int27 = month26.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries25.getDataItem((org.jfree.data.time.RegularTimePeriod) month26);
//        java.lang.String str29 = timeSeries25.getRangeDescription();
//        timeSeries25.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        int int34 = month33.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
//        java.lang.String str36 = timeSeries32.getRangeDescription();
//        timeSeries32.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries25.addAndOrUpdate(timeSeries32);
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
//        int int40 = month39.getMonth();
//        java.util.Date date41 = month39.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(date41);
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date41);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate43);
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) day44, (double) (-1));
//        boolean boolean47 = year11.equals((java.lang.Object) timeSeries32);
//        int int48 = year11.getYear();
//        java.lang.String str49 = year11.toString();
//        long long50 = year11.getSerialIndex();
//        long long51 = year11.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560439316625L + "'", long7 == 1560439316625L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560439316625L + "'", long10 == 1560439316625L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Value" + "'", str29.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Value" + "'", str36.equals("Value"));
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2019" + "'", str49.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2019L + "'", long50 == 2019L);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2019L + "'", long51 == 2019L);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month4);
        java.lang.String str7 = timeSeries3.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        int int13 = month12.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) month12);
        java.lang.String str15 = timeSeries11.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries11.removeChangeListener(seriesChangeListener16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = month18.getMonth();
        java.util.Date date20 = month18.getEnd();
        java.util.Date date21 = month18.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (double) 0L);
        int int24 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month18);
        java.util.Date date25 = month18.getEnd();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        java.lang.String str27 = serialDate26.toString();
        boolean boolean28 = spreadsheetDate1.isOnOrAfter(serialDate26);
        int int29 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "30-June-2019" + "'", str27.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1900 + "'", int29 == 1900);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
//        java.lang.String str7 = serialDate6.getDescription();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate6);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
//        int int11 = month10.getMonth();
//        java.util.Date date12 = month10.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date12);
//        java.lang.String str15 = serialDate14.toString();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate14);
//        java.lang.String str17 = serialDate16.toString();
//        org.jfree.data.time.SerialDate serialDate18 = serialDate6.getEndOfCurrentMonth(serialDate16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number20 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, number20);
//        java.lang.String str22 = fixedMillisecond19.toString();
//        long long23 = fixedMillisecond19.getFirstMillisecond();
//        java.util.Date date24 = fixedMillisecond19.getTime();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
//        org.jfree.data.time.SerialDate serialDate26 = serialDate6.getEndOfCurrentMonth(serialDate25);
//        java.lang.String str27 = serialDate6.toString();
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays((int) (short) -1, serialDate6);
//        java.lang.String str29 = serialDate6.getDescription();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "30-June-2019" + "'", str15.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "30-June-2018" + "'", str17.equals("30-June-2018"));
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Thu Jun 13 08:21:57 PDT 2019" + "'", str22.equals("Thu Jun 13 08:21:57 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560439317132L + "'", long23 == 1560439317132L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "30-June-2019" + "'", str27.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNull(str29);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        java.util.Date date10 = month8.getEnd();
        java.util.Date date11 = month8.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (double) 0L);
        java.lang.Class class14 = timeSeries1.getTimePeriodClass();
        timeSeries1.setRangeDescription("Thu Jun 13 08:20:38 PDT 2019");
        boolean boolean17 = timeSeries1.getNotify();
        timeSeries1.removeAgedItems(1560439236176L, true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.getDataItem(0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        java.util.Date date6 = month4.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date6);
        java.lang.String str9 = serialDate8.toString();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate8);
        java.lang.String str11 = serialDate10.toString();
        boolean boolean12 = spreadsheetDate2.isOn(serialDate10);
        java.util.Date date13 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getMonth();
        java.util.Date date19 = month17.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date19);
        java.lang.String str22 = serialDate21.toString();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate21);
        java.lang.String str24 = serialDate23.toString();
        boolean boolean25 = spreadsheetDate15.isOn(serialDate23);
        boolean boolean26 = spreadsheetDate2.isOnOrAfter(serialDate23);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        int int29 = month28.getMonth();
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date30);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date30);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, serialDate32);
        boolean boolean34 = spreadsheetDate2.isOn(serialDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        int int39 = month38.getMonth();
        java.util.Date date40 = month38.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(date40);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date40);
        java.lang.String str43 = serialDate42.toString();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate42);
        java.lang.String str45 = serialDate44.toString();
        boolean boolean46 = spreadsheetDate36.isOn(serialDate44);
        boolean boolean47 = spreadsheetDate2.isOn(serialDate44);
        try {
            org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) '4', serialDate44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "30-June-2019" + "'", str9.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "30-June-2018" + "'", str11.equals("30-June-2018"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "30-June-2019" + "'", str22.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "30-June-2018" + "'", str24.equals("30-June-2018"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "30-June-2019" + "'", str43.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "30-June-2018" + "'", str45.equals("30-June-2018"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        java.lang.String str5 = timeSeries1.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month10);
        java.lang.String str13 = timeSeries9.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries9.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int17 = month16.getMonth();
        java.util.Date date18 = month16.getEnd();
        java.util.Date date19 = month16.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (double) 0L);
        int int22 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month16);
        java.util.Date date23 = month16.getEnd();
        long long24 = month16.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month16.next();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        int int27 = month26.getMonth();
        java.util.Date date28 = month26.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date28);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
        long long32 = day31.getFirstMillisecond();
        long long33 = day31.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day31.previous();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.Object obj37 = timeSeries36.clone();
        java.lang.Object obj38 = timeSeries36.clone();
        boolean boolean39 = day31.equals(obj38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) 1560439239079L);
        int int42 = month16.compareTo((java.lang.Object) timeSeriesDataItem41);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        int int45 = month43.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        int int49 = month48.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries47.getDataItem((org.jfree.data.time.RegularTimePeriod) month48);
        java.lang.String str51 = timeSeries47.getRangeDescription();
        int int52 = month43.compareTo((java.lang.Object) timeSeries47);
        boolean boolean53 = timeSeries47.getNotify();
        int int54 = month16.compareTo((java.lang.Object) boolean53);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Value" + "'", str13.equals("Value"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 24234L + "'", long24 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561878000000L + "'", long32 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1561964399999L + "'", long33 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Value" + "'", str51.equals("Value"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        java.util.Date date6 = month4.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date6);
        java.lang.String str9 = serialDate8.toString();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate8);
        java.lang.String str11 = serialDate10.toString();
        boolean boolean12 = spreadsheetDate2.isOn(serialDate10);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        int int15 = month14.getMonth();
        java.util.Date date16 = month14.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date16);
        java.lang.String str19 = serialDate18.getDescription();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(6, serialDate18);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        int int23 = month22.getMonth();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date24);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date24);
        java.lang.String str27 = serialDate26.toString();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate26);
        java.lang.String str29 = serialDate28.toString();
        org.jfree.data.time.SerialDate serialDate30 = serialDate18.getEndOfCurrentMonth(serialDate28);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        int int33 = month32.getMonth();
        java.util.Date date34 = month32.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date34);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date34);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addYears(0, serialDate36);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        int int41 = month40.getMonth();
        java.util.Date date42 = month40.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(date42);
        java.lang.String str45 = serialDate44.toString();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate44);
        org.jfree.data.time.SerialDate serialDate47 = serialDate36.getEndOfCurrentMonth(serialDate46);
        boolean boolean48 = spreadsheetDate2.isInRange(serialDate30, serialDate47);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addYears((-1), serialDate30);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "30-June-2019" + "'", str9.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "30-June-2018" + "'", str11.equals("30-June-2018"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "30-June-2019" + "'", str27.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "30-June-2018" + "'", str29.equals("30-June-2018"));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "30-June-2019" + "'", str45.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(serialDate49);
    }
}

