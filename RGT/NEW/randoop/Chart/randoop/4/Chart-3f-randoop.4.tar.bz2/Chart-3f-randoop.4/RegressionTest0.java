import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-9999), year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date3 = month2.getStart();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Calendar calendar3 = null;
        try {
            year1.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        java.util.Calendar calendar6 = null;
        try {
            month2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date3 = month2.getStart();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.addChangeListener(seriesChangeListener10);
        try {
            timeSeries7.delete((-9999), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        int int9 = timeSeries7.getItemCount();
        try {
            org.jfree.data.time.TimeSeries timeSeries12 = timeSeries7.createCopy(1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year5.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.util.Date date29 = month26.getStart();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month26, (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        int int9 = timeSeries7.getItemCount();
        java.lang.Object obj10 = timeSeries7.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        try {
            timeSeries7.delete((int) '#', 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        java.lang.String str25 = timeSeries7.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2020" + "'", str25.equals("2020"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int36 = month35.getYearValue();
        java.util.Date date37 = month35.getEnd();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month35, "2020", "2020");
        java.lang.Class class41 = timeSeries40.getTimePeriodClass();
        java.lang.String str42 = timeSeries40.getDescription();
        org.jfree.data.time.Year year44 = org.jfree.data.time.Year.parseYear("100");
        int int45 = year44.getYear();
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass52 = month51.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = month51.previous();
        java.lang.Class<?> wildcardClass54 = regularTimePeriod53.getClass();
        boolean boolean55 = fixedMillisecond48.equals((java.lang.Object) regularTimePeriod53);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries40.getDataItem(regularTimePeriod53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = timeSeriesDataItem56.getPeriod();
        try {
            timeSeries7.add(timeSeriesDataItem56);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 100 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 100 + "'", int36 == 100);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(class41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(year44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 10, seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent2.getSummary();
        org.junit.Assert.assertNull(seriesChangeInfo3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        long long5 = month2.getSerialIndex();
        long long6 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1210L + "'", long5 == 1210L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-58987929600000L) + "'", long6 == (-58987929600000L));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        long long5 = month2.getSerialIndex();
        long long6 = month2.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            month2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62133062400001L) + "'", long6 == (-62133062400001L));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.lang.String str3 = fixedMillisecond1.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str3.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        try {
            timeSeries7.update(regularTimePeriod9, (java.lang.Number) (-58986590400001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        timeSeries7.removeAgedItems(false);
        try {
            timeSeries7.delete(9, 2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        java.lang.Object obj7 = timeSeriesDataItem5.clone();
        timeSeriesDataItem5.setSelected(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        try {
            org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries7.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.addOrUpdate(regularTimePeriod11, (java.lang.Number) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.lang.String str6 = year5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year5.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9999, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener34);
        boolean boolean36 = timeSeries7.getNotify();
        try {
            org.jfree.data.time.TimeSeries timeSeries39 = timeSeries7.createCopy(2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("100");
        java.util.Calendar calendar2 = null;
        try {
            year1.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        double double17 = timeSeries7.getMaxY();
        try {
            java.lang.Number number19 = timeSeries7.getValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        org.jfree.data.time.Year year14 = org.jfree.data.time.Year.parseYear("100");
        boolean boolean15 = timeSeries7.equals((java.lang.Object) "100");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries7.addChangeListener(seriesChangeListener16);
        try {
            org.jfree.data.time.TimeSeries timeSeries20 = timeSeries7.createCopy((int) ' ', 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.addChangeListener(seriesChangeListener10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
        try {
            timeSeries7.add(regularTimePeriod12, (double) ' ', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        long long4 = month2.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            month2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-58987929600000L) + "'", long4 == (-58987929600000L));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        java.lang.String str33 = timeSeries7.getDomainDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = null;
        try {
            timeSeries7.add(regularTimePeriod34, (double) (-62133062400001L), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2020" + "'", str33.equals("2020"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setMaximumItemAge((long) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) 1560150000000L);
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        java.util.Calendar calendar5 = null;
        try {
            month2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        java.util.Calendar calendar28 = null;
        try {
            long long29 = regularTimePeriod27.getMiddleMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        int int9 = timeSeries7.getItemCount();
        timeSeries7.setDescription("October 100");
        int int12 = timeSeries7.getMaximumItemCount();
        try {
            timeSeries7.delete(0, 9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        try {
            org.jfree.data.time.TimeSeries timeSeries40 = timeSeries7.createCopy(0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
        int int14 = year8.compareTo((java.lang.Object) regularTimePeriod13);
        boolean boolean15 = month2.equals((java.lang.Object) int14);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = month2.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        double double17 = timeSeries7.getMinY();
        try {
            timeSeries7.delete((int) ' ', (int) '4', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        try {
            org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod3, "", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries7.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.previous();
        try {
            timeSeries7.add(regularTimePeriod15, (double) (short) 10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(regularTimePeriod15);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        java.lang.Object obj27 = timeSeries7.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries7.removeChangeListener(seriesChangeListener28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        int int15 = year9.compareTo((java.lang.Object) year12);
        java.util.Calendar calendar16 = null;
        try {
            year9.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        java.lang.Object obj15 = timeSeries7.clone();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries7.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        try {
            java.lang.Number number28 = timeSeries7.getValue(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
        long long2 = year1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int15 = month14.getYearValue();
        boolean boolean17 = month14.equals((java.lang.Object) (short) 10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month14, (double) (-58987929600000L), false);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        try {
            org.jfree.data.time.TimeSeries timeSeries35 = timeSeries7.createCopy(2, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("100");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: 100" + "'", str2.equals("org.jfree.data.general.SeriesException: 100"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        int int9 = timeSeries7.getItemCount();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            timeSeries7.add(regularTimePeriod10, (double) 9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int12 = month11.getYearValue();
        java.util.Date date13 = month11.getEnd();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "2020", "2020");
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        java.lang.String str18 = timeSeries16.getDescription();
        timeSeries16.setRangeDescription("2020");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int24 = month23.getYearValue();
        boolean boolean26 = month23.equals((java.lang.Object) (short) 10);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month23, (double) (-58987929600000L), false);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month23, (double) (byte) -1, true);
        java.util.Calendar calendar33 = null;
        try {
            long long34 = month23.getFirstMillisecond(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        timeSeries7.removeAgedItems(6L, true);
        try {
            timeSeries7.setMaximumItemCount((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date3 = month2.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Wed Dec 31 16:00:00 PST 1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date3 = month2.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.lang.String str8 = month7.toString();
        boolean boolean9 = fixedMillisecond4.equals((java.lang.Object) month7);
        long long10 = month7.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "January 0" + "'", str8.equals("January 0"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62150212800001L) + "'", long10 == (-62150212800001L));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9999, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond1.getMiddleMillisecond(calendar11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = year1.getStart();
        long long4 = year1.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62104204800000L) + "'", long4 == (-62104204800000L));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year9);
        try {
            java.lang.Number number13 = timeSeries7.getValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        timeSeries7.removeAgedItems(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries7.addChangeListener(seriesChangeListener29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj34 = null;
        int int35 = fixedMillisecond33.compareTo(obj34);
        boolean boolean36 = day31.equals((java.lang.Object) int35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day31.next();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) 12, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass15 = month14.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        boolean boolean17 = year9.equals((java.lang.Object) wildcardClass15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.lang.String str34 = timeSeries7.getDomainDescription();
        java.lang.Object obj35 = timeSeries7.clone();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int39 = month38.getYearValue();
        java.util.Date date40 = month38.getEnd();
        boolean boolean42 = month38.equals((java.lang.Object) 'a');
        long long43 = month38.getLastMillisecond();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month47.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.previous();
        int int50 = year44.compareTo((java.lang.Object) regularTimePeriod49);
        boolean boolean51 = month38.equals((java.lang.Object) int50);
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month38, (double) 11, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2020" + "'", str34.equals("2020"));
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 100 + "'", int39 == 100);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-58985251200001L) + "'", long43 == (-58985251200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener29);
        try {
            org.jfree.data.time.TimeSeries timeSeries33 = timeSeries7.createCopy(2, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        timeSeries7.removeAgedItems(false);
        timeSeries7.removeAgedItems(true);
        java.lang.String str31 = timeSeries7.getRangeDescription();
        try {
            timeSeries7.delete(2147483647, 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2020" + "'", str31.equals("2020"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        java.util.Date date9 = month2.getEnd();
        java.util.TimeZone timeZone10 = null;
        try {
            org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year5.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, 100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date3 = month2.getStart();
        long long4 = month2.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.util.Collection collection34 = timeSeries7.getTimePeriods();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.next();
        java.lang.String str37 = regularTimePeriod36.toString();
        timeSeries7.add(regularTimePeriod36, (java.lang.Number) 0L, false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2020" + "'", str37.equals("2020"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        java.util.TimeZone timeZone8 = null;
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date5, timeZone8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.lang.String str2 = regularTimePeriod1.toString();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = regularTimePeriod1.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2020" + "'", str2.equals("2020"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        java.lang.Object obj29 = timeSeries7.clone();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries7.getDataItem(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj29);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int4 = day0.compareTo((java.lang.Object) 8);
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        try {
            java.lang.Number number39 = timeSeries7.getValue(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        java.lang.Object obj7 = timeSeriesDataItem5.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem5.getPeriod();
        timeSeriesDataItem5.setSelected(true);
        timeSeriesDataItem5.setValue((java.lang.Number) 1210L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = month7.getMiddleMillisecond();
        java.util.Calendar calendar12 = null;
        try {
            month7.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-58986590400001L) + "'", long11 == (-58986590400001L));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: 100");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        java.util.Calendar calendar6 = null;
        try {
            month2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        java.lang.Class<?> wildcardClass5 = regularTimePeriod4.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date7, timeZone8);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNull(regularTimePeriod9);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.util.Collection collection34 = timeSeries7.getTimePeriods();
        boolean boolean35 = timeSeries7.getNotify();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year37.next();
        timeSeries7.add(regularTimePeriod38, (java.lang.Number) 2147483647);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        timeSeries7.removeAgedItems(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries7.addChangeListener(seriesChangeListener29);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int34 = month33.getYearValue();
        java.util.Date date35 = month33.getEnd();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "2020", "2020");
        java.lang.String str39 = timeSeries38.getDescription();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month43.previous();
        int int46 = year40.compareTo((java.lang.Object) regularTimePeriod45);
        boolean boolean47 = timeSeries38.equals((java.lang.Object) regularTimePeriod45);
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int51 = month50.getYearValue();
        java.util.Date date52 = month50.getEnd();
        long long53 = month50.getSerialIndex();
        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) month50, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener56 = null;
        timeSeries38.addChangeListener(seriesChangeListener56);
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int61 = month60.getYearValue();
        java.util.Date date62 = month60.getEnd();
        boolean boolean64 = month60.equals((java.lang.Object) 'a');
        java.lang.String str65 = month60.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month60.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries38.addOrUpdate(regularTimePeriod66, (java.lang.Number) 9);
        try {
            timeSeries7.update(regularTimePeriod66, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1210L + "'", long53 == 1210L);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 100 + "'", int61 == 100);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "October 100" + "'", str65.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNull(timeSeriesDataItem68);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        java.lang.Object obj27 = timeSeries7.clone();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int31 = month30.getYearValue();
        java.util.Date date32 = month30.getEnd();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "2020", "2020");
        int int36 = month30.getYearValue();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month30, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 100 + "'", int36 == 100);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        long long4 = month2.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-58987929600000L) + "'", long4 == (-58987929600000L));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        java.lang.Object obj7 = timeSeriesDataItem5.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem5.getPeriod();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj12 = null;
        int int13 = fixedMillisecond11.compareTo(obj12);
        boolean boolean14 = day9.equals((java.lang.Object) int13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day9.next();
        int int16 = timeSeriesDataItem5.compareTo((java.lang.Object) day9);
        java.lang.Object obj17 = null;
        int int18 = day9.compareTo(obj17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2020");
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        timeSeriesDataItem31.setSelected(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = timeSeriesDataItem31.getPeriod();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        org.jfree.data.time.Year year14 = org.jfree.data.time.Year.parseYear("100");
        boolean boolean15 = timeSeries7.equals((java.lang.Object) "100");
        try {
            timeSeries7.delete(7, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj2 = null;
        int int3 = fixedMillisecond1.compareTo(obj2);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass7 = month6.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.previous();
        int int9 = fixedMillisecond1.compareTo((java.lang.Object) month6);
        long long10 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getLastMillisecond();
        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) (byte) 0);
        long long6 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = null;
        try {
            timeSeries7.add(regularTimePeriod15, (java.lang.Number) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        double double17 = timeSeries7.getMaxY();
        java.lang.Class class18 = timeSeries7.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNull(class18);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj27 = null;
        int int28 = fixedMillisecond26.compareTo(obj27);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass32 = month31.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month31.previous();
        int int34 = fixedMillisecond26.compareTo((java.lang.Object) month31);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 10, seriesChangeInfo1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        java.lang.String str4 = seriesChangeEvent2.toString();
        java.lang.Object obj5 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo6);
        java.lang.String str8 = seriesChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (byte) 10 + "'", obj3.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (byte) 10 + "'", obj5.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str8.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Date date3 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem9.getPeriod();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener29);
        timeSeries7.setDescription("2020");
        java.lang.String str33 = timeSeries7.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2020" + "'", str33.equals("2020"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) Double.NaN);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5);
        java.util.TimeZone timeZone8 = null;
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date5, timeZone8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj29 = null;
        int int30 = fixedMillisecond28.compareTo(obj29);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int34 = month33.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeriesDataItem36.getPeriod();
        java.lang.Object obj38 = timeSeriesDataItem36.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeriesDataItem36.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, regularTimePeriod39);
        long long41 = regularTimePeriod39.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-58986590400001L) + "'", long41 == (-58986590400001L));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("January 0");
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        java.lang.String str15 = year11.toString();
        java.util.Calendar calendar16 = null;
        try {
            year11.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100" + "'", str15.equals("100"));
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj3 = null;
//        int int4 = fixedMillisecond2.compareTo(obj3);
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        long long8 = day0.getFirstMillisecond();
//        int int9 = day0.getMonth();
//        long long10 = day0.getSerialIndex();
//        java.util.Calendar calendar11 = null;
//        try {
//            day0.peg(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj3 = null;
//        int int4 = fixedMillisecond2.compareTo(obj3);
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        long long8 = day0.getFirstMillisecond();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = day0.getMiddleMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj3 = null;
        int int4 = fixedMillisecond2.compareTo(obj3);
        boolean boolean5 = day0.equals((java.lang.Object) int4);
        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day0.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        java.util.Date date9 = month2.getEnd();
        java.lang.String str10 = month2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "October 100" + "'", str10.equals("October 100"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        timeSeries7.removeAgedItems(false);
        try {
            timeSeries7.delete((int) (short) 100, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj31 = null;
        int int32 = fixedMillisecond30.compareTo(obj31);
        boolean boolean33 = day28.equals((java.lang.Object) int32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.next();
        int int35 = day28.getYear();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day28);
        timeSeries7.setNotify(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = year1.getStart();
        long long4 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        long long6 = year1.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year1.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62104204800000L) + "'", long4 == (-62104204800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62072668800001L) + "'", long6 == (-62072668800001L));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        java.lang.Object obj7 = timeSeriesDataItem5.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem5.getPeriod();
        timeSeriesDataItem5.setSelected(true);
        java.lang.Number number11 = timeSeriesDataItem5.getValue();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj15 = null;
        int int16 = fixedMillisecond14.compareTo(obj15);
        boolean boolean17 = day12.equals((java.lang.Object) int16);
        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day12.next();
        boolean boolean20 = timeSeriesDataItem5.equals((java.lang.Object) regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.0d + "'", number11.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        long long3 = year0.getMiddleMillisecond();
        long long4 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        java.util.Date date11 = month7.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        java.util.TimeZone timeZone13 = null;
        try {
            org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date11, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("100");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int12 = month11.getYearValue();
        java.util.Date date13 = month11.getEnd();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "2020", "2020");
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        java.lang.String str18 = timeSeries16.getDescription();
        timeSeries16.setRangeDescription("2020");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int24 = month23.getYearValue();
        boolean boolean26 = month23.equals((java.lang.Object) (short) 10);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month23, (double) (-58987929600000L), false);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month23, (double) (byte) -1, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = null;
        try {
            timeSeries7.add(regularTimePeriod33, (double) 25568L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 10, seriesChangeInfo1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        java.lang.String str4 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo5);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo7);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo9);
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (byte) 10 + "'", obj3.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        java.lang.String str7 = month2.toString();
        org.jfree.data.time.Year year8 = month2.getYear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "October 100" + "'", str7.equals("October 100"));
        org.junit.Assert.assertNotNull(year8);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date3 = month2.getStart();
        long long4 = month2.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj31 = null;
        int int32 = fixedMillisecond30.compareTo(obj31);
        boolean boolean33 = day28.equals((java.lang.Object) int32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.next();
        int int35 = day28.getYear();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day28);
        java.util.Calendar calendar37 = null;
        try {
            long long38 = day28.getFirstMillisecond(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        timeSeries7.setKey((java.lang.Comparable) year29);
        timeSeries7.setDescription("org.jfree.data.time.TimePeriodFormatException: 100");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int12 = month11.getYearValue();
        java.util.Date date13 = month11.getEnd();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "2020", "2020");
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        java.lang.String str18 = timeSeries16.getDescription();
        timeSeries16.setRangeDescription("2020");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int24 = month23.getYearValue();
        boolean boolean26 = month23.equals((java.lang.Object) (short) 10);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month23, (double) (-58987929600000L), false);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month23, (double) (byte) -1, true);
        java.util.Calendar calendar33 = null;
        try {
            long long34 = month23.getLastMillisecond(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        timeSeries7.clear();
        double double25 = timeSeries7.getMaxY();
        double double26 = timeSeries7.getMinY();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        java.lang.String str5 = month2.toString();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "October 100" + "'", str5.equals("October 100"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("October 100");
        org.junit.Assert.assertNotNull(month1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        java.lang.String str4 = month2.toString();
        java.lang.String str5 = month2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "January 0" + "'", str4.equals("January 0"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January 0" + "'", str5.equals("January 0"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(6);
        long long3 = year2.getFirstMillisecond();
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 100, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61977974400000L) + "'", long3 == (-61977974400000L));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        java.lang.String str33 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int37 = month36.getYearValue();
        java.util.Date date38 = month36.getEnd();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month36, "2020", "2020");
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int45 = month44.getYearValue();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month44, "2020", "2020");
        java.lang.Class class50 = timeSeries49.getTimePeriodClass();
        java.lang.String str51 = timeSeries49.getDescription();
        org.jfree.data.time.Year year53 = org.jfree.data.time.Year.parseYear("100");
        int int54 = year53.getYear();
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass61 = month60.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month60.previous();
        java.lang.Class<?> wildcardClass63 = regularTimePeriod62.getClass();
        boolean boolean64 = fixedMillisecond57.equals((java.lang.Object) regularTimePeriod62);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries49.getDataItem(regularTimePeriod62);
        timeSeries41.add(timeSeriesDataItem65);
        java.lang.String str67 = timeSeries41.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries7.addAndOrUpdate(timeSeries41);
        java.lang.Class class69 = timeSeries41.getTimePeriodClass();
        java.lang.Class class70 = org.jfree.data.time.RegularTimePeriod.downsize(class69);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2020" + "'", str33.equals("2020"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 100 + "'", int37 == 100);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(class50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(year53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 100 + "'", int54 == 100);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2020" + "'", str67.equals("2020"));
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertNotNull(class69);
        org.junit.Assert.assertNotNull(class70);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = year1.getStart();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        timeSeries7.setMaximumItemAge(1560150000000L);
        java.util.List list30 = timeSeries7.getItems();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(list30);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1));
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = seriesChangeEvent1.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo3);
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) seriesChangeInfo3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(seriesChangeInfo2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("10-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        java.lang.Object obj27 = timeSeries7.clone();
        try {
            timeSeries7.delete((int) (byte) 1, 5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        boolean boolean5 = month2.equals((java.lang.Object) (short) 10);
        long long6 = month2.getSerialIndex();
        int int7 = month2.getYearValue();
        java.util.Calendar calendar8 = null;
        try {
            month2.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1210L + "'", long6 == 1210L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = null;
        try {
            timeSeries7.add(timeSeriesDataItem25, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        long long3 = year0.getMiddleMillisecond();
        long long4 = year0.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '#', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = year1.getStart();
        long long4 = year1.getFirstMillisecond();
        java.lang.String str5 = year1.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62104204800000L) + "'", long4 == (-62104204800000L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1));
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = seriesChangeEvent1.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo3);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent1.getSummary();
        org.junit.Assert.assertNull(seriesChangeInfo2);
        org.junit.Assert.assertNull(seriesChangeInfo5);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj31 = null;
        int int32 = fixedMillisecond30.compareTo(obj31);
        boolean boolean33 = day28.equals((java.lang.Object) int32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.next();
        int int35 = day28.getYear();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(1560236399999L);
        boolean boolean39 = day28.equals((java.lang.Object) 1560236399999L);
        java.util.Calendar calendar40 = null;
        try {
            day28.peg(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year9);
        java.lang.String str12 = year9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date3 = month2.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        int int15 = year9.compareTo((java.lang.Object) year12);
        long long16 = year12.getLastMillisecond();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = year12.getLastMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = year1.getStart();
        long long4 = year1.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62104204800000L) + "'", long4 == (-62104204800000L));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        java.lang.Object obj25 = timeSeriesDataItem23.clone();
        timeSeriesDataItem23.setSelected(false);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int31 = month30.getYearValue();
        java.util.Date date32 = month30.getEnd();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "2020", "2020");
        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
        java.lang.String str37 = timeSeries35.getDescription();
        org.jfree.data.time.Year year39 = org.jfree.data.time.Year.parseYear("100");
        int int40 = year39.getYear();
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass47 = month46.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month46.previous();
        java.lang.Class<?> wildcardClass49 = regularTimePeriod48.getClass();
        boolean boolean50 = fixedMillisecond43.equals((java.lang.Object) regularTimePeriod48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries35.getDataItem(regularTimePeriod48);
        long long52 = timeSeries35.getMaximumItemAge();
        timeSeries35.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timeSeries35.removePropertyChangeListener(propertyChangeListener55);
        java.beans.PropertyChangeListener propertyChangeListener57 = null;
        timeSeries35.addPropertyChangeListener(propertyChangeListener57);
        timeSeries35.setDescription("2020");
        boolean boolean61 = timeSeriesDataItem23.equals((java.lang.Object) "2020");
        boolean boolean62 = timeSeriesDataItem23.isSelected();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(class36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(year39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 100 + "'", int40 == 100);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 9223372036854775807L + "'", long52 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 10, seriesChangeInfo1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        java.lang.String str4 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo5);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo7);
        java.lang.Object obj9 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo10);
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (byte) 10 + "'", obj3.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + obj9 + "' != '" + (byte) 10 + "'", obj9.equals((byte) 10));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        java.util.Date date11 = month7.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11);
        java.util.TimeZone timeZone14 = null;
        try {
            org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date11, timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        java.lang.Comparable comparable25 = timeSeries7.getKey();
        boolean boolean27 = timeSeries7.equals((java.lang.Object) 9223372036854775807L);
        java.lang.String str28 = timeSeries7.getRangeDescription();
        int int29 = timeSeries7.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertNotNull(comparable25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2020" + "'", str28.equals("2020"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2147483647 + "'", int29 == 2147483647);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Wed Dec 31 16:00:00 PST 1969");
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setRangeDescription("January 0");
        double double27 = timeSeries7.getMaxY();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries7.addOrUpdate(regularTimePeriod28, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-1.0d) + "'", double27 == (-1.0d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) (byte) 100);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, (-1), (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        timeSeries7.setKey((java.lang.Comparable) year29);
        long long31 = year29.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329600000L + "'", long31 == 1546329600000L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2020");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = fixedMillisecond1.getSerialIndex();
        long long12 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond1.previous();
        long long14 = regularTimePeriod13.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9L + "'", long14 == 9L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day6.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        long long15 = year11.getFirstMillisecond();
        java.util.Calendar calendar16 = null;
        try {
            year11.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-59011603200000L) + "'", long15 == (-59011603200000L));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.util.Collection collection34 = timeSeries7.getTimePeriods();
        boolean boolean35 = timeSeries7.getNotify();
        double double36 = timeSeries7.getMaxY();
        try {
            java.lang.Number number38 = timeSeries7.getValue(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.56015E12d + "'", double36 == 1.56015E12d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date3 = month2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        timeSeries7.setDescription("org.jfree.data.time.TimePeriodFormatException: 100");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.String str8 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
//        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
//        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int20 = month19.getYearValue();
//        java.util.Date date21 = month19.getEnd();
//        long long22 = month19.getSerialIndex();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
//        java.lang.Comparable comparable25 = timeSeries7.getKey();
//        boolean boolean27 = timeSeries7.equals((java.lang.Object) 9223372036854775807L);
//        int int28 = timeSeries7.getItemCount();
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int32 = month31.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, 0.0d);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day35.next();
//        int int38 = timeSeriesDataItem34.compareTo((java.lang.Object) day35);
//        try {
//            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day35, (double) 100.0f, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
//        org.junit.Assert.assertNotNull(comparable25);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10-June-2019" + "'", str36.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("2020");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        java.lang.Comparable comparable25 = timeSeries7.getKey();
        boolean boolean27 = timeSeries7.equals((java.lang.Object) 9223372036854775807L);
        timeSeries7.removeAgedItems((long) 1, true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertNotNull(comparable25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        long long3 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560193199999L + "'", long3 == 1560193199999L);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj29 = null;
        int int30 = fixedMillisecond28.compareTo(obj29);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int34 = month33.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeriesDataItem36.getPeriod();
        java.lang.Object obj38 = timeSeriesDataItem36.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeriesDataItem36.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, regularTimePeriod39);
        long long41 = timeSeries7.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036854775807L + "'", long41 == 9223372036854775807L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = fixedMillisecond1.getSerialIndex();
        long long12 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond1.previous();
        java.util.Calendar calendar14 = null;
        fixedMillisecond1.peg(calendar14);
        java.util.Date date16 = fixedMillisecond1.getStart();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        int int9 = timeSeries7.getItemCount();
        timeSeries7.removeAgedItems(false);
        boolean boolean12 = timeSeries7.getNotify();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries7.getDataItem(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj3 = null;
        int int4 = fixedMillisecond2.compareTo(obj3);
        boolean boolean5 = day0.equals((java.lang.Object) int4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int10 = month9.getYearValue();
        boolean boolean12 = month9.equals((java.lang.Object) (short) 10);
        java.lang.String str13 = month9.toString();
        boolean boolean14 = day0.equals((java.lang.Object) str13);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "October 100" + "'", str13.equals("October 100"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
        long long2 = year1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61946438400001L) + "'", long2 == (-61946438400001L));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        java.lang.Object obj7 = null;
        int int8 = year6.compareTo(obj7);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getMonth();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) -1);
        long long2 = year1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        timeSeries7.clear();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int29 = month28.getYearValue();
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month28, "2020", "2020");
        java.util.Collection collection34 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = null;
        try {
            timeSeries7.update(regularTimePeriod35, (java.lang.Number) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 100 + "'", int29 == 100);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(collection34);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1));
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = seriesChangeEvent1.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent1.setSummary(seriesChangeInfo3);
        java.lang.String str5 = seriesChangeEvent1.toString();
        org.junit.Assert.assertNull(seriesChangeInfo2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=-1]" + "'", str5.equals("org.jfree.data.event.SeriesChangeEvent[source=-1]"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.previous();
        int int6 = year0.compareTo((java.lang.Object) regularTimePeriod5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        long long4 = month2.getSerialIndex();
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        boolean boolean5 = month2.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int9 = month8.getYearValue();
        java.util.Date date10 = month8.getEnd();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "2020", "2020");
        java.lang.String str14 = timeSeries13.getDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        int int21 = year15.compareTo((java.lang.Object) regularTimePeriod20);
        boolean boolean22 = timeSeries13.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int26 = month25.getYearValue();
        java.util.Date date27 = month25.getEnd();
        long long28 = month25.getSerialIndex();
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month25, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries13.addChangeListener(seriesChangeListener31);
        timeSeries13.removeAgedItems(false);
        timeSeries13.removeAgedItems(true);
        boolean boolean37 = month2.equals((java.lang.Object) timeSeries13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1210L + "'", long28 == 1210L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 10, seriesChangeInfo1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        java.lang.String str4 = seriesChangeEvent2.toString();
        java.lang.Object obj5 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo6);
        java.lang.Class<?> wildcardClass8 = seriesChangeEvent2.getClass();
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (byte) 10 + "'", obj3.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (byte) 10 + "'", obj5.equals((byte) 10));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj3 = null;
        int int4 = fixedMillisecond2.compareTo(obj3);
        boolean boolean5 = day0.equals((java.lang.Object) int4);
        int int6 = day0.getMonth();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj3 = null;
//        int int4 = fixedMillisecond2.compareTo(obj3);
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        long long7 = day0.getLastMillisecond();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int11 = month10.getYearValue();
//        java.util.Date date12 = month10.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
//        java.lang.String str16 = timeSeries15.getDescription();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month20.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month20.previous();
//        int int23 = year17.compareTo((java.lang.Object) regularTimePeriod22);
//        boolean boolean24 = timeSeries15.equals((java.lang.Object) regularTimePeriod22);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int28 = month27.getYearValue();
//        java.util.Date date29 = month27.getEnd();
//        long long30 = month27.getSerialIndex();
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 6L);
//        java.lang.Comparable comparable33 = timeSeries15.getKey();
//        int int34 = day0.compareTo((java.lang.Object) timeSeries15);
//        int int35 = day0.getYear();
//        java.lang.String str36 = day0.toString();
//        java.util.Calendar calendar37 = null;
//        try {
//            long long38 = day0.getLastMillisecond(calendar37);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1210L + "'", long30 == 1210L);
//        org.junit.Assert.assertNotNull(comparable33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10-June-2019" + "'", str36.equals("10-June-2019"));
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        java.util.Date date9 = month2.getEnd();
        org.jfree.data.time.Year year10 = month2.getYear();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year10.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.lang.String str34 = timeSeries7.getDomainDescription();
        java.lang.Object obj35 = timeSeries7.clone();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int39 = month38.getYearValue();
        java.util.Date date40 = month38.getEnd();
        boolean boolean42 = month38.equals((java.lang.Object) 'a');
        long long43 = month38.getLastMillisecond();
        int int44 = month38.getYearValue();
        long long45 = month38.getFirstMillisecond();
        java.util.Date date46 = month38.getStart();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month38, (double) (byte) 10, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2020" + "'", str34.equals("2020"));
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 100 + "'", int39 == 100);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-58985251200001L) + "'", long43 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 100 + "'", int44 == 100);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-58987929600000L) + "'", long45 == (-58987929600000L));
        org.junit.Assert.assertNotNull(date46);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date4, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        java.util.Date date9 = month2.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (-62150212800001L));
        int int12 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.util.Collection collection34 = timeSeries7.getTimePeriods();
        timeSeries7.setRangeDescription("org.jfree.data.general.SeriesException: 100");
        timeSeries7.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(collection34);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182755453L + "'", long2 == 1560182755453L);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        timeSeries7.removeAgedItems(6L, true);
        java.util.List list41 = timeSeries7.getItems();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = null;
        try {
            timeSeries7.add(regularTimePeriod42, (double) (-62104204800000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(list41);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        timeSeries7.clear();
        long long25 = timeSeries7.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        java.util.Date date11 = month7.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        java.util.TimeZone timeZone13 = null;
        java.util.Locale locale14 = null;
        try {
            org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date11, timeZone13, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        boolean boolean13 = timeSeries7.getNotify();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.previous();
        long long17 = year14.getMiddleMillisecond();
        long long18 = year14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.next();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) Double.NaN, false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = null;
        try {
            java.lang.Number number35 = timeSeries7.getValue(regularTimePeriod34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        java.util.Date date11 = month7.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(0, 5);
        int int17 = timeSeries13.getItemCount();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(4);
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) '4', year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries7.getDataItem((int) (short) 0);
        timeSeries7.removeAgedItems(9223372036854775807L, false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.lang.String str4 = month2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 10, seriesChangeInfo6);
        java.lang.Object obj8 = seriesChangeEvent7.getSource();
        java.lang.String str9 = seriesChangeEvent7.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo12);
        boolean boolean14 = month2.equals((java.lang.Object) seriesChangeInfo12);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int18 = month17.getYearValue();
        java.util.Date date19 = month17.getEnd();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "2020", "2020");
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int26 = month25.getYearValue();
        java.util.Date date27 = month25.getEnd();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month25, "2020", "2020");
        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
        java.lang.String str32 = timeSeries30.getDescription();
        org.jfree.data.time.Year year34 = org.jfree.data.time.Year.parseYear("100");
        int int35 = year34.getYear();
        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass42 = month41.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month41.previous();
        java.lang.Class<?> wildcardClass44 = regularTimePeriod43.getClass();
        boolean boolean45 = fixedMillisecond38.equals((java.lang.Object) regularTimePeriod43);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries30.getDataItem(regularTimePeriod43);
        timeSeries22.add(timeSeriesDataItem46);
        java.lang.String str48 = timeSeries22.getDomainDescription();
        boolean boolean49 = month2.equals((java.lang.Object) timeSeries22);
        java.util.Calendar calendar50 = null;
        try {
            long long51 = month2.getLastMillisecond(calendar50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "October 100" + "'", str4.equals("October 100"));
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + (byte) 10 + "'", obj8.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str9.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(class31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 100 + "'", int35 == 100);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "2020" + "'", str48.equals("2020"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.String str8 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
//        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
//        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int20 = month19.getYearValue();
//        java.util.Date date21 = month19.getEnd();
//        long long22 = month19.getSerialIndex();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries7.addChangeListener(seriesChangeListener25);
//        timeSeries7.removeAgedItems(false);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        int int31 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
//        java.lang.Class class32 = timeSeries7.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(class32);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        java.util.Date date9 = month2.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (-62150212800001L));
        boolean boolean12 = timeSeriesDataItem11.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem11.getPeriod();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
//        int int12 = year11.getYear();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
//        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
//        long long24 = timeSeries7.getMaximumItemAge();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
//        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        java.lang.String str37 = day34.toString();
//        boolean boolean38 = timeSeries7.equals((java.lang.Object) str37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj42 = null;
//        int int43 = fixedMillisecond41.compareTo(obj42);
//        boolean boolean44 = day39.equals((java.lang.Object) int43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day39.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day39.next();
//        long long47 = day39.getFirstMillisecond();
//        int int48 = day39.getMonth();
//        timeSeries7.update((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) (-1L));
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month51, (java.lang.Number) 0.0f);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560150000000L + "'", long47 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "org.jfree.data.time.TimePeriodFormatException: 100", "2019");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = year1.getStart();
        long long4 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        long long6 = year1.getFirstMillisecond();
        int int7 = year1.getYear();
        java.util.Calendar calendar8 = null;
        try {
            year1.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62104204800000L) + "'", long4 == (-62104204800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62104204800000L) + "'", long6 == (-62104204800000L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        java.lang.Number number7 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int15 = month14.getYearValue();
        java.util.Date date16 = month14.getEnd();
        boolean boolean18 = month14.equals((java.lang.Object) 'a');
        long long19 = month14.getLastMillisecond();
        int int20 = month14.getYearValue();
        java.util.Date date21 = month14.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (-62150212800001L));
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 1.0f, true);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "2019", "10-June-2019");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-58985251200001L) + "'", long19 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond1.next();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond1.getMiddleMillisecond(calendar12);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int4 = day0.compareTo((java.lang.Object) 8);
//        long long5 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        timeSeries7.clear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries7.addOrUpdate(timeSeriesDataItem25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        long long8 = month2.getLastMillisecond();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int12 = month11.getYearValue();
        java.util.Date date13 = month11.getEnd();
        boolean boolean15 = month11.equals((java.lang.Object) 'a');
        long long16 = month11.getLastMillisecond();
        int int17 = month11.getYearValue();
        long long18 = month11.getFirstMillisecond();
        long long19 = month11.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("100");
        boolean boolean22 = month11.equals((java.lang.Object) seriesException21);
        int int23 = month2.compareTo((java.lang.Object) boolean22);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int27 = month26.getYearValue();
        java.util.Date date28 = month26.getEnd();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month26, "2020", "2020");
        java.lang.Class class32 = timeSeries31.getTimePeriodClass();
        java.lang.String str33 = timeSeries31.getDescription();
        org.jfree.data.time.Year year35 = org.jfree.data.time.Year.parseYear("100");
        int int36 = year35.getYear();
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) year35, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass43 = month42.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month42.previous();
        java.lang.Class<?> wildcardClass45 = regularTimePeriod44.getClass();
        boolean boolean46 = fixedMillisecond39.equals((java.lang.Object) regularTimePeriod44);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries31.getDataItem(regularTimePeriod44);
        long long48 = timeSeries31.getMaximumItemAge();
        timeSeries31.setNotify(false);
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = month53.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = month53.next();
        timeSeries31.update(regularTimePeriod55, (java.lang.Number) 1560150000000L);
        java.util.Collection collection58 = timeSeries31.getTimePeriods();
        boolean boolean59 = timeSeries31.getNotify();
        boolean boolean60 = month2.equals((java.lang.Object) timeSeries31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-58985251200001L) + "'", long8 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-58985251200001L) + "'", long16 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-58987929600000L) + "'", long18 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-58987929600000L) + "'", long19 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 100 + "'", int27 == 100);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(class32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(year35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 100 + "'", int36 == 100);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 9223372036854775807L + "'", long48 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(collection58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int15 = month14.getYearValue();
        boolean boolean17 = month14.equals((java.lang.Object) (short) 10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month14, (double) (-58987929600000L), false);
        java.lang.Object obj21 = null;
        int int22 = month14.compareTo(obj21);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = month14.getFirstMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int4 = day0.compareTo((java.lang.Object) 8);
//        long long5 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int15 = month14.getYearValue();
        java.util.Date date16 = month14.getEnd();
        boolean boolean18 = month14.equals((java.lang.Object) 'a');
        long long19 = month14.getLastMillisecond();
        int int20 = month14.getYearValue();
        java.util.Date date21 = month14.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (-62150212800001L));
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 1.0f, true);
        timeSeries7.clear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-58985251200001L) + "'", long19 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.addChangeListener(seriesChangeListener10);
        timeSeries7.setNotify(true);
        int int14 = timeSeries7.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        timeSeries7.removeAgedItems(6L, true);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int45 = month44.getYearValue();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month44, "2020", "2020");
        java.lang.Class class50 = timeSeries49.getTimePeriodClass();
        java.lang.String str51 = timeSeries49.getDescription();
        org.jfree.data.time.Year year53 = org.jfree.data.time.Year.parseYear("100");
        int int54 = year53.getYear();
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass61 = month60.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month60.previous();
        java.lang.Class<?> wildcardClass63 = regularTimePeriod62.getClass();
        boolean boolean64 = fixedMillisecond57.equals((java.lang.Object) regularTimePeriod62);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries49.getDataItem(regularTimePeriod62);
        long long66 = timeSeries49.getMaximumItemAge();
        timeSeries49.setNotify(false);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = month71.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = month71.next();
        timeSeries49.update(regularTimePeriod73, (java.lang.Number) 1560150000000L);
        java.beans.PropertyChangeListener propertyChangeListener76 = null;
        timeSeries49.removePropertyChangeListener(propertyChangeListener76);
        boolean boolean78 = timeSeries49.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar81 = null;
        long long82 = fixedMillisecond80.getLastMillisecond(calendar81);
        long long83 = fixedMillisecond80.getSerialIndex();
        long long84 = fixedMillisecond80.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = timeSeries49.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond80);
        java.lang.Number number86 = timeSeriesDataItem85.getValue();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem87 = timeSeries7.addOrUpdate(timeSeriesDataItem85);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(class50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(year53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 100 + "'", int54 == 100);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 9223372036854775807L + "'", long66 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 10L + "'", long82 == 10L);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 10L + "'", long83 == 10L);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 10L + "'", long84 == 10L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem85);
        org.junit.Assert.assertTrue("'" + number86 + "' != '" + 1560150000000L + "'", number86.equals(1560150000000L));
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj3 = null;
//        int int4 = fixedMillisecond2.compareTo(obj3);
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        long long8 = day0.getSerialIndex();
//        long long9 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43626L + "'", long8 == 43626L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("100");
        int int2 = year1.getYear();
        java.lang.String str3 = year1.toString();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date3 = month2.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        java.util.Calendar calendar5 = null;
        try {
            month4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1969, 1969, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(12, 6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        java.util.List list24 = timeSeries7.getItems();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(list24);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        long long4 = month2.getFirstMillisecond();
        int int5 = month2.getMonth();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-58987929600000L) + "'", long4 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: 100");
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        timeSeries7.removeAgedItems((long) 4, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries7.addOrUpdate(regularTimePeriod30, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        boolean boolean5 = month2.equals((java.lang.Object) (short) 10);
        java.util.Date date6 = month2.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        timeSeries7.clear();
        timeSeries7.setDomainDescription("January 0");
        try {
            timeSeries7.update((int) ' ', (java.lang.Number) 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        timeSeries7.clear();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int29 = month28.getYearValue();
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month28, "2020", "2020");
        java.util.Collection collection34 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        java.lang.String str35 = timeSeries7.getDescription();
        int int36 = timeSeries7.getMaximumItemCount();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
        java.util.Date date40 = year38.getStart();
        long long41 = year38.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year38.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod42, (double) (-61946438400001L));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries7.addOrUpdate(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 100 + "'", int29 == 100);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2147483647 + "'", int36 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-62104204800000L) + "'", long41 == (-62104204800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj32 = null;
        int int33 = fixedMillisecond31.compareTo(obj32);
        boolean boolean34 = day29.equals((java.lang.Object) int33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day29.next();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (double) 1560236399999L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
//        int int12 = year11.getYear();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
//        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
//        long long24 = timeSeries7.getMaximumItemAge();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
//        timeSeries7.setMaximumItemAge(1560150000000L);
//        java.lang.String str30 = timeSeries7.getRangeDescription();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int34 = month33.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, 0.0d);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.lang.String str38 = day37.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day37.next();
//        int int40 = timeSeriesDataItem36.compareTo((java.lang.Object) day37);
//        try {
//            timeSeries7.add(timeSeriesDataItem36);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2020" + "'", str30.equals("2020"));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "10-June-2019" + "'", str38.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        boolean boolean6 = timeSeriesDataItem5.isSelected();
        java.lang.Number number7 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
        int int14 = year8.compareTo((java.lang.Object) regularTimePeriod13);
        boolean boolean15 = month2.equals((java.lang.Object) int14);
        java.util.Calendar calendar16 = null;
        try {
            month2.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        java.util.Date date11 = month7.getStart();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        java.util.TimeZone timeZone13 = null;
        try {
            org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date11, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        timeSeries7.removeAgedItems(6L, true);
        boolean boolean41 = timeSeries7.isEmpty();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int45 = month44.getYearValue();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month44, "2020", "2020");
        java.lang.String str50 = timeSeries49.getDescription();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = month54.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month54.previous();
        int int57 = year51.compareTo((java.lang.Object) regularTimePeriod56);
        boolean boolean58 = timeSeries49.equals((java.lang.Object) regularTimePeriod56);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int62 = month61.getYearValue();
        java.util.Date date63 = month61.getEnd();
        long long64 = month61.getSerialIndex();
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) month61, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener67 = null;
        timeSeries49.addChangeListener(seriesChangeListener67);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int72 = month71.getYearValue();
        java.util.Date date73 = month71.getEnd();
        boolean boolean75 = month71.equals((java.lang.Object) 'a');
        java.lang.String str76 = month71.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = month71.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries49.addOrUpdate(regularTimePeriod77, (java.lang.Number) 9);
        timeSeries49.removeAgedItems(6L, true);
        boolean boolean83 = timeSeries49.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries7.addAndOrUpdate(timeSeries49);
        boolean boolean85 = timeSeries7.isEmpty();
        long long86 = timeSeries7.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 100 + "'", int62 == 100);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1210L + "'", long64 == 1210L);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 100 + "'", int72 == 100);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "October 100" + "'", str76.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertNull(timeSeriesDataItem79);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(timeSeries84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 9223372036854775807L + "'", long86 == 9223372036854775807L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int15 = month14.getYearValue();
        boolean boolean17 = month14.equals((java.lang.Object) (short) 10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month14, (double) (-58987929600000L), false);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener21);
        java.lang.Comparable comparable23 = timeSeries7.getKey();
        boolean boolean24 = timeSeries7.isEmpty();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(comparable23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        java.util.Date date4 = year2.getStart();
        java.util.Date date5 = year2.getEnd();
        long long6 = year2.getFirstMillisecond();
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(0, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62104204800000L) + "'", long6 == (-62104204800000L));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(31, 0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.Year year5 = org.jfree.data.time.Year.parseYear("100");
        int int6 = month2.compareTo((java.lang.Object) "100");
        java.lang.String str7 = month2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January 0" + "'", str7.equals("January 0"));
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj3 = null;
//        int int4 = fixedMillisecond2.compareTo(obj3);
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        long long8 = day0.getFirstMillisecond();
//        long long9 = day0.getFirstMillisecond();
//        java.util.Calendar calendar10 = null;
//        try {
//            day0.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        timeSeries7.removeAgedItems(6L, true);
        java.util.List list41 = timeSeries7.getItems();
        try {
            timeSeries7.delete(11, 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(list41);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setRangeDescription("January 0");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeries7.getTimePeriod(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = month7.getMiddleMillisecond();
        long long12 = month7.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (double) 6L);
        java.lang.Number number15 = timeSeriesDataItem14.getValue();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-58986590400001L) + "'", long11 == (-58986590400001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-58985251200001L) + "'", long12 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 6.0d + "'", number15.equals(6.0d));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = month7.getMiddleMillisecond();
        long long12 = month7.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (double) 6L);
        timeSeriesDataItem14.setValue((java.lang.Number) 1560150000000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-58986590400001L) + "'", long11 == (-58986590400001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-58985251200001L) + "'", long12 == (-58985251200001L));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        boolean boolean5 = month2.equals((java.lang.Object) (short) 10);
        java.util.Date date6 = month2.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date6, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
        java.util.Date date30 = year28.getStart();
        long long31 = year28.getFirstMillisecond();
        try {
            timeSeries7.update((org.jfree.data.time.RegularTimePeriod) year28, (java.lang.Number) 6L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-62104204800000L) + "'", long31 == (-62104204800000L));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        int int15 = year9.compareTo((java.lang.Object) year12);
        long long16 = year12.getLastMillisecond();
        java.lang.Class<?> wildcardClass17 = year12.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener29);
        java.lang.String str31 = timeSeries7.getDescription();
        try {
            timeSeries7.setMaximumItemAge((-62133062400001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNull(str31);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.String str8 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
//        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
//        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int20 = month19.getYearValue();
//        java.util.Date date21 = month19.getEnd();
//        long long22 = month19.getSerialIndex();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries7.addChangeListener(seriesChangeListener25);
//        timeSeries7.removeAgedItems(false);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        int int31 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
//        java.lang.String str32 = day29.toString();
//        long long33 = day29.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
//        int int12 = year11.getYear();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
//        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
//        long long24 = timeSeries7.getMaximumItemAge();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
//        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        java.lang.String str37 = day34.toString();
//        boolean boolean38 = timeSeries7.equals((java.lang.Object) str37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj42 = null;
//        int int43 = fixedMillisecond41.compareTo(obj42);
//        boolean boolean44 = day39.equals((java.lang.Object) int43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day39.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day39.next();
//        long long47 = day39.getFirstMillisecond();
//        int int48 = day39.getMonth();
//        timeSeries7.update((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) (-1L));
//        timeSeries7.setMaximumItemCount((int) (byte) 100);
//        timeSeries7.setDescription("October 100");
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560150000000L + "'", long47 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj3 = null;
//        int int4 = fixedMillisecond2.compareTo(obj3);
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        long long7 = day0.getLastMillisecond();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj31 = null;
        int int32 = fixedMillisecond30.compareTo(obj31);
        boolean boolean33 = day28.equals((java.lang.Object) int32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.next();
        int int35 = day28.getYear();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day28);
        timeSeries7.setDomainDescription("2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getLastMillisecond(calendar41);
        long long43 = fixedMillisecond40.getSerialIndex();
        java.util.Date date44 = fixedMillisecond40.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = fixedMillisecond40.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long10 = fixedMillisecond9.getSerialIndex();
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond9.getMiddleMillisecond(calendar11);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass16 = month15.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month15.previous();
        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) month15);
        long long19 = fixedMillisecond9.getFirstMillisecond();
        long long20 = fixedMillisecond9.getLastMillisecond();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int24 = month23.getYearValue();
        java.util.Date date25 = month23.getEnd();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month23, "2020", "2020");
        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
        java.lang.String str30 = timeSeries28.getDescription();
        org.jfree.data.time.Year year32 = org.jfree.data.time.Year.parseYear("100");
        int int33 = year32.getYear();
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass40 = month39.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month39.previous();
        java.lang.Class<?> wildcardClass42 = regularTimePeriod41.getClass();
        boolean boolean43 = fixedMillisecond36.equals((java.lang.Object) regularTimePeriod41);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries28.getDataItem(regularTimePeriod41);
        long long45 = timeSeries28.getMaximumItemAge();
        timeSeries28.setNotify(false);
        java.lang.Object obj48 = timeSeries28.clone();
        int int49 = fixedMillisecond9.compareTo((java.lang.Object) timeSeries28);
        timeSeries7.setKey((java.lang.Comparable) int49);
        try {
            org.jfree.data.time.TimeSeries timeSeries53 = timeSeries7.createCopy(31, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(class29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 100 + "'", int33 == 100);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) -1);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-58985251200001L), seriesChangeInfo1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        int int15 = year9.compareTo((java.lang.Object) year12);
        long long16 = year12.getLastMillisecond();
        java.util.Calendar calendar17 = null;
        try {
            year12.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        timeSeries7.clear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int28 = month27.getYearValue();
        long long29 = month27.getFirstMillisecond();
        java.lang.Number number30 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date34 = month33.getStart();
        long long35 = month33.getSerialIndex();
        java.lang.String str36 = month33.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month33, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = timeSeries7.getTimePeriod((int) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries7.getDataItem(regularTimePeriod41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-58987929600000L) + "'", long29 == (-58987929600000L));
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "January 0" + "'", str36.equals("January 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int15 = month14.getYearValue();
        boolean boolean17 = month14.equals((java.lang.Object) (short) 10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month14, (double) (-58987929600000L), false);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener21);
        java.lang.Comparable comparable23 = timeSeries7.getKey();
        timeSeries7.setDescription("2");
        try {
            org.jfree.data.time.TimeSeries timeSeries28 = timeSeries7.createCopy(100, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(comparable23);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = fixedMillisecond1.getSerialIndex();
        long long12 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond1.getLastMillisecond(calendar13);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(10L);
        int int40 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        timeSeries7.setMaximumItemAge((long) (byte) 10);
        boolean boolean43 = timeSeries7.isEmpty();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        java.lang.Object obj7 = timeSeriesDataItem5.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem5.getPeriod();
        timeSeriesDataItem5.setSelected(true);
        java.lang.Object obj11 = null;
        int int12 = timeSeriesDataItem5.compareTo(obj11);
        java.lang.Object obj13 = null;
        int int14 = timeSeriesDataItem5.compareTo(obj13);
        java.lang.Number number15 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0.0d + "'", number15.equals(0.0d));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.Year year16 = org.jfree.data.time.Year.parseYear("100");
        int int17 = year16.getYear();
        int int18 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int22 = month21.getYearValue();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "2020", "2020");
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int31 = month30.getYearValue();
        java.util.Date date32 = month30.getEnd();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "2020", "2020");
        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
        java.lang.String str37 = timeSeries35.getDescription();
        timeSeries35.setRangeDescription("2020");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int43 = month42.getYearValue();
        boolean boolean45 = month42.equals((java.lang.Object) (short) 10);
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) month42, (double) (-58987929600000L), false);
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month42, (double) (byte) -1, true);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) 2019, false);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = month57.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = month57.next();
        long long60 = month57.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month57, (java.lang.Number) 1546329600000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month57.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = month57.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(class36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 100 + "'", int43 == 100);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1L + "'", long60 == 1L);
        org.junit.Assert.assertNull(timeSeriesDataItem62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNull(regularTimePeriod64);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.Year year16 = org.jfree.data.time.Year.parseYear("100");
        int int17 = year16.getYear();
        int int18 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int22 = month21.getYearValue();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "2020", "2020");
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int31 = month30.getYearValue();
        java.util.Date date32 = month30.getEnd();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "2020", "2020");
        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
        java.lang.String str37 = timeSeries35.getDescription();
        timeSeries35.setRangeDescription("2020");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int43 = month42.getYearValue();
        boolean boolean45 = month42.equals((java.lang.Object) (short) 10);
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) month42, (double) (-58987929600000L), false);
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month42, (double) (byte) -1, true);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) 2019, false);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo55 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent56 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) false, seriesChangeInfo55);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo57 = seriesChangeEvent56.getSummary();
        java.lang.Object obj58 = seriesChangeEvent56.getSource();
        java.lang.Object obj59 = seriesChangeEvent56.getSource();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(class36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 100 + "'", int43 == 100);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(seriesChangeInfo57);
        org.junit.Assert.assertTrue("'" + obj58 + "' != '" + false + "'", obj58.equals(false));
        org.junit.Assert.assertTrue("'" + obj59 + "' != '" + false + "'", obj59.equals(false));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        timeSeries7.setMaximumItemAge(1560150000000L);
        java.lang.String str30 = timeSeries7.getRangeDescription();
        timeSeries7.setMaximumItemAge((long) 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2020" + "'", str30.equals("2020"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        java.lang.Comparable comparable25 = timeSeries7.getKey();
        boolean boolean27 = timeSeries7.equals((java.lang.Object) 9223372036854775807L);
        try {
            timeSeries7.delete(6, 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertNotNull(comparable25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "2020");
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        java.lang.Object obj29 = timeSeries7.clone();
        timeSeries7.removeAgedItems(false);
        java.lang.String str32 = timeSeries7.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2020" + "'", str32.equals("2020"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("100");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("100");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str7 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 100" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: 100"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        java.util.Date date11 = month7.getStart();
        int int12 = month7.getMonth();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        java.lang.Comparable comparable25 = timeSeries7.getKey();
        boolean boolean27 = timeSeries7.equals((java.lang.Object) 9223372036854775807L);
        int int28 = timeSeries7.getItemCount();
        timeSeries7.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertNotNull(comparable25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = month7.getMiddleMillisecond();
        long long12 = month7.getLastMillisecond();
        long long13 = month7.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-58986590400001L) + "'", long11 == (-58986590400001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-58985251200001L) + "'", long12 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-58985251200001L) + "'", long13 == (-58985251200001L));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        java.lang.String str33 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int37 = month36.getYearValue();
        java.util.Date date38 = month36.getEnd();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month36, "2020", "2020");
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int45 = month44.getYearValue();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month44, "2020", "2020");
        java.lang.Class class50 = timeSeries49.getTimePeriodClass();
        java.lang.String str51 = timeSeries49.getDescription();
        org.jfree.data.time.Year year53 = org.jfree.data.time.Year.parseYear("100");
        int int54 = year53.getYear();
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass61 = month60.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month60.previous();
        java.lang.Class<?> wildcardClass63 = regularTimePeriod62.getClass();
        boolean boolean64 = fixedMillisecond57.equals((java.lang.Object) regularTimePeriod62);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries49.getDataItem(regularTimePeriod62);
        timeSeries41.add(timeSeriesDataItem65);
        java.lang.String str67 = timeSeries41.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries7.addAndOrUpdate(timeSeries41);
        java.lang.Number number70 = null;
        try {
            timeSeries7.update(7, number70);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2020" + "'", str33.equals("2020"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 100 + "'", int37 == 100);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(class50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(year53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 100 + "'", int54 == 100);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2020" + "'", str67.equals("2020"));
        org.junit.Assert.assertNotNull(timeSeries68);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        timeSeries7.setRangeDescription("2020");
//        int int12 = timeSeries7.getItemCount();
//        timeSeries7.setMaximumItemCount((int) (short) 1);
//        org.jfree.data.time.Year year16 = org.jfree.data.time.Year.parseYear("100");
//        int int17 = year16.getYear();
//        int int18 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries7.addChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj24 = null;
//        int int25 = fixedMillisecond23.compareTo(obj24);
//        boolean boolean26 = day21.equals((java.lang.Object) int25);
//        org.jfree.data.time.SerialDate serialDate27 = day21.getSerialDate();
//        long long28 = day21.getLastMillisecond();
//        int int29 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day21);
//        int int30 = day21.getYear();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.time.Year year25 = month19.getYear();
        java.util.Date date26 = month19.getStart();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month29, "2020", "2020");
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int38 = month37.getYearValue();
        java.util.Date date39 = month37.getEnd();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "2020", "2020");
        java.lang.Class class43 = timeSeries42.getTimePeriodClass();
        java.lang.String str44 = timeSeries42.getDescription();
        org.jfree.data.time.Year year46 = org.jfree.data.time.Year.parseYear("100");
        int int47 = year46.getYear();
        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) year46, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass54 = month53.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = month53.previous();
        java.lang.Class<?> wildcardClass56 = regularTimePeriod55.getClass();
        boolean boolean57 = fixedMillisecond50.equals((java.lang.Object) regularTimePeriod55);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries42.getDataItem(regularTimePeriod55);
        timeSeries34.add(timeSeriesDataItem58);
        timeSeries34.removeAgedItems(false);
        timeSeries34.setRangeDescription("October 100");
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) month66);
        int int68 = month19.compareTo((java.lang.Object) timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 100 + "'", int38 == 100);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(class43);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(year46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 100 + "'", int47 == 100);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem58);
        org.junit.Assert.assertNotNull(timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.lang.String str34 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int38 = month37.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month37, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeriesDataItem40.getPeriod();
        java.lang.Object obj42 = timeSeriesDataItem40.clone();
        try {
            timeSeries7.add(timeSeriesDataItem40);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2020" + "'", str34.equals("2020"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 100 + "'", int38 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        java.util.Date date11 = month7.getStart();
        java.util.TimeZone timeZone12 = null;
        java.util.Locale locale13 = null;
        try {
            org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date11, timeZone12, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        try {
            timeSeries7.update((-9999), (java.lang.Number) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
//        int int12 = year11.getYear();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
//        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
//        long long24 = timeSeries7.getMaximumItemAge();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
//        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        java.lang.String str37 = day34.toString();
//        boolean boolean38 = timeSeries7.equals((java.lang.Object) str37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj42 = null;
//        int int43 = fixedMillisecond41.compareTo(obj42);
//        boolean boolean44 = day39.equals((java.lang.Object) int43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day39.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day39.next();
//        long long47 = day39.getFirstMillisecond();
//        int int48 = day39.getMonth();
//        timeSeries7.update((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) (-1L));
//        timeSeries7.setMaximumItemCount((int) (byte) 100);
//        java.lang.Class class53 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int57 = month56.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month56, 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = timeSeriesDataItem59.getPeriod();
//        java.lang.Object obj61 = timeSeriesDataItem59.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = timeSeriesDataItem59.getPeriod();
//        timeSeriesDataItem59.setSelected(true);
//        java.lang.Number number65 = timeSeriesDataItem59.getValue();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries7.addOrUpdate(timeSeriesDataItem59);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560150000000L + "'", long47 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertNotNull(class53);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 100 + "'", int57 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 0.0d + "'", number65.equals(0.0d));
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(31, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        timeSeries7.setRangeDescription("2020");
//        int int12 = timeSeries7.getItemCount();
//        timeSeries7.setMaximumItemCount((int) (short) 1);
//        org.jfree.data.time.Year year16 = org.jfree.data.time.Year.parseYear("100");
//        int int17 = year16.getYear();
//        int int18 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries7.addChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj24 = null;
//        int int25 = fixedMillisecond23.compareTo(obj24);
//        boolean boolean26 = day21.equals((java.lang.Object) int25);
//        org.jfree.data.time.SerialDate serialDate27 = day21.getSerialDate();
//        long long28 = day21.getLastMillisecond();
//        int int29 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        long long32 = fixedMillisecond31.getFirstMillisecond();
//        long long33 = fixedMillisecond31.getSerialIndex();
//        int int34 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
//        java.util.List list35 = timeSeries7.getItems();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(list35);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        timeSeries7.setMaximumItemAge(1560150000000L);
        java.lang.String str30 = timeSeries7.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj33 = null;
        int int34 = fixedMillisecond32.compareTo(obj33);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass38 = month37.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month37.previous();
        int int40 = fixedMillisecond32.compareTo((java.lang.Object) month37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month37);
        timeSeriesDataItem41.setValue((java.lang.Number) 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2020" + "'", str30.equals("2020"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        int int6 = day0.getMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.addChangeListener(seriesChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long14 = fixedMillisecond13.getSerialIndex();
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond13.getMiddleMillisecond(calendar15);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass20 = month19.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month19.previous();
        boolean boolean22 = fixedMillisecond13.equals((java.lang.Object) month19);
        long long23 = fixedMillisecond13.getSerialIndex();
        long long24 = fixedMillisecond13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond13.previous();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) '#', false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = null;
        try {
            timeSeries7.add(timeSeriesDataItem29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getLastMillisecond();
        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) (byte) 0);
        long long6 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date7 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date7, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        long long7 = day6.getSerialIndex();
        int int8 = day6.getDayOfMonth();
        int int9 = day6.getYear();
        org.jfree.data.time.SerialDate serialDate10 = day6.getSerialDate();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("2019");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        timeSeries7.setMaximumItemAge(1560150000000L);
        java.lang.String str30 = timeSeries7.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj33 = null;
        int int34 = fixedMillisecond32.compareTo(obj33);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass38 = month37.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month37.previous();
        int int40 = fixedMillisecond32.compareTo((java.lang.Object) month37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month37);
        timeSeries7.removeAgedItems(false);
        try {
            timeSeries7.update((int) (byte) 100, (java.lang.Number) 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2020" + "'", str30.equals("2020"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        timeSeries7.clear();
        java.util.List list26 = timeSeries7.getItems();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries7.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertNotNull(list26);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        boolean boolean5 = month2.equals((java.lang.Object) (short) 10);
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.next();
        java.lang.String str8 = month2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 100" + "'", str6.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 100" + "'", str8.equals("October 100"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        int int9 = timeSeries7.getItemCount();
        timeSeries7.setDescription("October 100");
        int int12 = timeSeries7.getMaximumItemCount();
        timeSeries7.setMaximumItemCount((int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "", "org.jfree.data.general.SeriesException: 100");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        long long7 = day6.getSerialIndex();
        long long8 = day6.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-57600000L) + "'", long8 == (-57600000L));
        org.junit.Assert.assertNotNull(serialDate9);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
//        java.lang.Object obj7 = timeSeriesDataItem5.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem5.getPeriod();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj12 = null;
//        int int13 = fixedMillisecond11.compareTo(obj12);
//        boolean boolean14 = day9.equals((java.lang.Object) int13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day9.next();
//        int int16 = timeSeriesDataItem5.compareTo((java.lang.Object) day9);
//        long long17 = day9.getFirstMillisecond();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) long17, seriesChangeInfo18);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = seriesChangeEvent19.getSummary();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertNull(seriesChangeInfo20);
//    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.time.Year year25 = month19.getYear();
        java.lang.Object obj26 = null;
        int int27 = year25.compareTo(obj26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        long long9 = month2.getFirstMillisecond();
        java.util.Date date10 = month2.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month15.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month15.previous();
        int int18 = year12.compareTo((java.lang.Object) regularTimePeriod17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(8, year12);
        org.jfree.data.time.Year year20 = month19.getYear();
        int int21 = month2.compareTo((java.lang.Object) year20);
        long long22 = year20.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        java.lang.Object obj25 = timeSeriesDataItem23.clone();
        timeSeriesDataItem23.setSelected(false);
        boolean boolean28 = timeSeriesDataItem23.isSelected();
        timeSeriesDataItem23.setValue((java.lang.Number) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.lang.String str6 = year5.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year5.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        java.util.Date date9 = month2.getEnd();
        org.jfree.data.time.Year year10 = month2.getYear();
        long long11 = year10.getSerialIndex();
        int int12 = year10.getYear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        int int9 = timeSeries7.getItemCount();
        timeSeries7.removeAgedItems(false);
        boolean boolean12 = timeSeries7.isEmpty();
        timeSeries7.removeAgedItems((long) (short) 100, true);
        try {
            timeSeries7.update(8, (java.lang.Number) 25568L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        java.lang.String str33 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int37 = month36.getYearValue();
        java.util.Date date38 = month36.getEnd();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month36, "2020", "2020");
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int45 = month44.getYearValue();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month44, "2020", "2020");
        java.lang.Class class50 = timeSeries49.getTimePeriodClass();
        java.lang.String str51 = timeSeries49.getDescription();
        org.jfree.data.time.Year year53 = org.jfree.data.time.Year.parseYear("100");
        int int54 = year53.getYear();
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass61 = month60.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month60.previous();
        java.lang.Class<?> wildcardClass63 = regularTimePeriod62.getClass();
        boolean boolean64 = fixedMillisecond57.equals((java.lang.Object) regularTimePeriod62);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries49.getDataItem(regularTimePeriod62);
        timeSeries41.add(timeSeriesDataItem65);
        java.lang.String str67 = timeSeries41.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries7.addAndOrUpdate(timeSeries41);
        java.lang.Comparable comparable69 = timeSeries7.getKey();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(2);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year71);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2020" + "'", str33.equals("2020"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 100 + "'", int37 == 100);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(class50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(year53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 100 + "'", int54 == 100);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2020" + "'", str67.equals("2020"));
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertNotNull(comparable69);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        java.lang.Object obj15 = timeSeries7.clone();
        boolean boolean16 = timeSeries7.isEmpty();
        long long17 = timeSeries7.getMaximumItemAge();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int21 = month20.getYearValue();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20, "2020", "2020");
        java.lang.Class class26 = timeSeries25.getTimePeriodClass();
        java.util.Collection collection27 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(class26);
        org.junit.Assert.assertNotNull(collection27);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = year1.getStart();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.lang.String str2 = regularTimePeriod1.toString();
        java.util.Date date3 = regularTimePeriod1.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date3);
        try {
            java.lang.Number number6 = timeSeries4.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2020" + "'", str2.equals("2020"));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.util.Collection collection34 = timeSeries7.getTimePeriods();
        boolean boolean35 = timeSeries7.getNotify();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int39 = month38.getYearValue();
        java.util.Date date40 = month38.getEnd();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month38, "2020", "2020");
        java.lang.String str44 = timeSeries43.getDescription();
        int int45 = timeSeries43.getItemCount();
        timeSeries43.setDescription("October 100");
        int int48 = timeSeries43.getMaximumItemCount();
        timeSeries43.setDomainDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond52.next();
        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (double) '4', true);
        try {
            org.jfree.data.time.TimeSeries timeSeries57 = timeSeries7.addAndOrUpdate(timeSeries43);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 100 + "'", int39 == 100);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2147483647 + "'", int48 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Date date5 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.lang.String str2 = regularTimePeriod1.toString();
        java.util.Date date3 = regularTimePeriod1.getStart();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2020" + "'", str2.equals("2020"));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.setDescription("hi!");
        try {
            timeSeries7.delete(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (-1.0d));
        java.lang.Object obj10 = null;
        int int11 = month2.compareTo(obj10);
        int int12 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        timeSeries7.setMaximumItemAge(1560150000000L);
        java.lang.String str30 = timeSeries7.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj33 = null;
        int int34 = fixedMillisecond32.compareTo(obj33);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass38 = month37.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month37.previous();
        int int40 = fixedMillisecond32.compareTo((java.lang.Object) month37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month37);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date45 = month44.getStart();
        java.lang.String str46 = month44.toString();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month44, (double) 1562097599999L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2020" + "'", str30.equals("2020"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "January 0" + "'", str46.equals("January 0"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj2 = null;
        int int3 = fixedMillisecond1.compareTo(obj2);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass7 = month6.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.previous();
        int int9 = fixedMillisecond1.compareTo((java.lang.Object) month6);
        long long10 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj31 = null;
        int int32 = fixedMillisecond30.compareTo(obj31);
        boolean boolean33 = day28.equals((java.lang.Object) int32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.next();
        int int35 = day28.getYear();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day28);
        org.jfree.data.time.SerialDate serialDate37 = day28.getSerialDate();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertNotNull(serialDate37);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        timeSeries7.clear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int28 = month27.getYearValue();
        long long29 = month27.getFirstMillisecond();
        java.lang.Number number30 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries7.removeChangeListener(seriesChangeListener31);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-58987929600000L) + "'", long29 == (-58987929600000L));
        org.junit.Assert.assertNull(number30);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        timeSeries7.clear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int28 = month27.getYearValue();
        long long29 = month27.getFirstMillisecond();
        java.lang.Number number30 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date34 = month33.getStart();
        long long35 = month33.getSerialIndex();
        java.lang.String str36 = month33.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month33, (double) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries7.addOrUpdate(regularTimePeriod39, (java.lang.Number) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-58987929600000L) + "'", long29 == (-58987929600000L));
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "January 0" + "'", str36.equals("January 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        java.util.Date date5 = month2.getStart();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.addChangeListener(seriesChangeListener10);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int15 = month14.getYearValue();
        java.util.Date date16 = month14.getEnd();
        boolean boolean18 = month14.equals((java.lang.Object) 'a');
        long long19 = month14.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (-1.0d));
        boolean boolean22 = timeSeries7.equals((java.lang.Object) (-1.0d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-58985251200001L) + "'", long19 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        long long8 = month2.getLastMillisecond();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int12 = month11.getYearValue();
        java.util.Date date13 = month11.getEnd();
        boolean boolean15 = month11.equals((java.lang.Object) 'a');
        long long16 = month11.getLastMillisecond();
        int int17 = month11.getYearValue();
        long long18 = month11.getFirstMillisecond();
        long long19 = month11.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("100");
        boolean boolean22 = month11.equals((java.lang.Object) seriesException21);
        int int23 = month2.compareTo((java.lang.Object) boolean22);
        java.lang.String str24 = month2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-58985251200001L) + "'", long8 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-58985251200001L) + "'", long16 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-58987929600000L) + "'", long18 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-58987929600000L) + "'", long19 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 100" + "'", str24.equals("October 100"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        java.lang.String str4 = month2.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "January 0" + "'", str4.equals("January 0"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener34);
        boolean boolean36 = timeSeries7.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
        long long41 = fixedMillisecond38.getSerialIndex();
        long long42 = fixedMillisecond38.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        long long44 = fixedMillisecond38.getLastMillisecond();
        java.lang.Object obj45 = null;
        boolean boolean46 = fixedMillisecond38.equals(obj45);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int15 = month14.getYearValue();
        java.util.Date date16 = month14.getEnd();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14, "2020", "2020");
        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
        java.lang.String str21 = timeSeries19.getDescription();
        timeSeries19.setRangeDescription("2020");
        int int24 = timeSeries19.getItemCount();
        timeSeries19.setMaximumItemCount((int) (short) 1);
        int int27 = fixedMillisecond1.compareTo((java.lang.Object) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(class20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 10, seriesChangeInfo1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        java.lang.String str4 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo5);
        java.lang.String str7 = seriesChangeEvent2.toString();
        java.lang.String str8 = seriesChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (byte) 10 + "'", obj3.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str7.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str8.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.Year year16 = org.jfree.data.time.Year.parseYear("100");
        int int17 = year16.getYear();
        int int18 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int22 = month21.getYearValue();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "2020", "2020");
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int31 = month30.getYearValue();
        java.util.Date date32 = month30.getEnd();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "2020", "2020");
        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
        java.lang.String str37 = timeSeries35.getDescription();
        timeSeries35.setRangeDescription("2020");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int43 = month42.getYearValue();
        boolean boolean45 = month42.equals((java.lang.Object) (short) 10);
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) month42, (double) (-58987929600000L), false);
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month42, (double) (byte) -1, true);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) 2019, false);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = month57.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = month57.next();
        long long60 = month57.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month57, (java.lang.Number) 1546329600000L);
        double double63 = timeSeries7.getMinY();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(class36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 100 + "'", int43 == 100);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1L + "'", long60 == 1L);
        org.junit.Assert.assertNull(timeSeriesDataItem62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 2019.0d + "'", double63 == 2019.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        java.lang.Class class27 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
        java.lang.String str30 = regularTimePeriod29.toString();
        java.util.Date date31 = regularTimePeriod29.getStart();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date31, timeZone32);
        java.util.TimeZone timeZone34 = null;
        java.util.Locale locale35 = null;
        try {
            org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date31, timeZone34, locale35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2020" + "'", str30.equals("2020"));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod33);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj2 = null;
        int int3 = fixedMillisecond1.compareTo(obj2);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass7 = month6.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.previous();
        int int9 = fixedMillisecond1.compareTo((java.lang.Object) month6);
        long long10 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int9 = month8.getYearValue();
        java.util.Date date10 = month8.getEnd();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "2020", "2020");
        java.lang.String str14 = timeSeries13.getDescription();
        int int15 = timeSeries13.getItemCount();
        timeSeries13.setDescription("October 100");
        int int18 = timeSeries13.getMaximumItemCount();
        timeSeries13.setDomainDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.next();
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) '4', true);
        int int27 = month2.compareTo((java.lang.Object) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        long long3 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj3 = null;
        int int4 = fixedMillisecond2.compareTo(obj3);
        boolean boolean5 = day0.equals((java.lang.Object) int4);
        java.util.Date date6 = day0.getEnd();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
        int int14 = year8.compareTo((java.lang.Object) regularTimePeriod13);
        boolean boolean15 = month2.equals((java.lang.Object) int14);
        int int16 = month2.getMonth();
        long long17 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-58987929600000L) + "'", long17 == (-58987929600000L));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int15 = month14.getYearValue();
        java.util.Date date16 = month14.getEnd();
        boolean boolean18 = month14.equals((java.lang.Object) 'a');
        long long19 = month14.getLastMillisecond();
        int int20 = month14.getYearValue();
        java.util.Date date21 = month14.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (-62150212800001L));
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 1.0f, true);
        timeSeries7.setDescription("org.jfree.data.general.SeriesException: 100");
        timeSeries7.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-58985251200001L) + "'", long19 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        boolean boolean9 = month2.equals((java.lang.Object) 100.0d);
        java.util.Calendar calendar10 = null;
        try {
            month2.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date4, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        timeSeries7.removeAgedItems(6L, true);
        boolean boolean41 = timeSeries7.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long44 = fixedMillisecond43.getFirstMillisecond();
        int int45 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        java.util.Date date46 = fixedMillisecond43.getStart();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(date46);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener29);
        java.lang.String str31 = timeSeries7.getDescription();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.String str35 = month34.toString();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "October 100" + "'", str35.equals("October 100"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-58986590400001L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        java.util.Date date6 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date6, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-58986590400001L) + "'", long4 == (-58986590400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        boolean boolean13 = timeSeries7.getNotify();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        java.util.Date date17 = year15.getStart();
        long long18 = year15.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year15.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod19, (double) (-61946438400001L));
        timeSeries7.add(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62104204800000L) + "'", long18 == (-62104204800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        timeSeries7.clear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int28 = month27.getYearValue();
        long long29 = month27.getFirstMillisecond();
        java.lang.Number number30 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date34 = month33.getStart();
        long long35 = month33.getSerialIndex();
        java.lang.String str36 = month33.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month33, (double) 1);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries7.getDataItem(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-58987929600000L) + "'", long29 == (-58987929600000L));
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "January 0" + "'", str36.equals("January 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 10L);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month19, "2020", "2020");
        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
        java.lang.String str26 = timeSeries24.getDescription();
        org.jfree.data.time.Year year28 = org.jfree.data.time.Year.parseYear("100");
        int int29 = year28.getYear();
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) year28, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass36 = month35.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month35.previous();
        java.lang.Class<?> wildcardClass38 = regularTimePeriod37.getClass();
        boolean boolean39 = fixedMillisecond32.equals((java.lang.Object) regularTimePeriod37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries24.getDataItem(regularTimePeriod37);
        long long41 = timeSeries24.getMaximumItemAge();
        timeSeries24.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeries24.getNextTimePeriod();
        int int45 = year13.compareTo((java.lang.Object) regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(class25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 100 + "'", int29 == 100);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036854775807L + "'", long41 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-99) + "'", int45 == (-99));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 10L);
        long long17 = year13.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62104204800000L) + "'", long17 == (-62104204800000L));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int15 = month14.getYearValue();
        boolean boolean17 = month14.equals((java.lang.Object) (short) 10);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.previous();
        java.util.Date date11 = month9.getStart();
        int int12 = month9.getMonth();
        int int13 = year6.compareTo((java.lang.Object) month9);
        java.util.Calendar calendar14 = null;
        try {
            year6.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        long long6 = fixedMillisecond1.getFirstMillisecond();
        long long7 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        long long6 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
        long long2 = year1.getSerialIndex();
        long long3 = year1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61946438400001L) + "'", long3 == (-61946438400001L));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        timeSeries7.removeAgedItems(6L, true);
        boolean boolean41 = timeSeries7.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long44 = fixedMillisecond43.getFirstMillisecond();
        int int45 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        long long46 = fixedMillisecond43.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 10L + "'", long46 == 10L);
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        timeSeries7.setRangeDescription("2020");
//        int int12 = timeSeries7.getItemCount();
//        org.jfree.data.time.Year year14 = org.jfree.data.time.Year.parseYear("100");
//        boolean boolean15 = timeSeries7.equals((java.lang.Object) "100");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries7.addChangeListener(seriesChangeListener16);
//        timeSeries7.removeAgedItems((long) ' ', true);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj24 = null;
//        int int25 = fixedMillisecond23.compareTo(obj24);
//        boolean boolean26 = day21.equals((java.lang.Object) int25);
//        org.jfree.data.time.SerialDate serialDate27 = day21.getSerialDate();
//        long long28 = day21.getLastMillisecond();
//        java.lang.Number number29 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) day21);
//        long long30 = day21.getLastMillisecond();
//        java.util.Calendar calendar31 = null;
//        try {
//            long long32 = day21.getLastMillisecond(calendar31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560236399999L + "'", long30 == 1560236399999L);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.Year year16 = org.jfree.data.time.Year.parseYear("100");
        int int17 = year16.getYear();
        int int18 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int22 = month21.getYearValue();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "2020", "2020");
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int31 = month30.getYearValue();
        java.util.Date date32 = month30.getEnd();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "2020", "2020");
        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
        java.lang.String str37 = timeSeries35.getDescription();
        timeSeries35.setRangeDescription("2020");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int43 = month42.getYearValue();
        boolean boolean45 = month42.equals((java.lang.Object) (short) 10);
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) month42, (double) (-58987929600000L), false);
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month42, (double) (byte) -1, true);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) 2019, false);
        long long55 = month42.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(class36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 100 + "'", int43 == 100);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1210L + "'", long55 == 1210L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener34);
        boolean boolean36 = timeSeries7.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
        long long41 = fixedMillisecond38.getSerialIndex();
        long long42 = fixedMillisecond38.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        java.lang.Object obj44 = timeSeriesDataItem43.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(obj44);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        timeSeries7.removeAgedItems(false);
        timeSeries7.removeAgedItems(true);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener31);
        try {
            timeSeries7.update((int) (byte) -1, (java.lang.Number) 6.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
//        int int12 = year11.getYear();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
//        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
//        long long24 = timeSeries7.getMaximumItemAge();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
//        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        java.lang.String str37 = day34.toString();
//        boolean boolean38 = timeSeries7.equals((java.lang.Object) str37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj42 = null;
//        int int43 = fixedMillisecond41.compareTo(obj42);
//        boolean boolean44 = day39.equals((java.lang.Object) int43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day39.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day39.next();
//        long long47 = day39.getFirstMillisecond();
//        int int48 = day39.getMonth();
//        timeSeries7.update((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) (-1L));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = null;
//        try {
//            timeSeries7.add(regularTimePeriod51, (double) 8, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560150000000L + "'", long47 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
//        java.lang.Object obj7 = timeSeriesDataItem5.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem5.getPeriod();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj12 = null;
//        int int13 = fixedMillisecond11.compareTo(obj12);
//        boolean boolean14 = day9.equals((java.lang.Object) int13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day9.next();
//        int int16 = timeSeriesDataItem5.compareTo((java.lang.Object) day9);
//        long long17 = day9.getFirstMillisecond();
//        java.lang.String str18 = day9.toString();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getLastMillisecond();
        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) (byte) 0);
        long long6 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        java.util.Date date4 = month2.getStart();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        long long9 = month2.getFirstMillisecond();
        java.util.Date date10 = month2.getStart();
        long long11 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-58987929600000L) + "'", long11 == (-58987929600000L));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
        long long2 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-59011603200000L) + "'", long2 == (-59011603200000L));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.String str3 = month2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "October 100" + "'", str3.equals("October 100"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        java.util.Date date11 = month7.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        long long13 = fixedMillisecond12.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-58987929600000L) + "'", long13 == (-58987929600000L));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        timeSeries7.clear();
        double double25 = timeSeries7.getMaxY();
        timeSeries7.setMaximumItemAge((long) 5);
        java.util.Collection collection28 = timeSeries7.getTimePeriods();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection28);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = fixedMillisecond1.getSerialIndex();
        long long12 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond1.previous();
        java.util.Calendar calendar14 = null;
        fixedMillisecond1.peg(calendar14);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int19 = month18.getYearValue();
        java.util.Date date20 = month18.getEnd();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month18, "2020", "2020");
        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
        java.lang.String str25 = timeSeries23.getDescription();
        timeSeries23.setRangeDescription("2020");
        int int28 = timeSeries23.getItemCount();
        timeSeries23.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.Year year32 = org.jfree.data.time.Year.parseYear("100");
        int int33 = year32.getYear();
        int int34 = timeSeries23.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int38 = month37.getYearValue();
        java.util.Date date39 = month37.getEnd();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "2020", "2020");
        java.lang.Class class43 = timeSeries42.getTimePeriodClass();
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int47 = month46.getYearValue();
        java.util.Date date48 = month46.getEnd();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month46, "2020", "2020");
        java.lang.Class class52 = timeSeries51.getTimePeriodClass();
        java.lang.String str53 = timeSeries51.getDescription();
        timeSeries51.setRangeDescription("2020");
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int59 = month58.getYearValue();
        boolean boolean61 = month58.equals((java.lang.Object) (short) 10);
        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) month58, (double) (-58987929600000L), false);
        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) month58, (double) (byte) -1, true);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month58, (java.lang.Number) 2019, false);
        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = month73.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = month73.next();
        long long76 = month73.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month73, (java.lang.Number) 1546329600000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = month73.previous();
        int int80 = fixedMillisecond1.compareTo((java.lang.Object) month73);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(class24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 100 + "'", int33 == 100);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 100 + "'", int38 == 100);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(class43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 100 + "'", int47 == 100);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNull(class52);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 100 + "'", int59 == 100);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1L + "'", long76 == 1L);
        org.junit.Assert.assertNull(timeSeriesDataItem78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) 4);
        boolean boolean10 = timeSeriesDataItem9.isSelected();
        boolean boolean11 = timeSeriesDataItem9.isSelected();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        timeSeries7.removeAgedItems(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries7.addChangeListener(seriesChangeListener29);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener10);
        java.lang.Comparable comparable12 = timeSeries7.getKey();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(comparable12);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.util.Collection collection34 = timeSeries7.getTimePeriods();
        timeSeries7.setRangeDescription("org.jfree.data.general.SeriesException: 100");
        timeSeries7.setMaximumItemCount(1);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date42 = month41.getStart();
        java.lang.String str43 = month41.toString();
        int int44 = month41.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month41.previous();
        int int46 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month41);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "January 0" + "'", str43.equals("January 0"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        long long38 = regularTimePeriod35.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-58983955200001L) + "'", long38 == (-58983955200001L));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        long long4 = month2.getFirstMillisecond();
        int int5 = month2.getMonth();
        java.lang.Object obj6 = null;
        int int7 = month2.compareTo(obj6);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-58987929600000L) + "'", long4 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
//        int int12 = year11.getYear();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
//        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
//        long long24 = timeSeries7.getMaximumItemAge();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
//        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        java.lang.String str37 = day34.toString();
//        boolean boolean38 = timeSeries7.equals((java.lang.Object) str37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj41 = null;
//        int int42 = fixedMillisecond40.compareTo(obj41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        long long45 = fixedMillisecond44.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        long long49 = fixedMillisecond48.getSerialIndex();
//        java.util.Calendar calendar50 = null;
//        long long51 = fixedMillisecond48.getMiddleMillisecond(calendar50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = fixedMillisecond48.previous();
//        java.util.Calendar calendar53 = null;
//        long long54 = fixedMillisecond48.getMiddleMillisecond(calendar53);
//        try {
//            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) (byte) 0, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 10L + "'", long49 == 10L);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 10L + "'", long51 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 10L + "'", long54 == 10L);
//    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj3 = null;
//        int int4 = fixedMillisecond2.compareTo(obj3);
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        long long7 = day0.getLastMillisecond();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int11 = month10.getYearValue();
//        java.util.Date date12 = month10.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
//        java.lang.String str16 = timeSeries15.getDescription();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month20.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month20.previous();
//        int int23 = year17.compareTo((java.lang.Object) regularTimePeriod22);
//        boolean boolean24 = timeSeries15.equals((java.lang.Object) regularTimePeriod22);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int28 = month27.getYearValue();
//        java.util.Date date29 = month27.getEnd();
//        long long30 = month27.getSerialIndex();
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 6L);
//        java.lang.Comparable comparable33 = timeSeries15.getKey();
//        int int34 = day0.compareTo((java.lang.Object) timeSeries15);
//        int int35 = day0.getDayOfMonth();
//        java.util.Calendar calendar36 = null;
//        try {
//            day0.peg(calendar36);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1210L + "'", long30 == 1210L);
//        org.junit.Assert.assertNotNull(comparable33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.lang.String str2 = regularTimePeriod1.toString();
        java.util.Date date3 = regularTimePeriod1.getStart();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date3);
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date3, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2020" + "'", str2.equals("2020"));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        java.util.Date date11 = month7.getStart();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        java.util.TimeZone timeZone13 = null;
        java.util.Locale locale14 = null;
        try {
            org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date11, timeZone13, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) 4);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 4);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        java.lang.Object obj25 = timeSeriesDataItem23.clone();
        timeSeriesDataItem23.setSelected(false);
        boolean boolean28 = timeSeriesDataItem23.isSelected();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year29.previous();
        long long32 = year29.getMiddleMillisecond();
        long long33 = year29.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year29.next();
        boolean boolean35 = timeSeriesDataItem23.equals((java.lang.Object) year29);
        java.lang.Object obj36 = timeSeriesDataItem23.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1562097599999L + "'", long32 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(obj36);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.String str8 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
//        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
//        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int20 = month19.getYearValue();
//        java.util.Date date21 = month19.getEnd();
//        long long22 = month19.getSerialIndex();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries7.addChangeListener(seriesChangeListener25);
//        timeSeries7.removeAgedItems(false);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        int int31 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.next();
//        long long34 = day32.getFirstMillisecond();
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month37.next();
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) day32, (org.jfree.data.time.RegularTimePeriod) month37);
//        boolean boolean40 = timeSeries7.isEmpty();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560150000000L + "'", long34 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.previous();
        int int7 = year1.compareTo((java.lang.Object) regularTimePeriod6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(8, year1);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month8.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        long long5 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        java.util.Date date11 = month7.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11);
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy(0, 5);
        timeSeries16.setMaximumItemCount((int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeSeries16);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        long long7 = day6.getSerialIndex();
        int int8 = day6.getDayOfMonth();
        int int9 = day6.getYear();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day6.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int14 = month13.getYearValue();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "2020", "2020");
        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
        java.lang.String str20 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("2020");
        int int23 = timeSeries18.getItemCount();
        timeSeries18.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.Year year27 = org.jfree.data.time.Year.parseYear("100");
        int int28 = year27.getYear();
        int int29 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year27);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int33 = month32.getYearValue();
        java.util.Date date34 = month32.getEnd();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month32, "2020", "2020");
        java.lang.Class class38 = timeSeries37.getTimePeriodClass();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int42 = month41.getYearValue();
        java.util.Date date43 = month41.getEnd();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month41, "2020", "2020");
        java.lang.Class class47 = timeSeries46.getTimePeriodClass();
        java.lang.String str48 = timeSeries46.getDescription();
        timeSeries46.setRangeDescription("2020");
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int54 = month53.getYearValue();
        boolean boolean56 = month53.equals((java.lang.Object) (short) 10);
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) month53, (double) (-58987929600000L), false);
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) month53, (double) (byte) -1, true);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month53, (java.lang.Number) 2019, false);
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = month68.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = month68.next();
        long long71 = month68.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month68, (java.lang.Number) 1546329600000L);
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timeSeries18.removePropertyChangeListener(propertyChangeListener74);
        boolean boolean76 = month7.equals((java.lang.Object) propertyChangeListener74);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 100 + "'", int33 == 100);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(class38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(class47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 100 + "'", int54 == 100);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1L + "'", long71 == 1L);
        org.junit.Assert.assertNull(timeSeriesDataItem73);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182778967L + "'", long2 == 1560182778967L);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener34);
        boolean boolean36 = timeSeries7.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
        long long41 = fixedMillisecond38.getSerialIndex();
        long long42 = fixedMillisecond38.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj46 = null;
        int int47 = fixedMillisecond45.compareTo(obj46);
        int int48 = timeSeriesDataItem43.compareTo((java.lang.Object) int47);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        java.util.Calendar calendar9 = null;
        try {
            month2.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        timeSeries7.removeAgedItems(false);
        timeSeries7.removeAgedItems(true);
        java.lang.String str31 = timeSeries7.getRangeDescription();
        timeSeries7.setMaximumItemCount(2);
        timeSeries7.setDomainDescription("");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2020" + "'", str31.equals("2020"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        timeSeries7.removeAgedItems(6L, true);
        timeSeries7.setDescription("org.jfree.data.general.SeriesException: 100");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2147483647, 100, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        long long9 = month2.getFirstMillisecond();
        long long10 = month2.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("100");
        boolean boolean13 = month2.equals((java.lang.Object) seriesException12);
        java.lang.String str14 = month2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-58987929600000L) + "'", long10 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "October 100" + "'", str14.equals("October 100"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        long long2 = year1.getFirstMillisecond();
        java.lang.String str3 = year1.toString();
        long long4 = year1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62104204800000L) + "'", long2 == (-62104204800000L));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2" + "'", str3.equals("2"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2L + "'", long4 == 2L);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date3 = month2.getStart();
        java.lang.String str4 = month2.toString();
        int int5 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "January 0" + "'", str4.equals("January 0"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        org.jfree.data.time.Year year14 = org.jfree.data.time.Year.parseYear("100");
        boolean boolean15 = timeSeries7.equals((java.lang.Object) "100");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (byte) 100);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int21 = month20.getYearValue();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20, "2020", "2020");
        long long26 = month20.getLastMillisecond();
        int int27 = year17.compareTo((java.lang.Object) month20);
        int int28 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int32 = month31.getYearValue();
        java.util.Date date33 = month31.getEnd();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month31, "2020", "2020");
        java.lang.Class class37 = timeSeries36.getTimePeriodClass();
        java.lang.String str38 = timeSeries36.getDescription();
        org.jfree.data.time.Year year40 = org.jfree.data.time.Year.parseYear("100");
        int int41 = year40.getYear();
        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) (-1));
        try {
            timeSeries7.update((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-58985251200001L) + "'", long26 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(class37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(year40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 100 + "'", int41 == 100);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.previous();
        int int7 = year1.compareTo((java.lang.Object) regularTimePeriod6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(8, year1);
        java.util.Calendar calendar9 = null;
        try {
            year1.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
//        java.lang.Object obj7 = timeSeriesDataItem5.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem5.getPeriod();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj12 = null;
//        int int13 = fixedMillisecond11.compareTo(obj12);
//        boolean boolean14 = day9.equals((java.lang.Object) int13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day9.next();
//        int int16 = timeSeriesDataItem5.compareTo((java.lang.Object) day9);
//        long long17 = day9.getFirstMillisecond();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) long17, seriesChangeInfo18);
//        java.lang.Object obj20 = seriesChangeEvent19.getSource();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + obj20 + "' != '" + 1560150000000L + "'", obj20.equals(1560150000000L));
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.setDescription("hi!");
        double double11 = timeSeries7.getMaxY();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.previous();
        int int7 = year1.compareTo((java.lang.Object) regularTimePeriod6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(8, year1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 8, seriesChangeInfo9);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
//        int int12 = year11.getYear();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
//        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
//        long long24 = timeSeries7.getMaximumItemAge();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
//        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
//        java.util.Collection collection34 = timeSeries7.getTimePeriods();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj38 = null;
//        int int39 = fixedMillisecond37.compareTo(obj38);
//        boolean boolean40 = day35.equals((java.lang.Object) int39);
//        int int41 = day35.getDayOfMonth();
//        java.lang.String str42 = day35.toString();
//        int int43 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, 0.0d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(collection34);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "10-June-2019" + "'", str42.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int15 = month14.getYearValue();
        long long16 = month14.getFirstMillisecond();
        int int17 = month14.getMonth();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month14, (double) 4, false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-58987929600000L) + "'", long16 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        int int9 = timeSeries7.getItemCount();
        timeSeries7.setDescription("October 100");
        int int12 = timeSeries7.getMaximumItemCount();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year15);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year15, "2019", "100");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int15 = month14.getYearValue();
        java.util.Date date16 = month14.getEnd();
        boolean boolean18 = month14.equals((java.lang.Object) 'a');
        long long19 = month14.getLastMillisecond();
        int int20 = month14.getYearValue();
        java.util.Date date21 = month14.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (-62150212800001L));
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 1.0f, true);
        timeSeries7.setDescription("org.jfree.data.general.SeriesException: 100");
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond30.next();
        java.util.Date date32 = fixedMillisecond30.getStart();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 9999);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-58985251200001L) + "'", long19 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date5);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, 12);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "100", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
//        int int12 = year11.getYear();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
//        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
//        long long24 = timeSeries7.getMaximumItemAge();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
//        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        java.lang.String str37 = day34.toString();
//        boolean boolean38 = timeSeries7.equals((java.lang.Object) str37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj42 = null;
//        int int43 = fixedMillisecond41.compareTo(obj42);
//        boolean boolean44 = day39.equals((java.lang.Object) int43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day39.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day39.next();
//        long long47 = day39.getFirstMillisecond();
//        int int48 = day39.getMonth();
//        timeSeries7.update((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) (-1L));
//        timeSeries7.removeAgedItems(true);
//        java.util.Collection collection53 = timeSeries7.getTimePeriods();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560150000000L + "'", long47 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertNotNull(collection53);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        java.lang.Number number25 = timeSeriesDataItem23.getValue();
        timeSeriesDataItem23.setSelected(true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-1) + "'", number25.equals((-1)));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long11 = fixedMillisecond10.getFirstMillisecond();
        long long12 = fixedMillisecond10.getSerialIndex();
        long long13 = fixedMillisecond10.getFirstMillisecond();
        long long14 = fixedMillisecond10.getFirstMillisecond();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) (-1), true);
        long long18 = fixedMillisecond10.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        java.util.Date date11 = month7.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date11);
        java.util.TimeZone timeZone15 = null;
        java.util.Locale locale16 = null;
        try {
            org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date11, timeZone15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        long long8 = month2.getLastMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month2.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-58985251200001L) + "'", long8 == (-58985251200001L));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        timeSeries7.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries7.getDataItem(regularTimePeriod14);
        boolean boolean16 = timeSeries7.getNotify();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        timeSeries7.removeAgedItems(false);
        timeSeries7.removeAgedItems(true);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener31);
        java.lang.Number number34 = timeSeries7.getValue(0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 6L + "'", number34.equals(6L));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.Year year16 = org.jfree.data.time.Year.parseYear("100");
        int int17 = year16.getYear();
        int int18 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int22 = month21.getYearValue();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "2020", "2020");
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int31 = month30.getYearValue();
        java.util.Date date32 = month30.getEnd();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "2020", "2020");
        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
        java.lang.String str37 = timeSeries35.getDescription();
        timeSeries35.setRangeDescription("2020");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int43 = month42.getYearValue();
        boolean boolean45 = month42.equals((java.lang.Object) (short) 10);
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) month42, (double) (-58987929600000L), false);
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month42, (double) (byte) -1, true);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) 2019, false);
        timeSeries7.removeAgedItems((-61946438400001L), true);
        int int58 = timeSeries7.getItemCount();
        java.lang.Number number60 = timeSeries7.getValue(0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(class36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 100 + "'", int43 == 100);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + 2019 + "'", number60.equals(2019));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January 0" + "'", str3.equals("January 0"));
        org.junit.Assert.assertNull(regularTimePeriod4);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        java.lang.String str33 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int37 = month36.getYearValue();
        java.util.Date date38 = month36.getEnd();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month36, "2020", "2020");
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int45 = month44.getYearValue();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month44, "2020", "2020");
        java.lang.Class class50 = timeSeries49.getTimePeriodClass();
        java.lang.String str51 = timeSeries49.getDescription();
        org.jfree.data.time.Year year53 = org.jfree.data.time.Year.parseYear("100");
        int int54 = year53.getYear();
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass61 = month60.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month60.previous();
        java.lang.Class<?> wildcardClass63 = regularTimePeriod62.getClass();
        boolean boolean64 = fixedMillisecond57.equals((java.lang.Object) regularTimePeriod62);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries49.getDataItem(regularTimePeriod62);
        timeSeries41.add(timeSeriesDataItem65);
        java.lang.String str67 = timeSeries41.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries7.addAndOrUpdate(timeSeries41);
        java.lang.Class class69 = timeSeries41.getTimePeriodClass();
        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date73 = month72.getStart();
        java.util.TimeZone timeZone74 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class69, date73, timeZone74);
        java.util.TimeZone timeZone76 = null;
        try {
            org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date73, timeZone76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2020" + "'", str33.equals("2020"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 100 + "'", int37 == 100);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(class50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(year53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 100 + "'", int54 == 100);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2020" + "'", str67.equals("2020"));
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertNotNull(class69);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNull(regularTimePeriod75);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int7 = month6.getYearValue();
        java.util.Date date8 = month6.getEnd();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "2020", "2020");
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        java.lang.String str13 = timeSeries11.getDescription();
        timeSeries11.setRangeDescription("2020");
        int int16 = timeSeries11.getItemCount();
        timeSeries11.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.Year year20 = org.jfree.data.time.Year.parseYear("100");
        int int21 = year20.getYear();
        int int22 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int26 = month25.getYearValue();
        java.util.Date date27 = month25.getEnd();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month25, "2020", "2020");
        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
        java.lang.String str32 = timeSeries30.getDescription();
        org.jfree.data.time.Year year34 = org.jfree.data.time.Year.parseYear("100");
        int int35 = year34.getYear();
        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass42 = month41.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month41.previous();
        java.lang.Class<?> wildcardClass44 = regularTimePeriod43.getClass();
        boolean boolean45 = fixedMillisecond38.equals((java.lang.Object) regularTimePeriod43);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries30.getDataItem(regularTimePeriod43);
        long long47 = timeSeries30.getMaximumItemAge();
        timeSeries30.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timeSeries30.removePropertyChangeListener(propertyChangeListener50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        timeSeries30.setKey((java.lang.Comparable) year52);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) year52, (java.lang.Number) 1562097599999L, false);
        boolean boolean57 = fixedMillisecond1.equals((java.lang.Object) 1562097599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(class31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 100 + "'", int35 == 100);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 9223372036854775807L + "'", long47 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        java.lang.String str3 = day0.toString();
//        java.lang.String str4 = day0.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.String str8 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
//        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
//        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int20 = month19.getYearValue();
//        java.util.Date date21 = month19.getEnd();
//        long long22 = month19.getSerialIndex();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries7.addChangeListener(seriesChangeListener25);
//        timeSeries7.removeAgedItems(false);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        int int31 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj35 = null;
//        int int36 = fixedMillisecond34.compareTo(obj35);
//        boolean boolean37 = day32.equals((java.lang.Object) int36);
//        org.jfree.data.time.SerialDate serialDate38 = day32.getSerialDate();
//        java.lang.Number number39 = null;
//        try {
//            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day32, number39, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(serialDate38);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener34);
        boolean boolean36 = timeSeries7.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long39 = fixedMillisecond38.getSerialIndex();
        java.util.Date date40 = fixedMillisecond38.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(date40);
        timeSeries7.setKey((java.lang.Comparable) date40);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
        org.junit.Assert.assertNotNull(date40);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        double double17 = timeSeries7.getMaxY();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month20.next();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month20, (double) 12, false);
        timeSeries7.removeAgedItems(1L, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = null;
        try {
            int int29 = timeSeries7.getIndex(regularTimePeriod28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
//        int int12 = year11.getYear();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
//        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
//        long long24 = timeSeries7.getMaximumItemAge();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
//        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        java.lang.String str37 = day34.toString();
//        boolean boolean38 = timeSeries7.equals((java.lang.Object) str37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj41 = null;
//        int int42 = fixedMillisecond40.compareTo(obj41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        long long45 = fixedMillisecond44.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond44);
//        java.util.Calendar calendar47 = null;
//        long long48 = fixedMillisecond40.getMiddleMillisecond(calendar47);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 10L + "'", long48 == 10L);
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = fixedMillisecond1.getFirstMillisecond();
        long long12 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int16 = month15.getYearValue();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month15, "2020", "2020");
        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
        java.lang.String str22 = timeSeries20.getDescription();
        org.jfree.data.time.Year year24 = org.jfree.data.time.Year.parseYear("100");
        int int25 = year24.getYear();
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass32 = month31.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month31.previous();
        java.lang.Class<?> wildcardClass34 = regularTimePeriod33.getClass();
        boolean boolean35 = fixedMillisecond28.equals((java.lang.Object) regularTimePeriod33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries20.getDataItem(regularTimePeriod33);
        long long37 = timeSeries20.getMaximumItemAge();
        timeSeries20.setNotify(false);
        java.lang.Object obj40 = timeSeries20.clone();
        int int41 = fixedMillisecond1.compareTo((java.lang.Object) timeSeries20);
        long long42 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        timeSeries7.removeAgedItems(6L, true);
        boolean boolean41 = timeSeries7.isEmpty();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int45 = month44.getYearValue();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month44, "2020", "2020");
        java.lang.String str50 = timeSeries49.getDescription();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = month54.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month54.previous();
        int int57 = year51.compareTo((java.lang.Object) regularTimePeriod56);
        boolean boolean58 = timeSeries49.equals((java.lang.Object) regularTimePeriod56);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int62 = month61.getYearValue();
        java.util.Date date63 = month61.getEnd();
        long long64 = month61.getSerialIndex();
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) month61, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener67 = null;
        timeSeries49.addChangeListener(seriesChangeListener67);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int72 = month71.getYearValue();
        java.util.Date date73 = month71.getEnd();
        boolean boolean75 = month71.equals((java.lang.Object) 'a');
        java.lang.String str76 = month71.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = month71.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries49.addOrUpdate(regularTimePeriod77, (java.lang.Number) 9);
        timeSeries49.removeAgedItems(6L, true);
        boolean boolean83 = timeSeries49.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries7.addAndOrUpdate(timeSeries49);
        org.jfree.data.time.Month month87 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int88 = month87.getYearValue();
        java.util.Date date89 = month87.getEnd();
        org.jfree.data.time.TimeSeries timeSeries92 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month87, "2020", "2020");
        java.lang.Class class93 = timeSeries92.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener94 = null;
        timeSeries92.removeChangeListener(seriesChangeListener94);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener96 = null;
        timeSeries92.addChangeListener(seriesChangeListener96);
        java.util.Collection collection98 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries92);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 100 + "'", int62 == 100);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1210L + "'", long64 == 1210L);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 100 + "'", int72 == 100);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "October 100" + "'", str76.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertNull(timeSeriesDataItem79);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(timeSeries84);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 100 + "'", int88 == 100);
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertNull(class93);
        org.junit.Assert.assertNotNull(collection98);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getLastMillisecond();
        long long3 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj29 = null;
        int int30 = fixedMillisecond28.compareTo(obj29);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int34 = month33.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeriesDataItem36.getPeriod();
        java.lang.Object obj38 = timeSeriesDataItem36.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeriesDataItem36.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, regularTimePeriod39);
        double double41 = timeSeries40.getMaxY();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
        timeSeries40.addChangeListener(seriesChangeListener42);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-1.0d) + "'", double41 == (-1.0d));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        boolean boolean5 = month2.equals((java.lang.Object) (short) 10);
        long long6 = month2.getSerialIndex();
        long long7 = month2.getLastMillisecond();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month2, seriesChangeInfo8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1210L + "'", long6 == 1210L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem9.getPeriod();
        timeSeriesDataItem9.setSelected(false);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int16 = month15.getYearValue();
        java.util.Date date17 = month15.getEnd();
        int int18 = timeSeriesDataItem9.compareTo((java.lang.Object) date17);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
//        int int12 = year11.getYear();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
//        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
//        long long24 = timeSeries7.getMaximumItemAge();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
//        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
//        java.util.Collection collection34 = timeSeries7.getTimePeriods();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj38 = null;
//        int int39 = fixedMillisecond37.compareTo(obj38);
//        boolean boolean40 = day35.equals((java.lang.Object) int39);
//        int int41 = day35.getDayOfMonth();
//        java.lang.String str42 = day35.toString();
//        int int43 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.next();
//        java.util.Date date47 = year45.getStart();
//        long long48 = year45.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year45.previous();
//        long long50 = year45.getFirstMillisecond();
//        int int51 = year45.getYear();
//        java.lang.Number number52 = null;
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year45, number52, false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(collection34);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "10-June-2019" + "'", str42.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-62104204800000L) + "'", long48 == (-62104204800000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-62104204800000L) + "'", long50 == (-62104204800000L));
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
//    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        java.lang.Object obj25 = timeSeriesDataItem23.clone();
        timeSeriesDataItem23.setSelected(false);
        boolean boolean28 = timeSeriesDataItem23.isSelected();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int32 = month31.getYearValue();
        java.util.Date date33 = month31.getEnd();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month31, "2020", "2020");
        java.lang.Class class37 = timeSeries36.getTimePeriodClass();
        java.lang.String str38 = timeSeries36.getDescription();
        timeSeries36.setRangeDescription("2020");
        int int41 = timeSeries36.getItemCount();
        int int42 = timeSeriesDataItem23.compareTo((java.lang.Object) timeSeries36);
        timeSeries36.removeAgedItems((long) 10, false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(class37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        boolean boolean5 = month2.equals((java.lang.Object) (short) 10);
        java.lang.String str6 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.next();
        int int8 = month2.getMonth();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int12 = month11.getYearValue();
        java.util.Date date13 = month11.getEnd();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "2020", "2020");
        java.lang.String str17 = timeSeries16.getDescription();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month21.previous();
        int int24 = year18.compareTo((java.lang.Object) regularTimePeriod23);
        boolean boolean25 = timeSeries16.equals((java.lang.Object) regularTimePeriod23);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int29 = month28.getYearValue();
        java.util.Date date30 = month28.getEnd();
        long long31 = month28.getSerialIndex();
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries16.addChangeListener(seriesChangeListener34);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int39 = month38.getYearValue();
        java.util.Date date40 = month38.getEnd();
        boolean boolean42 = month38.equals((java.lang.Object) 'a');
        java.lang.String str43 = month38.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month38.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries16.addOrUpdate(regularTimePeriod44, (java.lang.Number) 9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(10L);
        int int49 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        timeSeries16.setMaximumItemAge((long) (byte) 10);
        int int52 = month2.compareTo((java.lang.Object) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 100" + "'", str6.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 100 + "'", int29 == 100);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1210L + "'", long31 == 1210L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 100 + "'", int39 == 100);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "October 100" + "'", str43.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.addChangeListener(seriesChangeListener10);
        timeSeries7.setNotify(true);
        int int14 = timeSeries7.getItemCount();
        timeSeries7.clear();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int19 = month18.getYearValue();
        java.util.Date date20 = month18.getEnd();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month18, "2020", "2020");
        java.lang.String str24 = timeSeries23.getDescription();
        int int25 = timeSeries23.getItemCount();
        timeSeries23.setDescription("October 100");
        int int28 = timeSeries23.getMaximumItemCount();
        timeSeries23.setDomainDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond32.next();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) '4', true);
        int int37 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2147483647 + "'", int28 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        long long7 = day6.getSerialIndex();
        long long8 = day6.getFirstMillisecond();
        int int9 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.next();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day6.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-57600000L) + "'", long8 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        java.lang.Comparable comparable25 = timeSeries7.getKey();
        boolean boolean27 = timeSeries7.equals((java.lang.Object) 9223372036854775807L);
        java.lang.String str28 = timeSeries7.getRangeDescription();
        double double29 = timeSeries7.getMaxY();
        timeSeries7.setMaximumItemAge(0L);
        timeSeries7.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertNotNull(comparable25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2020" + "'", str28.equals("2020"));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 6.0d + "'", double29 == 6.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = year1.getStart();
        long long4 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod5, (double) (-61946438400001L));
        java.lang.Object obj8 = timeSeriesDataItem7.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62104204800000L) + "'", long4 == (-62104204800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, 1969);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getLastMillisecond(calendar12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.lang.String str17 = month16.toString();
        int int18 = fixedMillisecond11.compareTo((java.lang.Object) str17);
        long long19 = fixedMillisecond11.getLastMillisecond();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) (byte) -1);
        java.lang.Comparable comparable22 = timeSeries7.getKey();
        timeSeries7.setMaximumItemAge(6L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "January 0" + "'", str17.equals("January 0"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertNotNull(comparable22);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        timeSeries7.clear();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int29 = month28.getYearValue();
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month28, "2020", "2020");
        java.util.Collection collection34 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int38 = month37.getYearValue();
        java.util.Date date39 = month37.getEnd();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, "2020", "2020");
        java.lang.String str43 = timeSeries42.getDescription();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month47.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month47.previous();
        int int50 = year44.compareTo((java.lang.Object) regularTimePeriod49);
        boolean boolean51 = timeSeries42.equals((java.lang.Object) regularTimePeriod49);
        double double52 = timeSeries42.getMaxY();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month55.next();
        timeSeries42.add((org.jfree.data.time.RegularTimePeriod) month55, (double) 12, false);
        boolean boolean60 = timeSeries33.equals((java.lang.Object) month55);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 100 + "'", int29 == 100);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 100 + "'", int38 == 100);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        double double17 = timeSeries7.getMinY();
        double double18 = timeSeries7.getMaxY();
        timeSeries7.setDomainDescription("org.jfree.data.general.SeriesException: 100");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-58986590400001L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-58986590400001L) + "'", long4 == (-58986590400001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-58986590400001L) + "'", long5 == (-58986590400001L));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.lang.String str34 = timeSeries7.getDomainDescription();
        java.lang.Object obj35 = timeSeries7.clone();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int39 = month38.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month38, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeriesDataItem41.getPeriod();
        java.lang.Object obj43 = timeSeriesDataItem41.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeriesDataItem41.getPeriod();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj48 = null;
        int int49 = fixedMillisecond47.compareTo(obj48);
        boolean boolean50 = day45.equals((java.lang.Object) int49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day45.next();
        int int52 = timeSeriesDataItem41.compareTo((java.lang.Object) day45);
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day45, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2020" + "'", str34.equals("2020"));
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 100 + "'", int39 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.Year year16 = org.jfree.data.time.Year.parseYear("100");
        int int17 = year16.getYear();
        int int18 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int22 = month21.getYearValue();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "2020", "2020");
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        java.lang.String str28 = timeSeries26.getDescription();
        org.jfree.data.time.Year year30 = org.jfree.data.time.Year.parseYear("100");
        int int31 = year30.getYear();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass38 = month37.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month37.previous();
        java.lang.Class<?> wildcardClass40 = regularTimePeriod39.getClass();
        boolean boolean41 = fixedMillisecond34.equals((java.lang.Object) regularTimePeriod39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries26.getDataItem(regularTimePeriod39);
        long long43 = timeSeries26.getMaximumItemAge();
        timeSeries26.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timeSeries26.removePropertyChangeListener(propertyChangeListener46);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        timeSeries26.setKey((java.lang.Comparable) year48);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 1562097599999L, false);
        int int53 = timeSeries7.getMaximumItemCount();
        java.lang.String str54 = timeSeries7.getDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036854775807L + "'", long43 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNull(str54);
    }
}

