import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = year1.getStart();
        java.util.Date date4 = year1.getEnd();
        java.util.Calendar calendar5 = null;
        try {
            year1.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date3 = month2.getStart();
        java.lang.String str4 = month2.toString();
        int int5 = month2.getYearValue();
        org.jfree.data.time.Year year6 = month2.getYear();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "January 0" + "'", str4.equals("January 0"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(year6);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        double double17 = timeSeries7.getMinY();
        boolean boolean18 = timeSeries7.getNotify();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        boolean boolean4 = year1.equals((java.lang.Object) year2);
        long long5 = year2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        java.lang.Object obj24 = timeSeriesDataItem23.clone();
        timeSeriesDataItem23.setValue((java.lang.Number) 1.0f);
        java.lang.Object obj27 = timeSeriesDataItem23.clone();
        timeSeriesDataItem23.setSelected(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '#', 4, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.String str8 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
//        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
//        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int20 = month19.getYearValue();
//        java.util.Date date21 = month19.getEnd();
//        long long22 = month19.getSerialIndex();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries7.addChangeListener(seriesChangeListener25);
//        timeSeries7.removeAgedItems(false);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        int int31 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
//        java.lang.String str32 = day29.toString();
//        int int33 = day29.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2147483647);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(31);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        java.util.Date date10 = year8.getStart();
        long long11 = year8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year8.previous();
        long long13 = year8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year8.next();
        boolean boolean15 = year5.equals((java.lang.Object) regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62104204800000L) + "'", long11 == (-62104204800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62072668800001L) + "'", long13 == (-62072668800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj31 = null;
        int int32 = fixedMillisecond30.compareTo(obj31);
        boolean boolean33 = day28.equals((java.lang.Object) int32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.next();
        int int35 = day28.getYear();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day28);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(10L);
        int int40 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries7.removeChangeListener(seriesChangeListener41);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener43 = null;
        timeSeries7.removeChangeListener(seriesChangeListener43);
        timeSeries7.setMaximumItemCount(6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.lang.String str7 = month6.toString();
        int int8 = fixedMillisecond1.compareTo((java.lang.Object) str7);
        long long9 = fixedMillisecond1.getLastMillisecond();
        long long10 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January 0" + "'", str7.equals("January 0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        long long7 = day6.getSerialIndex();
        int int8 = day6.getDayOfMonth();
        java.util.Calendar calendar9 = null;
        try {
            day6.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = year1.getStart();
        java.util.Date date4 = year1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getSerialIndex();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        java.lang.Object obj25 = timeSeriesDataItem23.clone();
        timeSeriesDataItem23.setSelected(false);
        boolean boolean28 = timeSeriesDataItem23.isSelected();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int32 = month31.getYearValue();
        java.util.Date date33 = month31.getEnd();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month31, "2020", "2020");
        java.lang.Class class37 = timeSeries36.getTimePeriodClass();
        java.lang.String str38 = timeSeries36.getDescription();
        timeSeries36.setRangeDescription("2020");
        int int41 = timeSeries36.getItemCount();
        int int42 = timeSeriesDataItem23.compareTo((java.lang.Object) timeSeries36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeriesDataItem23.getPeriod();
        java.lang.Class<?> wildcardClass44 = regularTimePeriod43.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(class37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(wildcardClass44);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.lang.String str2 = regularTimePeriod1.toString();
        java.util.Date date3 = regularTimePeriod1.getStart();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2020" + "'", str2.equals("2020"));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        java.util.Date date9 = month2.getEnd();
        org.jfree.data.time.Year year10 = month2.getYear();
        java.lang.Object obj11 = null;
        boolean boolean12 = month2.equals(obj11);
        int int13 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        java.lang.Comparable comparable25 = timeSeries7.getKey();
        boolean boolean27 = timeSeries7.equals((java.lang.Object) 9223372036854775807L);
        java.lang.String str28 = timeSeries7.getRangeDescription();
        double double29 = timeSeries7.getMaxY();
        timeSeries7.setMaximumItemAge(0L);
        java.lang.String str32 = timeSeries7.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertNotNull(comparable25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2020" + "'", str28.equals("2020"));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 6.0d + "'", double29 == 6.0d);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2020" + "'", str32.equals("2020"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        java.util.Date date11 = month7.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        java.util.TimeZone timeZone13 = null;
        try {
            org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date11, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener34);
        boolean boolean36 = timeSeries7.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
        long long41 = fixedMillisecond38.getSerialIndex();
        long long42 = fixedMillisecond38.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        java.util.List list44 = timeSeries7.getItems();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int48 = month47.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month47, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = timeSeriesDataItem50.getPeriod();
        java.lang.Object obj52 = timeSeriesDataItem50.clone();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries7.addOrUpdate(timeSeriesDataItem50);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 100 + "'", int48 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(obj52);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setRangeDescription("January 0");
        double double27 = timeSeries7.getMaxY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long30 = fixedMillisecond29.getFirstMillisecond();
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond29.getFirstMillisecond(calendar31);
        java.lang.Number number33 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        long long34 = fixedMillisecond29.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-1.0d) + "'", double27 == (-1.0d));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (-1) + "'", number33.equals((-1)));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        timeSeries7.setNotify(true);
        timeSeries7.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        timeSeries7.removeAgedItems(6L, true);
        boolean boolean41 = timeSeries7.isEmpty();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int45 = month44.getYearValue();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month44, "2020", "2020");
        java.lang.String str50 = timeSeries49.getDescription();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = month54.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month54.previous();
        int int57 = year51.compareTo((java.lang.Object) regularTimePeriod56);
        boolean boolean58 = timeSeries49.equals((java.lang.Object) regularTimePeriod56);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int62 = month61.getYearValue();
        java.util.Date date63 = month61.getEnd();
        long long64 = month61.getSerialIndex();
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) month61, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener67 = null;
        timeSeries49.addChangeListener(seriesChangeListener67);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int72 = month71.getYearValue();
        java.util.Date date73 = month71.getEnd();
        boolean boolean75 = month71.equals((java.lang.Object) 'a');
        java.lang.String str76 = month71.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = month71.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries49.addOrUpdate(regularTimePeriod77, (java.lang.Number) 9);
        timeSeries49.removeAgedItems(6L, true);
        boolean boolean83 = timeSeries49.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries7.addAndOrUpdate(timeSeries49);
        timeSeries84.setDescription("org.jfree.data.event.SeriesChangeEvent[source=10]");
        timeSeries84.setNotify(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 100 + "'", int62 == 100);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1210L + "'", long64 == 1210L);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 100 + "'", int72 == 100);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "October 100" + "'", str76.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertNull(timeSeriesDataItem79);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(timeSeries84);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=10]");
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
//        int int12 = year11.getYear();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
//        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
//        long long24 = timeSeries7.getMaximumItemAge();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj31 = null;
//        int int32 = fixedMillisecond30.compareTo(obj31);
//        boolean boolean33 = day28.equals((java.lang.Object) int32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.next();
//        int int35 = day28.getYear();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(1560236399999L);
//        boolean boolean39 = day28.equals((java.lang.Object) 1560236399999L);
//        long long40 = day28.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 43626L + "'", long40 == 43626L);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        int int9 = timeSeries7.getItemCount();
        double double10 = timeSeries7.getMaxY();
        try {
            timeSeries7.delete((-1), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 10L);
        int int17 = timeSeries7.getMaximumItemCount();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int21 = month20.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month20, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        java.lang.Object obj25 = timeSeriesDataItem23.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem23.getPeriod();
        timeSeriesDataItem23.setSelected(true);
        java.lang.Number number29 = timeSeriesDataItem23.getValue();
        try {
            timeSeries7.add(timeSeriesDataItem23, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 0.0d + "'", number29.equals(0.0d));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        java.lang.Class class27 = timeSeries7.getTimePeriodClass();
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize(class27);
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize(class27);
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize(class29);
        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize(class30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNotNull(class31);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        timeSeries7.removeAgedItems(false);
        timeSeries7.removeAgedItems(true);
        java.lang.String str31 = timeSeries7.getRangeDescription();
        timeSeries7.setMaximumItemCount(2);
        timeSeries7.setMaximumItemCount(0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2020" + "'", str31.equals("2020"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        long long8 = month2.getLastMillisecond();
        long long9 = month2.getSerialIndex();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int13 = month12.getYearValue();
        java.util.Date date14 = month12.getEnd();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month12, "2020", "2020");
        java.lang.String str18 = timeSeries17.getDescription();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month22.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.previous();
        int int25 = year19.compareTo((java.lang.Object) regularTimePeriod24);
        boolean boolean26 = timeSeries17.equals((java.lang.Object) regularTimePeriod24);
        double double27 = timeSeries17.getMaxY();
        int int28 = month2.compareTo((java.lang.Object) double27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.next();
        boolean boolean31 = month2.equals((java.lang.Object) fixedMillisecond29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-58985251200001L) + "'", long8 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1210L + "'", long9 == 1210L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        timeSeriesDataItem31.setSelected(false);
        timeSeriesDataItem31.setSelected(false);
        timeSeriesDataItem31.setSelected(true);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date42 = month41.getStart();
        boolean boolean43 = timeSeriesDataItem31.equals((java.lang.Object) month41);
        boolean boolean44 = timeSeriesDataItem31.isSelected();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(10L);
        int int40 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int44 = month43.getYearValue();
        java.util.Date date45 = month43.getEnd();
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month43, "2020", "2020");
        java.lang.Class class49 = timeSeries48.getTimePeriodClass();
        java.lang.String str50 = timeSeries48.getDescription();
        org.jfree.data.time.Year year52 = org.jfree.data.time.Year.parseYear("100");
        int int53 = year52.getYear();
        timeSeries48.add((org.jfree.data.time.RegularTimePeriod) year52, (java.lang.Number) (-1));
        timeSeries48.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long62 = fixedMillisecond61.getSerialIndex();
        java.util.Date date63 = fixedMillisecond61.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(date63);
        boolean boolean65 = year59.equals((java.lang.Object) date63);
        timeSeries48.add((org.jfree.data.time.RegularTimePeriod) year59, (double) 1969, false);
        try {
            org.jfree.data.time.TimeSeries timeSeries69 = timeSeries7.addAndOrUpdate(timeSeries48);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 100 + "'", int44 == 100);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNull(class49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(year52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 100 + "'", int53 == 100);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 10L + "'", long62 == 10L);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        java.lang.Object obj29 = timeSeries7.clone();
        timeSeries7.removeAgedItems(false);
        java.lang.Object obj32 = null;
        boolean boolean33 = timeSeries7.equals(obj32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        java.util.Date date9 = month2.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (-62150212800001L));
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int15 = month14.getYearValue();
        java.util.Date date16 = month14.getEnd();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14, "2020", "2020");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int23 = month22.getYearValue();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month22, "2020", "2020");
        java.lang.Class class28 = timeSeries27.getTimePeriodClass();
        java.lang.String str29 = timeSeries27.getDescription();
        org.jfree.data.time.Year year31 = org.jfree.data.time.Year.parseYear("100");
        int int32 = year31.getYear();
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass39 = month38.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month38.previous();
        java.lang.Class<?> wildcardClass41 = regularTimePeriod40.getClass();
        boolean boolean42 = fixedMillisecond35.equals((java.lang.Object) regularTimePeriod40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries27.getDataItem(regularTimePeriod40);
        timeSeries19.add(timeSeriesDataItem43);
        java.lang.String str45 = timeSeries19.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo47 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent48 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond46, seriesChangeInfo47);
        int int49 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int53 = month52.getYearValue();
        java.util.Date date54 = month52.getEnd();
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month52, "2020", "2020");
        java.lang.Class class58 = timeSeries57.getTimePeriodClass();
        java.lang.String str59 = timeSeries57.getDescription();
        org.jfree.data.time.Year year61 = org.jfree.data.time.Year.parseYear("100");
        int int62 = year61.getYear();
        timeSeries57.add((org.jfree.data.time.RegularTimePeriod) year61, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass69 = month68.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = month68.previous();
        java.lang.Class<?> wildcardClass71 = regularTimePeriod70.getClass();
        boolean boolean72 = fixedMillisecond65.equals((java.lang.Object) regularTimePeriod70);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = timeSeries57.getDataItem(regularTimePeriod70);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = timeSeriesDataItem73.getPeriod();
        java.lang.Object obj75 = timeSeriesDataItem73.clone();
        timeSeriesDataItem73.setSelected(false);
        boolean boolean78 = timeSeriesDataItem73.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries19.addOrUpdate(timeSeriesDataItem73);
        boolean boolean80 = timeSeriesDataItem11.equals((java.lang.Object) timeSeries19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(class28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2020" + "'", str45.equals("2020"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 100 + "'", int53 == 100);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNull(class58);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(year61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 100 + "'", int62 == 100);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem73);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(obj75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year9);
        java.lang.String str12 = year9.toString();
        long long13 = year9.getSerialIndex();
        long long14 = year9.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) 4);
        boolean boolean10 = timeSeriesDataItem9.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem9.getPeriod();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        double double17 = timeSeries7.getMinY();
        double double18 = timeSeries7.getMaxY();
        timeSeries7.setRangeDescription("");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeries7.getTimePeriod((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj3 = null;
//        int int4 = fixedMillisecond2.compareTo(obj3);
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        long long7 = day0.getLastMillisecond();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int11 = month10.getYearValue();
//        java.util.Date date12 = month10.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
//        java.lang.String str16 = timeSeries15.getDescription();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month20.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month20.previous();
//        int int23 = year17.compareTo((java.lang.Object) regularTimePeriod22);
//        boolean boolean24 = timeSeries15.equals((java.lang.Object) regularTimePeriod22);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int28 = month27.getYearValue();
//        java.util.Date date29 = month27.getEnd();
//        long long30 = month27.getSerialIndex();
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 6L);
//        java.lang.Comparable comparable33 = timeSeries15.getKey();
//        int int34 = day0.compareTo((java.lang.Object) timeSeries15);
//        int int35 = day0.getYear();
//        java.lang.String str36 = day0.toString();
//        long long37 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1210L + "'", long30 == 1210L);
//        org.junit.Assert.assertNotNull(comparable33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10-June-2019" + "'", str36.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 43626L + "'", long37 == 43626L);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        java.util.Date date9 = month2.getEnd();
        org.jfree.data.time.Year year10 = month2.getYear();
        java.lang.Class<?> wildcardClass11 = year10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        try {
            java.lang.Number number26 = timeSeries7.getValue(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(10L);
        int int40 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.lang.String str41 = timeSeries7.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2020" + "'", str41.equals("2020"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        long long15 = year11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.next();
        java.util.Date date17 = regularTimePeriod16.getEnd();
        java.util.TimeZone timeZone18 = null;
        try {
            org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17, timeZone18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-59011603200000L) + "'", long15 == (-59011603200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int12 = month11.getYearValue();
        java.util.Date date13 = month11.getEnd();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "2020", "2020");
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        java.lang.String str18 = timeSeries16.getDescription();
        timeSeries16.setRangeDescription("2020");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int24 = month23.getYearValue();
        boolean boolean26 = month23.equals((java.lang.Object) (short) 10);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month23, (double) (-58987929600000L), false);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month23, (double) (byte) -1, true);
        java.lang.Class class33 = timeSeries7.getTimePeriodClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = timeSeries7.getTimePeriod((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(class33);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        boolean boolean29 = timeSeries7.isEmpty();
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int33 = month32.getYearValue();
        java.util.Date date34 = month32.getEnd();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month32, "2020", "2020");
        long long38 = month32.getLastMillisecond();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int42 = month41.getYearValue();
        java.util.Date date43 = month41.getEnd();
        boolean boolean45 = month41.equals((java.lang.Object) 'a');
        long long46 = month41.getLastMillisecond();
        int int47 = month41.getYearValue();
        long long48 = month41.getFirstMillisecond();
        long long49 = month41.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException51 = new org.jfree.data.general.SeriesException("100");
        boolean boolean52 = month41.equals((java.lang.Object) seriesException51);
        int int53 = month32.compareTo((java.lang.Object) boolean52);
        boolean boolean55 = month32.equals((java.lang.Object) 4);
        int int56 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 100 + "'", int33 == 100);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-58985251200001L) + "'", long38 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-58985251200001L) + "'", long46 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 100 + "'", int47 == 100);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-58987929600000L) + "'", long48 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-58987929600000L) + "'", long49 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        timeSeries7.removeAgedItems(false);
        boolean boolean29 = timeSeries7.getNotify();
        try {
            timeSeries7.delete(1969, (int) (short) 1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj3 = null;
//        int int4 = fixedMillisecond2.compareTo(obj3);
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        int int7 = day0.getYear();
//        int int8 = day0.getYear();
//        java.lang.String str9 = day0.toString();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        int int9 = timeSeries7.getItemCount();
        timeSeries7.removeAgedItems(false);
        timeSeries7.removeAgedItems(0L, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries7.removeChangeListener(seriesChangeListener15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        boolean boolean5 = month2.equals((java.lang.Object) (short) 10);
        java.util.Date date6 = month2.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        timeSeries7.removeAgedItems(false);
        timeSeries7.removeAgedItems(true);
        java.lang.String str31 = timeSeries7.getRangeDescription();
        timeSeries7.setMaximumItemCount(2);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int37 = month36.getYearValue();
        boolean boolean39 = month36.equals((java.lang.Object) (short) 10);
        java.lang.String str40 = month36.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month36.next();
        timeSeries7.delete(regularTimePeriod41);
        timeSeries7.setRangeDescription("org.jfree.data.general.SeriesException: 100");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2020" + "'", str31.equals("2020"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 100 + "'", int37 == 100);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "October 100" + "'", str40.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod41);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        boolean boolean6 = month2.equals((java.lang.Object) 'a');
//        long long7 = month2.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (-1.0d));
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.next();
//        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
//        java.lang.String str13 = day10.toString();
//        java.lang.String str14 = day10.toString();
//        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) day10);
//        int int16 = day10.getMonth();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        java.util.Date date9 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass15 = month14.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.previous();
        java.lang.Class<?> wildcardClass17 = regularTimePeriod16.getClass();
        boolean boolean18 = fixedMillisecond11.equals((java.lang.Object) regularTimePeriod16);
        try {
            timeSeries10.update(regularTimePeriod16, (java.lang.Number) 2L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj3 = null;
//        int int4 = fixedMillisecond2.compareTo(obj3);
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        long long8 = day0.getFirstMillisecond();
//        long long9 = day0.getFirstMillisecond();
//        long long10 = day0.getFirstMillisecond();
//        long long11 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        java.lang.Class class27 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
        java.lang.String str30 = regularTimePeriod29.toString();
        java.util.Date date31 = regularTimePeriod29.getStart();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date31, timeZone32);
        java.util.TimeZone timeZone34 = null;
        try {
            org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date31, timeZone34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2020" + "'", str30.equals("2020"));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod33);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        int int16 = year11.compareTo((java.lang.Object) 1L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getLastMillisecond();
        boolean boolean5 = fixedMillisecond1.equals((java.lang.Object) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        timeSeries7.setRangeDescription("2020");
//        int int12 = timeSeries7.getItemCount();
//        timeSeries7.setMaximumItemCount((int) (short) 1);
//        org.jfree.data.time.Year year16 = org.jfree.data.time.Year.parseYear("100");
//        int int17 = year16.getYear();
//        int int18 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries7.addChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj24 = null;
//        int int25 = fixedMillisecond23.compareTo(obj24);
//        boolean boolean26 = day21.equals((java.lang.Object) int25);
//        org.jfree.data.time.SerialDate serialDate27 = day21.getSerialDate();
//        long long28 = day21.getLastMillisecond();
//        int int29 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        long long32 = fixedMillisecond31.getFirstMillisecond();
//        long long33 = fixedMillisecond31.getSerialIndex();
//        int int34 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond31.getMiddleMillisecond(calendar35);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560236399999L + "'", long28 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        int int9 = timeSeries7.getItemCount();
        timeSeries7.setDescription("October 100");
        int int12 = timeSeries7.getMaximumItemCount();
        timeSeries7.setDomainDescription("");
        double double15 = timeSeries7.getMinY();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int19 = month18.getYearValue();
        java.util.Date date20 = month18.getEnd();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month18, "2020", "2020");
        boolean boolean25 = month18.equals((java.lang.Object) 100.0d);
        java.lang.Number number26 = null;
        try {
            timeSeries7.update((org.jfree.data.time.RegularTimePeriod) month18, number26);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(10L);
        int int40 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries7.removeChangeListener(seriesChangeListener41);
        int int43 = timeSeries7.getItemCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2 + "'", int43 == 2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.lang.String str4 = month2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 10, seriesChangeInfo6);
        java.lang.Object obj8 = seriesChangeEvent7.getSource();
        java.lang.String str9 = seriesChangeEvent7.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo12);
        boolean boolean14 = month2.equals((java.lang.Object) seriesChangeInfo12);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int18 = month17.getYearValue();
        java.util.Date date19 = month17.getEnd();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "2020", "2020");
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        java.lang.String str24 = timeSeries22.getDescription();
        org.jfree.data.time.Year year26 = org.jfree.data.time.Year.parseYear("100");
        int int27 = year26.getYear();
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass34 = month33.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month33.previous();
        java.lang.Class<?> wildcardClass36 = regularTimePeriod35.getClass();
        boolean boolean37 = fixedMillisecond30.equals((java.lang.Object) regularTimePeriod35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries22.getDataItem(regularTimePeriod35);
        long long39 = timeSeries22.getMaximumItemAge();
        timeSeries22.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeries22.getNextTimePeriod();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj46 = null;
        int int47 = fixedMillisecond45.compareTo(obj46);
        boolean boolean48 = day43.equals((java.lang.Object) int47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day43.next();
        int int50 = day43.getYear();
        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) day43);
        timeSeries22.setDomainDescription("2019");
        boolean boolean54 = month2.equals((java.lang.Object) timeSeries22);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries22.getDataItem(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "October 100" + "'", str4.equals("October 100"));
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + (byte) 10 + "'", obj8.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str9.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 100 + "'", int27 == 100);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 9223372036854775807L + "'", long39 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        long long9 = month2.getFirstMillisecond();
        java.util.Date date10 = month2.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month15.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month15.previous();
        int int18 = year12.compareTo((java.lang.Object) regularTimePeriod17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(8, year12);
        org.jfree.data.time.Year year20 = month19.getYear();
        int int21 = month2.compareTo((java.lang.Object) year20);
        long long22 = year20.getLastMillisecond();
        java.lang.String str23 = year20.toString();
        java.lang.String str24 = year20.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int14 = month13.getYearValue();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month13, "2020", "2020");
        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
        java.lang.String str20 = timeSeries18.getDescription();
        timeSeries18.setRangeDescription("2020");
        int int23 = timeSeries18.getItemCount();
        timeSeries18.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.Year year27 = org.jfree.data.time.Year.parseYear("100");
        int int28 = year27.getYear();
        int int29 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year27);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int33 = month32.getYearValue();
        java.util.Date date34 = month32.getEnd();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month32, "2020", "2020");
        java.lang.Class class38 = timeSeries37.getTimePeriodClass();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int42 = month41.getYearValue();
        java.util.Date date43 = month41.getEnd();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month41, "2020", "2020");
        java.lang.Class class47 = timeSeries46.getTimePeriodClass();
        java.lang.String str48 = timeSeries46.getDescription();
        timeSeries46.setRangeDescription("2020");
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int54 = month53.getYearValue();
        boolean boolean56 = month53.equals((java.lang.Object) (short) 10);
        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) month53, (double) (-58987929600000L), false);
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) month53, (double) (byte) -1, true);
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month53, (java.lang.Number) 2019, false);
        int int66 = fixedMillisecond1.compareTo((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 100 + "'", int33 == 100);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(class38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(class47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 100 + "'", int54 == 100);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        timeSeries7.removeAgedItems(false);
        timeSeries7.setRangeDescription("October 100");
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month39);
        long long41 = month39.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-58987929600000L) + "'", long41 == (-58987929600000L));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj31 = null;
        int int32 = fixedMillisecond30.compareTo(obj31);
        boolean boolean33 = day28.equals((java.lang.Object) int32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.next();
        int int35 = day28.getYear();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(1560236399999L);
        boolean boolean39 = day28.equals((java.lang.Object) 1560236399999L);
        org.jfree.data.time.SerialDate serialDate40 = day28.getSerialDate();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(serialDate40);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj3 = null;
//        int int4 = fixedMillisecond2.compareTo(obj3);
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        long long7 = day0.getSerialIndex();
//        long long8 = day0.getFirstMillisecond();
//        long long9 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560236399999L + "'", long9 == 1560236399999L);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        timeSeries7.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((-58986590400001L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond26.previous();
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond26.getLastMillisecond(calendar28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond26.next();
        java.util.Date date31 = fixedMillisecond26.getTime();
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond26.getMiddleMillisecond(calendar32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries35 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, regularTimePeriod34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-58986590400001L) + "'", long29 == (-58986590400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-58986590400001L) + "'", long33 == (-58986590400001L));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, 2019);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long11 = fixedMillisecond10.getFirstMillisecond();
        long long12 = fixedMillisecond10.getSerialIndex();
        long long13 = fixedMillisecond10.getFirstMillisecond();
        long long14 = fixedMillisecond10.getFirstMillisecond();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) (-1), true);
        timeSeries7.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.previous();
        int int7 = year1.compareTo((java.lang.Object) regularTimePeriod6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(8, year1);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int12 = month11.getYearValue();
        java.util.Date date13 = month11.getEnd();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month11, "2020", "2020");
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        java.lang.String str18 = timeSeries16.getDescription();
        timeSeries16.setRangeDescription("2020");
        int int21 = timeSeries16.getItemCount();
        timeSeries16.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.Year year25 = org.jfree.data.time.Year.parseYear("100");
        int int26 = year25.getYear();
        int int27 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) year25);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int31 = month30.getYearValue();
        java.util.Date date32 = month30.getEnd();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "2020", "2020");
        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
        java.lang.String str37 = timeSeries35.getDescription();
        org.jfree.data.time.Year year39 = org.jfree.data.time.Year.parseYear("100");
        int int40 = year39.getYear();
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass47 = month46.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month46.previous();
        java.lang.Class<?> wildcardClass49 = regularTimePeriod48.getClass();
        boolean boolean50 = fixedMillisecond43.equals((java.lang.Object) regularTimePeriod48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries35.getDataItem(regularTimePeriod48);
        long long52 = timeSeries35.getMaximumItemAge();
        timeSeries35.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timeSeries35.removePropertyChangeListener(propertyChangeListener55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        timeSeries35.setKey((java.lang.Comparable) year57);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year57, (java.lang.Number) 1562097599999L, false);
        boolean boolean62 = month8.equals((java.lang.Object) 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(class17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(class36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(year39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 100 + "'", int40 == 100);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 9223372036854775807L + "'", long52 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        java.lang.Class class27 = timeSeries7.getTimePeriodClass();
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize(class27);
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNull(regularTimePeriod31);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-58986590400001L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-58986590400001L) + "'", long4 == (-58986590400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        java.util.Date date9 = month2.getEnd();
        org.jfree.data.time.Year year10 = month2.getYear();
        long long11 = year10.getSerialIndex();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int15 = month14.getYearValue();
        java.util.Date date16 = month14.getEnd();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14, "2020", "2020");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int23 = month22.getYearValue();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month22, "2020", "2020");
        java.lang.Class class28 = timeSeries27.getTimePeriodClass();
        java.lang.String str29 = timeSeries27.getDescription();
        org.jfree.data.time.Year year31 = org.jfree.data.time.Year.parseYear("100");
        int int32 = year31.getYear();
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass39 = month38.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month38.previous();
        java.lang.Class<?> wildcardClass41 = regularTimePeriod40.getClass();
        boolean boolean42 = fixedMillisecond35.equals((java.lang.Object) regularTimePeriod40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries27.getDataItem(regularTimePeriod40);
        timeSeries19.add(timeSeriesDataItem43);
        java.lang.String str45 = timeSeries19.getDomainDescription();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int49 = month48.getYearValue();
        java.util.Date date50 = month48.getEnd();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month48, "2020", "2020");
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int57 = month56.getYearValue();
        java.util.Date date58 = month56.getEnd();
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month56, "2020", "2020");
        java.lang.Class class62 = timeSeries61.getTimePeriodClass();
        java.lang.String str63 = timeSeries61.getDescription();
        org.jfree.data.time.Year year65 = org.jfree.data.time.Year.parseYear("100");
        int int66 = year65.getYear();
        timeSeries61.add((org.jfree.data.time.RegularTimePeriod) year65, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass73 = month72.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = month72.previous();
        java.lang.Class<?> wildcardClass75 = regularTimePeriod74.getClass();
        boolean boolean76 = fixedMillisecond69.equals((java.lang.Object) regularTimePeriod74);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries61.getDataItem(regularTimePeriod74);
        timeSeries53.add(timeSeriesDataItem77);
        java.lang.String str79 = timeSeries53.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries19.addAndOrUpdate(timeSeries53);
        boolean boolean81 = year10.equals((java.lang.Object) timeSeries80);
        java.util.Calendar calendar82 = null;
        try {
            year10.peg(calendar82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(class28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2020" + "'", str45.equals("2020"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 100 + "'", int49 == 100);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 100 + "'", int57 == 100);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNull(class62);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(year65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 100 + "'", int66 == 100);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem77);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "2020" + "'", str79.equals("2020"));
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj3 = null;
//        int int4 = fixedMillisecond2.compareTo(obj3);
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        long long7 = day0.getLastMillisecond();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int11 = month10.getYearValue();
//        java.util.Date date12 = month10.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
//        java.lang.String str16 = timeSeries15.getDescription();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month20.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month20.previous();
//        int int23 = year17.compareTo((java.lang.Object) regularTimePeriod22);
//        boolean boolean24 = timeSeries15.equals((java.lang.Object) regularTimePeriod22);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int28 = month27.getYearValue();
//        java.util.Date date29 = month27.getEnd();
//        long long30 = month27.getSerialIndex();
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 6L);
//        java.lang.Comparable comparable33 = timeSeries15.getKey();
//        int int34 = day0.compareTo((java.lang.Object) timeSeries15);
//        int int35 = day0.getYear();
//        java.lang.String str36 = day0.toString();
//        java.util.Calendar calendar37 = null;
//        try {
//            day0.peg(calendar37);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1210L + "'", long30 == 1210L);
//        org.junit.Assert.assertNotNull(comparable33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10-June-2019" + "'", str36.equals("10-June-2019"));
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        long long5 = month2.getSerialIndex();
        java.lang.Class<?> wildcardClass6 = month2.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long11 = fixedMillisecond10.getFirstMillisecond();
        long long12 = fixedMillisecond10.getSerialIndex();
        long long13 = fixedMillisecond10.getFirstMillisecond();
        long long14 = fixedMillisecond10.getFirstMillisecond();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) (-1), true);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond10.getMiddleMillisecond(calendar18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj29 = null;
        int int30 = fixedMillisecond28.compareTo(obj29);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int34 = month33.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeriesDataItem36.getPeriod();
        java.lang.Object obj38 = timeSeriesDataItem36.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeriesDataItem36.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, regularTimePeriod39);
        double double41 = timeSeries40.getMaxY();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day42.next();
        org.jfree.data.time.SerialDate serialDate44 = day42.getSerialDate();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(serialDate44);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(serialDate44);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate44);
        timeSeries40.setKey((java.lang.Comparable) serialDate44);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-1.0d) + "'", double41 == (-1.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(serialDate44);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        long long2 = fixedMillisecond1.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond1.getEnd();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int9 = month8.getYearValue();
//        java.util.Date date10 = month8.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "2020", "2020");
//        java.lang.String str14 = timeSeries13.getDescription();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        int int21 = year15.compareTo((java.lang.Object) regularTimePeriod20);
//        boolean boolean22 = timeSeries13.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int26 = month25.getYearValue();
//        java.util.Date date27 = month25.getEnd();
//        long long28 = month25.getSerialIndex();
//        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) month25, (java.lang.Number) 6L);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries13.addChangeListener(seriesChangeListener31);
//        timeSeries13.removeAgedItems(false);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        int int37 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.next();
//        long long40 = day38.getFirstMillisecond();
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.next();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) day38, (org.jfree.data.time.RegularTimePeriod) month43);
//        int int46 = fixedMillisecond1.compareTo((java.lang.Object) timeSeries13);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1210L + "'", long28 == 1210L);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10-June-2019" + "'", str36.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560150000000L + "'", long40 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
//        int int12 = year11.getYear();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
//        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
//        long long24 = timeSeries7.getMaximumItemAge();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
//        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        java.lang.String str37 = day34.toString();
//        boolean boolean38 = timeSeries7.equals((java.lang.Object) str37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj42 = null;
//        int int43 = fixedMillisecond41.compareTo(obj42);
//        boolean boolean44 = day39.equals((java.lang.Object) int43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day39.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day39.next();
//        long long47 = day39.getFirstMillisecond();
//        int int48 = day39.getMonth();
//        timeSeries7.update((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) (-1L));
//        try {
//            org.jfree.data.time.TimeSeries timeSeries53 = timeSeries7.createCopy(1, 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560150000000L + "'", long47 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = fixedMillisecond1.getSerialIndex();
        long long12 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.event.SeriesChangeEvent[source=-1]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        timeSeries7.clear();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int29 = month28.getYearValue();
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month28, "2020", "2020");
        java.util.Collection collection34 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        java.lang.String str35 = timeSeries7.getDescription();
        java.lang.Class class36 = timeSeries7.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 100 + "'", int29 == 100);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNull(class36);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        java.util.Date date11 = month7.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        long long6 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date7 = fixedMillisecond1.getTime();
        long long8 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj29 = null;
        int int30 = fixedMillisecond28.compareTo(obj29);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int34 = month33.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeriesDataItem36.getPeriod();
        java.lang.Object obj38 = timeSeriesDataItem36.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeriesDataItem36.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, regularTimePeriod39);
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond28.getFirstMillisecond(calendar41);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        timeSeries7.setMaximumItemAge(1560150000000L);
        timeSeries7.setDomainDescription("100");
        long long32 = timeSeries7.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560150000000L + "'", long32 == 1560150000000L);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        java.lang.String str33 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int37 = month36.getYearValue();
        java.util.Date date38 = month36.getEnd();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month36, "2020", "2020");
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int45 = month44.getYearValue();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month44, "2020", "2020");
        java.lang.Class class50 = timeSeries49.getTimePeriodClass();
        java.lang.String str51 = timeSeries49.getDescription();
        org.jfree.data.time.Year year53 = org.jfree.data.time.Year.parseYear("100");
        int int54 = year53.getYear();
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass61 = month60.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month60.previous();
        java.lang.Class<?> wildcardClass63 = regularTimePeriod62.getClass();
        boolean boolean64 = fixedMillisecond57.equals((java.lang.Object) regularTimePeriod62);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries49.getDataItem(regularTimePeriod62);
        timeSeries41.add(timeSeriesDataItem65);
        java.lang.String str67 = timeSeries41.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries7.addAndOrUpdate(timeSeries41);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int72 = month71.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month71, 0.0d);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries41.addOrUpdate(timeSeriesDataItem74);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2020" + "'", str33.equals("2020"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 100 + "'", int37 == 100);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(class50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(year53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 100 + "'", int54 == 100);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2020" + "'", str67.equals("2020"));
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 100 + "'", int72 == 100);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        long long7 = day6.getSerialIndex();
        long long8 = day6.getFirstMillisecond();
        int int9 = day6.getYear();
        int int10 = day6.getYear();
        org.jfree.data.time.SerialDate serialDate11 = day6.getSerialDate();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-57600000L) + "'", long8 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.lang.String str4 = month2.toString();
        java.util.Calendar calendar5 = null;
        try {
            month2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "October 100" + "'", str4.equals("October 100"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        int int25 = timeSeriesDataItem23.compareTo((java.lang.Object) 3);
        java.lang.Number number26 = timeSeriesDataItem23.getValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (-1) + "'", number26.equals((-1)));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = year1.getStart();
        long long4 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62104204800000L) + "'", long4 == (-62104204800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        long long6 = month2.getSerialIndex();
        long long7 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1210L + "'", long6 == 1210L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1210L + "'", long7 == 1210L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getMonth();
//        int int3 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        java.lang.Class class27 = timeSeries7.getTimePeriodClass();
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize(class27);
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize(class27);
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize(class29);
        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize(class29);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo32 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) class31, seriesChangeInfo32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNotNull(class31);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        long long7 = day6.getSerialIndex();
        long long8 = day6.getFirstMillisecond();
        long long9 = day6.getLastMillisecond();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        java.lang.String str12 = regularTimePeriod11.toString();
        java.util.Date date13 = regularTimePeriod11.getStart();
        boolean boolean14 = day6.equals((java.lang.Object) regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-57600000L) + "'", long8 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2020" + "'", str12.equals("2020"));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener10);
        java.lang.String str12 = timeSeries7.getDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int16 = month15.getYearValue();
        java.util.Date date17 = month15.getEnd();
        boolean boolean19 = month15.equals((java.lang.Object) 'a');
        long long20 = month15.getLastMillisecond();
        int int21 = month15.getYearValue();
        java.util.Date date22 = month15.getEnd();
        java.lang.Number number23 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month15.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-58985251200001L) + "'", long20 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-9999L) + "'", long3 == (-9999L));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        java.util.Date date11 = month7.getStart();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month7);
        boolean boolean14 = month7.equals((java.lang.Object) 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        java.lang.String str15 = timeSeries7.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener16);
        java.lang.Class class18 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int22 = month21.getYearValue();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "2020", "2020");
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        java.lang.String str28 = timeSeries26.getDescription();
        org.jfree.data.time.Year year30 = org.jfree.data.time.Year.parseYear("100");
        int int31 = year30.getYear();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass38 = month37.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month37.previous();
        java.lang.Class<?> wildcardClass40 = regularTimePeriod39.getClass();
        boolean boolean41 = fixedMillisecond34.equals((java.lang.Object) regularTimePeriod39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries26.getDataItem(regularTimePeriod39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeriesDataItem42.getPeriod();
        java.lang.Object obj44 = timeSeriesDataItem42.clone();
        try {
            timeSeries7.add(timeSeriesDataItem42);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 100 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2020" + "'", str15.equals("2020"));
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(obj44);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        java.lang.String str33 = timeSeries7.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo35 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond34, seriesChangeInfo35);
        int int37 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.Calendar calendar38 = null;
        fixedMillisecond34.peg(calendar38);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int43 = month42.getYearValue();
        java.util.Date date44 = month42.getEnd();
        boolean boolean46 = month42.equals((java.lang.Object) 'a');
        java.lang.String str47 = month42.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month42.next();
        boolean boolean49 = fixedMillisecond34.equals((java.lang.Object) month42);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2020" + "'", str33.equals("2020"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 100 + "'", int43 == 100);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "October 100" + "'", str47.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        long long6 = month2.getSerialIndex();
        org.jfree.data.time.Year year7 = month2.getYear();
        java.util.Calendar calendar8 = null;
        try {
            year7.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1210L + "'", long6 == 1210L);
        org.junit.Assert.assertNotNull(year7);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        timeSeries7.clear();
        timeSeries7.setDomainDescription("January 0");
        timeSeries7.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date3 = month2.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        java.lang.Class<?> wildcardClass5 = date3.getClass();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        long long8 = month2.getLastMillisecond();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date12 = month11.getStart();
        int int13 = month2.compareTo((java.lang.Object) month11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        java.util.Date date17 = year15.getStart();
        long long18 = year15.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year15.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod19, (double) (-61946438400001L));
        boolean boolean22 = month11.equals((java.lang.Object) regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-58985251200001L) + "'", long8 == (-58985251200001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62104204800000L) + "'", long18 == (-62104204800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        int int9 = timeSeries7.getItemCount();
        timeSeries7.removeAgedItems(false);
        boolean boolean12 = timeSeries7.isEmpty();
        java.lang.String str13 = timeSeries7.getDomainDescription();
        timeSeries7.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2020" + "'", str13.equals("2020"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        timeSeries7.clear();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int29 = month28.getYearValue();
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month28, "2020", "2020");
        java.util.Collection collection34 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        java.lang.String str35 = timeSeries7.getDescription();
        int int36 = timeSeries7.getMaximumItemCount();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int40 = month39.getYearValue();
        java.util.Date date41 = month39.getEnd();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month39, "2020", "2020");
        java.lang.String str45 = timeSeries44.getDescription();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month49.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month49.previous();
        int int52 = year46.compareTo((java.lang.Object) regularTimePeriod51);
        boolean boolean53 = timeSeries44.equals((java.lang.Object) regularTimePeriod51);
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int57 = month56.getYearValue();
        java.util.Date date58 = month56.getEnd();
        long long59 = month56.getSerialIndex();
        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) month56, (java.lang.Number) 6L);
        java.lang.Comparable comparable62 = timeSeries44.getKey();
        boolean boolean64 = timeSeries44.equals((java.lang.Object) 9223372036854775807L);
        java.lang.String str65 = timeSeries44.getRangeDescription();
        timeSeries44.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries7.addAndOrUpdate(timeSeries44);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 100 + "'", int29 == 100);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2147483647 + "'", int36 == 2147483647);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 100 + "'", int40 == 100);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 100 + "'", int57 == 100);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1210L + "'", long59 == 1210L);
        org.junit.Assert.assertNotNull(comparable62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "2020" + "'", str65.equals("2020"));
        org.junit.Assert.assertNotNull(timeSeries68);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        java.lang.String str33 = timeSeries7.getDescription();
        double double34 = timeSeries7.getMinY();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + (-1.0d) + "'", double34 == (-1.0d));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        java.lang.String str25 = month19.toString();
        int int26 = month19.getMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "October 100" + "'", str25.equals("October 100"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.Year year16 = org.jfree.data.time.Year.parseYear("100");
        int int17 = year16.getYear();
        int int18 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int22 = month21.getYearValue();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "2020", "2020");
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int31 = month30.getYearValue();
        java.util.Date date32 = month30.getEnd();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "2020", "2020");
        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
        java.lang.String str37 = timeSeries35.getDescription();
        timeSeries35.setRangeDescription("2020");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int43 = month42.getYearValue();
        boolean boolean45 = month42.equals((java.lang.Object) (short) 10);
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) month42, (double) (-58987929600000L), false);
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month42, (double) (byte) -1, true);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) 2019, false);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = month57.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = month57.next();
        long long60 = month57.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month57, (java.lang.Number) 1546329600000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month57.previous();
        long long64 = month57.getLastMillisecond();
        java.util.Calendar calendar65 = null;
        try {
            long long66 = month57.getFirstMillisecond(calendar65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(class36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 100 + "'", int43 == 100);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1L + "'", long60 == 1L);
        org.junit.Assert.assertNull(timeSeriesDataItem62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-62133062400001L) + "'", long64 == (-62133062400001L));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener10);
        java.lang.String str12 = timeSeries7.getDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int16 = month15.getYearValue();
        java.util.Date date17 = month15.getEnd();
        boolean boolean19 = month15.equals((java.lang.Object) 'a');
        long long20 = month15.getLastMillisecond();
        int int21 = month15.getYearValue();
        java.util.Date date22 = month15.getEnd();
        java.lang.Number number23 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str24 = timeSeries7.getDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-58985251200001L) + "'", long20 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        long long15 = year11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.next();
        java.lang.Object obj17 = null;
        boolean boolean18 = year11.equals(obj17);
        java.lang.String str19 = year11.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-59011603200000L) + "'", long15 == (-59011603200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        timeSeries7.removeAgedItems(6L, true);
        boolean boolean41 = timeSeries7.isEmpty();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries7.addOrUpdate(timeSeriesDataItem42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        java.lang.Object obj33 = timeSeries7.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(0L);
        long long36 = fixedMillisecond35.getFirstMillisecond();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int40 = month39.getYearValue();
        java.util.Date date41 = month39.getEnd();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month39, "2020", "2020");
        java.lang.Class class45 = timeSeries44.getTimePeriodClass();
        java.lang.String str46 = timeSeries44.getDescription();
        org.jfree.data.time.Year year48 = org.jfree.data.time.Year.parseYear("100");
        int int49 = year48.getYear();
        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass56 = month55.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month55.previous();
        java.lang.Class<?> wildcardClass58 = regularTimePeriod57.getClass();
        boolean boolean59 = fixedMillisecond52.equals((java.lang.Object) regularTimePeriod57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries44.getDataItem(regularTimePeriod57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = timeSeriesDataItem60.getPeriod();
        int int62 = fixedMillisecond35.compareTo((java.lang.Object) regularTimePeriod61);
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int66 = month65.getYearValue();
        java.util.Date date67 = month65.getEnd();
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month65, "2020", "2020");
        java.lang.Class class71 = timeSeries70.getTimePeriodClass();
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = year72.next();
        timeSeries70.delete((org.jfree.data.time.RegularTimePeriod) year72);
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(6);
        timeSeries70.add((org.jfree.data.time.RegularTimePeriod) year76, (double) 1210L, false);
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (org.jfree.data.time.RegularTimePeriod) year76);
        timeSeries80.removeAgedItems(1L, true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 100 + "'", int40 == 100);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNull(class45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(year48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 100 + "'", int49 == 100);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem60);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 100 + "'", int66 == 100);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNull(class71);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(timeSeries80);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond0, seriesChangeInfo1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo4);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo6);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = seriesChangeEvent2.getSummary();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(seriesChangeInfo8);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener34);
        boolean boolean36 = timeSeries7.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
        long long41 = fixedMillisecond38.getSerialIndex();
        long long42 = fixedMillisecond38.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        java.lang.Number number44 = timeSeriesDataItem43.getValue();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj48 = null;
        int int49 = fixedMillisecond47.compareTo(obj48);
        boolean boolean50 = day45.equals((java.lang.Object) int49);
        org.jfree.data.time.SerialDate serialDate51 = day45.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(serialDate51);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean55 = timeSeriesDataItem43.equals((java.lang.Object) serialDate51);
        java.lang.Number number56 = timeSeriesDataItem43.getValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 1560150000000L + "'", number44.equals(1560150000000L));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 1560150000000L + "'", number56.equals(1560150000000L));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, (int) (short) 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        long long4 = month2.getFirstMillisecond();
        int int5 = month2.getMonth();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-58987929600000L) + "'", long4 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = month7.getMiddleMillisecond();
        long long12 = month7.getSerialIndex();
        java.lang.String str13 = month7.toString();
        long long14 = month7.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-58986590400001L) + "'", long11 == (-58986590400001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1210L + "'", long12 == 1210L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "October 100" + "'", str13.equals("October 100"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58987929600000L) + "'", long14 == (-58987929600000L));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj3 = null;
        int int4 = fixedMillisecond2.compareTo(obj3);
        boolean boolean5 = day0.equals((java.lang.Object) int4);
        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6);
        timeSeries7.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(serialDate6);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj3 = null;
//        int int4 = fixedMillisecond2.compareTo(obj3);
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        long long8 = day0.getFirstMillisecond();
//        int int9 = day0.getMonth();
//        long long10 = day0.getSerialIndex();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) long10, seriesChangeInfo11);
//        java.lang.Object obj13 = seriesChangeEvent12.getSource();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//        org.junit.Assert.assertTrue("'" + obj13 + "' != '" + 43626L + "'", obj13.equals(43626L));
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = month7.getMiddleMillisecond();
        long long12 = month7.getSerialIndex();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int16 = month15.getYearValue();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month15, "2020", "2020");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int24 = month23.getYearValue();
        java.util.Date date25 = month23.getEnd();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month23, "2020", "2020");
        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
        java.lang.String str30 = timeSeries28.getDescription();
        org.jfree.data.time.Year year32 = org.jfree.data.time.Year.parseYear("100");
        int int33 = year32.getYear();
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass40 = month39.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month39.previous();
        java.lang.Class<?> wildcardClass42 = regularTimePeriod41.getClass();
        boolean boolean43 = fixedMillisecond36.equals((java.lang.Object) regularTimePeriod41);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries28.getDataItem(regularTimePeriod41);
        timeSeries20.add(timeSeriesDataItem44);
        java.lang.String str46 = timeSeries20.getDomainDescription();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int50 = month49.getYearValue();
        java.util.Date date51 = month49.getEnd();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month49, "2020", "2020");
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int58 = month57.getYearValue();
        java.util.Date date59 = month57.getEnd();
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month57, "2020", "2020");
        java.lang.Class class63 = timeSeries62.getTimePeriodClass();
        java.lang.String str64 = timeSeries62.getDescription();
        org.jfree.data.time.Year year66 = org.jfree.data.time.Year.parseYear("100");
        int int67 = year66.getYear();
        timeSeries62.add((org.jfree.data.time.RegularTimePeriod) year66, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass74 = month73.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = month73.previous();
        java.lang.Class<?> wildcardClass76 = regularTimePeriod75.getClass();
        boolean boolean77 = fixedMillisecond70.equals((java.lang.Object) regularTimePeriod75);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = timeSeries62.getDataItem(regularTimePeriod75);
        timeSeries54.add(timeSeriesDataItem78);
        java.lang.String str80 = timeSeries54.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries20.addAndOrUpdate(timeSeries54);
        java.lang.Comparable comparable82 = timeSeries20.getKey();
        boolean boolean83 = month7.equals((java.lang.Object) timeSeries20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (-58983955200001L));
        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = year87.next();
        java.util.Date date89 = year87.getStart();
        java.util.Date date90 = year87.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond91 = new org.jfree.data.time.FixedMillisecond(date90);
        int int92 = timeSeriesDataItem85.compareTo((java.lang.Object) fixedMillisecond91);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-58986590400001L) + "'", long11 == (-58986590400001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1210L + "'", long12 == 1210L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(class29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 100 + "'", int33 == 100);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "2020" + "'", str46.equals("2020"));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 100 + "'", int50 == 100);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 100 + "'", int58 == 100);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNull(class63);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(year66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 100 + "'", int67 == 100);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem78);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "2020" + "'", str80.equals("2020"));
        org.junit.Assert.assertNotNull(timeSeries81);
        org.junit.Assert.assertNotNull(comparable82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod88);
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertNotNull(date90);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        timeSeries7.clear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int28 = month27.getYearValue();
        long long29 = month27.getFirstMillisecond();
        java.lang.Number number30 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date34 = month33.getStart();
        long long35 = month33.getSerialIndex();
        java.lang.String str36 = month33.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month33, (double) 1);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int42 = month41.getYearValue();
        java.util.Date date43 = month41.getEnd();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month41, "2020", "2020");
        java.lang.Class class47 = timeSeries46.getTimePeriodClass();
        java.lang.String str48 = timeSeries46.getDescription();
        timeSeries46.setRangeDescription("2020");
        int int51 = timeSeries46.getItemCount();
        timeSeries46.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.Year year55 = org.jfree.data.time.Year.parseYear("100");
        int int56 = year55.getYear();
        int int57 = timeSeries46.getIndex((org.jfree.data.time.RegularTimePeriod) year55);
        int int58 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year55);
        try {
            timeSeries7.update(9999, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-58987929600000L) + "'", long29 == (-58987929600000L));
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "January 0" + "'", str36.equals("January 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(class47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(year55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 100 + "'", int56 == 100);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj3 = null;
        int int4 = fixedMillisecond2.compareTo(obj3);
        boolean boolean5 = day0.equals((java.lang.Object) int4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
        int int7 = day0.getYear();
        int int8 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day0.previous();
        org.jfree.data.time.SerialDate serialDate10 = day0.getSerialDate();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1));
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = seriesChangeEvent1.getSummary();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertNull(seriesChangeInfo2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=-1]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=-1]"));
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int7 = month6.getYearValue();
//        java.util.Date date8 = month6.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "2020", "2020");
//        java.lang.String str12 = timeSeries11.getDescription();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.previous();
//        int int19 = year13.compareTo((java.lang.Object) regularTimePeriod18);
//        boolean boolean20 = timeSeries11.equals((java.lang.Object) regularTimePeriod18);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int24 = month23.getYearValue();
//        java.util.Date date25 = month23.getEnd();
//        long long26 = month23.getSerialIndex();
//        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) 6L);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries11.addChangeListener(seriesChangeListener29);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries11.getDataItem((int) (short) 0);
//        int int33 = day0.compareTo((java.lang.Object) (short) 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1210L + "'", long26 == 1210L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(6);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year13, (double) 1210L, false);
        int int17 = timeSeries7.getMaximumItemCount();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int21 = month20.getYearValue();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20, "2020", "2020");
        java.lang.Class class26 = timeSeries25.getTimePeriodClass();
        java.lang.String str27 = timeSeries25.getDescription();
        org.jfree.data.time.Year year29 = org.jfree.data.time.Year.parseYear("100");
        int int30 = year29.getYear();
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass37 = month36.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month36.previous();
        java.lang.Class<?> wildcardClass39 = regularTimePeriod38.getClass();
        boolean boolean40 = fixedMillisecond33.equals((java.lang.Object) regularTimePeriod38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries25.getDataItem(regularTimePeriod38);
        java.lang.Object obj42 = timeSeriesDataItem41.clone();
        timeSeriesDataItem41.setValue((java.lang.Number) 1.0f);
        boolean boolean45 = timeSeriesDataItem41.isSelected();
        timeSeries7.add(timeSeriesDataItem41);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int50 = month49.getYearValue();
        java.util.Date date51 = month49.getEnd();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month49, "2020", "2020");
        java.lang.Class class55 = timeSeries54.getTimePeriodClass();
        java.lang.String str56 = timeSeries54.getDescription();
        org.jfree.data.time.Year year58 = org.jfree.data.time.Year.parseYear("100");
        int int59 = year58.getYear();
        timeSeries54.add((org.jfree.data.time.RegularTimePeriod) year58, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass66 = month65.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = month65.previous();
        java.lang.Class<?> wildcardClass68 = regularTimePeriod67.getClass();
        boolean boolean69 = fixedMillisecond62.equals((java.lang.Object) regularTimePeriod67);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries54.getDataItem(regularTimePeriod67);
        long long71 = timeSeries54.getMaximumItemAge();
        timeSeries54.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timeSeries54.removePropertyChangeListener(propertyChangeListener74);
        java.beans.PropertyChangeListener propertyChangeListener76 = null;
        timeSeries54.addPropertyChangeListener(propertyChangeListener76);
        java.lang.String str78 = timeSeries54.getDescription();
        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries7.addAndOrUpdate(timeSeries54);
        try {
            java.lang.Number number81 = timeSeries54.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(class26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 100 + "'", int50 == 100);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNull(class55);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNotNull(year58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 100 + "'", int59 == 100);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem70);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 9223372036854775807L + "'", long71 == 9223372036854775807L);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertNotNull(timeSeries79);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.lang.Object obj0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent(obj0, seriesChangeInfo1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month7.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long11 = fixedMillisecond10.getFirstMillisecond();
        long long12 = fixedMillisecond10.getSerialIndex();
        long long13 = fixedMillisecond10.getFirstMillisecond();
        long long14 = fixedMillisecond10.getFirstMillisecond();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) (-1), true);
        java.util.Calendar calendar18 = null;
        fixedMillisecond10.peg(calendar18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond10.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        java.lang.Object obj25 = timeSeriesDataItem23.clone();
        timeSeriesDataItem23.setSelected(false);
        boolean boolean28 = timeSeriesDataItem23.isSelected();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int32 = month31.getYearValue();
        java.util.Date date33 = month31.getEnd();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month31, "2020", "2020");
        java.lang.Class class37 = timeSeries36.getTimePeriodClass();
        java.lang.String str38 = timeSeries36.getDescription();
        timeSeries36.setRangeDescription("2020");
        int int41 = timeSeries36.getItemCount();
        int int42 = timeSeriesDataItem23.compareTo((java.lang.Object) timeSeries36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeriesDataItem23.getPeriod();
        java.lang.Object obj44 = timeSeriesDataItem23.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(class37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(obj44);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("10-June-2019");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: 10-June-2019" + "'", str2.equals("org.jfree.data.general.SeriesException: 10-June-2019"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        timeSeries7.clear();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int28 = month27.getYearValue();
        long long29 = month27.getFirstMillisecond();
        java.lang.Number number30 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date34 = month33.getStart();
        long long35 = month33.getSerialIndex();
        java.lang.String str36 = month33.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month33, (double) 1);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int42 = month41.getYearValue();
        java.util.Date date43 = month41.getEnd();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month41, "2020", "2020");
        java.lang.Class class47 = timeSeries46.getTimePeriodClass();
        java.lang.String str48 = timeSeries46.getDescription();
        timeSeries46.setRangeDescription("2020");
        int int51 = timeSeries46.getItemCount();
        timeSeries46.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.Year year55 = org.jfree.data.time.Year.parseYear("100");
        int int56 = year55.getYear();
        int int57 = timeSeries46.getIndex((org.jfree.data.time.RegularTimePeriod) year55);
        int int58 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year55.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-58987929600000L) + "'", long29 == (-58987929600000L));
        org.junit.Assert.assertNull(number30);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "January 0" + "'", str36.equals("January 0"));
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNull(class47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(year55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 100 + "'", int56 == 100);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        try {
            timeSeries7.delete(100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("100");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("100");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("100");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("10-June-2019");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException9);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
//        int int12 = year11.getYear();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
//        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
//        long long24 = timeSeries7.getMaximumItemAge();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj31 = null;
//        int int32 = fixedMillisecond30.compareTo(obj31);
//        boolean boolean33 = day28.equals((java.lang.Object) int32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.next();
//        int int35 = day28.getYear();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int40 = month39.getYearValue();
//        java.util.Date date41 = month39.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month39, "2020", "2020");
//        java.lang.Class class45 = timeSeries44.getTimePeriodClass();
//        java.lang.String str46 = timeSeries44.getDescription();
//        org.jfree.data.time.Year year48 = org.jfree.data.time.Year.parseYear("100");
//        int int49 = year48.getYear();
//        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass56 = month55.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month55.previous();
//        java.lang.Class<?> wildcardClass58 = regularTimePeriod57.getClass();
//        boolean boolean59 = fixedMillisecond52.equals((java.lang.Object) regularTimePeriod57);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries44.getDataItem(regularTimePeriod57);
//        long long61 = timeSeries44.getMaximumItemAge();
//        timeSeries44.setNotify(false);
//        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = month66.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = month66.next();
//        timeSeries44.update(regularTimePeriod68, (java.lang.Number) 1560150000000L);
//        java.util.Collection collection71 = timeSeries44.getTimePeriods();
//        boolean boolean72 = timeSeries44.getNotify();
//        double double73 = timeSeries44.getMaxY();
//        boolean boolean74 = day28.equals((java.lang.Object) double73);
//        java.lang.String str75 = day28.toString();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 100 + "'", int40 == 100);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(class45);
//        org.junit.Assert.assertNull(str46);
//        org.junit.Assert.assertNotNull(year48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 100 + "'", int49 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem60);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 9223372036854775807L + "'", long61 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(collection71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.56015E12d + "'", double73 == 1.56015E12d);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "10-June-2019" + "'", str75.equals("10-June-2019"));
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long11 = fixedMillisecond10.getFirstMillisecond();
        long long12 = fixedMillisecond10.getSerialIndex();
        long long13 = fixedMillisecond10.getFirstMillisecond();
        long long14 = fixedMillisecond10.getFirstMillisecond();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) (-1), true);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) true, "2", "");
        long long21 = timeSeries20.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        java.lang.Object obj25 = timeSeriesDataItem23.clone();
        timeSeriesDataItem23.setSelected(false);
        boolean boolean28 = timeSeriesDataItem23.isSelected();
        boolean boolean29 = timeSeriesDataItem23.isSelected();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        boolean boolean5 = month2.equals((java.lang.Object) (short) 10);
        java.util.Date date6 = month2.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        int int8 = year7.getYear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        timeSeries7.removeAgedItems(false);
        timeSeries7.setRangeDescription("October 100");
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month39);
        java.util.List list41 = timeSeries7.getItems();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(list41);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int7 = month6.getYearValue();
        java.util.Date date8 = month6.getEnd();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, "2020", "2020");
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        java.lang.String str13 = timeSeries11.getDescription();
        org.jfree.data.time.Year year15 = org.jfree.data.time.Year.parseYear("100");
        int int16 = year15.getYear();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) (-1));
        timeSeries11.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long25 = fixedMillisecond24.getSerialIndex();
        java.util.Date date26 = fixedMillisecond24.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date26);
        boolean boolean28 = year22.equals((java.lang.Object) date26);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) year22, (double) 1969, false);
        boolean boolean32 = fixedMillisecond1.equals((java.lang.Object) timeSeries11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("100");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("100");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("2");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 10L);
        int int17 = timeSeries7.getMaximumItemCount();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int21 = month20.getYearValue();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20, "2020", "2020");
        java.lang.Class class26 = timeSeries25.getTimePeriodClass();
        java.lang.String str27 = timeSeries25.getDescription();
        org.jfree.data.time.Year year29 = org.jfree.data.time.Year.parseYear("100");
        int int30 = year29.getYear();
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass37 = month36.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month36.previous();
        java.lang.Class<?> wildcardClass39 = regularTimePeriod38.getClass();
        boolean boolean40 = fixedMillisecond33.equals((java.lang.Object) regularTimePeriod38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries25.getDataItem(regularTimePeriod38);
        long long42 = timeSeries25.getMaximumItemAge();
        timeSeries25.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timeSeries25.removePropertyChangeListener(propertyChangeListener45);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        timeSeries25.setKey((java.lang.Comparable) year47);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year47, (double) 4, false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(class26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9223372036854775807L + "'", long42 == 9223372036854775807L);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
//        java.lang.Object obj7 = timeSeriesDataItem5.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem5.getPeriod();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj12 = null;
//        int int13 = fixedMillisecond11.compareTo(obj12);
//        boolean boolean14 = day9.equals((java.lang.Object) int13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day9.next();
//        int int16 = timeSeriesDataItem5.compareTo((java.lang.Object) day9);
//        long long17 = day9.getFirstMillisecond();
//        java.util.Calendar calendar18 = null;
//        try {
//            day9.peg(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 10, seriesChangeInfo1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        java.lang.String str4 = seriesChangeEvent2.toString();
        java.lang.Object obj5 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo6);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = seriesChangeEvent2.getSummary();
        java.lang.Object obj9 = seriesChangeEvent2.getSource();
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (byte) 10 + "'", obj3.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (byte) 10 + "'", obj5.equals((byte) 10));
        org.junit.Assert.assertNull(seriesChangeInfo8);
        org.junit.Assert.assertTrue("'" + obj9 + "' != '" + (byte) 10 + "'", obj9.equals((byte) 10));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("October 100");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: October 100" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: October 100"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        java.util.Date date5 = month2.getStart();
        long long6 = month2.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1210L + "'", long6 == 1210L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        double double17 = timeSeries7.getMinY();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int21 = month20.getYearValue();
        java.util.Date date22 = month20.getEnd();
        boolean boolean24 = month20.equals((java.lang.Object) 'a');
        long long25 = month20.getLastMillisecond();
        int int26 = month20.getYearValue();
        java.util.Date date27 = month20.getEnd();
        org.jfree.data.time.Year year28 = month20.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long31 = fixedMillisecond30.getFirstMillisecond();
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond30.getFirstMillisecond(calendar32);
        int int34 = year28.compareTo((java.lang.Object) calendar32);
        java.lang.String str35 = year28.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year28.next();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year28, 0.0d);
        double double39 = timeSeries7.getMinY();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-58985251200001L) + "'", long25 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "100" + "'", str35.equals("100"));
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        java.lang.Class class27 = timeSeries7.getTimePeriodClass();
        boolean boolean28 = timeSeries7.getNotify();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
        try {
            org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        java.lang.String str33 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int37 = month36.getYearValue();
        java.util.Date date38 = month36.getEnd();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month36, "2020", "2020");
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int45 = month44.getYearValue();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month44, "2020", "2020");
        java.lang.Class class50 = timeSeries49.getTimePeriodClass();
        java.lang.String str51 = timeSeries49.getDescription();
        org.jfree.data.time.Year year53 = org.jfree.data.time.Year.parseYear("100");
        int int54 = year53.getYear();
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass61 = month60.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month60.previous();
        java.lang.Class<?> wildcardClass63 = regularTimePeriod62.getClass();
        boolean boolean64 = fixedMillisecond57.equals((java.lang.Object) regularTimePeriod62);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries49.getDataItem(regularTimePeriod62);
        timeSeries41.add(timeSeriesDataItem65);
        java.lang.String str67 = timeSeries41.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries7.addAndOrUpdate(timeSeries41);
        timeSeries68.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2020" + "'", str33.equals("2020"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 100 + "'", int37 == 100);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(class50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(year53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 100 + "'", int54 == 100);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2020" + "'", str67.equals("2020"));
        org.junit.Assert.assertNotNull(timeSeries68);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        boolean boolean6 = timeSeriesDataItem5.isSelected();
        java.lang.Class<?> wildcardClass7 = timeSeriesDataItem5.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        long long6 = month2.getMiddleMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int10 = month9.getYearValue();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "2020", "2020");
        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
        java.lang.String str16 = timeSeries14.getDescription();
        timeSeries14.setRangeDescription("2020");
        int int19 = timeSeries14.getItemCount();
        timeSeries14.setMaximumItemCount((int) (short) 1);
        java.util.Collection collection22 = timeSeries14.getTimePeriods();
        java.lang.Object obj23 = timeSeries14.clone();
        int int24 = month2.compareTo(obj23);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-58986590400001L) + "'", long6 == (-58986590400001L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(class15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj3 = null;
//        int int4 = fixedMillisecond2.compareTo(obj3);
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        long long7 = day0.getSerialIndex();
//        long long8 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560193199999L + "'", long8 == 1560193199999L);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        timeSeries7.removeAgedItems(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries7.addChangeListener(seriesChangeListener29);
        timeSeries7.removeAgedItems(false);
        java.util.List list33 = timeSeries7.getItems();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertNotNull(list33);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        java.lang.Object obj29 = timeSeries7.clone();
        timeSeries7.removeAgedItems(false);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass35 = month34.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month34.previous();
        java.util.Date date37 = month34.getStart();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date37);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month39.next();
        boolean boolean43 = timeSeries7.equals((java.lang.Object) month39);
        java.util.Calendar calendar44 = null;
        try {
            long long45 = month39.getLastMillisecond(calendar44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "2", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        int int9 = timeSeries7.getItemCount();
        timeSeries7.setDescription("October 100");
        int int12 = timeSeries7.getMaximumItemCount();
        timeSeries7.setDomainDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.next();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) '4', true);
        long long21 = fixedMillisecond16.getSerialIndex();
        long long22 = fixedMillisecond16.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = fixedMillisecond1.getSerialIndex();
        long long12 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener34);
        boolean boolean36 = timeSeries7.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
        long long41 = fixedMillisecond38.getSerialIndex();
        long long42 = fixedMillisecond38.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        java.util.List list44 = timeSeries7.getItems();
        try {
            timeSeries7.delete((int) (byte) -1, 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(list44);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj3 = null;
        int int4 = fixedMillisecond2.compareTo(obj3);
        boolean boolean5 = day0.equals((java.lang.Object) int4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
        int int7 = day0.getYear();
        int int8 = day0.getMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-9999));
        long long2 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9999L) + "'", long2 == (-9999L));
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        long long3 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        long long9 = month2.getFirstMillisecond();
        long long10 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year11 = month2.getYear();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year11.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-58987929600000L) + "'", long10 == (-58987929600000L));
        org.junit.Assert.assertNotNull(year11);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        boolean boolean29 = timeSeries7.isEmpty();
        timeSeries7.removeAgedItems(28799999L, false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        timeSeries7.removeAgedItems(6L, true);
        boolean boolean41 = timeSeries7.isEmpty();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int45 = month44.getYearValue();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month44, "2020", "2020");
        java.lang.String str50 = timeSeries49.getDescription();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = month54.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month54.previous();
        int int57 = year51.compareTo((java.lang.Object) regularTimePeriod56);
        boolean boolean58 = timeSeries49.equals((java.lang.Object) regularTimePeriod56);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int62 = month61.getYearValue();
        java.util.Date date63 = month61.getEnd();
        long long64 = month61.getSerialIndex();
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) month61, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener67 = null;
        timeSeries49.addChangeListener(seriesChangeListener67);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int72 = month71.getYearValue();
        java.util.Date date73 = month71.getEnd();
        boolean boolean75 = month71.equals((java.lang.Object) 'a');
        java.lang.String str76 = month71.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = month71.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries49.addOrUpdate(regularTimePeriod77, (java.lang.Number) 9);
        timeSeries49.removeAgedItems(6L, true);
        boolean boolean83 = timeSeries49.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries7.addAndOrUpdate(timeSeries49);
        timeSeries7.removeAgedItems(6L, false);
        int int88 = timeSeries7.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 100 + "'", int62 == 100);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1210L + "'", long64 == 1210L);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 100 + "'", int72 == 100);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "October 100" + "'", str76.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertNull(timeSeriesDataItem79);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(timeSeries84);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 2147483647 + "'", int88 == 2147483647);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(10L);
        int int40 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
        java.util.Calendar calendar41 = null;
        fixedMillisecond39.peg(calendar41);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        java.util.Date date11 = month7.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date11);
        java.lang.String str15 = year14.toString();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100" + "'", str15.equals("100"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        timeSeries7.setNotify(true);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int22 = month21.getYearValue();
        java.util.Date date23 = month21.getEnd();
        boolean boolean25 = month21.equals((java.lang.Object) 'a');
        long long26 = month21.getLastMillisecond();
        int int27 = month21.getYearValue();
        long long28 = month21.getFirstMillisecond();
        long long29 = month21.getFirstMillisecond();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month21, (double) (-1L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-58985251200001L) + "'", long26 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 100 + "'", int27 == 100);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-58987929600000L) + "'", long28 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-58987929600000L) + "'", long29 == (-58987929600000L));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = fixedMillisecond1.getSerialIndex();
        long long12 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond1.previous();
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond1.getLastMillisecond(calendar14);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
//        timeSeries5.removeAgedItems(true);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        org.jfree.data.time.Year year14 = org.jfree.data.time.Year.parseYear("100");
        boolean boolean15 = timeSeries7.equals((java.lang.Object) "100");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (byte) 100);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int21 = month20.getYearValue();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20, "2020", "2020");
        long long26 = month20.getLastMillisecond();
        int int27 = year17.compareTo((java.lang.Object) month20);
        int int28 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year17.previous();
        java.lang.Class<?> wildcardClass30 = year17.getClass();
        java.util.Calendar calendar31 = null;
        try {
            long long32 = year17.getFirstMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-58985251200001L) + "'", long26 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-58986590400001L));
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        java.util.Date date5 = year3.getStart();
        long long6 = year3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year3.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long10 = fixedMillisecond9.getFirstMillisecond();
        long long11 = fixedMillisecond9.getSerialIndex();
        long long12 = fixedMillisecond9.getFirstMillisecond();
        long long13 = fixedMillisecond9.getFirstMillisecond();
        long long14 = fixedMillisecond9.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long17 = fixedMillisecond16.getSerialIndex();
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond16.getMiddleMillisecond(calendar18);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass23 = month22.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month22.previous();
        boolean boolean25 = fixedMillisecond16.equals((java.lang.Object) month22);
        java.util.Date date26 = month22.getStart();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
        boolean boolean28 = fixedMillisecond9.equals((java.lang.Object) date26);
        int int29 = year3.compareTo((java.lang.Object) date26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year3, (double) 43626L);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo32 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1, seriesChangeInfo32);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62104204800000L) + "'", long6 == (-62104204800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        int int15 = year9.compareTo((java.lang.Object) year12);
        long long16 = year12.getLastMillisecond();
        java.lang.String str17 = year12.toString();
        long long18 = year12.getSerialIndex();
        int int19 = year12.getYear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        int int9 = timeSeries7.getItemCount();
        timeSeries7.setDescription("October 100");
        int int12 = timeSeries7.getMaximumItemCount();
        timeSeries7.setDomainDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.next();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) '4', true);
        java.util.Date date21 = fixedMillisecond16.getTime();
        java.util.TimeZone timeZone22 = null;
        java.util.Locale locale23 = null;
        try {
            org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21, timeZone22, locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: October 100");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int15 = month14.getYearValue();
        java.util.Date date16 = month14.getEnd();
        boolean boolean18 = month14.equals((java.lang.Object) 'a');
        long long19 = month14.getLastMillisecond();
        int int20 = month14.getYearValue();
        java.util.Date date21 = month14.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (-62150212800001L));
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 1.0f, true);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeries7.getTimePeriod((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-58985251200001L) + "'", long19 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond1, seriesChangeInfo4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Date date3 = day0.getEnd();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        timeSeries7.removeAgedItems(6L, true);
        boolean boolean41 = timeSeries7.isEmpty();
        int int42 = timeSeries7.getMaximumItemCount();
        double double43 = timeSeries7.getMinY();
        timeSeries7.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2147483647 + "'", int42 == 2147483647);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 6.0d + "'", double43 == 6.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        timeSeries7.setMaximumItemAge(1560150000000L);
        java.lang.String str30 = timeSeries7.getRangeDescription();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int34 = month33.getYearValue();
        java.util.Date date35 = month33.getEnd();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month33, "2020", "2020");
        java.lang.Class class39 = timeSeries38.getTimePeriodClass();
        java.lang.String str40 = timeSeries38.getDescription();
        timeSeries38.setRangeDescription("2020");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int46 = month45.getYearValue();
        boolean boolean48 = month45.equals((java.lang.Object) (short) 10);
        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) month45, (double) (-58987929600000L), false);
        timeSeries38.setKey((java.lang.Comparable) (-58985251200001L));
        try {
            org.jfree.data.time.TimeSeries timeSeries54 = timeSeries7.addAndOrUpdate(timeSeries38);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2020" + "'", str30.equals("2020"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(class39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 100 + "'", int46 == 100);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int5 = month4.getYearValue();
        java.util.Date date6 = month4.getEnd();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "2020", "2020");
        long long10 = month4.getLastMillisecond();
        int int11 = year1.compareTo((java.lang.Object) month4);
        int int12 = year1.getYear();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-58985251200001L) + "'", long10 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj3 = null;
        int int4 = fixedMillisecond2.compareTo(obj3);
        boolean boolean5 = day0.equals((java.lang.Object) int4);
        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.next();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.lang.String str6 = year5.toString();
        java.util.Calendar calendar7 = null;
        try {
            year5.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        timeSeries7.setMaximumItemAge(1560150000000L);
        java.lang.String str30 = timeSeries7.getRangeDescription();
        java.lang.Object obj31 = timeSeries7.clone();
        boolean boolean32 = timeSeries7.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long35 = fixedMillisecond34.getFirstMillisecond();
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond34.getFirstMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond34.getEnd();
        long long39 = fixedMillisecond34.getFirstMillisecond();
        java.lang.String str40 = fixedMillisecond34.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond34.next();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year((-1));
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (org.jfree.data.time.RegularTimePeriod) year43);
        java.util.Calendar calendar45 = null;
        fixedMillisecond34.peg(calendar45);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2020" + "'", str30.equals("2020"));
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str40.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeries44);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date7 = month6.getStart();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date7, timeZone9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date7);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone13 = null;
        try {
            org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date7, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.time.Year year25 = month19.getYear();
        long long26 = year25.getSerialIndex();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo28 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 10, seriesChangeInfo28);
        java.lang.Object obj30 = seriesChangeEvent29.getSource();
        java.lang.String str31 = seriesChangeEvent29.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo32 = null;
        seriesChangeEvent29.setSummary(seriesChangeInfo32);
        java.lang.Object obj34 = seriesChangeEvent29.getSource();
        boolean boolean35 = year25.equals(obj34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertTrue("'" + obj30 + "' != '" + (byte) 10 + "'", obj30.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str31.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + obj34 + "' != '" + (byte) 10 + "'", obj34.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int5 = month4.getYearValue();
//        java.util.Date date6 = month4.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4, "2020", "2020");
//        java.lang.String str10 = timeSeries9.getDescription();
//        timeSeries9.removeAgedItems(false);
//        boolean boolean13 = day0.equals((java.lang.Object) timeSeries9);
//        org.jfree.data.time.SerialDate serialDate14 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(serialDate14);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        timeSeries7.setMaximumItemAge(1560150000000L);
        java.lang.String str30 = timeSeries7.getRangeDescription();
        java.lang.Object obj31 = timeSeries7.clone();
        boolean boolean32 = timeSeries7.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long35 = fixedMillisecond34.getFirstMillisecond();
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond34.getFirstMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond34.getEnd();
        long long39 = fixedMillisecond34.getFirstMillisecond();
        java.lang.String str40 = fixedMillisecond34.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond34.next();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year((-1));
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (org.jfree.data.time.RegularTimePeriod) year43);
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond34.getFirstMillisecond(calendar45);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2020" + "'", str30.equals("2020"));
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str40.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 10L + "'", long46 == 10L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        java.lang.Comparable comparable25 = timeSeries7.getKey();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo26 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) comparable25, seriesChangeInfo26);
        java.lang.Object obj28 = seriesChangeEvent27.getSource();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertNotNull(comparable25);
        org.junit.Assert.assertNotNull(obj28);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        java.lang.Object obj15 = timeSeries7.clone();
        boolean boolean16 = timeSeries7.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener17);
        timeSeries7.setNotify(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getMiddleMillisecond(calendar6);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int9 = month8.getYearValue();
//        java.util.Date date10 = month8.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month8, "2020", "2020");
//        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
//        java.lang.String str15 = timeSeries13.getDescription();
//        timeSeries13.setRangeDescription("2020");
//        int int18 = timeSeries13.getItemCount();
//        timeSeries13.setMaximumItemCount((int) (short) 1);
//        java.lang.Object obj21 = timeSeries13.clone();
//        int int22 = day0.compareTo(obj21);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(class14);
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        double double17 = timeSeries7.getMinY();
        double double18 = timeSeries7.getMaxY();
        timeSeries7.setRangeDescription("");
        try {
            timeSeries7.setMaximumItemAge((-58985251200001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("100");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("100");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("100");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str8 = timePeriodFormatException5.toString();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 100" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: 100"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        java.lang.Object obj5 = null;
        int int6 = month2.compareTo(obj5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        java.util.Date date5 = month2.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem9.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem9.getPeriod();
        timeSeriesDataItem9.setSelected(false);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month11.previous();
        int int14 = year8.compareTo((java.lang.Object) regularTimePeriod13);
        boolean boolean15 = month2.equals((java.lang.Object) int14);
        int int16 = month2.getMonth();
        long long17 = month2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-58985251200001L) + "'", long17 == (-58985251200001L));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getEnd();
        java.lang.Number number6 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number6);
        long long8 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.Year year16 = org.jfree.data.time.Year.parseYear("100");
        int int17 = year16.getYear();
        int int18 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int22 = month21.getYearValue();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "2020", "2020");
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        java.lang.String str28 = timeSeries26.getDescription();
        org.jfree.data.time.Year year30 = org.jfree.data.time.Year.parseYear("100");
        int int31 = year30.getYear();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass38 = month37.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month37.previous();
        java.lang.Class<?> wildcardClass40 = regularTimePeriod39.getClass();
        boolean boolean41 = fixedMillisecond34.equals((java.lang.Object) regularTimePeriod39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries26.getDataItem(regularTimePeriod39);
        long long43 = timeSeries26.getMaximumItemAge();
        timeSeries26.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timeSeries26.removePropertyChangeListener(propertyChangeListener46);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        timeSeries26.setKey((java.lang.Comparable) year48);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 1562097599999L, false);
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int56 = month55.getYearValue();
        java.util.Date date57 = month55.getEnd();
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month55, "2020", "2020");
        java.lang.Class class61 = timeSeries60.getTimePeriodClass();
        java.lang.String str62 = timeSeries60.getDescription();
        org.jfree.data.time.Year year64 = org.jfree.data.time.Year.parseYear("100");
        int int65 = year64.getYear();
        timeSeries60.add((org.jfree.data.time.RegularTimePeriod) year64, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass72 = month71.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = month71.previous();
        java.lang.Class<?> wildcardClass74 = regularTimePeriod73.getClass();
        boolean boolean75 = fixedMillisecond68.equals((java.lang.Object) regularTimePeriod73);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries60.getDataItem(regularTimePeriod73);
        long long77 = timeSeries60.getMaximumItemAge();
        timeSeries60.setRangeDescription("January 0");
        double double80 = timeSeries60.getMaxY();
        int int81 = timeSeries60.getItemCount();
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = year83.next();
        java.util.Date date85 = year83.getStart();
        timeSeries60.add((org.jfree.data.time.RegularTimePeriod) year83, (java.lang.Number) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year83, (java.lang.Number) 10L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036854775807L + "'", long43 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 100 + "'", int56 == 100);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNull(class61);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertNotNull(year64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem76);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 9223372036854775807L + "'", long77 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + (-1.0d) + "'", double80 == (-1.0d));
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNull(timeSeriesDataItem89);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        java.util.Date date9 = month2.getEnd();
        org.jfree.data.time.Year year10 = month2.getYear();
        long long11 = year10.getSerialIndex();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int15 = month14.getYearValue();
        java.util.Date date16 = month14.getEnd();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14, "2020", "2020");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int23 = month22.getYearValue();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month22, "2020", "2020");
        java.lang.Class class28 = timeSeries27.getTimePeriodClass();
        java.lang.String str29 = timeSeries27.getDescription();
        org.jfree.data.time.Year year31 = org.jfree.data.time.Year.parseYear("100");
        int int32 = year31.getYear();
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass39 = month38.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month38.previous();
        java.lang.Class<?> wildcardClass41 = regularTimePeriod40.getClass();
        boolean boolean42 = fixedMillisecond35.equals((java.lang.Object) regularTimePeriod40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries27.getDataItem(regularTimePeriod40);
        timeSeries19.add(timeSeriesDataItem43);
        java.lang.String str45 = timeSeries19.getDomainDescription();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int49 = month48.getYearValue();
        java.util.Date date50 = month48.getEnd();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month48, "2020", "2020");
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int57 = month56.getYearValue();
        java.util.Date date58 = month56.getEnd();
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month56, "2020", "2020");
        java.lang.Class class62 = timeSeries61.getTimePeriodClass();
        java.lang.String str63 = timeSeries61.getDescription();
        org.jfree.data.time.Year year65 = org.jfree.data.time.Year.parseYear("100");
        int int66 = year65.getYear();
        timeSeries61.add((org.jfree.data.time.RegularTimePeriod) year65, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass73 = month72.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = month72.previous();
        java.lang.Class<?> wildcardClass75 = regularTimePeriod74.getClass();
        boolean boolean76 = fixedMillisecond69.equals((java.lang.Object) regularTimePeriod74);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries61.getDataItem(regularTimePeriod74);
        timeSeries53.add(timeSeriesDataItem77);
        java.lang.String str79 = timeSeries53.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries19.addAndOrUpdate(timeSeries53);
        boolean boolean81 = year10.equals((java.lang.Object) timeSeries80);
        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long84 = fixedMillisecond83.getSerialIndex();
        java.util.Calendar calendar85 = null;
        long long86 = fixedMillisecond83.getMiddleMillisecond(calendar85);
        org.jfree.data.time.Month month89 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass90 = month89.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = month89.previous();
        boolean boolean92 = fixedMillisecond83.equals((java.lang.Object) month89);
        long long93 = month89.getMiddleMillisecond();
        long long94 = month89.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem96 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month89, (double) 6L);
        try {
            timeSeries80.add(timeSeriesDataItem96, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(class28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2020" + "'", str45.equals("2020"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 100 + "'", int49 == 100);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 100 + "'", int57 == 100);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNull(class62);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(year65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 100 + "'", int66 == 100);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem77);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "2020" + "'", str79.equals("2020"));
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 10L + "'", long84 == 10L);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 10L + "'", long86 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass90);
        org.junit.Assert.assertNotNull(regularTimePeriod91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + long93 + "' != '" + (-58986590400001L) + "'", long93 == (-58986590400001L));
        org.junit.Assert.assertTrue("'" + long94 + "' != '" + (-58985251200001L) + "'", long94 == (-58985251200001L));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener34);
        java.lang.Object obj36 = timeSeries7.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = null;
        try {
            timeSeries7.add(regularTimePeriod37, 10.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        timeSeries7.removeAgedItems(6L, true);
        boolean boolean41 = timeSeries7.isEmpty();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int45 = month44.getYearValue();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month44, "2020", "2020");
        java.lang.String str50 = timeSeries49.getDescription();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = month54.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = month54.previous();
        int int57 = year51.compareTo((java.lang.Object) regularTimePeriod56);
        boolean boolean58 = timeSeries49.equals((java.lang.Object) regularTimePeriod56);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int62 = month61.getYearValue();
        java.util.Date date63 = month61.getEnd();
        long long64 = month61.getSerialIndex();
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) month61, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener67 = null;
        timeSeries49.addChangeListener(seriesChangeListener67);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int72 = month71.getYearValue();
        java.util.Date date73 = month71.getEnd();
        boolean boolean75 = month71.equals((java.lang.Object) 'a');
        java.lang.String str76 = month71.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = month71.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = timeSeries49.addOrUpdate(regularTimePeriod77, (java.lang.Number) 9);
        timeSeries49.removeAgedItems(6L, true);
        boolean boolean83 = timeSeries49.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries7.addAndOrUpdate(timeSeries49);
        timeSeries7.removeAgedItems(6L, false);
        timeSeries7.setKey((java.lang.Comparable) 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 100 + "'", int62 == 100);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1210L + "'", long64 == 1210L);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 100 + "'", int72 == 100);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "October 100" + "'", str76.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertNull(timeSeriesDataItem79);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(timeSeries84);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        java.lang.Object obj15 = timeSeries7.clone();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries7.addChangeListener(seriesChangeListener16);
        java.util.List list18 = timeSeries7.getItems();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.time.Year year25 = month19.getYear();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month19.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setRangeDescription("January 0");
        double double27 = timeSeries7.getMaxY();
        int int28 = timeSeries7.getItemCount();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.next();
        java.util.Date date32 = year30.getStart();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) 100L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries7.removeChangeListener(seriesChangeListener35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-1.0d) + "'", double27 == (-1.0d));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        int int15 = year9.compareTo((java.lang.Object) year12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year12.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date3 = month2.getStart();
        long long4 = month2.getSerialIndex();
        java.lang.String str5 = month2.toString();
        java.lang.String str6 = month2.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January 0" + "'", str5.equals("January 0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "January 0" + "'", str6.equals("January 0"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        java.lang.Comparable comparable25 = timeSeries7.getKey();
        boolean boolean27 = timeSeries7.equals((java.lang.Object) 9223372036854775807L);
        java.lang.String str28 = timeSeries7.getRangeDescription();
        double double29 = timeSeries7.getMaxY();
        timeSeries7.setMaximumItemAge(0L);
        java.util.List list32 = timeSeries7.getItems();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertNotNull(comparable25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2020" + "'", str28.equals("2020"));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 6.0d + "'", double29 == 6.0d);
        org.junit.Assert.assertNotNull(list32);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        timeSeries7.setMaximumItemAge(1560150000000L);
        java.lang.String str30 = timeSeries7.getRangeDescription();
        double double31 = timeSeries7.getMinY();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2020" + "'", str30.equals("2020"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-1.0d) + "'", double31 == (-1.0d));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj3 = null;
        int int4 = fixedMillisecond2.compareTo(obj3);
        boolean boolean5 = day0.equals((java.lang.Object) int4);
        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        java.lang.Object obj25 = timeSeriesDataItem23.clone();
        timeSeriesDataItem23.setSelected(false);
        boolean boolean28 = timeSeriesDataItem23.isSelected();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int32 = month31.getYearValue();
        java.util.Date date33 = month31.getEnd();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month31, "2020", "2020");
        java.lang.Class class37 = timeSeries36.getTimePeriodClass();
        java.lang.String str38 = timeSeries36.getDescription();
        timeSeries36.setRangeDescription("2020");
        int int41 = timeSeries36.getItemCount();
        int int42 = timeSeriesDataItem23.compareTo((java.lang.Object) timeSeries36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = timeSeriesDataItem23.getPeriod();
        timeSeriesDataItem23.setValue((java.lang.Number) 9L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(class37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(43626L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        long long7 = day6.getSerialIndex();
        java.lang.Object obj8 = null;
        boolean boolean9 = day6.equals(obj8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long14 = fixedMillisecond13.getSerialIndex();
        java.util.Date date15 = fixedMillisecond13.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
        boolean boolean17 = year11.equals((java.lang.Object) date15);
        int int18 = day6.compareTo((java.lang.Object) boolean17);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2147483647, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        java.lang.Object obj25 = timeSeriesDataItem23.clone();
        timeSeriesDataItem23.setSelected(false);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int31 = month30.getYearValue();
        java.util.Date date32 = month30.getEnd();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "2020", "2020");
        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
        java.lang.String str37 = timeSeries35.getDescription();
        org.jfree.data.time.Year year39 = org.jfree.data.time.Year.parseYear("100");
        int int40 = year39.getYear();
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass47 = month46.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month46.previous();
        java.lang.Class<?> wildcardClass49 = regularTimePeriod48.getClass();
        boolean boolean50 = fixedMillisecond43.equals((java.lang.Object) regularTimePeriod48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries35.getDataItem(regularTimePeriod48);
        long long52 = timeSeries35.getMaximumItemAge();
        timeSeries35.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timeSeries35.removePropertyChangeListener(propertyChangeListener55);
        java.beans.PropertyChangeListener propertyChangeListener57 = null;
        timeSeries35.addPropertyChangeListener(propertyChangeListener57);
        timeSeries35.setDescription("2020");
        boolean boolean61 = timeSeriesDataItem23.equals((java.lang.Object) "2020");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = timeSeriesDataItem23.getPeriod();
        java.lang.Object obj63 = timeSeriesDataItem23.clone();
        timeSeriesDataItem23.setValue((java.lang.Number) 28799999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(class36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(year39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 100 + "'", int40 == 100);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 9223372036854775807L + "'", long52 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(obj63);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        java.lang.String str33 = timeSeries7.getDomainDescription();
        timeSeries7.setRangeDescription("October 100");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2020" + "'", str33.equals("2020"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        java.lang.Object obj27 = timeSeries7.clone();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int31 = month30.getYearValue();
        java.util.Date date32 = month30.getEnd();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "2020", "2020");
        java.lang.String str36 = timeSeries35.getDescription();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month40.previous();
        int int43 = year37.compareTo((java.lang.Object) regularTimePeriod42);
        boolean boolean44 = timeSeries35.equals((java.lang.Object) regularTimePeriod42);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int48 = month47.getYearValue();
        java.util.Date date49 = month47.getEnd();
        long long50 = month47.getSerialIndex();
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) month47, (java.lang.Number) 6L);
        java.lang.Comparable comparable53 = timeSeries35.getKey();
        boolean boolean55 = timeSeries35.equals((java.lang.Object) 9223372036854775807L);
        java.lang.String str56 = timeSeries35.getRangeDescription();
        double double57 = timeSeries35.getMaxY();
        double double58 = timeSeries35.getMaxY();
        try {
            org.jfree.data.time.TimeSeries timeSeries59 = timeSeries7.addAndOrUpdate(timeSeries35);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 100 + "'", int48 == 100);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1210L + "'", long50 == 1210L);
        org.junit.Assert.assertNotNull(comparable53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "2020" + "'", str56.equals("2020"));
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 6.0d + "'", double57 == 6.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 6.0d + "'", double58 == 6.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        java.lang.String str7 = month2.toString();
        long long8 = month2.getSerialIndex();
        long long9 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "October 100" + "'", str7.equals("October 100"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1210L + "'", long8 == 1210L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        java.util.Date date9 = month2.getEnd();
        org.jfree.data.time.Year year10 = month2.getYear();
        long long11 = year10.getSerialIndex();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int15 = month14.getYearValue();
        java.util.Date date16 = month14.getEnd();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month14, "2020", "2020");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int23 = month22.getYearValue();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month22, "2020", "2020");
        java.lang.Class class28 = timeSeries27.getTimePeriodClass();
        java.lang.String str29 = timeSeries27.getDescription();
        org.jfree.data.time.Year year31 = org.jfree.data.time.Year.parseYear("100");
        int int32 = year31.getYear();
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass39 = month38.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month38.previous();
        java.lang.Class<?> wildcardClass41 = regularTimePeriod40.getClass();
        boolean boolean42 = fixedMillisecond35.equals((java.lang.Object) regularTimePeriod40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries27.getDataItem(regularTimePeriod40);
        timeSeries19.add(timeSeriesDataItem43);
        java.lang.String str45 = timeSeries19.getDomainDescription();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int49 = month48.getYearValue();
        java.util.Date date50 = month48.getEnd();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month48, "2020", "2020");
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int57 = month56.getYearValue();
        java.util.Date date58 = month56.getEnd();
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month56, "2020", "2020");
        java.lang.Class class62 = timeSeries61.getTimePeriodClass();
        java.lang.String str63 = timeSeries61.getDescription();
        org.jfree.data.time.Year year65 = org.jfree.data.time.Year.parseYear("100");
        int int66 = year65.getYear();
        timeSeries61.add((org.jfree.data.time.RegularTimePeriod) year65, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass73 = month72.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = month72.previous();
        java.lang.Class<?> wildcardClass75 = regularTimePeriod74.getClass();
        boolean boolean76 = fixedMillisecond69.equals((java.lang.Object) regularTimePeriod74);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries61.getDataItem(regularTimePeriod74);
        timeSeries53.add(timeSeriesDataItem77);
        java.lang.String str79 = timeSeries53.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries19.addAndOrUpdate(timeSeries53);
        boolean boolean81 = year10.equals((java.lang.Object) timeSeries80);
        java.lang.Comparable comparable82 = timeSeries80.getKey();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(class28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2020" + "'", str45.equals("2020"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 100 + "'", int49 == 100);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 100 + "'", int57 == 100);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNull(class62);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(year65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 100 + "'", int66 == 100);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem77);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "2020" + "'", str79.equals("2020"));
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + comparable82 + "' != '" + "Overwritten values from: October 100" + "'", comparable82.equals("Overwritten values from: October 100"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
        long long7 = fixedMillisecond6.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, 0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date7 = month6.getStart();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date7, timeZone9);
        java.util.TimeZone timeZone11 = null;
        try {
            org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date7, timeZone11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) 'a');
        java.lang.Class<?> wildcardClass2 = year1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = fixedMillisecond1.getFirstMillisecond();
        long long12 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int16 = month15.getYearValue();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month15, "2020", "2020");
        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
        java.lang.String str22 = timeSeries20.getDescription();
        org.jfree.data.time.Year year24 = org.jfree.data.time.Year.parseYear("100");
        int int25 = year24.getYear();
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass32 = month31.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month31.previous();
        java.lang.Class<?> wildcardClass34 = regularTimePeriod33.getClass();
        boolean boolean35 = fixedMillisecond28.equals((java.lang.Object) regularTimePeriod33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries20.getDataItem(regularTimePeriod33);
        long long37 = timeSeries20.getMaximumItemAge();
        timeSeries20.setNotify(false);
        java.lang.Object obj40 = timeSeries20.clone();
        int int41 = fixedMillisecond1.compareTo((java.lang.Object) timeSeries20);
        timeSeries20.setMaximumItemAge(1546329600000L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long46 = fixedMillisecond45.getSerialIndex();
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond45.getMiddleMillisecond(calendar47);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass52 = month51.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = month51.previous();
        boolean boolean54 = fixedMillisecond45.equals((java.lang.Object) month51);
        long long55 = fixedMillisecond45.getSerialIndex();
        long long56 = fixedMillisecond45.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long59 = fixedMillisecond58.getFirstMillisecond();
        boolean boolean60 = fixedMillisecond45.equals((java.lang.Object) fixedMillisecond58);
        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass64 = month63.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = month63.previous();
        java.util.Date date66 = month63.getStart();
        int int67 = month63.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (org.jfree.data.time.RegularTimePeriod) month63);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException70 = new org.jfree.data.time.TimePeriodFormatException("100");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException72 = new org.jfree.data.time.TimePeriodFormatException("100");
        timePeriodFormatException70.addSuppressed((java.lang.Throwable) timePeriodFormatException72);
        java.lang.String str74 = timePeriodFormatException70.toString();
        boolean boolean75 = fixedMillisecond45.equals((java.lang.Object) timePeriodFormatException70);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 10L + "'", long46 == 10L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 10L + "'", long48 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 10L + "'", long55 == 10L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10L + "'", long59 == 10L);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 100 + "'", int67 == 100);
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 100" + "'", str74.equals("org.jfree.data.time.TimePeriodFormatException: 100"));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        java.lang.String str33 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int37 = month36.getYearValue();
        java.util.Date date38 = month36.getEnd();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month36, "2020", "2020");
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int45 = month44.getYearValue();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month44, "2020", "2020");
        java.lang.Class class50 = timeSeries49.getTimePeriodClass();
        java.lang.String str51 = timeSeries49.getDescription();
        org.jfree.data.time.Year year53 = org.jfree.data.time.Year.parseYear("100");
        int int54 = year53.getYear();
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass61 = month60.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month60.previous();
        java.lang.Class<?> wildcardClass63 = regularTimePeriod62.getClass();
        boolean boolean64 = fixedMillisecond57.equals((java.lang.Object) regularTimePeriod62);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries49.getDataItem(regularTimePeriod62);
        timeSeries41.add(timeSeriesDataItem65);
        java.lang.String str67 = timeSeries41.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries7.addAndOrUpdate(timeSeries41);
        java.lang.Comparable comparable69 = timeSeries7.getKey();
        java.beans.PropertyChangeListener propertyChangeListener70 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener70);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2020" + "'", str33.equals("2020"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 100 + "'", int37 == 100);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(class50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(year53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 100 + "'", int54 == 100);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2020" + "'", str67.equals("2020"));
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertNotNull(comparable69);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        java.lang.Object obj29 = timeSeries7.clone();
        timeSeries7.removeAgedItems(false);
        java.lang.String str32 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int36 = month35.getYearValue();
        java.util.Date date37 = month35.getEnd();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month35, "2020", "2020");
        java.lang.Class class41 = timeSeries40.getTimePeriodClass();
        java.lang.String str42 = timeSeries40.getDescription();
        org.jfree.data.time.Year year44 = org.jfree.data.time.Year.parseYear("100");
        int int45 = year44.getYear();
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass52 = month51.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = month51.previous();
        java.lang.Class<?> wildcardClass54 = regularTimePeriod53.getClass();
        boolean boolean55 = fixedMillisecond48.equals((java.lang.Object) regularTimePeriod53);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries40.getDataItem(regularTimePeriod53);
        long long57 = timeSeries40.getMaximumItemAge();
        timeSeries40.setNotify(false);
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month62.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = month62.next();
        timeSeries40.update(regularTimePeriod64, (java.lang.Number) 1560150000000L);
        java.beans.PropertyChangeListener propertyChangeListener67 = null;
        timeSeries40.removePropertyChangeListener(propertyChangeListener67);
        boolean boolean69 = timeSeries40.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar72 = null;
        long long73 = fixedMillisecond71.getLastMillisecond(calendar72);
        long long74 = fixedMillisecond71.getSerialIndex();
        long long75 = fixedMillisecond71.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries40.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond71);
        java.lang.Class<?> wildcardClass77 = timeSeriesDataItem76.getClass();
        try {
            timeSeries7.add(timeSeriesDataItem76);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 100 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2020" + "'", str32.equals("2020"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 100 + "'", int36 == 100);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(class41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(year44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem56);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 9223372036854775807L + "'", long57 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 10L + "'", long73 == 10L);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 10L + "'", long74 == 10L);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 10L + "'", long75 == 10L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem76);
        org.junit.Assert.assertNotNull(wildcardClass77);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        long long3 = fixedMillisecond1.getSerialIndex();
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getFirstMillisecond();
        long long6 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long9 = fixedMillisecond8.getSerialIndex();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond8.getMiddleMillisecond(calendar10);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass15 = month14.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.previous();
        boolean boolean17 = fixedMillisecond8.equals((java.lang.Object) month14);
        java.util.Date date18 = month14.getStart();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        boolean boolean20 = fixedMillisecond1.equals((java.lang.Object) date18);
        long long21 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Date date5 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        long long7 = day6.getSerialIndex();
        long long8 = day6.getFirstMillisecond();
        int int9 = day6.getYear();
        int int10 = day6.getYear();
        long long11 = day6.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-57600000L) + "'", long8 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setRangeDescription("January 0");
        double double27 = timeSeries7.getMaxY();
        int int28 = timeSeries7.getItemCount();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.next();
        java.util.Date date32 = year30.getStart();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) 100L);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener35);
        java.lang.String str37 = timeSeries7.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-1.0d) + "'", double27 == (-1.0d));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "January 0" + "'", str37.equals("January 0"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        java.util.Date date3 = month2.getStart();
        long long4 = month2.getSerialIndex();
        int int5 = month2.getMonth();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
//        int int12 = year11.getYear();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
//        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
//        long long24 = timeSeries7.getMaximumItemAge();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
//        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        java.lang.String str37 = day34.toString();
//        boolean boolean38 = timeSeries7.equals((java.lang.Object) str37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj42 = null;
//        int int43 = fixedMillisecond41.compareTo(obj42);
//        boolean boolean44 = day39.equals((java.lang.Object) int43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day39.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day39.next();
//        long long47 = day39.getFirstMillisecond();
//        int int48 = day39.getMonth();
//        timeSeries7.update((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) (-1L));
//        timeSeries7.setMaximumItemCount((int) (byte) 100);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        long long55 = fixedMillisecond54.getFirstMillisecond();
//        java.util.Calendar calendar56 = null;
//        long long57 = fixedMillisecond54.getFirstMillisecond(calendar56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond54.next();
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass62 = month61.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month61.previous();
//        java.util.Date date64 = month61.getStart();
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date64);
//        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month(date64);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month66, (java.lang.Number) 4);
//        long long69 = month66.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries7.createCopy(regularTimePeriod58, (org.jfree.data.time.RegularTimePeriod) month66);
//        timeSeries7.removeAgedItems(25568L, true);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560150000000L + "'", long47 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 10L + "'", long55 == 10L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1210L + "'", long69 == 1210L);
//        org.junit.Assert.assertNotNull(timeSeries70);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        timeSeries7.setMaximumItemAge(1560150000000L);
        java.lang.String str30 = timeSeries7.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj33 = null;
        int int34 = fixedMillisecond32.compareTo(obj33);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass38 = month37.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month37.previous();
        int int40 = fixedMillisecond32.compareTo((java.lang.Object) month37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month37);
        timeSeries7.removeAgedItems(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeries7.getNextTimePeriod();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2020" + "'", str30.equals("2020"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        org.jfree.data.time.Year year14 = org.jfree.data.time.Year.parseYear("100");
        boolean boolean15 = timeSeries7.equals((java.lang.Object) "100");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year((int) (byte) 100);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int21 = month20.getYearValue();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20, "2020", "2020");
        long long26 = month20.getLastMillisecond();
        int int27 = year17.compareTo((java.lang.Object) month20);
        int int28 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year17.previous();
        java.lang.Class<?> wildcardClass30 = year17.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long33 = fixedMillisecond32.getSerialIndex();
        long long34 = fixedMillisecond32.getLastMillisecond();
        boolean boolean36 = fixedMillisecond32.equals((java.lang.Object) (byte) 0);
        long long37 = fixedMillisecond32.getFirstMillisecond();
        java.util.Date date38 = fixedMillisecond32.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
        java.util.TimeZone timeZone40 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date38, timeZone40);
        java.util.TimeZone timeZone42 = null;
        try {
            org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date38, timeZone42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-58985251200001L) + "'", long26 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(regularTimePeriod41);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 0);
//        long long3 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year9);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(6);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year13, (double) 1210L, false);
        int int17 = timeSeries7.getMaximumItemCount();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int21 = month20.getYearValue();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20, "2020", "2020");
        java.lang.Class class26 = timeSeries25.getTimePeriodClass();
        java.lang.String str27 = timeSeries25.getDescription();
        org.jfree.data.time.Year year29 = org.jfree.data.time.Year.parseYear("100");
        int int30 = year29.getYear();
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass37 = month36.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month36.previous();
        java.lang.Class<?> wildcardClass39 = regularTimePeriod38.getClass();
        boolean boolean40 = fixedMillisecond33.equals((java.lang.Object) regularTimePeriod38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries25.getDataItem(regularTimePeriod38);
        java.lang.Object obj42 = timeSeriesDataItem41.clone();
        timeSeriesDataItem41.setValue((java.lang.Number) 1.0f);
        boolean boolean45 = timeSeriesDataItem41.isSelected();
        timeSeries7.add(timeSeriesDataItem41);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int50 = month49.getYearValue();
        java.util.Date date51 = month49.getEnd();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month49, "2020", "2020");
        java.lang.Class class55 = timeSeries54.getTimePeriodClass();
        java.lang.String str56 = timeSeries54.getDescription();
        org.jfree.data.time.Year year58 = org.jfree.data.time.Year.parseYear("100");
        int int59 = year58.getYear();
        timeSeries54.add((org.jfree.data.time.RegularTimePeriod) year58, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass66 = month65.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = month65.previous();
        java.lang.Class<?> wildcardClass68 = regularTimePeriod67.getClass();
        boolean boolean69 = fixedMillisecond62.equals((java.lang.Object) regularTimePeriod67);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries54.getDataItem(regularTimePeriod67);
        long long71 = timeSeries54.getMaximumItemAge();
        timeSeries54.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener74 = null;
        timeSeries54.removePropertyChangeListener(propertyChangeListener74);
        java.beans.PropertyChangeListener propertyChangeListener76 = null;
        timeSeries54.addPropertyChangeListener(propertyChangeListener76);
        java.lang.String str78 = timeSeries54.getDescription();
        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries7.addAndOrUpdate(timeSeries54);
        timeSeries7.update((int) (short) 0, (java.lang.Number) 2147483647);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(class26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 100 + "'", int50 == 100);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNull(class55);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNotNull(year58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 100 + "'", int59 == 100);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem70);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 9223372036854775807L + "'", long71 == 9223372036854775807L);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertNotNull(timeSeries79);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getSerialIndex();
        int int6 = month2.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(31, 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        int int12 = timeSeries7.getItemCount();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.Year year16 = org.jfree.data.time.Year.parseYear("100");
        int int17 = year16.getYear();
        int int18 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int22 = month21.getYearValue();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month21, "2020", "2020");
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int31 = month30.getYearValue();
        java.util.Date date32 = month30.getEnd();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "2020", "2020");
        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
        java.lang.String str37 = timeSeries35.getDescription();
        timeSeries35.setRangeDescription("2020");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int43 = month42.getYearValue();
        boolean boolean45 = month42.equals((java.lang.Object) (short) 10);
        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) month42, (double) (-58987929600000L), false);
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month42, (double) (byte) -1, true);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) 2019, false);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = month57.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = month57.next();
        long long60 = month57.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month57, (java.lang.Number) 1546329600000L);
        long long63 = month57.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(class36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 100 + "'", int43 == 100);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1L + "'", long60 == 1L);
        org.junit.Assert.assertNull(timeSeriesDataItem62);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1L + "'", long63 == 1L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass3 = month2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        java.util.Date date5 = month2.getStart();
        long long6 = month2.getLastMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-58985251200001L) + "'", long6 == (-58985251200001L));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.Year year5 = org.jfree.data.time.Year.parseYear("100");
        int int6 = month2.compareTo((java.lang.Object) "100");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        boolean boolean4 = day2.equals((java.lang.Object) 0);
        int int5 = year1.compareTo((java.lang.Object) boolean4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.previous();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int10 = month9.getYearValue();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "2020", "2020");
        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
        java.lang.String str16 = timeSeries14.getDescription();
        org.jfree.data.time.Year year18 = org.jfree.data.time.Year.parseYear("100");
        int int19 = year18.getYear();
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass26 = month25.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month25.previous();
        java.lang.Class<?> wildcardClass28 = regularTimePeriod27.getClass();
        boolean boolean29 = fixedMillisecond22.equals((java.lang.Object) regularTimePeriod27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries14.getDataItem(regularTimePeriod27);
        long long31 = timeSeries14.getMaximumItemAge();
        timeSeries14.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = timeSeries14.getNextTimePeriod();
        timeSeries14.fireSeriesChanged();
        timeSeries14.setMaximumItemCount((int) (short) 0);
        int int38 = year1.compareTo((java.lang.Object) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(class15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year9);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(class12);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj3 = null;
        int int4 = fixedMillisecond2.compareTo(obj3);
        boolean boolean5 = day0.equals((java.lang.Object) int4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
        java.util.Calendar calendar7 = null;
        try {
            day0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        timeSeries7.removeAgedItems(6L, true);
        boolean boolean41 = timeSeries7.isEmpty();
        int int42 = timeSeries7.getMaximumItemCount();
        double double43 = timeSeries7.getMinY();
        timeSeries7.setNotify(false);
        java.lang.Class<?> wildcardClass46 = timeSeries7.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2147483647 + "'", int42 == 2147483647);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 6.0d + "'", double43 == 6.0d);
        org.junit.Assert.assertNotNull(wildcardClass46);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        int int9 = timeSeries7.getItemCount();
        timeSeries7.removeAgedItems(false);
        boolean boolean12 = timeSeries7.isEmpty();
        timeSeries7.removeAgedItems((long) (short) 100, true);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int21 = month20.getYearValue();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20, "2020", "2020");
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int29 = month28.getYearValue();
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month28, "2020", "2020");
        java.lang.Class class34 = timeSeries33.getTimePeriodClass();
        java.lang.String str35 = timeSeries33.getDescription();
        org.jfree.data.time.Year year37 = org.jfree.data.time.Year.parseYear("100");
        int int38 = year37.getYear();
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year37, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass45 = month44.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month44.previous();
        java.lang.Class<?> wildcardClass47 = regularTimePeriod46.getClass();
        boolean boolean48 = fixedMillisecond41.equals((java.lang.Object) regularTimePeriod46);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries33.getDataItem(regularTimePeriod46);
        timeSeries25.add(timeSeriesDataItem49);
        java.lang.String str51 = timeSeries25.getDomainDescription();
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int55 = month54.getYearValue();
        java.util.Date date56 = month54.getEnd();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month54, "2020", "2020");
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int63 = month62.getYearValue();
        java.util.Date date64 = month62.getEnd();
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month62, "2020", "2020");
        java.lang.Class class68 = timeSeries67.getTimePeriodClass();
        java.lang.String str69 = timeSeries67.getDescription();
        org.jfree.data.time.Year year71 = org.jfree.data.time.Year.parseYear("100");
        int int72 = year71.getYear();
        timeSeries67.add((org.jfree.data.time.RegularTimePeriod) year71, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass79 = month78.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = month78.previous();
        java.lang.Class<?> wildcardClass81 = regularTimePeriod80.getClass();
        boolean boolean82 = fixedMillisecond75.equals((java.lang.Object) regularTimePeriod80);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem83 = timeSeries67.getDataItem(regularTimePeriod80);
        timeSeries59.add(timeSeriesDataItem83);
        java.lang.String str85 = timeSeries59.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries86 = timeSeries25.addAndOrUpdate(timeSeries59);
        java.lang.Class class87 = timeSeries59.getTimePeriodClass();
        org.jfree.data.time.Year year89 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month92 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = month92.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = month92.previous();
        int int95 = year89.compareTo((java.lang.Object) regularTimePeriod94);
        org.jfree.data.time.Month month96 = new org.jfree.data.time.Month(8, year89);
        org.jfree.data.time.Year year97 = month96.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem98 = timeSeries59.getDataItem((org.jfree.data.time.RegularTimePeriod) month96);
        timeSeries7.setKey((java.lang.Comparable) timeSeriesDataItem98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 100 + "'", int29 == 100);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNull(class34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(year37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 100 + "'", int38 == 100);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2020" + "'", str51.equals("2020"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 100 + "'", int55 == 100);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 100 + "'", int63 == 100);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNull(class68);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNotNull(year71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 100 + "'", int72 == 100);
        org.junit.Assert.assertNotNull(wildcardClass79);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem83);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "2020" + "'", str85.equals("2020"));
        org.junit.Assert.assertNotNull(timeSeries86);
        org.junit.Assert.assertNotNull(class87);
        org.junit.Assert.assertNotNull(regularTimePeriod93);
        org.junit.Assert.assertNull(regularTimePeriod94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1 + "'", int95 == 1);
        org.junit.Assert.assertNotNull(year97);
        org.junit.Assert.assertNotNull(timeSeriesDataItem98);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Wed Dec 31 16:00:00 PST 1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = fixedMillisecond1.getFirstMillisecond();
        long long12 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int16 = month15.getYearValue();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month15, "2020", "2020");
        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
        java.lang.String str22 = timeSeries20.getDescription();
        org.jfree.data.time.Year year24 = org.jfree.data.time.Year.parseYear("100");
        int int25 = year24.getYear();
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass32 = month31.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month31.previous();
        java.lang.Class<?> wildcardClass34 = regularTimePeriod33.getClass();
        boolean boolean35 = fixedMillisecond28.equals((java.lang.Object) regularTimePeriod33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries20.getDataItem(regularTimePeriod33);
        long long37 = timeSeries20.getMaximumItemAge();
        timeSeries20.setNotify(false);
        java.lang.Object obj40 = timeSeries20.clone();
        int int41 = fixedMillisecond1.compareTo((java.lang.Object) timeSeries20);
        try {
            timeSeries20.setMaximumItemAge((-58987929600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.lang.String str34 = timeSeries7.getDomainDescription();
        java.lang.Object obj35 = timeSeries7.clone();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener36);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2020" + "'", str34.equals("2020"));
        org.junit.Assert.assertNotNull(obj35);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        double double17 = timeSeries7.getMinY();
        java.lang.Comparable comparable18 = timeSeries7.getKey();
        try {
            timeSeries7.delete(7, (int) '4', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(comparable18);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 10, seriesChangeInfo1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        java.lang.String str4 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo5);
        java.lang.String str7 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo8);
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (byte) 10 + "'", obj3.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str7.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = month7.getMiddleMillisecond();
        long long12 = month7.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (double) 6L);
        java.lang.Class<?> wildcardClass15 = month7.getClass();
        org.jfree.data.time.Year year16 = month7.getYear();
        long long17 = year16.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-58986590400001L) + "'", long11 == (-58986590400001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-58985251200001L) + "'", long12 == (-58985251200001L));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        timeSeries7.removeAgedItems(6L, true);
        boolean boolean41 = timeSeries7.isEmpty();
        int int42 = timeSeries7.getMaximumItemCount();
        double double43 = timeSeries7.getMinY();
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int47 = month46.getYearValue();
        java.util.Date date48 = month46.getEnd();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month46, "2020", "2020");
        java.lang.Class class52 = timeSeries51.getTimePeriodClass();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year53.next();
        timeSeries51.delete((org.jfree.data.time.RegularTimePeriod) year53);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year56.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year56.previous();
        int int59 = year53.compareTo((java.lang.Object) year56);
        timeSeries7.update((org.jfree.data.time.RegularTimePeriod) year56, (java.lang.Number) 1.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2147483647 + "'", int42 == 2147483647);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 6.0d + "'", double43 == 6.0d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 100 + "'", int47 == 100);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNull(class52);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.util.Collection collection34 = timeSeries7.getTimePeriods();
        boolean boolean35 = timeSeries7.getNotify();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month40.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month40.previous();
        int int43 = year37.compareTo((java.lang.Object) regularTimePeriod42);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(8, year37);
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) month44);
        boolean boolean46 = timeSeries7.isEmpty();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2020");
        org.junit.Assert.assertNotNull(year1);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.String str8 = timeSeries7.getDescription();
//        int int9 = timeSeries7.getItemCount();
//        timeSeries7.removeAgedItems(false);
//        boolean boolean12 = timeSeries7.isEmpty();
//        timeSeries7.removeAgedItems((long) (short) 100, true);
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries7.addPropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int21 = month20.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month20, 0.0d);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.lang.String str25 = day24.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day24.next();
//        int int27 = timeSeriesDataItem23.compareTo((java.lang.Object) day24);
//        try {
//            timeSeries7.update((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) 1.56015E12d);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        int int9 = timeSeries7.getItemCount();
        timeSeries7.removeAgedItems(false);
        boolean boolean12 = timeSeries7.isEmpty();
        java.lang.String str13 = timeSeries7.getDomainDescription();
        try {
            java.lang.Number number15 = timeSeries7.getValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2020" + "'", str13.equals("2020"));
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.String str8 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
//        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
//        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int20 = month19.getYearValue();
//        java.util.Date date21 = month19.getEnd();
//        long long22 = month19.getSerialIndex();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
//        timeSeries7.clear();
//        timeSeries7.setDomainDescription("January 0");
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.next();
//        long long30 = day28.getFirstMillisecond();
//        int int31 = day28.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day28.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(0L);
//        long long35 = fixedMillisecond34.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries7.createCopy(regularTimePeriod32, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        long long37 = timeSeries7.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries7.createCopy(0, 10);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560150000000L + "'", long30 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries40);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        timeSeries7.setMaximumItemAge(1560150000000L);
        java.lang.String str30 = timeSeries7.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj33 = null;
        int int34 = fixedMillisecond32.compareTo(obj33);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass38 = month37.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month37.previous();
        int int40 = fixedMillisecond32.compareTo((java.lang.Object) month37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month37);
        timeSeries7.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long46 = fixedMillisecond45.getFirstMillisecond();
        long long47 = fixedMillisecond45.getSerialIndex();
        long long48 = fixedMillisecond45.getFirstMillisecond();
        long long49 = fixedMillisecond45.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((-58986590400001L));
        boolean boolean52 = fixedMillisecond45.equals((java.lang.Object) fixedMillisecond51);
        long long53 = fixedMillisecond51.getFirstMillisecond();
        int int54 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2020" + "'", str30.equals("2020"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 10L + "'", long46 == 10L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 10L + "'", long47 == 10L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 10L + "'", long48 == 10L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 10L + "'", long49 == 10L);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-58986590400001L) + "'", long53 == (-58986590400001L));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        boolean boolean5 = month2.equals((java.lang.Object) (short) 10);
        java.util.Date date6 = month2.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.String str16 = timeSeries15.getDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month20.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month20.previous();
        int int23 = year17.compareTo((java.lang.Object) regularTimePeriod22);
        boolean boolean24 = timeSeries15.equals((java.lang.Object) regularTimePeriod22);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int28 = month27.getYearValue();
        java.util.Date date29 = month27.getEnd();
        long long30 = month27.getSerialIndex();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 6L);
        java.lang.Comparable comparable33 = timeSeries15.getKey();
        boolean boolean35 = timeSeries15.equals((java.lang.Object) 9223372036854775807L);
        int int36 = year7.compareTo((java.lang.Object) timeSeries15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long39 = fixedMillisecond38.getSerialIndex();
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond38.getMiddleMillisecond(calendar40);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass45 = month44.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month44.previous();
        boolean boolean47 = fixedMillisecond38.equals((java.lang.Object) month44);
        long long48 = fixedMillisecond38.getFirstMillisecond();
        int int49 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        long long50 = fixedMillisecond38.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1210L + "'", long30 == 1210L);
        org.junit.Assert.assertNotNull(comparable33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 10L + "'", long48 == 10L);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        timeSeries7.setRangeDescription("2020");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int15 = month14.getYearValue();
        boolean boolean17 = month14.equals((java.lang.Object) (short) 10);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month14, (double) (-58987929600000L), false);
        timeSeries7.setKey((java.lang.Comparable) (-58985251200001L));
        int int23 = timeSeries7.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener24);
        timeSeries7.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 10, seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        timeSeries7.setMaximumItemAge(1560150000000L);
        java.lang.String str30 = timeSeries7.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.lang.Object obj33 = null;
        int int34 = fixedMillisecond32.compareTo(obj33);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass38 = month37.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month37.previous();
        int int40 = fixedMillisecond32.compareTo((java.lang.Object) month37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month37);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem41, "org.jfree.data.general.SeriesException: 10-June-2019", "org.jfree.data.event.SeriesChangeEvent[source=10]");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2020" + "'", str30.equals("2020"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.event.SeriesChangeEvent[source=10]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries7.getNextTimePeriod();
        timeSeries7.setMaximumItemAge(1560150000000L);
        java.lang.String str30 = timeSeries7.getRangeDescription();
        java.util.Collection collection31 = timeSeries7.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries32 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries33 = timeSeries7.addAndOrUpdate(timeSeries32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2020" + "'", str30.equals("2020"));
        org.junit.Assert.assertNotNull(collection31);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.setDescription("hi!");
        java.lang.String str11 = timeSeries7.getRangeDescription();
        java.lang.Object obj12 = timeSeries7.clone();
        java.lang.Class<?> wildcardClass13 = obj12.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2020" + "'", str11.equals("2020"));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        java.util.Date date11 = month7.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        java.util.TimeZone timeZone13 = null;
        try {
            org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date11, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        double double17 = timeSeries7.getMinY();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int21 = month20.getYearValue();
        java.util.Date date22 = month20.getEnd();
        boolean boolean24 = month20.equals((java.lang.Object) 'a');
        long long25 = month20.getLastMillisecond();
        int int26 = month20.getYearValue();
        java.util.Date date27 = month20.getEnd();
        org.jfree.data.time.Year year28 = month20.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long31 = fixedMillisecond30.getFirstMillisecond();
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond30.getFirstMillisecond(calendar32);
        int int34 = year28.compareTo((java.lang.Object) calendar32);
        java.lang.String str35 = year28.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year28.next();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year28, 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long41 = fixedMillisecond40.getSerialIndex();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getMiddleMillisecond(calendar42);
        long long44 = fixedMillisecond40.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = fixedMillisecond40.previous();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 9223372036854775807L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-58985251200001L) + "'", long25 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "100" + "'", str35.equals("100"));
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.lang.String str4 = month2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 10, seriesChangeInfo6);
        java.lang.Object obj8 = seriesChangeEvent7.getSource();
        java.lang.String str9 = seriesChangeEvent7.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo12);
        boolean boolean14 = month2.equals((java.lang.Object) seriesChangeInfo12);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int18 = month17.getYearValue();
        java.util.Date date19 = month17.getEnd();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "2020", "2020");
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int26 = month25.getYearValue();
        java.util.Date date27 = month25.getEnd();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month25, "2020", "2020");
        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
        java.lang.String str32 = timeSeries30.getDescription();
        org.jfree.data.time.Year year34 = org.jfree.data.time.Year.parseYear("100");
        int int35 = year34.getYear();
        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass42 = month41.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month41.previous();
        java.lang.Class<?> wildcardClass44 = regularTimePeriod43.getClass();
        boolean boolean45 = fixedMillisecond38.equals((java.lang.Object) regularTimePeriod43);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries30.getDataItem(regularTimePeriod43);
        timeSeries22.add(timeSeriesDataItem46);
        java.lang.String str48 = timeSeries22.getDomainDescription();
        boolean boolean49 = month2.equals((java.lang.Object) timeSeries22);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener50 = null;
        timeSeries22.addChangeListener(seriesChangeListener50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "October 100" + "'", str4.equals("October 100"));
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + (byte) 10 + "'", obj8.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str9.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(class31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 100 + "'", int35 == 100);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "2020" + "'", str48.equals("2020"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        java.util.Date date9 = month2.getEnd();
        org.jfree.data.time.Year year10 = month2.getYear();
        long long11 = year10.getSerialIndex();
        java.lang.String str12 = year10.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100" + "'", str12.equals("100"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        java.util.Date date9 = month2.getEnd();
        org.jfree.data.time.Year year10 = month2.getYear();
        java.lang.Class<?> wildcardClass11 = year10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        java.util.Date date17 = year15.getStart();
        long long18 = year15.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year15.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long22 = fixedMillisecond21.getFirstMillisecond();
        long long23 = fixedMillisecond21.getSerialIndex();
        long long24 = fixedMillisecond21.getFirstMillisecond();
        long long25 = fixedMillisecond21.getFirstMillisecond();
        long long26 = fixedMillisecond21.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long29 = fixedMillisecond28.getSerialIndex();
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond28.getMiddleMillisecond(calendar30);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass35 = month34.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month34.previous();
        boolean boolean37 = fixedMillisecond28.equals((java.lang.Object) month34);
        java.util.Date date38 = month34.getStart();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
        boolean boolean40 = fixedMillisecond21.equals((java.lang.Object) date38);
        int int41 = year15.compareTo((java.lang.Object) date38);
        java.util.TimeZone timeZone42 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date38, timeZone42);
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date44, timeZone45);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62104204800000L) + "'", long18 == (-62104204800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod46);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        long long9 = month2.getFirstMillisecond();
        java.util.Date date10 = month2.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        boolean boolean12 = month2.equals((java.lang.Object) day11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        long long5 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.previous();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int10 = month9.getYearValue();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "2020", "2020");
        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
        java.lang.String str16 = timeSeries14.getDescription();
        org.jfree.data.time.Year year18 = org.jfree.data.time.Year.parseYear("100");
        int int19 = year18.getYear();
        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass26 = month25.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month25.previous();
        java.lang.Class<?> wildcardClass28 = regularTimePeriod27.getClass();
        boolean boolean29 = fixedMillisecond22.equals((java.lang.Object) regularTimePeriod27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries14.getDataItem(regularTimePeriod27);
        long long31 = timeSeries14.getMaximumItemAge();
        timeSeries14.setNotify(false);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month36.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month36.next();
        timeSeries14.update(regularTimePeriod38, (java.lang.Number) 1560150000000L);
        java.beans.PropertyChangeListener propertyChangeListener41 = null;
        timeSeries14.removePropertyChangeListener(propertyChangeListener41);
        java.lang.Object obj43 = timeSeries14.clone();
        int int44 = fixedMillisecond1.compareTo(obj43);
        long long45 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(class15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj3 = null;
//        int int4 = fixedMillisecond2.compareTo(obj3);
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        long long8 = day0.getFirstMillisecond();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj12 = null;
//        int int13 = fixedMillisecond11.compareTo(obj12);
//        boolean boolean14 = day9.equals((java.lang.Object) int13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day9.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day9.next();
//        int int17 = day0.compareTo((java.lang.Object) regularTimePeriod16);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
//        java.util.Collection collection19 = timeSeries18.getTimePeriods();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(collection19);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        long long5 = fixedMillisecond1.getFirstMillisecond();
        long long6 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        timeSeries7.removeAgedItems((long) 4, false);
        timeSeries7.setDescription("January 0");
        java.lang.Class class32 = timeSeries7.getTimePeriodClass();
        java.lang.Object obj33 = timeSeries7.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertNotNull(class32);
        org.junit.Assert.assertNotNull(obj33);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) year9);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(6);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year13, (double) 1210L, false);
//        int int17 = timeSeries7.getMaximumItemCount();
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int21 = month20.getYearValue();
//        java.util.Date date22 = month20.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month20, "2020", "2020");
//        java.lang.Class class26 = timeSeries25.getTimePeriodClass();
//        java.lang.String str27 = timeSeries25.getDescription();
//        org.jfree.data.time.Year year29 = org.jfree.data.time.Year.parseYear("100");
//        int int30 = year29.getYear();
//        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) year29, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass37 = month36.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month36.previous();
//        java.lang.Class<?> wildcardClass39 = regularTimePeriod38.getClass();
//        boolean boolean40 = fixedMillisecond33.equals((java.lang.Object) regularTimePeriod38);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries25.getDataItem(regularTimePeriod38);
//        java.lang.Object obj42 = timeSeriesDataItem41.clone();
//        timeSeriesDataItem41.setValue((java.lang.Number) 1.0f);
//        boolean boolean45 = timeSeriesDataItem41.isSelected();
//        timeSeries7.add(timeSeriesDataItem41);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = day47.next();
//        long long49 = day47.getFirstMillisecond();
//        long long50 = day47.getFirstMillisecond();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent52 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1));
//        boolean boolean53 = day47.equals((java.lang.Object) (-1));
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day47);
//        int int55 = day47.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(class26);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
//        org.junit.Assert.assertNotNull(obj42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560150000000L + "'", long49 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560150000000L + "'", long50 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 10 + "'", int55 == 10);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        long long15 = year11.getLastMillisecond();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year11.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-58979980800001L) + "'", long15 == (-58979980800001L));
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
//        int int12 = year11.getYear();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
//        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
//        long long24 = timeSeries7.getMaximumItemAge();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
//        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
//        java.util.Collection collection34 = timeSeries7.getTimePeriods();
//        timeSeries7.setRangeDescription("org.jfree.data.general.SeriesException: 100");
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int40 = month39.getYearValue();
//        java.util.Date date41 = month39.getEnd();
//        boolean boolean43 = month39.equals((java.lang.Object) 'a');
//        long long44 = month39.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) (-1.0d));
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = day47.next();
//        org.jfree.data.time.SerialDate serialDate49 = day47.getSerialDate();
//        java.lang.String str50 = day47.toString();
//        java.lang.String str51 = day47.toString();
//        boolean boolean52 = timeSeriesDataItem46.equals((java.lang.Object) day47);
//        timeSeriesDataItem46.setValue((java.lang.Number) (byte) -1);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries7.addOrUpdate(timeSeriesDataItem46);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(collection34);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 100 + "'", int40 == 100);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-58985251200001L) + "'", long44 == (-58985251200001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "10-June-2019" + "'", str50.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "10-June-2019" + "'", str51.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener34);
        boolean boolean36 = timeSeries7.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) 10);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
        long long41 = fixedMillisecond38.getSerialIndex();
        long long42 = fixedMillisecond38.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        java.util.List list44 = timeSeries7.getItems();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener45 = null;
        timeSeries7.addChangeListener(seriesChangeListener45);
        timeSeries7.setRangeDescription("100");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(list44);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        long long24 = timeSeries7.getMaximumItemAge();
        timeSeries7.setMaximumItemCount((int) (short) 1);
        java.lang.Class class27 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int31 = month30.getYearValue();
        java.util.Date date32 = month30.getEnd();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month30, "2020", "2020");
        java.lang.Class class36 = timeSeries35.getTimePeriodClass();
        timeSeries35.setDescription("hi!");
        java.lang.String str39 = timeSeries35.getRangeDescription();
        org.jfree.data.time.Year year41 = org.jfree.data.time.Year.parseYear("100");
        int int42 = year41.getYear();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int46 = month45.getYearValue();
        java.util.Date date47 = month45.getEnd();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month45, "2020", "2020");
        java.lang.Class class51 = timeSeries50.getTimePeriodClass();
        java.lang.String str52 = timeSeries50.getDescription();
        timeSeries50.setRangeDescription("2020");
        int int55 = timeSeries50.getItemCount();
        timeSeries50.setMaximumItemCount((int) (short) 1);
        org.jfree.data.time.Year year59 = org.jfree.data.time.Year.parseYear("100");
        int int60 = year59.getYear();
        int int61 = timeSeries50.getIndex((org.jfree.data.time.RegularTimePeriod) year59);
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int65 = month64.getYearValue();
        java.util.Date date66 = month64.getEnd();
        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month64, "2020", "2020");
        java.lang.Class class70 = timeSeries69.getTimePeriodClass();
        java.lang.String str71 = timeSeries69.getDescription();
        org.jfree.data.time.Year year73 = org.jfree.data.time.Year.parseYear("100");
        int int74 = year73.getYear();
        timeSeries69.add((org.jfree.data.time.RegularTimePeriod) year73, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass81 = month80.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = month80.previous();
        java.lang.Class<?> wildcardClass83 = regularTimePeriod82.getClass();
        boolean boolean84 = fixedMillisecond77.equals((java.lang.Object) regularTimePeriod82);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = timeSeries69.getDataItem(regularTimePeriod82);
        long long86 = timeSeries69.getMaximumItemAge();
        timeSeries69.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener89 = null;
        timeSeries69.removePropertyChangeListener(propertyChangeListener89);
        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year();
        timeSeries69.setKey((java.lang.Comparable) year91);
        timeSeries50.add((org.jfree.data.time.RegularTimePeriod) year91, (java.lang.Number) 1562097599999L, false);
        boolean boolean96 = year41.equals((java.lang.Object) year91);
        timeSeries35.delete((org.jfree.data.time.RegularTimePeriod) year41);
        org.jfree.data.time.TimeSeries timeSeries98 = timeSeries7.addAndOrUpdate(timeSeries35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(class36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2020" + "'", str39.equals("2020"));
        org.junit.Assert.assertNotNull(year41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 100 + "'", int46 == 100);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNull(class51);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(year59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 100 + "'", int60 == 100);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 100 + "'", int65 == 100);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNull(class70);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertNotNull(year73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 100 + "'", int74 == 100);
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(wildcardClass83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem85);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 9223372036854775807L + "'", long86 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNotNull(timeSeries98);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long4 = fixedMillisecond3.getSerialIndex();
        java.util.Date date5 = fixedMillisecond3.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        boolean boolean7 = year1.equals((java.lang.Object) date5);
        java.util.TimeZone timeZone8 = null;
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date5, timeZone8, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = year1.getStart();
        long long4 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.next();
        int int6 = year1.getYear();
        int int7 = year1.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62104204800000L) + "'", long4 == (-62104204800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.String str8 = timeSeries7.getDescription();
//        int int9 = timeSeries7.getItemCount();
//        timeSeries7.removeAgedItems(false);
//        boolean boolean12 = timeSeries7.getNotify();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.previous();
//        int int20 = year14.compareTo((java.lang.Object) regularTimePeriod19);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(8, year14);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 9L, false);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int28 = month27.getYearValue();
//        java.util.Date date29 = month27.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month27, "2020", "2020");
//        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
//        java.lang.String str34 = timeSeries32.getDescription();
//        timeSeries32.setRangeDescription("2020");
//        int int37 = timeSeries32.getItemCount();
//        timeSeries32.setMaximumItemCount((int) (short) 1);
//        org.jfree.data.time.Year year41 = org.jfree.data.time.Year.parseYear("100");
//        int int42 = year41.getYear();
//        int int43 = timeSeries32.getIndex((org.jfree.data.time.RegularTimePeriod) year41);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries32.addChangeListener(seriesChangeListener44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj49 = null;
//        int int50 = fixedMillisecond48.compareTo(obj49);
//        boolean boolean51 = day46.equals((java.lang.Object) int50);
//        org.jfree.data.time.SerialDate serialDate52 = day46.getSerialDate();
//        long long53 = day46.getLastMillisecond();
//        int int54 = timeSeries32.getIndex((org.jfree.data.time.RegularTimePeriod) day46);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        long long57 = fixedMillisecond56.getFirstMillisecond();
//        long long58 = fixedMillisecond56.getSerialIndex();
//        int int59 = timeSeries32.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = fixedMillisecond56.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(str8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 100 + "'", int28 == 100);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNull(class33);
//        org.junit.Assert.assertNull(str34);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(year41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560236399999L + "'", long53 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 10L + "'", long58 == 10L);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem61);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.time.Year year25 = month19.getYear();
        java.util.Date date26 = month19.getStart();
        try {
            org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertNotNull(year25);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long10 = fixedMillisecond9.getSerialIndex();
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond9.getMiddleMillisecond(calendar11);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass16 = month15.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month15.previous();
        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) month15);
        long long19 = fixedMillisecond9.getFirstMillisecond();
        long long20 = fixedMillisecond9.getLastMillisecond();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int24 = month23.getYearValue();
        java.util.Date date25 = month23.getEnd();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month23, "2020", "2020");
        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
        java.lang.String str30 = timeSeries28.getDescription();
        org.jfree.data.time.Year year32 = org.jfree.data.time.Year.parseYear("100");
        int int33 = year32.getYear();
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass40 = month39.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month39.previous();
        java.lang.Class<?> wildcardClass42 = regularTimePeriod41.getClass();
        boolean boolean43 = fixedMillisecond36.equals((java.lang.Object) regularTimePeriod41);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries28.getDataItem(regularTimePeriod41);
        long long45 = timeSeries28.getMaximumItemAge();
        timeSeries28.setNotify(false);
        java.lang.Object obj48 = timeSeries28.clone();
        int int49 = fixedMillisecond9.compareTo((java.lang.Object) timeSeries28);
        timeSeries7.setKey((java.lang.Comparable) int49);
        timeSeries7.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: 100");
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass56 = month55.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month55.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = month55.previous();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month55, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(class29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 100 + "'", int33 == 100);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.Year year5 = month2.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        int int9 = timeSeries7.getItemCount();
        timeSeries7.removeAgedItems(false);
        boolean boolean12 = timeSeries7.getNotify();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.previous();
        int int20 = year14.compareTo((java.lang.Object) regularTimePeriod19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(8, year14);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 9L, false);
        java.util.Calendar calendar25 = null;
        try {
            long long26 = month21.getLastMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("100");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("100");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        java.lang.Throwable[] throwableArray6 = seriesException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=10]");
        seriesException4.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) 1560150000000L);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        java.util.Date date10 = year8.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
        boolean boolean12 = fixedMillisecond1.equals((java.lang.Object) date10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        timeSeries7.clear();
        double double25 = timeSeries7.getMaxY();
        timeSeries7.setMaximumItemAge((long) 5);
        java.util.List list28 = timeSeries7.getItems();
        java.lang.Object obj29 = null;
        boolean boolean30 = timeSeries7.equals(obj29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        java.util.Date date9 = month2.getEnd();
        java.util.TimeZone timeZone10 = null;
        java.util.Locale locale11 = null;
        try {
            org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date9, timeZone10, locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        long long3 = year0.getSerialIndex();
        java.lang.String str4 = year0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = year1.getStart();
        java.util.Date date4 = year1.getEnd();
        long long5 = year1.getFirstMillisecond();
        java.lang.String str6 = year1.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62104204800000L) + "'", long5 == (-62104204800000L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2" + "'", str6.equals("2"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.lang.String str4 = month2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 10, seriesChangeInfo6);
        java.lang.Object obj8 = seriesChangeEvent7.getSource();
        java.lang.String str9 = seriesChangeEvent7.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo12);
        boolean boolean14 = month2.equals((java.lang.Object) seriesChangeInfo12);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int18 = month17.getYearValue();
        java.util.Date date19 = month17.getEnd();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month17, "2020", "2020");
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int26 = month25.getYearValue();
        java.util.Date date27 = month25.getEnd();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month25, "2020", "2020");
        java.lang.Class class31 = timeSeries30.getTimePeriodClass();
        java.lang.String str32 = timeSeries30.getDescription();
        org.jfree.data.time.Year year34 = org.jfree.data.time.Year.parseYear("100");
        int int35 = year34.getYear();
        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass42 = month41.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month41.previous();
        java.lang.Class<?> wildcardClass44 = regularTimePeriod43.getClass();
        boolean boolean45 = fixedMillisecond38.equals((java.lang.Object) regularTimePeriod43);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries30.getDataItem(regularTimePeriod43);
        timeSeries22.add(timeSeriesDataItem46);
        java.lang.String str48 = timeSeries22.getDomainDescription();
        boolean boolean49 = month2.equals((java.lang.Object) timeSeries22);
        java.lang.Object obj50 = timeSeries22.clone();
        int int51 = timeSeries22.getMaximumItemCount();
        timeSeries22.clear();
        timeSeries22.clear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "October 100" + "'", str4.equals("October 100"));
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + (byte) 10 + "'", obj8.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str9.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(class31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 100 + "'", int35 == 100);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "2020" + "'", str48.equals("2020"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2147483647 + "'", int51 == 2147483647);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        long long6 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
        int int12 = year11.getYear();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass19 = month18.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        java.lang.Object obj25 = timeSeriesDataItem23.clone();
        timeSeriesDataItem23.setSelected(false);
        boolean boolean28 = timeSeriesDataItem23.isSelected();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year29.previous();
        long long32 = year29.getMiddleMillisecond();
        long long33 = year29.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year29.next();
        boolean boolean35 = timeSeriesDataItem23.equals((java.lang.Object) year29);
        java.util.Calendar calendar36 = null;
        try {
            long long37 = year29.getMiddleMillisecond(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1562097599999L + "'", long32 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (short) 10, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass8 = month7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) month7);
        long long11 = fixedMillisecond1.getFirstMillisecond();
        long long12 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int16 = month15.getYearValue();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month15, "2020", "2020");
        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
        java.lang.String str22 = timeSeries20.getDescription();
        org.jfree.data.time.Year year24 = org.jfree.data.time.Year.parseYear("100");
        int int25 = year24.getYear();
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass32 = month31.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month31.previous();
        java.lang.Class<?> wildcardClass34 = regularTimePeriod33.getClass();
        boolean boolean35 = fixedMillisecond28.equals((java.lang.Object) regularTimePeriod33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries20.getDataItem(regularTimePeriod33);
        long long37 = timeSeries20.getMaximumItemAge();
        timeSeries20.setNotify(false);
        java.lang.Object obj40 = timeSeries20.clone();
        int int41 = fixedMillisecond1.compareTo((java.lang.Object) timeSeries20);
        timeSeries20.setNotify(false);
        timeSeries20.setNotify(false);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 9223372036854775807L + "'", long37 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
//        int int12 = year11.getYear();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
//        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
//        long long24 = timeSeries7.getMaximumItemAge();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
//        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        java.lang.String str37 = day34.toString();
//        boolean boolean38 = timeSeries7.equals((java.lang.Object) str37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj42 = null;
//        int int43 = fixedMillisecond41.compareTo(obj42);
//        boolean boolean44 = day39.equals((java.lang.Object) int43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day39.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day39.next();
//        long long47 = day39.getFirstMillisecond();
//        int int48 = day39.getMonth();
//        timeSeries7.update((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) (-1L));
//        timeSeries7.setMaximumItemCount((int) (byte) 100);
//        timeSeries7.setDomainDescription("10-June-2019");
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560150000000L + "'", long47 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 0);
        long long3 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        double double17 = timeSeries7.getMinY();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int21 = month20.getYearValue();
        java.util.Date date22 = month20.getEnd();
        boolean boolean24 = month20.equals((java.lang.Object) 'a');
        long long25 = month20.getLastMillisecond();
        int int26 = month20.getYearValue();
        java.util.Date date27 = month20.getEnd();
        org.jfree.data.time.Year year28 = month20.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long31 = fixedMillisecond30.getFirstMillisecond();
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond30.getFirstMillisecond(calendar32);
        int int34 = year28.compareTo((java.lang.Object) calendar32);
        java.lang.String str35 = year28.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year28.next();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year28, 0.0d);
        java.lang.String str39 = year28.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-58985251200001L) + "'", long25 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "100" + "'", str35.equals("100"));
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "100" + "'", str39.equals("100"));
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
//        int int5 = day4.getMonth();
//        long long6 = day4.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560193199999L + "'", long6 == 1560193199999L);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        int int5 = day4.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.delete((int) (byte) -1, 2147483647);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(class8);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        java.lang.Object obj33 = timeSeries7.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(0L);
        long long36 = fixedMillisecond35.getFirstMillisecond();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int40 = month39.getYearValue();
        java.util.Date date41 = month39.getEnd();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month39, "2020", "2020");
        java.lang.Class class45 = timeSeries44.getTimePeriodClass();
        java.lang.String str46 = timeSeries44.getDescription();
        org.jfree.data.time.Year year48 = org.jfree.data.time.Year.parseYear("100");
        int int49 = year48.getYear();
        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass56 = month55.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month55.previous();
        java.lang.Class<?> wildcardClass58 = regularTimePeriod57.getClass();
        boolean boolean59 = fixedMillisecond52.equals((java.lang.Object) regularTimePeriod57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries44.getDataItem(regularTimePeriod57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = timeSeriesDataItem60.getPeriod();
        int int62 = fixedMillisecond35.compareTo((java.lang.Object) regularTimePeriod61);
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int66 = month65.getYearValue();
        java.util.Date date67 = month65.getEnd();
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month65, "2020", "2020");
        java.lang.Class class71 = timeSeries70.getTimePeriodClass();
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = year72.next();
        timeSeries70.delete((org.jfree.data.time.RegularTimePeriod) year72);
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(6);
        timeSeries70.add((org.jfree.data.time.RegularTimePeriod) year76, (double) 1210L, false);
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (org.jfree.data.time.RegularTimePeriod) year76);
        double double81 = timeSeries80.getMinY();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 100 + "'", int40 == 100);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNull(class45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(year48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 100 + "'", int49 == 100);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem60);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 100 + "'", int66 == 100);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNull(class71);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + (-1.0d) + "'", double81 == (-1.0d));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        boolean boolean6 = month2.equals((java.lang.Object) 'a');
        long long7 = month2.getLastMillisecond();
        int int8 = month2.getYearValue();
        long long9 = month2.getFirstMillisecond();
        long long10 = month2.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("100");
        boolean boolean13 = month2.equals((java.lang.Object) seriesException12);
        java.lang.Throwable[] throwableArray14 = seriesException12.getSuppressed();
        java.lang.String str15 = seriesException12.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58985251200001L) + "'", long7 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-58987929600000L) + "'", long10 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesException: 100" + "'", str15.equals("org.jfree.data.general.SeriesException: 100"));
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test321");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43626L + "'", long2 == 43626L);
//    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test322");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.lang.String str2 = regularTimePeriod1.toString();
        java.util.Date date3 = regularTimePeriod1.getStart();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod1, seriesChangeInfo4);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2020" + "'", str2.equals("2020"));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond6, "2020", "");
        timeSeries9.setMaximumItemAge(9L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long10 = fixedMillisecond9.getSerialIndex();
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond9.getMiddleMillisecond(calendar11);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass16 = month15.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month15.previous();
        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) month15);
        long long19 = fixedMillisecond9.getFirstMillisecond();
        long long20 = fixedMillisecond9.getLastMillisecond();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int24 = month23.getYearValue();
        java.util.Date date25 = month23.getEnd();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month23, "2020", "2020");
        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
        java.lang.String str30 = timeSeries28.getDescription();
        org.jfree.data.time.Year year32 = org.jfree.data.time.Year.parseYear("100");
        int int33 = year32.getYear();
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass40 = month39.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month39.previous();
        java.lang.Class<?> wildcardClass42 = regularTimePeriod41.getClass();
        boolean boolean43 = fixedMillisecond36.equals((java.lang.Object) regularTimePeriod41);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries28.getDataItem(regularTimePeriod41);
        long long45 = timeSeries28.getMaximumItemAge();
        timeSeries28.setNotify(false);
        java.lang.Object obj48 = timeSeries28.clone();
        int int49 = fixedMillisecond9.compareTo((java.lang.Object) timeSeries28);
        timeSeries7.setKey((java.lang.Comparable) int49);
        timeSeries7.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: 100");
        timeSeries7.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries55 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries56 = timeSeries7.addAndOrUpdate(timeSeries55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(class29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 100 + "'", int33 == 100);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test326");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        long long2 = day0.getFirstMillisecond();
//        int int4 = day0.compareTo((java.lang.Object) 8);
//        long long5 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 1, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.previous();
        int int15 = year9.compareTo((java.lang.Object) regularTimePeriod14);
        boolean boolean16 = timeSeries7.equals((java.lang.Object) regularTimePeriod14);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int20 = month19.getYearValue();
        java.util.Date date21 = month19.getEnd();
        long long22 = month19.getSerialIndex();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 6L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int30 = month29.getYearValue();
        java.util.Date date31 = month29.getEnd();
        boolean boolean33 = month29.equals((java.lang.Object) 'a');
        java.lang.String str34 = month29.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries7.addOrUpdate(regularTimePeriod35, (java.lang.Number) 9);
        timeSeries7.removeAgedItems(6L, true);
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) 10);
        long long44 = fixedMillisecond43.getSerialIndex();
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond43.getMiddleMillisecond(calendar45);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass50 = month49.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month49.previous();
        boolean boolean52 = fixedMillisecond43.equals((java.lang.Object) month49);
        long long53 = fixedMillisecond43.getFirstMillisecond();
        long long54 = fixedMillisecond43.getLastMillisecond();
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int58 = month57.getYearValue();
        java.util.Date date59 = month57.getEnd();
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month57, "2020", "2020");
        java.lang.Class class63 = timeSeries62.getTimePeriodClass();
        java.lang.String str64 = timeSeries62.getDescription();
        org.jfree.data.time.Year year66 = org.jfree.data.time.Year.parseYear("100");
        int int67 = year66.getYear();
        timeSeries62.add((org.jfree.data.time.RegularTimePeriod) year66, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass74 = month73.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = month73.previous();
        java.lang.Class<?> wildcardClass76 = regularTimePeriod75.getClass();
        boolean boolean77 = fixedMillisecond70.equals((java.lang.Object) regularTimePeriod75);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = timeSeries62.getDataItem(regularTimePeriod75);
        long long79 = timeSeries62.getMaximumItemAge();
        timeSeries62.setNotify(false);
        java.lang.Object obj82 = timeSeries62.clone();
        int int83 = fixedMillisecond43.compareTo((java.lang.Object) timeSeries62);
        java.util.Date date84 = fixedMillisecond43.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = fixedMillisecond43.previous();
        try {
            timeSeries7.add(regularTimePeriod85, (java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1210L + "'", long22 == 1210L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "October 100" + "'", str34.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 10L + "'", long46 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 10L + "'", long53 == 10L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 10L + "'", long54 == 10L);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 100 + "'", int58 == 100);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNull(class63);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(year66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 100 + "'", int67 == 100);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem78);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 9223372036854775807L + "'", long79 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("100");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("100");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("100");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("100");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        seriesException7.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str14 = timePeriodFormatException11.toString();
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException11.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 100" + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: 100"));
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.lang.String str4 = month2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) 10, seriesChangeInfo6);
        java.lang.Object obj8 = seriesChangeEvent7.getSource();
        java.lang.String str9 = seriesChangeEvent7.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        seriesChangeEvent7.setSummary(seriesChangeInfo12);
        boolean boolean14 = month2.equals((java.lang.Object) seriesChangeInfo12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month2.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "October 100" + "'", str4.equals("October 100"));
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + (byte) 10 + "'", obj8.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=10]" + "'", str9.equals("org.jfree.data.event.SeriesChangeEvent[source=10]"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test330");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj3 = null;
//        int int4 = fixedMillisecond2.compareTo(obj3);
//        boolean boolean5 = day0.equals((java.lang.Object) int4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        long long8 = day0.getFirstMillisecond();
//        int int9 = day0.getMonth();
//        long long10 = day0.getLastMillisecond();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj14 = null;
//        int int15 = fixedMillisecond13.compareTo(obj14);
//        boolean boolean16 = day11.equals((java.lang.Object) int15);
//        java.util.Date date17 = day11.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        boolean boolean19 = day0.equals((java.lang.Object) fixedMillisecond18);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(3);
        int int2 = year1.getYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test332");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
//        int int12 = year11.getYear();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
//        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
//        long long24 = timeSeries7.getMaximumItemAge();
//        timeSeries7.setRangeDescription("January 0");
//        double double27 = timeSeries7.getMaxY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        long long30 = fixedMillisecond29.getFirstMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond29.getFirstMillisecond(calendar31);
//        java.lang.Number number33 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int37 = month36.getYearValue();
//        java.util.Date date38 = month36.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month36, "2020", "2020");
//        java.lang.Class class42 = timeSeries41.getTimePeriodClass();
//        java.lang.String str43 = timeSeries41.getDescription();
//        timeSeries41.setRangeDescription("2020");
//        int int46 = timeSeries41.getItemCount();
//        timeSeries41.setMaximumItemCount((int) (short) 1);
//        org.jfree.data.time.Year year50 = org.jfree.data.time.Year.parseYear("100");
//        int int51 = year50.getYear();
//        int int52 = timeSeries41.getIndex((org.jfree.data.time.RegularTimePeriod) year50);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener53 = null;
//        timeSeries41.addChangeListener(seriesChangeListener53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj58 = null;
//        int int59 = fixedMillisecond57.compareTo(obj58);
//        boolean boolean60 = day55.equals((java.lang.Object) int59);
//        org.jfree.data.time.SerialDate serialDate61 = day55.getSerialDate();
//        long long62 = day55.getLastMillisecond();
//        int int63 = timeSeries41.getIndex((org.jfree.data.time.RegularTimePeriod) day55);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        long long66 = fixedMillisecond65.getFirstMillisecond();
//        long long67 = fixedMillisecond65.getSerialIndex();
//        int int68 = timeSeries41.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65);
//        java.util.Collection collection69 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries41);
//        java.lang.Object obj70 = timeSeries7.clone();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-1.0d) + "'", double27 == (-1.0d));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
//        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (-1) + "'", number33.equals((-1)));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 100 + "'", int37 == 100);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNull(class42);
//        org.junit.Assert.assertNull(str43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertNotNull(year50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 100 + "'", int51 == 100);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560236399999L + "'", long62 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 10L + "'", long66 == 10L);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 10L + "'", long67 == 10L);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
//        org.junit.Assert.assertNotNull(collection69);
//        org.junit.Assert.assertNotNull(obj70);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
        long long2 = year1.getSerialIndex();
        java.lang.String str3 = year1.toString();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6" + "'", str3.equals("6"));
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test334");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        int int3 = month2.getYearValue();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.Year year11 = org.jfree.data.time.Year.parseYear("100");
//        int int12 = year11.getYear();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) (-1));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass19 = month18.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month18.previous();
//        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
//        boolean boolean22 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.getDataItem(regularTimePeriod20);
//        long long24 = timeSeries7.getMaximumItemAge();
//        timeSeries7.setNotify(false);
//        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 1, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month29.next();
//        timeSeries7.update(regularTimePeriod31, (java.lang.Number) 1560150000000L);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day34.next();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        java.lang.String str37 = day34.toString();
//        boolean boolean38 = timeSeries7.equals((java.lang.Object) str37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        java.lang.Object obj41 = null;
//        int int42 = fixedMillisecond40.compareTo(obj41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) 10);
//        long long45 = fixedMillisecond44.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond44);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener47 = null;
//        timeSeries46.addChangeListener(seriesChangeListener47);
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timeSeries46.removePropertyChangeListener(propertyChangeListener49);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
//        org.junit.Assert.assertNotNull(timeSeries46);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int3 = month2.getYearValue();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "2020", "2020");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int11 = month10.getYearValue();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month10, "2020", "2020");
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.Year year19 = org.jfree.data.time.Year.parseYear("100");
        int int20 = year19.getYear();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass27 = month26.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month26.previous();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        boolean boolean30 = fixedMillisecond23.equals((java.lang.Object) regularTimePeriod28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries15.getDataItem(regularTimePeriod28);
        timeSeries7.add(timeSeriesDataItem31);
        java.lang.Object obj33 = timeSeries7.clone();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int37 = month36.getYearValue();
        java.util.Date date38 = month36.getEnd();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month36, "2020", "2020");
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        int int45 = month44.getYearValue();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month44, "2020", "2020");
        java.lang.Class class50 = timeSeries49.getTimePeriodClass();
        java.lang.String str51 = timeSeries49.getDescription();
        org.jfree.data.time.Year year53 = org.jfree.data.time.Year.parseYear("100");
        int int54 = year53.getYear();
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) (-1));
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month((int) (short) 10, (int) (byte) 100);
        java.lang.Class<?> wildcardClass61 = month60.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month60.previous();
        java.lang.Class<?> wildcardClass63 = regularTimePeriod62.getClass();
        boolean boolean64 = fixedMillisecond57.equals((java.lang.Object) regularTimePeriod62);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries49.getDataItem(regularTimePeriod62);
        timeSeries41.add(timeSeriesDataItem65);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries7.addOrUpdate(timeSeriesDataItem65);
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem67, "", "org.jfree.data.time.TimePeriodFormatException: 100");
        int int71 = timeSeries70.getItemCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNull(class16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 100 + "'", int37 == 100);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNull(class50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(year53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 100 + "'", int54 == 100);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem65);
        org.junit.Assert.assertNotNull(timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
    }
}

