import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        try {
            timePeriodValues3.delete(2, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        int int14 = day13.getDayOfMonth();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        java.util.Date date12 = simpleTimePeriod8.getStart();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        timePeriodValues3.setDomainDescription("");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        int int4 = timePeriodValues3.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod19);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) 43629L);
        java.lang.Comparable comparable26 = timePeriodValues3.getKey();
        int int27 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues31.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues31.add((org.jfree.data.time.TimePeriod) simpleTimePeriod36, 10.0d);
        java.util.Date date39 = simpleTimePeriod36.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        long long41 = day40.getMiddleMillisecond();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        long long43 = year42.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year42, (double) 2019);
        boolean boolean46 = day40.equals((java.lang.Object) timePeriodValue45);
        org.jfree.data.time.TimePeriod timePeriod47 = timePeriodValue45.getPeriod();
        timePeriodValues3.setKey((java.lang.Comparable) timePeriod47);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + "hi!" + "'", comparable26.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-14400001L) + "'", long41 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(timePeriod47);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timePeriodValues3.getDomainDescription();
        java.lang.String str27 = timePeriodValues3.getRangeDescription();
        int int28 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str26.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        java.util.Date date5 = day3.getEnd();
//        long long6 = day3.getLastMillisecond();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.String str8 = day7.toString();
//        long long9 = day7.getSerialIndex();
//        long long10 = day7.getLastMillisecond();
//        boolean boolean12 = day7.equals((java.lang.Object) "hi!");
//        boolean boolean13 = day3.equals((java.lang.Object) boolean12);
//        boolean boolean15 = day3.equals((java.lang.Object) 13);
//        java.util.Date date16 = day3.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        boolean boolean18 = simpleTimePeriod2.equals((java.lang.Object) day17);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        int int14 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.String str15 = timePeriodValues3.getDomainDescription();
        boolean boolean16 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str15.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.lang.Class<?> wildcardClass11 = simpleTimePeriod8.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues15.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, 10.0d);
        java.lang.Class<?> wildcardClass23 = simpleTimePeriod20.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues28.addPropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) simpleTimePeriod33, 10.0d);
        java.util.Date date36 = simpleTimePeriod33.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timePeriodValues42.addPropertyChangeListener(propertyChangeListener43);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues42.add((org.jfree.data.time.TimePeriod) simpleTimePeriod47, 10.0d);
        java.util.Date date50 = simpleTimePeriod47.getEnd();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date50);
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date50, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date36, timeZone53);
        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        boolean boolean57 = simpleTimePeriod8.equals((java.lang.Object) wildcardClass23);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException59 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        boolean boolean60 = simpleTimePeriod8.equals((java.lang.Object) timePeriodFormatException59);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(class56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("2019");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.String str5 = day4.toString();
//        long long6 = day4.getSerialIndex();
//        long long7 = day4.getLastMillisecond();
//        boolean boolean9 = day4.equals((java.lang.Object) "hi!");
//        boolean boolean10 = day0.equals((java.lang.Object) boolean9);
//        boolean boolean12 = day0.equals((java.lang.Object) 13);
//        java.util.Date date13 = day0.getStart();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        long long15 = day14.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        int int24 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setNotify(true);
        timePeriodValues3.setDomainDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues32.addPropertyChangeListener(propertyChangeListener33);
        timePeriodValues32.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
        timePeriodValues32.removeChangeListener(seriesChangeListener37);
        timePeriodValues32.setKey((java.lang.Comparable) 1.0f);
        int int41 = timePeriodValues32.getMinMiddleIndex();
        int int42 = timePeriodValues32.getMinMiddleIndex();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        java.lang.String str44 = year43.toString();
        boolean boolean45 = timePeriodValues32.equals((java.lang.Object) year43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year43.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year43.next();
        boolean boolean48 = timePeriodValues3.equals((java.lang.Object) year43);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "2019" + "'", str44.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: 13-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy(0, (int) '4');
        timePeriodValues4.fireSeriesChanged();
        boolean boolean6 = timePeriodValues4.isEmpty();
        org.junit.Assert.assertNotNull(timePeriodValues4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        int int6 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        long long11 = simpleTimePeriod8.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues15.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, 10.0d);
        int int23 = simpleTimePeriod8.compareTo((java.lang.Object) simpleTimePeriod20);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timePeriodValues27.addChangeListener(seriesChangeListener28);
        timePeriodValues27.setRangeDescription("13-June-2019");
        timePeriodValues27.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        boolean boolean34 = simpleTimePeriod20.equals((java.lang.Object) timePeriodValues27);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        java.util.Date date11 = simpleTimePeriod8.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod8);
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) (byte) 10);
//        java.lang.Number number15 = timePeriodValue14.getValue();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(2019);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray22 = timePeriodFormatException21.getSuppressed();
//        java.lang.Throwable[] throwableArray23 = timePeriodFormatException21.getSuppressed();
//        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
//        int int25 = year17.compareTo((java.lang.Object) timePeriodFormatException19);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.String str27 = day26.toString();
//        long long28 = day26.getSerialIndex();
//        java.lang.Object obj29 = null;
//        int int30 = day26.compareTo(obj29);
//        int int31 = day26.getMonth();
//        int int33 = day26.compareTo((java.lang.Object) (short) 1);
//        long long34 = day26.getLastMillisecond();
//        boolean boolean35 = year17.equals((java.lang.Object) day26);
//        boolean boolean36 = timePeriodValue14.equals((java.lang.Object) boolean35);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (byte) 10 + "'", number15.equals((byte) 10));
//        org.junit.Assert.assertNotNull(throwableArray22);
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43629L + "'", long28 == 43629L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560495599999L + "'", long34 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: hi!");
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        int int7 = day0.getMonth();
//        long long8 = day0.getFirstMillisecond();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = day0.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        timePeriodValues3.setNotify(false);
        int int15 = timePeriodValues3.getMinStartIndex();
        try {
            timePeriodValues3.update((-1), (java.lang.Number) 1560452399999L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "13-June-2019", "", "TimePeriodValue[13-June-2019,null]");
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        long long12 = simpleTimePeriod8.getStartMillis();
        long long13 = simpleTimePeriod8.getStartMillis();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues6.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        java.util.Date date12 = day10.getEnd();
//        long long13 = day10.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (short) -1);
//        java.lang.Number number16 = null;
//        timePeriodValue15.setValue(number16);
//        timePeriodValues6.add(timePeriodValue15);
//        java.lang.String str19 = timePeriodValue15.toString();
//        java.lang.Number number20 = timePeriodValue15.getValue();
//        java.lang.Number number21 = timePeriodValue15.getValue();
//        org.junit.Assert.assertNotNull(timePeriodValues6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str19.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNull(number21);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues17.addChangeListener(seriesChangeListener18);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues23.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, 10.0d);
        timePeriodValues17.setKey((java.lang.Comparable) simpleTimePeriod28);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
        timePeriodValues35.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
        timePeriodValues35.removeChangeListener(seriesChangeListener40);
        timePeriodValues35.setKey((java.lang.Comparable) 1.0f);
        int int44 = timePeriodValues35.getMinMiddleIndex();
        int int45 = timePeriodValues35.getMinMiddleIndex();
        boolean boolean46 = simpleTimePeriod28.equals((java.lang.Object) timePeriodValues35);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, (java.lang.Number) 1562097599999L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener49 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener49);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue52 = timePeriodValues3.getDataItem(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getEnd();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day0.equals(obj8);
//        int int10 = day0.getYear();
//        java.util.Date date11 = day0.getEnd();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        long long13 = year12.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 10.0d);
        java.util.Date date43 = simpleTimePeriod40.getEnd();
        long long44 = simpleTimePeriod40.getStartMillis();
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod40.equals(obj45);
        boolean boolean47 = year9.equals((java.lang.Object) simpleTimePeriod40);
        java.util.Date date48 = simpleTimePeriod40.getStart();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
        long long50 = day49.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-14400001L) + "'", long50 == (-14400001L));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.SerialDate serialDate10 = day9.getSerialDate();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate10);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues21.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener26);
        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
        int int30 = timePeriodValues21.getMinMiddleIndex();
        int int31 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
        java.util.Date date33 = simpleTimePeriod14.getStart();
        java.util.Date date34 = simpleTimePeriod14.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod14, "", "13-June-2019");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date34);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.lang.Class<?> wildcardClass11 = simpleTimePeriod8.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues15.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, 10.0d);
        java.lang.Class<?> wildcardClass23 = simpleTimePeriod20.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues28.addPropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) simpleTimePeriod33, 10.0d);
        java.util.Date date36 = simpleTimePeriod33.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timePeriodValues42.addPropertyChangeListener(propertyChangeListener43);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues42.add((org.jfree.data.time.TimePeriod) simpleTimePeriod47, 10.0d);
        java.util.Date date50 = simpleTimePeriod47.getEnd();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date50);
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date50, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date36, timeZone53);
        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        boolean boolean57 = simpleTimePeriod8.equals((java.lang.Object) wildcardClass23);
        org.jfree.data.time.TimePeriodValues timePeriodValues61 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener62 = null;
        timePeriodValues61.addPropertyChangeListener(propertyChangeListener62);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues61.add((org.jfree.data.time.TimePeriod) simpleTimePeriod66, 10.0d);
        int int69 = timePeriodValues61.getMaxMiddleIndex();
        boolean boolean70 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues61);
        java.util.Date date71 = simpleTimePeriod8.getEnd();
        long long72 = simpleTimePeriod8.getStartMillis();
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(class56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues20.addPropertyChangeListener(propertyChangeListener21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) simpleTimePeriod25, 10.0d);
        java.util.Date date28 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.Class<?> wildcardClass33 = seriesChangeEvent32.getClass();
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        int int35 = day30.compareTo((java.lang.Object) wildcardClass33);
        java.util.Date date36 = day30.getStart();
        java.util.Date date37 = day30.getStart();
        boolean boolean38 = year14.equals((java.lang.Object) date37);
        java.util.Date date39 = year14.getEnd();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
        timePeriodValues3.setNotify(true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues12.addPropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod17, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues23.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, 10.0d);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues12.addPropertyChangeListener(propertyChangeListener33);
        java.lang.String str35 = timePeriodValues12.getDomainDescription();
        timePeriodValues12.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        timePeriodValues12.setKey((java.lang.Comparable) 11);
        timePeriodValues12.fireSeriesChanged();
        boolean boolean41 = timePeriodValues3.equals((java.lang.Object) timePeriodValues12);
        int int42 = timePeriodValues12.getMinEndIndex();
        int int43 = timePeriodValues12.getItemCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str35.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2 + "'", int43 == 2);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "org.jfree.data.time.TimePeriodFormatException: hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year8, "org.jfree.data.time.TimePeriodFormatException: ", "13-June-2019");
//        boolean boolean13 = year8.equals((java.lang.Object) 13);
//        int int14 = day0.compareTo((java.lang.Object) 13);
//        int int15 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        java.util.Date date6 = regularTimePeriod5.getEnd();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6);
//        java.lang.String str9 = day8.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "14-June-2019" + "'", str9.equals("14-June-2019"));
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        long long11 = simpleTimePeriod8.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues15.addPropertyChangeListener(propertyChangeListener16);
        java.lang.String str18 = timePeriodValues15.getRangeDescription();
        timePeriodValues15.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.lang.String str22 = year21.toString();
        int int23 = year21.getYear();
        timePeriodValues15.setKey((java.lang.Comparable) year21);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timePeriodValues28.addChangeListener(seriesChangeListener29);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
        timePeriodValues28.setKey((java.lang.Comparable) simpleTimePeriod39);
        boolean boolean43 = year21.equals((java.lang.Object) timePeriodValues28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year21.previous();
        long long46 = year21.getFirstMillisecond();
        boolean boolean47 = simpleTimePeriod8.equals((java.lang.Object) long46);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues3.createCopy(4, (int) (short) 1);
        try {
            timePeriodValues3.delete((int) (short) -1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getFirstMillisecond();
//        java.lang.String str5 = day0.toString();
//        java.lang.String str6 = day0.toString();
//        java.util.Calendar calendar7 = null;
//        try {
//            day0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        java.util.Date date18 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        java.util.Date date30 = simpleTimePeriod27.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date18, date30);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date30);
        java.lang.String str35 = day34.toString();
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "31-December-1969" + "'", str35.equals("31-December-1969"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        int int4 = timePeriodValues3.getItemCount();
        java.lang.String str5 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        java.lang.String str12 = timePeriodValues9.getRangeDescription();
        timePeriodValues9.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.lang.String str16 = year15.toString();
        int int17 = year15.getYear();
        timePeriodValues9.setKey((java.lang.Comparable) year15);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timePeriodValues22.addChangeListener(seriesChangeListener23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues28.addPropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) simpleTimePeriod33, 10.0d);
        timePeriodValues22.setKey((java.lang.Comparable) simpleTimePeriod33);
        boolean boolean37 = year15.equals((java.lang.Object) timePeriodValues22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year15.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year15.previous();
        boolean boolean40 = timePeriodValues3.equals((java.lang.Object) year15);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
//        int int2 = timePeriodValues1.getMinMiddleIndex();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getSerialIndex();
//        java.util.Date date5 = day3.getEnd();
//        long long6 = day3.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (java.lang.Number) (short) -1);
//        java.lang.Number number9 = timePeriodValue8.getValue();
//        timePeriodValues1.add(timePeriodValue8);
//        java.lang.String str11 = timePeriodValues1.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) -1 + "'", number9.equals((short) -1));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        int int4 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setNotify(false);
        try {
            timePeriodValues3.update((-1), (java.lang.Number) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues21.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener26);
        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
        int int30 = timePeriodValues21.getMinMiddleIndex();
        int int31 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
        int int33 = timePeriodValues21.getMaxEndIndex();
        int int34 = timePeriodValues21.getItemCount();
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        long long13 = day12.getMiddleMillisecond();
        java.util.Date date14 = day12.getEnd();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-14400001L) + "'", long13 == (-14400001L));
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues27.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, 10.0d);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 0L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 13);
        java.lang.String str39 = timePeriodValues3.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener40);
        try {
            org.jfree.data.time.TimePeriod timePeriod43 = timePeriodValues3.getTimePeriod(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str39.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.lang.String str4 = day3.toString();
//        long long5 = day3.getSerialIndex();
//        long long6 = day3.getLastMillisecond();
//        java.util.Date date7 = day3.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        long long10 = day8.getSerialIndex();
//        long long11 = day8.getLastMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues17.addPropertyChangeListener(propertyChangeListener18);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues17.add((org.jfree.data.time.TimePeriod) simpleTimePeriod22, 10.0d);
//        java.lang.Class<?> wildcardClass25 = simpleTimePeriod22.getClass();
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timePeriodValues30.addPropertyChangeListener(propertyChangeListener31);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues30.add((org.jfree.data.time.TimePeriod) simpleTimePeriod35, 10.0d);
//        java.util.Date date38 = simpleTimePeriod35.getEnd();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38);
//        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timePeriodValues44.addPropertyChangeListener(propertyChangeListener45);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues44.add((org.jfree.data.time.TimePeriod) simpleTimePeriod49, 10.0d);
//        java.util.Date date52 = simpleTimePeriod49.getEnd();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date52);
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date52, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date38, timeZone55);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date12, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone55);
//        java.lang.Class class60 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(class60);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        java.util.Date date11 = simpleTimePeriod8.getEnd();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        java.lang.String str13 = day12.toString();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        long long16 = day14.getSerialIndex();
//        java.lang.Object obj17 = null;
//        int int18 = day14.compareTo(obj17);
//        boolean boolean19 = day12.equals((java.lang.Object) int18);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
//        java.lang.String str21 = year20.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.previous();
//        java.util.Date date23 = regularTimePeriod22.getEnd();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getSerialIndex();
//        java.lang.Class<?> wildcardClass26 = day24.getClass();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        long long29 = day27.getSerialIndex();
//        long long30 = day27.getLastMillisecond();
//        java.util.Date date31 = day27.getStart();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.lang.String str33 = day32.toString();
//        long long34 = day32.getSerialIndex();
//        long long35 = day32.getLastMillisecond();
//        java.util.Date date36 = day32.getStart();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
//        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener42 = null;
//        timePeriodValues41.addPropertyChangeListener(propertyChangeListener42);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues41.add((org.jfree.data.time.TimePeriod) simpleTimePeriod46, 10.0d);
//        java.lang.Class<?> wildcardClass49 = simpleTimePeriod46.getClass();
//        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass49);
//        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener55 = null;
//        timePeriodValues54.addPropertyChangeListener(propertyChangeListener55);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod59 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues54.add((org.jfree.data.time.TimePeriod) simpleTimePeriod59, 10.0d);
//        java.util.Date date62 = simpleTimePeriod59.getEnd();
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date62);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date62);
//        org.jfree.data.time.TimePeriodValues timePeriodValues68 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener69 = null;
//        timePeriodValues68.addPropertyChangeListener(propertyChangeListener69);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod73 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues68.add((org.jfree.data.time.TimePeriod) simpleTimePeriod73, 10.0d);
//        java.util.Date date76 = simpleTimePeriod73.getEnd();
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date76);
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date76);
//        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date76, timeZone79);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date62, timeZone79);
//        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date36, timeZone79);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date31, timeZone79);
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date23, timeZone79);
//        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(date23);
//        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day();
//        java.lang.String str87 = day86.toString();
//        long long88 = day86.getSerialIndex();
//        java.lang.Object obj89 = null;
//        int int90 = day86.compareTo(obj89);
//        int int91 = day86.getMonth();
//        org.jfree.data.time.SerialDate serialDate92 = day86.getSerialDate();
//        long long93 = day86.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate94 = day86.getSerialDate();
//        int int95 = year85.compareTo((java.lang.Object) day86);
//        int int96 = day12.compareTo((java.lang.Object) day86);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-1969" + "'", str13.equals("31-December-1969"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43629L + "'", long16 == 43629L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43629L + "'", long25 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43629L + "'", long29 == 43629L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560495599999L + "'", long30 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "13-June-2019" + "'", str33.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 43629L + "'", long34 == 43629L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560495599999L + "'", long35 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(class50);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(timeZone79);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "13-June-2019" + "'", str87.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 43629L + "'", long88 == 43629L);
//        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 1 + "'", int90 == 1);
//        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 6 + "'", int91 == 6);
//        org.junit.Assert.assertNotNull(serialDate92);
//        org.junit.Assert.assertTrue("'" + long93 + "' != '" + 43629L + "'", long93 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate94);
//        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + (-18061) + "'", int96 == (-18061));
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
//        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
//        int int9 = year1.compareTo((java.lang.Object) timePeriodFormatException3);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        long long12 = day10.getSerialIndex();
//        java.lang.Object obj13 = null;
//        int int14 = day10.compareTo(obj13);
//        int int15 = day10.getMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day10.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate16);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate16);
//        int int20 = year1.compareTo((java.lang.Object) day19);
//        long long21 = year1.getMiddleMillisecond();
//        java.lang.Object obj22 = null;
//        int int23 = year1.compareTo(obj22);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1562097599999L + "'", long21 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.setDomainDescription("TimePeriodValue[13-June-2019,null]");
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues17.addPropertyChangeListener(propertyChangeListener18);
        int int20 = timePeriodValues17.getMinEndIndex();
        timePeriodValues17.setRangeDescription("hi!");
        java.lang.Object obj23 = timePeriodValues17.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues17);
        boolean boolean25 = timePeriodValues3.equals((java.lang.Object) seriesChangeEvent24);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        int int4 = timePeriodValues3.getMaxMiddleIndex();
        int int5 = timePeriodValues3.getItemCount();
        int int6 = timePeriodValues3.getMinMiddleIndex();
        boolean boolean7 = timePeriodValues3.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("TimePeriodValue[13-June-2019,null]");
        int int13 = timePeriodValues3.getItemCount();
        int int14 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getEnd();
//        long long8 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "org.jfree.data.time.TimePeriodFormatException: hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        boolean boolean8 = timePeriodValues7.getNotify();
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timePeriodValues12.addChangeListener(seriesChangeListener13);
//        timePeriodValues12.setRangeDescription("13-June-2019");
//        timePeriodValues12.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
//        java.util.Date date30 = simpleTimePeriod27.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod27);
//        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod27, (java.lang.Number) (byte) 10);
//        timePeriodValues12.add(timePeriodValue33);
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
//        boolean boolean37 = timePeriodValue33.equals((java.lang.Object) timePeriodValues36);
//        java.lang.Number number38 = timePeriodValue33.getValue();
//        org.jfree.data.time.TimePeriod timePeriod39 = timePeriodValue33.getPeriod();
//        timePeriodValues7.add(timePeriodValue33);
//        java.lang.Object obj41 = timePeriodValue33.clone();
//        java.lang.String str42 = timePeriodValue33.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + number38 + "' != '" + (byte) 10 + "'", number38.equals((byte) 10));
//        org.junit.Assert.assertNotNull(timePeriod39);
//        org.junit.Assert.assertNotNull(obj41);
//    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Date date4 = day0.getEnd();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        java.lang.Class<?> wildcardClass7 = day5.getClass();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        long long10 = day8.getSerialIndex();
//        long long11 = day8.getLastMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        long long15 = day13.getSerialIndex();
//        long long16 = day13.getLastMillisecond();
//        java.util.Date date17 = day13.getStart();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
//        java.lang.Class<?> wildcardClass30 = simpleTimePeriod27.getClass();
//        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 10.0d);
//        java.util.Date date43 = simpleTimePeriod40.getEnd();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date43);
//        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener50 = null;
//        timePeriodValues49.addPropertyChangeListener(propertyChangeListener50);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues49.add((org.jfree.data.time.TimePeriod) simpleTimePeriod54, 10.0d);
//        java.util.Date date57 = simpleTimePeriod54.getEnd();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date57);
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date57, timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date43, timeZone60);
//        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date17, timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date12, timeZone60);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date4, timeZone60);
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
//        long long67 = year66.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue69 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year66, (double) 2019);
//        int int71 = year66.compareTo((java.lang.Object) 0L);
//        boolean boolean72 = day65.equals((java.lang.Object) year66);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 2019L + "'", long67 == 2019L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        timePeriodValues6.fireSeriesChanged();
        int int8 = timePeriodValues6.getMaxStartIndex();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getEnd();
//        java.lang.Object obj8 = null;
//        int int9 = day0.compareTo(obj8);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.lang.String str2 = year0.toString();
        java.util.Date date3 = year0.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Object obj9 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        java.lang.Object obj11 = seriesChangeEvent10.getSource();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.lang.String str10 = timePeriodValues3.getDescription();
        int int11 = timePeriodValues3.getItemCount();
        boolean boolean13 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("");
        int int9 = timePeriodValues3.getMinStartIndex();
        int int10 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod19);
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) (byte) 10);
        java.lang.Number number26 = timePeriodValue25.getValue();
        java.lang.String str27 = timePeriodValue25.toString();
        java.lang.Number number28 = null;
        timePeriodValue25.setValue(number28);
        timePeriodValues3.add(timePeriodValue25);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
        java.lang.String str37 = timePeriodValues34.getRangeDescription();
        timePeriodValues34.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        java.lang.String str41 = year40.toString();
        int int42 = year40.getYear();
        timePeriodValues34.setKey((java.lang.Comparable) year40);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year40, (java.lang.Number) 2019.0d);
        org.jfree.data.general.SeriesException seriesException47 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        int int48 = year40.compareTo((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (byte) 10 + "'", number26.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2019" + "'", str41.equals("2019"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod8);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) (byte) 10);
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue14.getPeriod();
        timePeriodValue14.setValue((java.lang.Number) 0.0f);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timePeriod15);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
//        int int24 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.lang.String str26 = day25.toString();
//        long long27 = day25.getSerialIndex();
//        long long28 = day25.getLastMillisecond();
//        long long29 = day25.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate30 = day25.getSerialDate();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day31, (double) 5);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "13-June-2019" + "'", str26.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43629L + "'", long27 == 43629L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560495599999L + "'", long28 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560409200000L + "'", long29 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate30);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        int int24 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues3.createCopy(13, 11);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener28);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues27);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "org.jfree.data.time.TimePeriodFormatException: hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        boolean boolean8 = timePeriodValues7.getNotify();
//        java.lang.Number number10 = null;
//        try {
//            timePeriodValues7.update((int) '#', number10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) (short) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day7.previous();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues3.getItemCount();
        int int10 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.String str5 = day4.toString();
//        long long6 = day4.getSerialIndex();
//        long long7 = day4.getLastMillisecond();
//        boolean boolean9 = day4.equals((java.lang.Object) "hi!");
//        boolean boolean10 = day0.equals((java.lang.Object) boolean9);
//        boolean boolean12 = day0.equals((java.lang.Object) 13);
//        java.util.Date date13 = day0.getStart();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        long long15 = day14.getSerialIndex();
//        java.lang.Object obj16 = null;
//        int int17 = day14.compareTo(obj16);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues6.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        java.lang.Class<?> wildcardClass12 = day10.getClass();
//        timePeriodValues6.setKey((java.lang.Comparable) day10);
//        try {
//            timePeriodValues6.update(13, (java.lang.Number) 7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(timePeriodValues6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues21.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener26);
        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
        int int30 = timePeriodValues21.getMinMiddleIndex();
        int int31 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues36.addPropertyChangeListener(propertyChangeListener37);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues36.add((org.jfree.data.time.TimePeriod) simpleTimePeriod41, 10.0d);
        java.util.Date date44 = simpleTimePeriod41.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod41);
        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod41, (java.lang.Number) (byte) 10);
        boolean boolean49 = timePeriodValue47.equals((java.lang.Object) 1560495599999L);
        org.jfree.data.time.TimePeriod timePeriod50 = timePeriodValue47.getPeriod();
        timePeriodValues21.add(timePeriodValue47);
        timePeriodValue47.setValue((java.lang.Number) 1);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(2019);
        java.util.Date date56 = year55.getStart();
        boolean boolean57 = timePeriodValue47.equals((java.lang.Object) date56);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(timePeriod50);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod19);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) 43629L);
        timePeriodValues3.setNotify(true);
        int int28 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 2, (-57600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        int int3 = day0.getDayOfMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        timePeriodValues3.setRangeDescription("hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener8);
//        int int10 = timePeriodValues3.getMinEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
//        java.util.Date date22 = simpleTimePeriod19.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod19);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) 43629L);
//        timePeriodValues3.setDescription("hi!");
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.lang.String str29 = day28.toString();
//        long long30 = day28.getSerialIndex();
//        java.lang.Object obj31 = null;
//        int int32 = day28.compareTo(obj31);
//        int int33 = day28.getMonth();
//        org.jfree.data.time.SerialDate serialDate34 = day28.getSerialDate();
//        int int35 = day28.getMonth();
//        long long36 = day28.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day28.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day28.previous();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod38, (java.lang.Number) 5);
//        int int41 = timePeriodValues3.getMinEndIndex();
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "13-June-2019" + "'", str29.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43629L + "'", long30 == 43629L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560409200000L + "'", long36 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        int int14 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.String str15 = timePeriodValues3.getDomainDescription();
        int int16 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str15.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setRangeDescription("13-June-2019");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod18);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 10);
        timePeriodValues3.add(timePeriodValue24);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
        boolean boolean28 = timePeriodValue24.equals((java.lang.Object) timePeriodValues27);
        java.lang.Number number29 = timePeriodValue24.getValue();
        timePeriodValue24.setValue((java.lang.Number) 100.0f);
        timePeriodValue24.setValue((java.lang.Number) (byte) 10);
        java.lang.Object obj34 = timePeriodValue24.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timePeriodValues38.addPropertyChangeListener(propertyChangeListener39);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues38.add((org.jfree.data.time.TimePeriod) simpleTimePeriod43, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timePeriodValues49.addPropertyChangeListener(propertyChangeListener50);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues49.add((org.jfree.data.time.TimePeriod) simpleTimePeriod54, 10.0d);
        timePeriodValues38.add((org.jfree.data.time.TimePeriod) simpleTimePeriod54, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timePeriodValues38.addPropertyChangeListener(propertyChangeListener59);
        java.lang.String str61 = timePeriodValues38.getDomainDescription();
        int int62 = timePeriodValues38.getItemCount();
        boolean boolean63 = timePeriodValue24.equals((java.lang.Object) timePeriodValues38);
        java.lang.String str64 = timePeriodValues38.getDomainDescription();
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (byte) 10 + "'", number29.equals((byte) 10));
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str61.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2 + "'", int62 == 2);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str64.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues6.addPropertyChangeListener(propertyChangeListener7);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues6.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, 10.0d);
//        java.util.Date date14 = simpleTimePeriod11.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod11);
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (java.lang.Number) (byte) 10);
//        java.lang.Number number18 = timePeriodValue17.getValue();
//        java.lang.String str19 = timePeriodValue17.toString();
//        int int20 = day0.compareTo((java.lang.Object) timePeriodValue17);
//        java.util.Calendar calendar21 = null;
//        try {
//            long long22 = day0.getLastMillisecond(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (byte) 10 + "'", number18.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues3.getRangeDescription();
//        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        java.lang.String str10 = year9.toString();
//        int int11 = year9.getYear();
//        timePeriodValues3.setKey((java.lang.Comparable) year9);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
//        timePeriodValues16.addChangeListener(seriesChangeListener17);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
//        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
//        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 10.0d);
//        java.util.Date date43 = simpleTimePeriod40.getEnd();
//        long long44 = simpleTimePeriod40.getStartMillis();
//        java.lang.Object obj45 = null;
//        boolean boolean46 = simpleTimePeriod40.equals(obj45);
//        boolean boolean47 = year9.equals((java.lang.Object) simpleTimePeriod40);
//        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod40, "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!", "org.jfree.data.general.SeriesException: hi!");
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        java.lang.String str52 = day51.toString();
//        long long53 = day51.getSerialIndex();
//        java.lang.Object obj54 = null;
//        int int55 = day51.compareTo(obj54);
//        int int56 = day51.getMonth();
//        org.jfree.data.time.SerialDate serialDate57 = day51.getSerialDate();
//        int int58 = day51.getMonth();
//        boolean boolean60 = day51.equals((java.lang.Object) 10);
//        boolean boolean61 = simpleTimePeriod40.equals((java.lang.Object) 10);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        long long63 = day62.getSerialIndex();
//        java.util.Date date64 = day62.getEnd();
//        long long65 = day62.getLastMillisecond();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        java.lang.String str67 = day66.toString();
//        long long68 = day66.getSerialIndex();
//        long long69 = day66.getLastMillisecond();
//        boolean boolean71 = day66.equals((java.lang.Object) "hi!");
//        boolean boolean72 = day62.equals((java.lang.Object) boolean71);
//        boolean boolean74 = day62.equals((java.lang.Object) 13);
//        org.jfree.data.time.SerialDate serialDate75 = day62.getSerialDate();
//        boolean boolean76 = simpleTimePeriod40.equals((java.lang.Object) serialDate75);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "13-June-2019" + "'", str52.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 43629L + "'", long53 == 43629L);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 6 + "'", int56 == 6);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 43629L + "'", long63 == 43629L);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560495599999L + "'", long65 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "13-June-2019" + "'", str67.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 43629L + "'", long68 == 43629L);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560495599999L + "'", long69 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 3);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        long long5 = day3.getSerialIndex();
//        int int6 = simpleTimePeriod2.compareTo((java.lang.Object) day3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setRangeDescription("13-June-2019");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod18);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 10);
        timePeriodValues3.add(timePeriodValue24);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
        boolean boolean28 = timePeriodValue24.equals((java.lang.Object) timePeriodValues27);
        java.lang.String str29 = timePeriodValue24.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues33.addPropertyChangeListener(propertyChangeListener34);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues33.add((org.jfree.data.time.TimePeriod) simpleTimePeriod38, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timePeriodValues44.addPropertyChangeListener(propertyChangeListener45);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues44.add((org.jfree.data.time.TimePeriod) simpleTimePeriod49, 10.0d);
        timePeriodValues33.add((org.jfree.data.time.TimePeriod) simpleTimePeriod49, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener54 = null;
        timePeriodValues33.addPropertyChangeListener(propertyChangeListener54);
        java.lang.String str56 = timePeriodValues33.getDomainDescription();
        timePeriodValues33.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        boolean boolean59 = timePeriodValue24.equals((java.lang.Object) timePeriodValues33);
        java.lang.Number number60 = timePeriodValue24.getValue();
        timePeriodValue24.setValue((java.lang.Number) 0.0d);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str56.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + (byte) 10 + "'", number60.equals((byte) 10));
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate6);
//        long long9 = day8.getMiddleMillisecond();
//        java.lang.String str10 = day8.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560452399999L + "'", long9 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues6.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        java.lang.Class<?> wildcardClass12 = day10.getClass();
//        timePeriodValues6.setKey((java.lang.Comparable) day10);
//        int int14 = timePeriodValues6.getMaxMiddleIndex();
//        java.lang.String str15 = timePeriodValues6.getRangeDescription();
//        java.lang.Class<?> wildcardClass16 = timePeriodValues6.getClass();
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.junit.Assert.assertNotNull(timePeriodValues6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(class17);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        timePeriodValues6.fireSeriesChanged();
        java.lang.String str8 = timePeriodValues6.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues6.removePropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod8);
        java.lang.String str13 = seriesChangeEvent12.toString();
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "org.jfree.data.time.TimePeriodFormatException: ", "13-June-2019");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        timePeriodValues3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        int int13 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        int int6 = day0.getMonth();
//        java.lang.String str7 = day0.toString();
//        long long8 = day0.getLastMillisecond();
//        long long9 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560495599999L + "'", long9 == 1560495599999L);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setRangeDescription("13-June-2019");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod18);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 10);
        timePeriodValues3.add(timePeriodValue24);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
        boolean boolean28 = timePeriodValue24.equals((java.lang.Object) timePeriodValues27);
        java.lang.Number number29 = timePeriodValue24.getValue();
        timePeriodValue24.setValue((java.lang.Number) 100.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timePeriodValues46.addPropertyChangeListener(propertyChangeListener47);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues46.add((org.jfree.data.time.TimePeriod) simpleTimePeriod51, 10.0d);
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod51, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues35.addPropertyChangeListener(propertyChangeListener56);
        java.lang.String str58 = timePeriodValues35.getDomainDescription();
        timePeriodValues35.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues63 = timePeriodValues35.createCopy(9, (int) (short) 1);
        boolean boolean64 = timePeriodValue24.equals((java.lang.Object) 9);
        java.lang.Number number65 = timePeriodValue24.getValue();
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (byte) 10 + "'", number29.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str58.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertNotNull(timePeriodValues63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 100.0f + "'", number65.equals(100.0f));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues11.addChangeListener(seriesChangeListener12);
        timePeriodValues11.setRangeDescription("13-June-2019");
        timePeriodValues11.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
        java.util.Date date29 = simpleTimePeriod26.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod26);
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod26, (java.lang.Number) (byte) 10);
        timePeriodValues11.add(timePeriodValue32);
        timePeriodValues6.add(timePeriodValue32);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.next();
        boolean boolean37 = timePeriodValues6.equals((java.lang.Object) year35);
        long long38 = year35.getLastMillisecond();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "org.jfree.data.time.TimePeriodFormatException: hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues7.removePropertyChangeListener(propertyChangeListener8);
//        int int10 = timePeriodValues7.getMaxEndIndex();
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues7.getDataItem((int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMaxStartIndex();
        java.lang.Class<?> wildcardClass8 = timePeriodValues6.getClass();
        int int9 = timePeriodValues6.getMinEndIndex();
        timePeriodValues6.setDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
        timePeriodValues6.setRangeDescription("2019");
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year9.next();
        long long16 = year9.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        java.util.Date date6 = regularTimePeriod5.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues10.addChangeListener(seriesChangeListener11);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, 10.0d);
//        timePeriodValues10.setKey((java.lang.Comparable) simpleTimePeriod21);
//        java.util.Date date25 = simpleTimePeriod21.getEnd();
//        java.lang.Class class26 = null;
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        java.lang.String str28 = year27.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.previous();
//        java.util.Date date30 = regularTimePeriod29.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date42, timeZone45);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date30, timeZone45);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date25, timeZone45);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date6, timeZone45);
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
//        timePeriodValues53.addChangeListener(seriesChangeListener54);
//        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener60 = null;
//        timePeriodValues59.addPropertyChangeListener(propertyChangeListener60);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues59.add((org.jfree.data.time.TimePeriod) simpleTimePeriod64, 10.0d);
//        timePeriodValues53.setKey((java.lang.Comparable) simpleTimePeriod64);
//        java.util.Date date68 = simpleTimePeriod64.getEnd();
//        boolean boolean69 = year49.equals((java.lang.Object) simpleTimePeriod64);
//        long long70 = simpleTimePeriod64.getStartMillis();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues6.removePropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues6.getItemCount();
        int int11 = timePeriodValues6.getMaxStartIndex();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        int int7 = day0.getMonth();
//        boolean boolean9 = day0.equals((java.lang.Object) 10);
//        int int10 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues27.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, 10.0d);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 0L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 13);
        int int39 = timePeriodValues3.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener40);
        int int42 = timePeriodValues3.getItemCount();
        timePeriodValues3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod19);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) 43629L);
        timePeriodValues3.setDescription("hi!");
        int int28 = timePeriodValues3.getMinMiddleIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod30 = timePeriodValues3.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        int int4 = timePeriodValues3.getItemCount();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        java.util.Date date18 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        java.util.Date date30 = simpleTimePeriod27.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date18, date30);
        java.util.Date date33 = simpleTimePeriod32.getStart();
        java.util.Date date34 = simpleTimePeriod32.getEnd();
        java.lang.Class class35 = null;
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.lang.String str37 = year36.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year36.previous();
        java.util.Date date39 = regularTimePeriod38.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues43.addPropertyChangeListener(propertyChangeListener44);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues43.add((org.jfree.data.time.TimePeriod) simpleTimePeriod48, 10.0d);
        java.util.Date date51 = simpleTimePeriod48.getEnd();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date51);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date51, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date39, timeZone54);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date34, timeZone54);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2019" + "'", str37.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod56);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValues3.getTimePeriod(0);
        boolean boolean28 = timePeriodValues3.getNotify();
        int int29 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.update((int) (short) 1, (java.lang.Number) 3);
        java.lang.Comparable comparable33 = timePeriodValues3.getKey();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertNotNull(timePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + "hi!" + "'", comparable33.equals("hi!"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        int int24 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setNotify(true);
        timePeriodValues3.setDomainDescription("");
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues3.update((int) (short) 0, (java.lang.Number) 10L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        timePeriodValues3.fireSeriesChanged();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener7);
//        boolean boolean10 = timePeriodValues3.equals((java.lang.Object) 0.0f);
//        timePeriodValues3.setKey((java.lang.Comparable) 1577865599999L);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getSerialIndex();
//        java.util.Date date15 = day13.getEnd();
//        long long16 = day13.getLastMillisecond();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        long long19 = day17.getSerialIndex();
//        long long20 = day17.getLastMillisecond();
//        boolean boolean22 = day17.equals((java.lang.Object) "hi!");
//        boolean boolean23 = day13.equals((java.lang.Object) boolean22);
//        boolean boolean25 = day13.equals((java.lang.Object) 13);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560495599999L + "'", long20 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        int int17 = year14.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 'a');
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year20, "org.jfree.data.time.TimePeriodFormatException: ", "13-June-2019");
        int int24 = year14.compareTo((java.lang.Object) "13-June-2019");
        int int25 = year14.getYear();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
//        long long10 = day9.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate11);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        java.lang.Object obj7 = timePeriodValues6.clone();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener8);
        java.lang.Class<?> wildcardClass10 = timePeriodValues6.getClass();
        int int11 = timePeriodValues6.getItemCount();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year9.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year9.previous();
        java.lang.String str34 = year9.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues3.getRangeDescription();
//        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        java.lang.String str10 = year9.toString();
//        int int11 = year9.getYear();
//        timePeriodValues3.setKey((java.lang.Comparable) year9);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getSerialIndex();
//        java.util.Date date15 = day13.getEnd();
//        long long16 = day13.getLastMillisecond();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        long long19 = day17.getSerialIndex();
//        long long20 = day17.getLastMillisecond();
//        boolean boolean22 = day17.equals((java.lang.Object) "hi!");
//        boolean boolean23 = day13.equals((java.lang.Object) boolean22);
//        boolean boolean25 = day13.equals((java.lang.Object) 13);
//        java.util.Date date26 = day13.getStart();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
//        boolean boolean28 = timePeriodValues3.equals((java.lang.Object) day27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day27.next();
//        int int30 = day27.getMonth();
//        java.lang.String str31 = day27.toString();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560495599999L + "'", long20 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "13-June-2019" + "'", str31.equals("13-June-2019"));
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues20.addPropertyChangeListener(propertyChangeListener21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) simpleTimePeriod25, 10.0d);
        java.util.Date date28 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.Class<?> wildcardClass33 = seriesChangeEvent32.getClass();
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        int int35 = day30.compareTo((java.lang.Object) wildcardClass33);
        java.util.Date date36 = day30.getStart();
        java.util.Date date37 = day30.getStart();
        boolean boolean38 = year14.equals((java.lang.Object) date37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date37);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        int int4 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.setNotify(true);
        try {
            java.lang.Number number8 = timePeriodValues3.getValue((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 10.0d);
        java.util.Date date43 = simpleTimePeriod40.getEnd();
        long long44 = simpleTimePeriod40.getStartMillis();
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod40.equals(obj45);
        boolean boolean47 = year9.equals((java.lang.Object) simpleTimePeriod40);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod40, "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!", "org.jfree.data.general.SeriesException: hi!");
        java.util.Date date51 = simpleTimePeriod40.getStart();
        java.util.Date date52 = simpleTimePeriod40.getStart();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(date52);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setRangeDescription("13-June-2019");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod18);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 10);
        timePeriodValues3.add(timePeriodValue24);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
        boolean boolean28 = timePeriodValue24.equals((java.lang.Object) timePeriodValues27);
        org.jfree.data.time.TimePeriod timePeriod29 = timePeriodValue24.getPeriod();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriod29);
        java.lang.String str31 = seriesChangeEvent30.toString();
        java.lang.Object obj32 = seriesChangeEvent30.getSource();
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timePeriod29);
        org.junit.Assert.assertNotNull(obj32);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int1);
//        timePeriodValues2.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues3.getRangeDescription();
//        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        java.lang.String str10 = year9.toString();
//        int int11 = year9.getYear();
//        timePeriodValues3.setKey((java.lang.Comparable) year9);
//        boolean boolean13 = timePeriodValues3.isEmpty();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getSerialIndex();
//        java.util.Date date16 = day14.getEnd();
//        long long17 = day14.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day14, (java.lang.Number) (short) -1);
//        timePeriodValues3.add(timePeriodValue19);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues3.createCopy(4, (int) (short) 1);
        timePeriodValues11.setDescription("");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "org.jfree.data.time.TimePeriodFormatException: hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues7.removePropertyChangeListener(propertyChangeListener8);
//        int int10 = timePeriodValues7.getMaxEndIndex();
//        java.lang.String str11 = timePeriodValues7.getDescription();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNull(str11);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.lang.String str10 = timePeriodValues3.getDescription();
        timePeriodValues3.setNotify(false);
        int int13 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
//        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
//        int int9 = year1.compareTo((java.lang.Object) timePeriodFormatException3);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        long long12 = day10.getSerialIndex();
//        java.lang.Object obj13 = null;
//        int int14 = day10.compareTo(obj13);
//        int int15 = day10.getMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day10.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate16);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate16);
//        int int20 = year1.compareTo((java.lang.Object) day19);
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener25 = null;
//        timePeriodValues24.addPropertyChangeListener(propertyChangeListener25);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues24.add((org.jfree.data.time.TimePeriod) simpleTimePeriod29, 10.0d);
//        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 10.0d);
//        timePeriodValues24.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, (double) 0L);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timePeriodValues24.addPropertyChangeListener(propertyChangeListener45);
//        org.jfree.data.time.TimePeriod timePeriod48 = timePeriodValues24.getTimePeriod(0);
//        int int49 = year1.compareTo((java.lang.Object) timePeriod48);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(timePeriod48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        boolean boolean29 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: 2019");
        java.lang.String str32 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str26.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues21.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener26);
        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
        int int30 = timePeriodValues21.getMinMiddleIndex();
        int int31 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues36.addPropertyChangeListener(propertyChangeListener37);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues36.add((org.jfree.data.time.TimePeriod) simpleTimePeriod41, 10.0d);
        java.util.Date date44 = simpleTimePeriod41.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod41);
        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod41, (java.lang.Number) (byte) 10);
        boolean boolean49 = timePeriodValue47.equals((java.lang.Object) 1560495599999L);
        org.jfree.data.time.TimePeriod timePeriod50 = timePeriodValue47.getPeriod();
        timePeriodValues21.add(timePeriodValue47);
        java.lang.Object obj52 = timePeriodValue47.clone();
        java.lang.Object obj53 = timePeriodValue47.clone();
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(timePeriod50);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNotNull(obj53);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        int int7 = day0.getMonth();
//        int int8 = day0.getYear();
//        long long9 = day0.getFirstMillisecond();
//        int int10 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getMiddleMillisecond();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getFirstMillisecond();
        java.lang.String str5 = year0.toString();
        long long6 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.lang.Class<?> wildcardClass11 = simpleTimePeriod8.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues15.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, 10.0d);
        java.lang.Class<?> wildcardClass23 = simpleTimePeriod20.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues28.addPropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) simpleTimePeriod33, 10.0d);
        java.util.Date date36 = simpleTimePeriod33.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timePeriodValues42.addPropertyChangeListener(propertyChangeListener43);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues42.add((org.jfree.data.time.TimePeriod) simpleTimePeriod47, 10.0d);
        java.util.Date date50 = simpleTimePeriod47.getEnd();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date50);
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date50, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date36, timeZone53);
        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        boolean boolean57 = simpleTimePeriod8.equals((java.lang.Object) wildcardClass23);
        org.jfree.data.time.TimePeriodValues timePeriodValues61 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener62 = null;
        timePeriodValues61.addPropertyChangeListener(propertyChangeListener62);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues61.add((org.jfree.data.time.TimePeriod) simpleTimePeriod66, 10.0d);
        int int69 = timePeriodValues61.getMaxMiddleIndex();
        boolean boolean70 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues61);
        java.util.Date date71 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date71);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(class56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(date71);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues21.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener26);
        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
        int int30 = timePeriodValues21.getMinMiddleIndex();
        int int31 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues36.addPropertyChangeListener(propertyChangeListener37);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues36.add((org.jfree.data.time.TimePeriod) simpleTimePeriod41, 10.0d);
        java.util.Date date44 = simpleTimePeriod41.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod41);
        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod41, (java.lang.Number) (byte) 10);
        boolean boolean49 = timePeriodValue47.equals((java.lang.Object) 1560495599999L);
        org.jfree.data.time.TimePeriod timePeriod50 = timePeriodValue47.getPeriod();
        timePeriodValues21.add(timePeriodValue47);
        int int52 = timePeriodValues21.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(timePeriod50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
//        int int10 = timePeriodValues7.getMinEndIndex();
//        timePeriodValues7.setRangeDescription("hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues7.createCopy(4, (int) (short) 1);
//        int int16 = day0.compareTo((java.lang.Object) timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100L, "", "13-June-2019");
        boolean boolean4 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        long long12 = simpleTimePeriod8.getStartMillis();
        java.util.Date date13 = simpleTimePeriod8.getStart();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(date13);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        int int3 = day0.getMonth();
//        long long4 = day0.getSerialIndex();
//        long long5 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues6.addPropertyChangeListener(propertyChangeListener7);
//        timePeriodValues6.setRangeDescription("hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues6.removeChangeListener(seriesChangeListener11);
//        timePeriodValues6.setKey((java.lang.Comparable) 1.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timePeriodValues6.removeChangeListener(seriesChangeListener15);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timePeriodValues20.addChangeListener(seriesChangeListener21);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timePeriodValues26.addPropertyChangeListener(propertyChangeListener27);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues26.add((org.jfree.data.time.TimePeriod) simpleTimePeriod31, 10.0d);
//        timePeriodValues20.setKey((java.lang.Comparable) simpleTimePeriod31);
//        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener39 = null;
//        timePeriodValues38.addPropertyChangeListener(propertyChangeListener39);
//        timePeriodValues38.setRangeDescription("hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
//        timePeriodValues38.removeChangeListener(seriesChangeListener43);
//        timePeriodValues38.setKey((java.lang.Comparable) 1.0f);
//        int int47 = timePeriodValues38.getMinMiddleIndex();
//        int int48 = timePeriodValues38.getMinMiddleIndex();
//        boolean boolean49 = simpleTimePeriod31.equals((java.lang.Object) timePeriodValues38);
//        timePeriodValues6.add((org.jfree.data.time.TimePeriod) simpleTimePeriod31, (java.lang.Number) 1562097599999L);
//        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener56 = null;
//        timePeriodValues55.addChangeListener(seriesChangeListener56);
//        org.jfree.data.time.TimePeriodValues timePeriodValues61 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener62 = null;
//        timePeriodValues61.addPropertyChangeListener(propertyChangeListener62);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues61.add((org.jfree.data.time.TimePeriod) simpleTimePeriod66, 10.0d);
//        timePeriodValues55.setKey((java.lang.Comparable) simpleTimePeriod66);
//        java.util.Date date70 = simpleTimePeriod66.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener75 = null;
//        timePeriodValues74.addPropertyChangeListener(propertyChangeListener75);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod79 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues74.add((org.jfree.data.time.TimePeriod) simpleTimePeriod79, 10.0d);
//        java.util.Date date82 = simpleTimePeriod79.getEnd();
//        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date82);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod(date70, date82);
//        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(date82);
//        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date82);
//        timePeriodValues6.setKey((java.lang.Comparable) date82);
//        int int88 = day0.compareTo((java.lang.Object) date82);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8, "13-June-2019", "13-June-2019");
        timePeriodValues13.fireSeriesChanged();
        java.lang.Comparable comparable15 = timePeriodValues13.getKey();
        java.lang.Object obj16 = timePeriodValues13.clone();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue18 = timePeriodValues13.getDataItem((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(comparable15);
        org.junit.Assert.assertNotNull(obj16);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
//        long long10 = day9.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) 8);
//        boolean boolean14 = timePeriodValue12.equals((java.lang.Object) false);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        java.lang.Object obj17 = timePeriodValues3.clone();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener20);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        int int6 = day0.getDayOfMonth();
//        int int7 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 2019);
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        java.util.Date date6 = regularTimePeriod5.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues10.addChangeListener(seriesChangeListener11);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, 10.0d);
//        timePeriodValues10.setKey((java.lang.Comparable) simpleTimePeriod21);
//        java.util.Date date25 = simpleTimePeriod21.getEnd();
//        java.lang.Class class26 = null;
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        java.lang.String str28 = year27.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.previous();
//        java.util.Date date30 = regularTimePeriod29.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date42, timeZone45);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date30, timeZone45);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date25, timeZone45);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date6, timeZone45);
//        java.util.Calendar calendar50 = null;
//        try {
//            long long51 = year49.getLastMillisecond(calendar50);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        int int24 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues3.createCopy(13, 11);
        int int28 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
//        java.util.Date date3 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass6 = day4.getClass();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.String str8 = day7.toString();
//        long long9 = day7.getSerialIndex();
//        long long10 = day7.getLastMillisecond();
//        java.util.Date date11 = day7.getStart();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        long long15 = day12.getLastMillisecond();
//        java.util.Date date16 = day12.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
//        java.lang.Class<?> wildcardClass29 = simpleTimePeriod26.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod53, 10.0d);
//        java.util.Date date56 = simpleTimePeriod53.getEnd();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date56, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date42, timeZone59);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date16, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date11, timeZone59);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date3, timeZone59);
//        org.jfree.data.time.SerialDate serialDate65 = day64.getSerialDate();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(serialDate65);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(serialDate65);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 10L);
        java.lang.String str9 = timePeriodValues3.getDescription();
        int int10 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMaxStartIndex();
        java.lang.Class<?> wildcardClass8 = timePeriodValues6.getClass();
        int int9 = timePeriodValues6.getMinStartIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues6.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("");
        int int9 = timePeriodValues3.getMinStartIndex();
        boolean boolean10 = timePeriodValues3.getNotify();
        int int11 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Object obj9 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        long long24 = day23.getMiddleMillisecond();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        long long27 = year25.getMiddleMillisecond();
        long long28 = year25.getLastMillisecond();
        boolean boolean29 = day23.equals((java.lang.Object) long28);
        java.lang.String str30 = day23.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day23.next();
        timePeriodValues3.setKey((java.lang.Comparable) day23);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-14400001L) + "'", long24 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1562097599999L + "'", long27 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-1969" + "'", str30.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        long long13 = day12.getMiddleMillisecond();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 2019);
        boolean boolean18 = day12.equals((java.lang.Object) timePeriodValue17);
        org.jfree.data.time.SerialDate serialDate19 = day12.getSerialDate();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-14400001L) + "'", long13 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.lang.String str10 = timePeriodValues3.getDescription();
        int int11 = timePeriodValues3.getItemCount();
        boolean boolean13 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        timePeriodValues3.delete((int) (short) 1, 0);
        try {
            timePeriodValues3.update(31, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!");
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        java.util.Date date7 = day5.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        long long11 = day9.getSerialIndex();
//        java.lang.Object obj12 = null;
//        int int13 = day9.compareTo(obj12);
//        int int14 = day9.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day9.previous();
//        java.util.Date date16 = regularTimePeriod15.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timePeriodValues20.addPropertyChangeListener(propertyChangeListener21);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues20.add((org.jfree.data.time.TimePeriod) simpleTimePeriod25, 10.0d);
//        java.util.Date date28 = simpleTimePeriod25.getEnd();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        long long31 = day29.getSerialIndex();
//        long long32 = day29.getLastMillisecond();
//        java.util.Date date33 = day29.getStart();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
//        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener39 = null;
//        timePeriodValues38.addPropertyChangeListener(propertyChangeListener39);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues38.add((org.jfree.data.time.TimePeriod) simpleTimePeriod43, 10.0d);
//        java.lang.Class<?> wildcardClass46 = simpleTimePeriod43.getClass();
//        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass46);
//        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener52 = null;
//        timePeriodValues51.addPropertyChangeListener(propertyChangeListener52);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues51.add((org.jfree.data.time.TimePeriod) simpleTimePeriod56, 10.0d);
//        java.util.Date date59 = simpleTimePeriod56.getEnd();
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date59);
//        org.jfree.data.time.TimePeriodValues timePeriodValues65 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener66 = null;
//        timePeriodValues65.addPropertyChangeListener(propertyChangeListener66);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod70 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues65.add((org.jfree.data.time.TimePeriod) simpleTimePeriod70, 10.0d);
//        java.util.Date date73 = simpleTimePeriod70.getEnd();
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date73);
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date73);
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date73, timeZone76);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date59, timeZone76);
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date33, timeZone76);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date28, timeZone76);
//        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date16, timeZone76);
//        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date7, timeZone76);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "13-June-2019" + "'", str30.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43629L + "'", long31 == 43629L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560495599999L + "'", long32 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(class47);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertNull(regularTimePeriod78);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getEnd();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day0.equals(obj8);
//        int int10 = day0.getYear();
//        java.util.Date date11 = day0.getEnd();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(date11);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) -1);
//        java.lang.String str6 = timePeriodValue5.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[13-June-2019,-1]" + "'", str6.equals("TimePeriodValue[13-June-2019,-1]"));
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        int int7 = day0.getMonth();
//        int int8 = day0.getYear();
//        long long9 = day0.getFirstMillisecond();
//        int int10 = day0.getDayOfMonth();
//        int int11 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.lang.Class<?> wildcardClass11 = simpleTimePeriod8.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        timePeriodValues6.fireSeriesChanged();
        java.lang.String str8 = timePeriodValues6.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues6.removeChangeListener(seriesChangeListener9);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues27.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, 10.0d);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 0L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 13);
        int int39 = timePeriodValues3.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener40);
        int int42 = timePeriodValues3.getItemCount();
        int int43 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year9.next();
        long long33 = year9.getFirstMillisecond();
        long long34 = year9.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) 13);
        java.lang.String str37 = year9.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2019" + "'", str37.equals("2019"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues3.createCopy(4, (int) (short) 1);
        int int12 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.lang.String str2 = year0.toString();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        int int4 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValues3.getTimePeriod(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = timePeriodValues3.createCopy(3, (int) (byte) 0);
        java.lang.String str35 = timePeriodValues34.getDescription();
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str26.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues34);
        org.junit.Assert.assertNull(str35);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues17.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues17.add((org.jfree.data.time.TimePeriod) simpleTimePeriod22, 10.0d);
        java.util.Date date25 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(date11, date25);
        java.util.Date date28 = simpleTimePeriod27.getEnd();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date28);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.String str5 = day4.toString();
//        long long6 = day4.getSerialIndex();
//        long long7 = day4.getLastMillisecond();
//        boolean boolean9 = day4.equals((java.lang.Object) "hi!");
//        boolean boolean10 = day0.equals((java.lang.Object) boolean9);
//        boolean boolean12 = day0.equals((java.lang.Object) 13);
//        java.util.Date date13 = day0.getStart();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        long long16 = day15.getSerialIndex();
//        java.util.Date date17 = day15.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day15.previous();
//        int int19 = day15.getMonth();
//        org.jfree.data.time.SerialDate serialDate20 = day15.getSerialDate();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
//        boolean boolean22 = day14.equals((java.lang.Object) day21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day21.next();
//        java.util.Calendar calendar24 = null;
//        try {
//            long long25 = day21.getFirstMillisecond(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43629L + "'", long16 == 43629L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod8);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) (byte) 10);
        boolean boolean16 = timePeriodValue14.equals((java.lang.Object) 1560495599999L);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues20.addPropertyChangeListener(propertyChangeListener21);
        timePeriodValues20.fireSeriesChanged();
        boolean boolean24 = timePeriodValue14.equals((java.lang.Object) timePeriodValues20);
        boolean boolean25 = timePeriodValues20.getNotify();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        int int7 = timePeriodValues6.getMaxMiddleIndex();
        timePeriodValues6.setRangeDescription("");
        int int10 = year0.compareTo((java.lang.Object) timePeriodValues6);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (32) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        java.util.Date date18 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        java.util.Date date30 = simpleTimePeriod27.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date18, date30);
        java.util.Date date33 = simpleTimePeriod32.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date33, "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!", "TimePeriodValue[13-June-2019,null]");
        java.util.Date date37 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date33, date37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues11.addChangeListener(seriesChangeListener12);
        timePeriodValues11.setRangeDescription("13-June-2019");
        timePeriodValues11.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
        java.util.Date date29 = simpleTimePeriod26.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod26);
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod26, (java.lang.Number) (byte) 10);
        timePeriodValues11.add(timePeriodValue32);
        timePeriodValues6.add(timePeriodValue32);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year35.next();
        boolean boolean37 = timePeriodValues6.equals((java.lang.Object) year35);
        int int38 = year35.getYear();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        long long11 = simpleTimePeriod8.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues15.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, 10.0d);
        int int23 = simpleTimePeriod8.compareTo((java.lang.Object) simpleTimePeriod20);
        java.util.Date date24 = simpleTimePeriod8.getEnd();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(date24);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        java.util.Date date11 = simpleTimePeriod8.getEnd();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        long long15 = day12.getLastMillisecond();
//        java.util.Date date16 = day12.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
//        java.lang.Class<?> wildcardClass29 = simpleTimePeriod26.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod53, 10.0d);
//        java.util.Date date56 = simpleTimePeriod53.getEnd();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date56, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date42, timeZone59);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date16, timeZone59);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date11, timeZone59);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date11);
//        java.util.Date date65 = year64.getEnd();
//        java.util.Calendar calendar66 = null;
//        try {
//            year64.peg(calendar66);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(date65);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod19);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) 43629L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener26);
        int int28 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8, "13-June-2019", "13-June-2019");
        timePeriodValues13.fireSeriesChanged();
        java.lang.Comparable comparable15 = timePeriodValues13.getKey();
        java.lang.Object obj16 = timePeriodValues13.clone();
        java.lang.String str17 = timePeriodValues13.getRangeDescription();
        timePeriodValues13.setDomainDescription("");
        org.junit.Assert.assertNotNull(comparable15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        timePeriodValues3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2019, "31-December-1969", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
        timePeriodValues7.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener12);
        timePeriodValues7.setKey((java.lang.Comparable) 1.0f);
        int int16 = timePeriodValues7.getMinMiddleIndex();
        int int17 = timePeriodValues7.getMinMiddleIndex();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.String str19 = year18.toString();
        boolean boolean20 = timePeriodValues7.equals((java.lang.Object) year18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year18.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year18.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod22, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
//        java.util.Date date3 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass6 = day4.getClass();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.String str8 = day7.toString();
//        long long9 = day7.getSerialIndex();
//        long long10 = day7.getLastMillisecond();
//        java.util.Date date11 = day7.getStart();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        long long15 = day12.getLastMillisecond();
//        java.util.Date date16 = day12.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
//        java.lang.Class<?> wildcardClass29 = simpleTimePeriod26.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod53, 10.0d);
//        java.util.Date date56 = simpleTimePeriod53.getEnd();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date56, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date42, timeZone59);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date16, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date11, timeZone59);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date3, timeZone59);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        java.lang.String str67 = day66.toString();
//        long long68 = day66.getSerialIndex();
//        java.lang.Object obj69 = null;
//        int int70 = day66.compareTo(obj69);
//        int int71 = day66.getMonth();
//        org.jfree.data.time.SerialDate serialDate72 = day66.getSerialDate();
//        long long73 = day66.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate74 = day66.getSerialDate();
//        int int75 = year65.compareTo((java.lang.Object) day66);
//        java.util.Calendar calendar76 = null;
//        try {
//            long long77 = year65.getMiddleMillisecond(calendar76);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "13-June-2019" + "'", str67.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 43629L + "'", long68 == 43629L);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 6 + "'", int71 == 6);
//        org.junit.Assert.assertNotNull(serialDate72);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 43629L + "'", long73 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        boolean boolean5 = day0.equals((java.lang.Object) "hi!");
//        long long6 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        int int11 = timePeriodValues10.getMaxMiddleIndex();
//        timePeriodValues10.fireSeriesChanged();
//        boolean boolean13 = day0.equals((java.lang.Object) timePeriodValues10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues17.addPropertyChangeListener(propertyChangeListener18);
//        java.lang.String str20 = timePeriodValues17.getRangeDescription();
//        timePeriodValues17.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        java.lang.String str24 = year23.toString();
//        int int25 = year23.getYear();
//        timePeriodValues17.setKey((java.lang.Comparable) year23);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getSerialIndex();
//        java.util.Date date29 = day27.getEnd();
//        long long30 = day27.getLastMillisecond();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.String str32 = day31.toString();
//        long long33 = day31.getSerialIndex();
//        long long34 = day31.getLastMillisecond();
//        boolean boolean36 = day31.equals((java.lang.Object) "hi!");
//        boolean boolean37 = day27.equals((java.lang.Object) boolean36);
//        boolean boolean39 = day27.equals((java.lang.Object) 13);
//        java.util.Date date40 = day27.getStart();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
//        boolean boolean42 = timePeriodValues17.equals((java.lang.Object) day41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day41.next();
//        int int44 = day41.getMonth();
//        java.lang.Number number45 = null;
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) day41, number45);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560452399999L + "'", long6 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43629L + "'", long28 == 43629L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560495599999L + "'", long30 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "13-June-2019" + "'", str32.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560495599999L + "'", long34 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues11.addChangeListener(seriesChangeListener12);
        timePeriodValues11.setRangeDescription("13-June-2019");
        timePeriodValues11.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
        java.util.Date date29 = simpleTimePeriod26.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod26);
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod26, (java.lang.Number) (byte) 10);
        timePeriodValues11.add(timePeriodValue32);
        timePeriodValues6.add(timePeriodValue32);
        timePeriodValue32.setValue((java.lang.Number) 4);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1), "org.jfree.data.time.TimePeriodFormatException: hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        boolean boolean4 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2019, "31-December-1969", "hi!");
        boolean boolean4 = timePeriodValues3.isEmpty();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
//        timePeriodValues2.addChangeListener(seriesChangeListener3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[13-June-2019,-1]");
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
//        java.lang.Object obj10 = null;
//        int int11 = day9.compareTo(obj10);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        long long7 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day0.next();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        java.lang.String str4 = day0.toString();
//        long long5 = day0.getSerialIndex();
//        long long6 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Date date4 = day0.getEnd();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        java.lang.Class<?> wildcardClass7 = day5.getClass();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        long long10 = day8.getSerialIndex();
//        long long11 = day8.getLastMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        long long15 = day13.getSerialIndex();
//        long long16 = day13.getLastMillisecond();
//        java.util.Date date17 = day13.getStart();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
//        java.lang.Class<?> wildcardClass30 = simpleTimePeriod27.getClass();
//        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 10.0d);
//        java.util.Date date43 = simpleTimePeriod40.getEnd();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date43);
//        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener50 = null;
//        timePeriodValues49.addPropertyChangeListener(propertyChangeListener50);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues49.add((org.jfree.data.time.TimePeriod) simpleTimePeriod54, 10.0d);
//        java.util.Date date57 = simpleTimePeriod54.getEnd();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date57);
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date57, timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date43, timeZone60);
//        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date17, timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date12, timeZone60);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date4, timeZone60);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date4);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod8);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (double) (byte) 0);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        java.util.Date date18 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        java.util.Date date30 = simpleTimePeriod27.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date18, date30);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date18, timeZone33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date18);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone33);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        int int4 = timePeriodValues3.getItemCount();
        java.lang.String str5 = timePeriodValues3.getDescription();
        timePeriodValues3.delete(9, 3);
        timePeriodValues3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(8, 0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setRangeDescription("13-June-2019");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod18);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 10);
        timePeriodValues3.add(timePeriodValue24);
        java.lang.Number number26 = timePeriodValue24.getValue();
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (byte) 10 + "'", number26.equals((byte) 10));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = timePeriodValues1.createCopy(100, 1969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues5);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        java.lang.String str9 = timePeriodFormatException7.toString();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.String str12 = seriesException11.toString();
        java.lang.String str13 = seriesException11.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException11);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) seriesException11);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException22.getSuppressed();
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException22.getSuppressed();
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        int int26 = year18.compareTo((java.lang.Object) timePeriodFormatException20);
        java.lang.String str27 = timePeriodFormatException20.toString();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str3.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        java.util.Date date11 = simpleTimePeriod8.getEnd();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        long long15 = day12.getLastMillisecond();
//        java.util.Date date16 = day12.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
//        java.lang.Class<?> wildcardClass29 = simpleTimePeriod26.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod53, 10.0d);
//        java.util.Date date56 = simpleTimePeriod53.getEnd();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date56, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date42, timeZone59);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date16, timeZone59);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date11, timeZone59);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date11);
//        java.util.Date date65 = year64.getEnd();
//        java.util.Calendar calendar66 = null;
//        try {
//            long long67 = year64.getLastMillisecond(calendar66);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(date65);
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues6.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        java.lang.Class<?> wildcardClass12 = day10.getClass();
//        timePeriodValues6.setKey((java.lang.Comparable) day10);
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues17.addPropertyChangeListener(propertyChangeListener18);
//        timePeriodValues17.setRangeDescription("hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
//        timePeriodValues17.removeChangeListener(seriesChangeListener22);
//        timePeriodValues17.setKey((java.lang.Comparable) 1.0f);
//        int int26 = timePeriodValues17.getMinMiddleIndex();
//        int int27 = timePeriodValues17.getMinMiddleIndex();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        java.lang.String str29 = year28.toString();
//        boolean boolean30 = timePeriodValues17.equals((java.lang.Object) year28);
//        int int31 = year28.getYear();
//        java.util.Date date32 = year28.getEnd();
//        int int33 = year28.getYear();
//        timePeriodValues6.setKey((java.lang.Comparable) int33);
//        org.junit.Assert.assertNotNull(timePeriodValues6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues3.createCopy((int) (short) 10, 5);
        java.lang.String str9 = timePeriodValues8.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues13.addChangeListener(seriesChangeListener14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) simpleTimePeriod24, 10.0d);
        timePeriodValues13.setKey((java.lang.Comparable) simpleTimePeriod24);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues31.addPropertyChangeListener(propertyChangeListener32);
        timePeriodValues31.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
        timePeriodValues31.removeChangeListener(seriesChangeListener36);
        timePeriodValues31.setKey((java.lang.Comparable) 1.0f);
        int int40 = timePeriodValues31.getMinMiddleIndex();
        int int41 = timePeriodValues31.getMinMiddleIndex();
        boolean boolean42 = simpleTimePeriod24.equals((java.lang.Object) timePeriodValues31);
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timePeriodValues46.addPropertyChangeListener(propertyChangeListener47);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues46.add((org.jfree.data.time.TimePeriod) simpleTimePeriod51, 10.0d);
        java.util.Date date54 = simpleTimePeriod51.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent55 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod51);
        org.jfree.data.time.TimePeriodValue timePeriodValue57 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod51, (java.lang.Number) (byte) 10);
        boolean boolean59 = timePeriodValue57.equals((java.lang.Object) 1560495599999L);
        org.jfree.data.time.TimePeriod timePeriod60 = timePeriodValue57.getPeriod();
        timePeriodValues31.add(timePeriodValue57);
        java.lang.Object obj62 = timePeriodValue57.clone();
        timePeriodValues8.add(timePeriodValue57);
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(timePeriod60);
        org.junit.Assert.assertNotNull(obj62);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        timePeriodValues3.setRangeDescription("hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener8);
//        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
//        int int12 = timePeriodValues3.getMinMiddleIndex();
//        int int13 = timePeriodValues3.getMinMiddleIndex();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
//        java.lang.Object obj17 = timePeriodValues3.clone();
//        int int18 = timePeriodValues3.getMinStartIndex();
//        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        boolean boolean21 = timePeriodValues3.getNotify();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
//        java.lang.String str28 = timePeriodValues25.getRangeDescription();
//        timePeriodValues25.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        int int33 = year31.getYear();
//        timePeriodValues25.setKey((java.lang.Comparable) year31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year31.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year31);
//        long long37 = year31.getSerialIndex();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.String str39 = day38.toString();
//        long long40 = day38.getSerialIndex();
//        long long41 = day38.getLastMillisecond();
//        java.util.Date date42 = day38.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day38.next();
//        boolean boolean44 = year31.equals((java.lang.Object) day38);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day38, (java.lang.Number) 1560495599999L);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        long long48 = day47.getSerialIndex();
//        java.util.Date date49 = day47.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = day47.previous();
//        int int51 = day47.getMonth();
//        org.jfree.data.time.SerialDate serialDate52 = day47.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue54 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day47, (java.lang.Number) 4);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day47, (java.lang.Number) 6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 43629L + "'", long40 == 43629L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560495599999L + "'", long41 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 43629L + "'", long48 == 43629L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 6 + "'", int51 == 6);
//        org.junit.Assert.assertNotNull(serialDate52);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) -1);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(2019);
//        java.lang.Number number8 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, number8);
//        boolean boolean10 = timePeriodValue5.equals((java.lang.Object) number8);
//        org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValue5.getPeriod();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timePeriodValues15.addPropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, 10.0d);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod20, "13-June-2019", "13-June-2019");
//        timePeriodValues25.fireSeriesChanged();
//        java.lang.Comparable comparable27 = timePeriodValues25.getKey();
//        timePeriodValues25.setNotify(false);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        long long31 = day30.getSerialIndex();
//        java.util.Date date32 = day30.getEnd();
//        long long33 = day30.getLastMillisecond();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.String str35 = day34.toString();
//        long long36 = day34.getSerialIndex();
//        long long37 = day34.getLastMillisecond();
//        boolean boolean39 = day34.equals((java.lang.Object) "hi!");
//        boolean boolean40 = day30.equals((java.lang.Object) boolean39);
//        boolean boolean42 = day30.equals((java.lang.Object) 13);
//        java.util.Date date43 = day30.getStart();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
//        boolean boolean45 = timePeriodValues25.equals((java.lang.Object) date43);
//        boolean boolean46 = timePeriodValues25.isEmpty();
//        boolean boolean47 = timePeriodValue5.equals((java.lang.Object) timePeriodValues25);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(timePeriod11);
//        org.junit.Assert.assertNotNull(comparable27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43629L + "'", long31 == 43629L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560495599999L + "'", long33 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "13-June-2019" + "'", str35.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43629L + "'", long36 == 43629L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560495599999L + "'", long37 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setRangeDescription("13-June-2019");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod18);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 10);
        timePeriodValues3.add(timePeriodValue24);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
        boolean boolean28 = timePeriodValue24.equals((java.lang.Object) timePeriodValues27);
        java.lang.Object obj29 = timePeriodValue24.clone();
        java.lang.String str30 = timePeriodValue24.toString();
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMaxStartIndex();
        java.lang.Class<?> wildcardClass8 = timePeriodValues6.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues12.addPropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod17, 10.0d);
        java.util.Date date20 = simpleTimePeriod17.getEnd();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date20, timeZone23);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date20, timeZone25);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues30.addPropertyChangeListener(propertyChangeListener31);
        timePeriodValues30.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues30.removeChangeListener(seriesChangeListener35);
        int int37 = timePeriodValues30.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timePeriodValues41.addPropertyChangeListener(propertyChangeListener42);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) simpleTimePeriod46, 10.0d);
        java.util.Date date49 = simpleTimePeriod46.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod46);
        timePeriodValues30.add((org.jfree.data.time.TimePeriod) simpleTimePeriod46, (java.lang.Number) 43629L);
        java.util.Date date53 = simpleTimePeriod46.getStart();
        java.util.Date date54 = simpleTimePeriod46.getStart();
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date54, timeZone55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date54);
        java.util.Calendar calendar58 = null;
        try {
            year57.peg(calendar58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNull(regularTimePeriod56);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        java.util.Date date18 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        java.util.Date date30 = simpleTimePeriod27.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date18, date30);
        java.util.Date date33 = simpleTimePeriod32.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues37.addPropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues37.add((org.jfree.data.time.TimePeriod) simpleTimePeriod42, 10.0d);
        java.lang.Class<?> wildcardClass45 = simpleTimePeriod42.getClass();
        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass45);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timePeriodValues50.addPropertyChangeListener(propertyChangeListener51);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod55 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues50.add((org.jfree.data.time.TimePeriod) simpleTimePeriod55, 10.0d);
        java.util.Date date58 = simpleTimePeriod55.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date58);
        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timePeriodValues64.addPropertyChangeListener(propertyChangeListener65);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod69 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues64.add((org.jfree.data.time.TimePeriod) simpleTimePeriod69, 10.0d);
        java.util.Date date72 = simpleTimePeriod69.getEnd();
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date72);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date72);
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date72, timeZone75);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date58, timeZone75);
        java.lang.Class<?> wildcardClass78 = timeZone75.getClass();
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date33, timeZone75);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(class46);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertNotNull(wildcardClass78);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.fireSeriesChanged();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        timePeriodValues3.fireSeriesChanged();
        int int9 = timePeriodValues3.getMinStartIndex();
        java.lang.Comparable comparable10 = timePeriodValues3.getKey();
        timePeriodValues3.setNotify(false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + "hi!" + "'", comparable7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "hi!" + "'", comparable10.equals("hi!"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        int int4 = timePeriodValues3.getItemCount();
        java.lang.String str5 = timePeriodValues3.getDescription();
        int int6 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMaxStartIndex();
        java.lang.Class<?> wildcardClass8 = timePeriodValues6.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues12.addPropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod17, 10.0d);
        java.util.Date date20 = simpleTimePeriod17.getEnd();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date20, timeZone23);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date20, timeZone25);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues30.addPropertyChangeListener(propertyChangeListener31);
        timePeriodValues30.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues30.removeChangeListener(seriesChangeListener35);
        int int37 = timePeriodValues30.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timePeriodValues41.addPropertyChangeListener(propertyChangeListener42);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) simpleTimePeriod46, 10.0d);
        java.util.Date date49 = simpleTimePeriod46.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod46);
        timePeriodValues30.add((org.jfree.data.time.TimePeriod) simpleTimePeriod46, (java.lang.Number) 43629L);
        java.util.Date date53 = simpleTimePeriod46.getStart();
        java.util.Date date54 = simpleTimePeriod46.getStart();
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date54, timeZone55);
        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(class57);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues3.createCopy(4, (int) (short) 1);
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesException: hi!");
        int int14 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        long long7 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        long long9 = day0.getFirstMillisecond();
//        long long10 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.lang.String str10 = timePeriodValues3.getDescription();
        timePeriodValues3.setNotify(false);
        java.lang.Comparable comparable13 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues17.addChangeListener(seriesChangeListener18);
        timePeriodValues17.setRangeDescription("13-June-2019");
        timePeriodValues17.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues27.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, 10.0d);
        java.util.Date date35 = simpleTimePeriod32.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod32);
        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (java.lang.Number) (byte) 10);
        timePeriodValues17.add(timePeriodValue38);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
        boolean boolean42 = timePeriodValue38.equals((java.lang.Object) timePeriodValues41);
        java.lang.String str43 = timePeriodValue38.toString();
        timePeriodValues3.add(timePeriodValue38);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + "hi!" + "'", comparable13.equals("hi!"));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
//        java.util.Date date24 = simpleTimePeriod19.getEnd();
//        java.lang.Number number25 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod19, number25);
//        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
//        int int29 = timePeriodValues28.getMinMiddleIndex();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        long long31 = day30.getSerialIndex();
//        java.util.Date date32 = day30.getEnd();
//        long long33 = day30.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day30, (java.lang.Number) (short) -1);
//        java.lang.Number number36 = timePeriodValue35.getValue();
//        timePeriodValues28.add(timePeriodValue35);
//        try {
//            int int38 = simpleTimePeriod19.compareTo((java.lang.Object) timePeriodValue35);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValue cannot be cast to org.jfree.data.time.TimePeriod");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43629L + "'", long31 == 43629L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560495599999L + "'", long33 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + number36 + "' != '" + (short) -1 + "'", number36.equals((short) -1));
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        long long7 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
//        long long10 = day9.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8, "13-June-2019", "13-June-2019");
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        long long15 = day14.getSerialIndex();
//        java.util.Date date16 = day14.getEnd();
//        long long17 = day14.getLastMillisecond();
//        java.lang.String str18 = day14.toString();
//        try {
//            int int19 = simpleTimePeriod8.compareTo((java.lang.Object) str18);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.data.time.TimePeriod");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) -1);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(2019);
//        java.lang.Number number8 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, number8);
//        boolean boolean10 = timePeriodValue5.equals((java.lang.Object) number8);
//        timePeriodValue5.setValue((java.lang.Number) 100L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        timePeriodValues3.setKey((java.lang.Comparable) 11);
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.fireSeriesChanged();
        int int33 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str26.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
//        java.util.Date date3 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass6 = day4.getClass();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.String str8 = day7.toString();
//        long long9 = day7.getSerialIndex();
//        long long10 = day7.getLastMillisecond();
//        java.util.Date date11 = day7.getStart();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        long long15 = day12.getLastMillisecond();
//        java.util.Date date16 = day12.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
//        java.lang.Class<?> wildcardClass29 = simpleTimePeriod26.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod53, 10.0d);
//        java.util.Date date56 = simpleTimePeriod53.getEnd();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date56, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date42, timeZone59);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date16, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date11, timeZone59);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date3, timeZone59);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date3);
//        int int66 = year65.getYear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 2018 + "'", int66 == 2018);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8, "13-June-2019", "13-June-2019");
        timePeriodValues13.fireSeriesChanged();
        java.lang.Comparable comparable15 = timePeriodValues13.getKey();
        java.lang.Object obj16 = timePeriodValues13.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues20.addPropertyChangeListener(propertyChangeListener21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) simpleTimePeriod25, 10.0d);
        java.util.Date date28 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        long long30 = day29.getMiddleMillisecond();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (double) 2019);
        boolean boolean35 = day29.equals((java.lang.Object) timePeriodValue34);
        boolean boolean37 = timePeriodValue34.equals((java.lang.Object) 3);
        timePeriodValues13.add(timePeriodValue34);
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = timePeriodValues13.getDataItem(0);
        boolean boolean41 = timePeriodValues13.isEmpty();
        org.junit.Assert.assertNotNull(comparable15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-14400001L) + "'", long30 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timePeriodValue40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int3, "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!", "TimePeriodValue[13-June-2019,null]");
//        try {
//            timePeriodValues6.delete((-1), 13);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues21.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener26);
        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
        int int30 = timePeriodValues21.getMinMiddleIndex();
        int int31 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
        long long33 = simpleTimePeriod14.getStartMillis();
        boolean boolean35 = simpleTimePeriod14.equals((java.lang.Object) 10);
        long long36 = simpleTimePeriod14.getEndMillis();
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.util.Date date0 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timePeriodValues4.getRangeDescription();
        timePeriodValues4.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.lang.String str11 = year10.toString();
        int int12 = year10.getYear();
        timePeriodValues4.setKey((java.lang.Comparable) year10);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues17.addChangeListener(seriesChangeListener18);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues23.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, 10.0d);
        timePeriodValues17.setKey((java.lang.Comparable) simpleTimePeriod28);
        boolean boolean32 = year10.equals((java.lang.Object) timePeriodValues17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year10.next();
        long long34 = year10.getFirstMillisecond();
        java.lang.String str35 = year10.toString();
        java.util.Date date36 = year10.getEnd();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod(date0, date36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1546329600000L + "'", long34 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
        org.junit.Assert.assertNotNull(date36);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        int int6 = day0.getYear();
//        java.util.Date date7 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        int int24 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setNotify(true);
        boolean boolean27 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        timePeriodValues3.fireSeriesChanged();
        int int10 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.String str5 = day4.toString();
//        long long6 = day4.getSerialIndex();
//        long long7 = day4.getLastMillisecond();
//        boolean boolean9 = day4.equals((java.lang.Object) "hi!");
//        boolean boolean10 = day0.equals((java.lang.Object) boolean9);
//        boolean boolean12 = day0.equals((java.lang.Object) 13);
//        java.util.Date date13 = day0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues17.addPropertyChangeListener(propertyChangeListener18);
//        java.lang.String str20 = timePeriodValues17.getRangeDescription();
//        timePeriodValues17.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        java.lang.String str24 = year23.toString();
//        int int25 = year23.getYear();
//        timePeriodValues17.setKey((java.lang.Comparable) year23);
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
//        timePeriodValues30.addChangeListener(seriesChangeListener31);
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener37 = null;
//        timePeriodValues36.addPropertyChangeListener(propertyChangeListener37);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues36.add((org.jfree.data.time.TimePeriod) simpleTimePeriod41, 10.0d);
//        timePeriodValues30.setKey((java.lang.Comparable) simpleTimePeriod41);
//        boolean boolean45 = year23.equals((java.lang.Object) timePeriodValues30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year23.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year23.previous();
//        boolean boolean48 = day0.equals((java.lang.Object) regularTimePeriod47);
//        long long49 = regularTimePeriod47.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1530561599999L + "'", long49 == 1530561599999L);
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener4);
//        timePeriodValues3.setRangeDescription("13-June-2019");
//        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
//        java.util.Date date21 = simpleTimePeriod18.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod18);
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 10);
//        timePeriodValues3.add(timePeriodValue24);
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
//        boolean boolean28 = timePeriodValue24.equals((java.lang.Object) timePeriodValues27);
//        java.lang.String str29 = timePeriodValue24.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timePeriodValues33.addPropertyChangeListener(propertyChangeListener34);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues33.add((org.jfree.data.time.TimePeriod) simpleTimePeriod38, 10.0d);
//        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timePeriodValues44.addPropertyChangeListener(propertyChangeListener45);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues44.add((org.jfree.data.time.TimePeriod) simpleTimePeriod49, 10.0d);
//        timePeriodValues33.add((org.jfree.data.time.TimePeriod) simpleTimePeriod49, (double) 0L);
//        java.beans.PropertyChangeListener propertyChangeListener54 = null;
//        timePeriodValues33.addPropertyChangeListener(propertyChangeListener54);
//        java.lang.String str56 = timePeriodValues33.getDomainDescription();
//        timePeriodValues33.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        boolean boolean59 = timePeriodValue24.equals((java.lang.Object) timePeriodValues33);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        java.lang.String str61 = day60.toString();
//        long long62 = day60.getSerialIndex();
//        long long63 = day60.getLastMillisecond();
//        long long64 = day60.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day60, (java.lang.Number) (short) -1);
//        boolean boolean67 = timePeriodValue24.equals((java.lang.Object) day60);
//        long long68 = day60.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str56.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "13-June-2019" + "'", str61.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 43629L + "'", long62 == 43629L);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560495599999L + "'", long63 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560409200000L + "'", long64 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560409200000L + "'", long68 == 1560409200000L);
//    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) -1);
//        java.lang.Number number6 = null;
//        timePeriodValue5.setValue(number6);
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timePeriodValues11.addChangeListener(seriesChangeListener12);
//        timePeriodValues11.setRangeDescription("13-June-2019");
//        timePeriodValues11.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
//        java.util.Date date29 = simpleTimePeriod26.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod26);
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod26, (java.lang.Number) (byte) 10);
//        timePeriodValues11.add(timePeriodValue32);
//        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
//        boolean boolean36 = timePeriodValue32.equals((java.lang.Object) timePeriodValues35);
//        java.lang.Number number37 = timePeriodValue32.getValue();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) number37);
//        boolean boolean39 = timePeriodValue5.equals((java.lang.Object) number37);
//        timePeriodValue5.setValue((java.lang.Number) (byte) 100);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (byte) 10 + "'", number37.equals((byte) 10));
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.String str5 = day4.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-1969" + "'", str5.equals("31-December-1969"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        int int2 = year0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setRangeDescription("13-June-2019");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod18);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 10);
        timePeriodValues3.add(timePeriodValue24);
        int int26 = timePeriodValues3.getMinMiddleIndex();
        int int27 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setRangeDescription("13-June-2019");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod18);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 10);
        timePeriodValues3.add(timePeriodValue24);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
        boolean boolean28 = timePeriodValue24.equals((java.lang.Object) timePeriodValues27);
        java.lang.Number number29 = timePeriodValue24.getValue();
        org.jfree.data.time.TimePeriod timePeriod30 = timePeriodValue24.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod31 = timePeriodValue24.getPeriod();
        java.lang.String str32 = timePeriodValue24.toString();
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (byte) 10 + "'", number29.equals((byte) 10));
        org.junit.Assert.assertNotNull(timePeriod30);
        org.junit.Assert.assertNotNull(timePeriod31);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) -1);
//        java.lang.Number number6 = null;
//        timePeriodValue5.setValue(number6);
//        java.lang.Number number8 = timePeriodValue5.getValue();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNull(number8);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        java.util.Date date7 = day5.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date3);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        int int7 = day0.getMonth();
//        long long8 = day0.getFirstMillisecond();
//        java.lang.String str9 = day0.toString();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        java.lang.String str11 = year10.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.previous();
//        java.util.Date date13 = regularTimePeriod12.getEnd();
//        int int14 = day0.compareTo((java.lang.Object) date13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day0.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod15);
//        int int17 = timePeriodValues16.getMaxEndIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, 2019, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.lang.String str2 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMaxStartIndex();
        java.lang.Class<?> wildcardClass8 = timePeriodValues6.getClass();
        int int9 = timePeriodValues6.getMinStartIndex();
        int int10 = timePeriodValues6.getMinStartIndex();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod8);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) (byte) 10);
        java.lang.Number number15 = timePeriodValue14.getValue();
        java.lang.String str16 = timePeriodValue14.toString();
        java.lang.Number number17 = null;
        timePeriodValue14.setValue(number17);
        timePeriodValue14.setValue((java.lang.Number) 2);
        java.lang.Number number21 = timePeriodValue14.getValue();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (byte) 10 + "'", number15.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 2 + "'", number21.equals(2));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        java.lang.Object obj17 = timePeriodValues3.clone();
        int int18 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.lang.Object obj21 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 12, "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: ", "");
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 10L);
        java.lang.String str9 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues13.addChangeListener(seriesChangeListener14);
        timePeriodValues13.setRangeDescription("13-June-2019");
        timePeriodValues13.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues23.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, 10.0d);
        java.util.Date date31 = simpleTimePeriod28.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod28);
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod28, (java.lang.Number) (byte) 10);
        timePeriodValues13.add(timePeriodValue34);
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
        boolean boolean38 = timePeriodValue34.equals((java.lang.Object) timePeriodValues37);
        java.lang.String str39 = timePeriodValue34.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues43.addPropertyChangeListener(propertyChangeListener44);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues43.add((org.jfree.data.time.TimePeriod) simpleTimePeriod48, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timePeriodValues54.addPropertyChangeListener(propertyChangeListener55);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod59 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues54.add((org.jfree.data.time.TimePeriod) simpleTimePeriod59, 10.0d);
        timePeriodValues43.add((org.jfree.data.time.TimePeriod) simpleTimePeriod59, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener64 = null;
        timePeriodValues43.addPropertyChangeListener(propertyChangeListener64);
        java.lang.String str66 = timePeriodValues43.getDomainDescription();
        timePeriodValues43.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        boolean boolean69 = timePeriodValue34.equals((java.lang.Object) timePeriodValues43);
        timePeriodValues3.add(timePeriodValue34);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener71 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener71);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str66.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 2018, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        timePeriodValues3.setRangeDescription("hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener8);
//        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
//        int int12 = timePeriodValues3.getMinMiddleIndex();
//        int int13 = timePeriodValues3.getMinMiddleIndex();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timePeriodValues20.addPropertyChangeListener(propertyChangeListener21);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues20.add((org.jfree.data.time.TimePeriod) simpleTimePeriod25, 10.0d);
//        java.util.Date date28 = simpleTimePeriod25.getEnd();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
//        java.lang.Class<?> wildcardClass33 = seriesChangeEvent32.getClass();
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
//        int int35 = day30.compareTo((java.lang.Object) wildcardClass33);
//        java.util.Date date36 = day30.getStart();
//        java.util.Date date37 = day30.getStart();
//        boolean boolean38 = year14.equals((java.lang.Object) date37);
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues45 = timePeriodValues42.createCopy((int) (short) -1, 11);
//        java.lang.Object obj46 = timePeriodValues45.clone();
//        java.beans.PropertyChangeListener propertyChangeListener47 = null;
//        timePeriodValues45.addPropertyChangeListener(propertyChangeListener47);
//        int int49 = timePeriodValues45.getMinEndIndex();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        long long51 = day50.getSerialIndex();
//        java.util.Date date52 = day50.getEnd();
//        long long53 = day50.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue55 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day50, (java.lang.Number) (short) -1);
//        java.lang.Number number56 = null;
//        timePeriodValue55.setValue(number56);
//        timePeriodValues45.add(timePeriodValue55);
//        java.lang.Number number59 = timePeriodValue55.getValue();
//        int int60 = year14.compareTo((java.lang.Object) number59);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(timePeriodValues45);
//        org.junit.Assert.assertNotNull(obj46);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 43629L + "'", long51 == 43629L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560495599999L + "'", long53 == 1560495599999L);
//        org.junit.Assert.assertNull(number59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        java.util.Date date11 = simpleTimePeriod8.getEnd();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        long long15 = day12.getLastMillisecond();
//        java.util.Date date16 = day12.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
//        java.lang.Class<?> wildcardClass29 = simpleTimePeriod26.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod53, 10.0d);
//        java.util.Date date56 = simpleTimePeriod53.getEnd();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date56, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date42, timeZone59);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date16, timeZone59);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date11, timeZone59);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date11);
//        java.util.Calendar calendar66 = null;
//        try {
//            year65.peg(calendar66);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test251");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        java.util.Date date11 = simpleTimePeriod8.getEnd();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        long long15 = day12.getLastMillisecond();
//        java.util.Date date16 = day12.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
//        java.lang.Class<?> wildcardClass29 = simpleTimePeriod26.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod53, 10.0d);
//        java.util.Date date56 = simpleTimePeriod53.getEnd();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date56, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date42, timeZone59);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date16, timeZone59);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date11, timeZone59);
//        int int64 = day63.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = day63.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = day63.next();
//        long long67 = day63.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1969 + "'", int64 == 1969);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-57600000L) + "'", long67 == (-57600000L));
//    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues3.getRangeDescription();
//        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        java.lang.String str10 = year9.toString();
//        int int11 = year9.getYear();
//        timePeriodValues3.setKey((java.lang.Comparable) year9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues17.addPropertyChangeListener(propertyChangeListener18);
//        java.lang.String str20 = timePeriodValues17.getRangeDescription();
//        timePeriodValues17.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        java.lang.String str24 = year23.toString();
//        int int25 = year23.getYear();
//        timePeriodValues17.setKey((java.lang.Comparable) year23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year23.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year23);
//        int int29 = year9.compareTo((java.lang.Object) year23);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timePeriodValues33.addPropertyChangeListener(propertyChangeListener34);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues33.add((org.jfree.data.time.TimePeriod) simpleTimePeriod38, 10.0d);
//        java.util.Date date41 = simpleTimePeriod38.getEnd();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        long long44 = day42.getSerialIndex();
//        long long45 = day42.getLastMillisecond();
//        java.util.Date date46 = day42.getStart();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
//        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener52 = null;
//        timePeriodValues51.addPropertyChangeListener(propertyChangeListener52);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues51.add((org.jfree.data.time.TimePeriod) simpleTimePeriod56, 10.0d);
//        java.lang.Class<?> wildcardClass59 = simpleTimePeriod56.getClass();
//        java.lang.Class class60 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass59);
//        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener65 = null;
//        timePeriodValues64.addPropertyChangeListener(propertyChangeListener65);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod69 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues64.add((org.jfree.data.time.TimePeriod) simpleTimePeriod69, 10.0d);
//        java.util.Date date72 = simpleTimePeriod69.getEnd();
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date72);
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date72);
//        org.jfree.data.time.TimePeriodValues timePeriodValues78 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener79 = null;
//        timePeriodValues78.addPropertyChangeListener(propertyChangeListener79);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod83 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues78.add((org.jfree.data.time.TimePeriod) simpleTimePeriod83, 10.0d);
//        java.util.Date date86 = simpleTimePeriod83.getEnd();
//        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day(date86);
//        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day(date86);
//        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date86, timeZone89);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date72, timeZone89);
//        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date46, timeZone89);
//        org.jfree.data.time.Day day93 = new org.jfree.data.time.Day(date41, timeZone89);
//        int int94 = year9.compareTo((java.lang.Object) day93);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "13-June-2019" + "'", str43.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 43629L + "'", long44 == 43629L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560495599999L + "'", long45 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(wildcardClass59);
//        org.junit.Assert.assertNotNull(class60);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNotNull(timeZone89);
//        org.junit.Assert.assertNull(regularTimePeriod91);
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValues3.getTimePeriod(0);
        boolean boolean28 = timePeriodValues3.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener29);
        timePeriodValues3.setRangeDescription("");
        org.jfree.data.time.TimePeriod timePeriod34 = timePeriodValues3.getTimePeriod(0);
        org.junit.Assert.assertNotNull(timePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(timePeriod34);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
//        int int7 = timePeriodValues6.getMaxStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues6.removePropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        long long12 = day10.getSerialIndex();
//        java.lang.Object obj13 = null;
//        int int14 = day10.compareTo(obj13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day10.next();
//        java.util.Date date16 = regularTimePeriod15.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timePeriodValues20.addChangeListener(seriesChangeListener21);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timePeriodValues26.addPropertyChangeListener(propertyChangeListener27);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues26.add((org.jfree.data.time.TimePeriod) simpleTimePeriod31, 10.0d);
//        timePeriodValues20.setKey((java.lang.Comparable) simpleTimePeriod31);
//        java.util.Date date35 = simpleTimePeriod31.getEnd();
//        java.lang.Class class36 = null;
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
//        java.lang.String str38 = year37.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year37.previous();
//        java.util.Date date40 = regularTimePeriod39.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timePeriodValues44.addPropertyChangeListener(propertyChangeListener45);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues44.add((org.jfree.data.time.TimePeriod) simpleTimePeriod49, 10.0d);
//        java.util.Date date52 = simpleTimePeriod49.getEnd();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date52);
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date52, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date40, timeZone55);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date35, timeZone55);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date16, timeZone55);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent61 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date16);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date16);
//        timePeriodValues6.add((org.jfree.data.time.TimePeriod) year62, (java.lang.Number) (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "2019" + "'", str38.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        int int4 = timePeriodValues3.getMaxMiddleIndex();
        int int5 = timePeriodValues3.getItemCount();
        timePeriodValues3.setNotify(false);
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        long long6 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test257");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
//        java.lang.Class<?> wildcardClass21 = simpleTimePeriod18.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timePeriodValues26.addPropertyChangeListener(propertyChangeListener27);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues26.add((org.jfree.data.time.TimePeriod) simpleTimePeriod31, 10.0d);
//        java.util.Date date34 = simpleTimePeriod31.getEnd();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener41 = null;
//        timePeriodValues40.addPropertyChangeListener(propertyChangeListener41);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues40.add((org.jfree.data.time.TimePeriod) simpleTimePeriod45, 10.0d);
//        java.util.Date date48 = simpleTimePeriod45.getEnd();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date48);
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date48, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date34, timeZone51);
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date7, timeZone51);
//        int int55 = year54.getYear();
//        int int56 = year54.getYear();
//        long long57 = year54.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2019 + "'", int55 == 2019);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1546329600000L + "'", long57 == 1546329600000L);
//    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.String str5 = day4.toString();
//        long long6 = day4.getSerialIndex();
//        long long7 = day4.getLastMillisecond();
//        boolean boolean9 = day4.equals((java.lang.Object) "hi!");
//        boolean boolean10 = day0.equals((java.lang.Object) boolean9);
//        boolean boolean12 = day0.equals((java.lang.Object) 13);
//        java.util.Date date13 = day0.getStart();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(serialDate15);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: hi!");
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        java.lang.String str4 = day0.toString();
//        long long5 = day0.getFirstMillisecond();
//        int int6 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year9);
        long long15 = year9.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues19.addChangeListener(seriesChangeListener20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) simpleTimePeriod30, 10.0d);
        timePeriodValues19.setKey((java.lang.Comparable) simpleTimePeriod30);
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues37.addPropertyChangeListener(propertyChangeListener38);
        timePeriodValues37.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener42 = null;
        timePeriodValues37.removeChangeListener(seriesChangeListener42);
        timePeriodValues37.setKey((java.lang.Comparable) 1.0f);
        int int46 = timePeriodValues37.getMinMiddleIndex();
        int int47 = timePeriodValues37.getMinMiddleIndex();
        boolean boolean48 = simpleTimePeriod30.equals((java.lang.Object) timePeriodValues37);
        java.util.Date date49 = simpleTimePeriod30.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener54 = null;
        timePeriodValues53.addPropertyChangeListener(propertyChangeListener54);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues53.add((org.jfree.data.time.TimePeriod) simpleTimePeriod58, 10.0d);
        java.util.Date date61 = simpleTimePeriod58.getEnd();
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date61);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date61);
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date61, timeZone64);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod(date49, date61);
        org.jfree.data.time.TimePeriodValues timePeriodValues67 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod66);
        int int68 = year9.compareTo((java.lang.Object) simpleTimePeriod66);
        org.jfree.data.time.TimePeriodValues timePeriodValues72 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener73 = null;
        timePeriodValues72.addPropertyChangeListener(propertyChangeListener73);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod77 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues72.add((org.jfree.data.time.TimePeriod) simpleTimePeriod77, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues83 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener84 = null;
        timePeriodValues83.addPropertyChangeListener(propertyChangeListener84);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod88 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues83.add((org.jfree.data.time.TimePeriod) simpleTimePeriod88, 10.0d);
        timePeriodValues72.add((org.jfree.data.time.TimePeriod) simpleTimePeriod88, (double) 0L);
        int int93 = timePeriodValues72.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues96 = timePeriodValues72.createCopy(13, 11);
        boolean boolean97 = simpleTimePeriod66.equals((java.lang.Object) 11);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues21.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener26);
        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
        int int30 = timePeriodValues21.getMinMiddleIndex();
        int int31 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
        java.util.Date date33 = simpleTimePeriod14.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues37.addPropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues37.add((org.jfree.data.time.TimePeriod) simpleTimePeriod42, 10.0d);
        java.util.Date date45 = simpleTimePeriod42.getEnd();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45);
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date45, timeZone48);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date33, date45);
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod50);
        long long52 = simpleTimePeriod50.getEndMillis();
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 10L + "'", long52 == 10L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod8);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) (byte) 10);
        java.lang.Number number15 = timePeriodValue14.getValue();
        java.lang.String str16 = timePeriodValue14.toString();
        java.lang.Number number17 = null;
        timePeriodValue14.setValue(number17);
        timePeriodValue14.setValue((java.lang.Number) 1562097599999L);
        java.lang.Number number21 = timePeriodValue14.getValue();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (byte) 10 + "'", number15.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1562097599999L + "'", number21.equals(1562097599999L));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2018, 11, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.Class<?> wildcardClass16 = seriesChangeEvent15.getClass();
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        int int18 = day13.compareTo((java.lang.Object) wildcardClass16);
        java.util.Date date19 = day13.getStart();
        java.util.Date date20 = day13.getStart();
        int int21 = day13.getDayOfMonth();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 31 + "'", int21 == 31);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.String str5 = day4.toString();
//        long long6 = day4.getSerialIndex();
//        long long7 = day4.getLastMillisecond();
//        boolean boolean9 = day4.equals((java.lang.Object) "hi!");
//        boolean boolean10 = day0.equals((java.lang.Object) boolean9);
//        boolean boolean12 = day0.equals((java.lang.Object) 13);
//        java.util.Date date13 = day0.getStart();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
//        java.lang.String str15 = year14.toString();
//        java.util.Date date16 = year14.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timePeriodValues20.addPropertyChangeListener(propertyChangeListener21);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues20.add((org.jfree.data.time.TimePeriod) simpleTimePeriod25, 10.0d);
//        java.lang.Class<?> wildcardClass28 = simpleTimePeriod25.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod25);
//        java.lang.Object obj30 = seriesChangeEvent29.getSource();
//        boolean boolean31 = year14.equals((java.lang.Object) seriesChangeEvent29);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(obj30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMaxStartIndex();
        try {
            timePeriodValues6.delete(1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "org.jfree.data.time.TimePeriodFormatException: hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        int int8 = day0.getYear();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        int int14 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.String str15 = timePeriodValues3.getDomainDescription();
        int int16 = timePeriodValues3.getMinMiddleIndex();
        try {
            timePeriodValues3.delete((-18061), 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str15.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues21.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener26);
        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
        int int30 = timePeriodValues21.getMinMiddleIndex();
        int int31 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
        java.util.Date date33 = simpleTimePeriod14.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues37.addPropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues37.add((org.jfree.data.time.TimePeriod) simpleTimePeriod42, 10.0d);
        java.util.Date date45 = simpleTimePeriod42.getEnd();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45);
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date45, timeZone48);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date33, date45);
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod50);
        int int52 = timePeriodValues51.getMaxStartIndex();
        java.lang.String str53 = timePeriodValues51.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Time" + "'", str53.equals("Time"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        java.util.Date date18 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        java.util.Date date30 = simpleTimePeriod27.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date18, date30);
        java.util.Date date33 = simpleTimePeriod32.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date33, "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!", "TimePeriodValue[13-June-2019,null]");
        try {
            java.lang.Number number38 = timePeriodValues36.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date33);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test273");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
//        int int9 = day7.getYear();
//        int int10 = day7.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day7.next();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMaxStartIndex();
        java.lang.Class<?> wildcardClass8 = timePeriodValues6.getClass();
        int int9 = timePeriodValues6.getMaxEndIndex();
        int int10 = timePeriodValues6.getMinMiddleIndex();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.Class<?> wildcardClass16 = seriesChangeEvent15.getClass();
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        int int18 = day13.compareTo((java.lang.Object) wildcardClass16);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(class19);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues17.addChangeListener(seriesChangeListener18);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues23.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, 10.0d);
        timePeriodValues17.setKey((java.lang.Comparable) simpleTimePeriod28);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
        timePeriodValues35.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
        timePeriodValues35.removeChangeListener(seriesChangeListener40);
        timePeriodValues35.setKey((java.lang.Comparable) 1.0f);
        int int44 = timePeriodValues35.getMinMiddleIndex();
        int int45 = timePeriodValues35.getMinMiddleIndex();
        boolean boolean46 = simpleTimePeriod28.equals((java.lang.Object) timePeriodValues35);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, (java.lang.Number) 1562097599999L);
        try {
            org.jfree.data.time.TimePeriod timePeriod50 = timePeriodValues3.getTimePeriod(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 10.0d);
        java.util.Date date43 = simpleTimePeriod40.getEnd();
        long long44 = simpleTimePeriod40.getStartMillis();
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod40.equals(obj45);
        boolean boolean47 = year9.equals((java.lang.Object) simpleTimePeriod40);
        java.util.Date date48 = simpleTimePeriod40.getEnd();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(date48);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (-57600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        java.lang.Throwable[] throwableArray4 = seriesException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year9, "", "Value");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        timePeriodValues3.setRangeDescription("hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener8);
//        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
//        int int12 = timePeriodValues3.getMinMiddleIndex();
//        int int13 = timePeriodValues3.getMinMiddleIndex();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        java.lang.String str15 = year14.toString();
//        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
//        java.lang.Object obj17 = timePeriodValues3.clone();
//        int int18 = timePeriodValues3.getMinStartIndex();
//        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        boolean boolean21 = timePeriodValues3.getNotify();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
//        java.lang.String str28 = timePeriodValues25.getRangeDescription();
//        timePeriodValues25.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        java.lang.String str32 = year31.toString();
//        int int33 = year31.getYear();
//        timePeriodValues25.setKey((java.lang.Comparable) year31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year31.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year31);
//        long long37 = year31.getSerialIndex();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.String str39 = day38.toString();
//        long long40 = day38.getSerialIndex();
//        long long41 = day38.getLastMillisecond();
//        java.util.Date date42 = day38.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day38.next();
//        boolean boolean44 = year31.equals((java.lang.Object) day38);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day38, (java.lang.Number) 1560495599999L);
//        int int47 = timePeriodValues3.getMinStartIndex();
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 43629L + "'", long40 == 43629L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560495599999L + "'", long41 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date11, timeZone14);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) (-1.0d));
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = timePeriodValues21.createCopy((int) (short) -1, 11);
        java.lang.Object obj25 = timePeriodValues24.clone();
        int int26 = day15.compareTo((java.lang.Object) timePeriodValues24);
        boolean boolean27 = timePeriodValues24.getNotify();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(timePeriodValues24);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        int int4 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.String str8 = day7.toString();
//        long long9 = day7.getSerialIndex();
//        java.lang.Object obj10 = null;
//        int int11 = day7.compareTo(obj10);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
//        boolean boolean15 = day6.equals((java.lang.Object) day14);
//        long long16 = day14.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8, "13-June-2019", "13-June-2019");
        timePeriodValues13.fireSeriesChanged();
        java.lang.Comparable comparable15 = timePeriodValues13.getKey();
        java.lang.Object obj16 = timePeriodValues13.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues20.addPropertyChangeListener(propertyChangeListener21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) simpleTimePeriod25, 10.0d);
        java.util.Date date28 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        long long30 = day29.getMiddleMillisecond();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (double) 2019);
        boolean boolean35 = day29.equals((java.lang.Object) timePeriodValue34);
        boolean boolean37 = timePeriodValue34.equals((java.lang.Object) 3);
        timePeriodValues13.add(timePeriodValue34);
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener39);
        timePeriodValues13.delete(4, 0);
        org.junit.Assert.assertNotNull(comparable15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-14400001L) + "'", long30 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        int int7 = day0.getMonth();
//        int int8 = day0.getYear();
//        long long9 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod10, (double) 100);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodFormatException1);
        java.lang.String str4 = seriesChangeEvent3.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 13-June-2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 13-June-2019"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.time.TimePeriodFormatException: 13-June-2019]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=org.jfree.data.time.TimePeriodFormatException: 13-June-2019]"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod8);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) (byte) 10);
        long long15 = simpleTimePeriod8.getEndMillis();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod19);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) 43629L);
        int int26 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("");
        int int9 = timePeriodValues3.getMinStartIndex();
        int int10 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod19);
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) (byte) 10);
        java.lang.Number number26 = timePeriodValue25.getValue();
        java.lang.String str27 = timePeriodValue25.toString();
        java.lang.Number number28 = null;
        timePeriodValue25.setValue(number28);
        timePeriodValues3.add(timePeriodValue25);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
        java.lang.String str37 = timePeriodValues34.getRangeDescription();
        timePeriodValues34.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        java.lang.String str41 = year40.toString();
        int int42 = year40.getYear();
        timePeriodValues34.setKey((java.lang.Comparable) year40);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year40, (java.lang.Number) 2019.0d);
        long long46 = year40.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (byte) 10 + "'", number26.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2019" + "'", str41.equals("2019"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        int int7 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test292");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8, "13-June-2019", "13-June-2019");
//        java.util.Date date14 = simpleTimePeriod8.getStart();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        long long17 = day15.getSerialIndex();
//        java.lang.Object obj18 = null;
//        int int19 = day15.compareTo(obj18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day15.next();
//        java.util.Date date21 = regularTimePeriod20.getEnd();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
//        boolean boolean23 = simpleTimePeriod8.equals((java.lang.Object) date21);
//        java.lang.Number number24 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, number24);
//        org.jfree.data.time.TimePeriod timePeriod26 = timePeriodValue25.getPeriod();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
//        java.lang.String str29 = timePeriodFormatException28.toString();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodFormatException28);
//        boolean boolean31 = timePeriodValue25.equals((java.lang.Object) timePeriodFormatException28);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(timePeriod26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 13-June-2019" + "'", str29.equals("org.jfree.data.time.TimePeriodFormatException: 13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!", "TimePeriodValue[13-June-2019,null]");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
        timePeriodValues7.setKey((java.lang.Comparable) simpleTimePeriod18);
        java.util.Date date22 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timePeriodValues26.addPropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) simpleTimePeriod31, 10.0d);
        java.util.Date date34 = simpleTimePeriod31.getEnd();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(date22, date34);
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        timePeriodValues40.addChangeListener(seriesChangeListener41);
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timePeriodValues46.addPropertyChangeListener(propertyChangeListener47);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues46.add((org.jfree.data.time.TimePeriod) simpleTimePeriod51, 10.0d);
        timePeriodValues40.setKey((java.lang.Comparable) simpleTimePeriod51);
        java.util.Date date55 = simpleTimePeriod51.getEnd();
        java.lang.Class class56 = null;
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        java.lang.String str58 = year57.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year57.previous();
        java.util.Date date60 = regularTimePeriod59.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timePeriodValues64.addPropertyChangeListener(propertyChangeListener65);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod69 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues64.add((org.jfree.data.time.TimePeriod) simpleTimePeriod69, 10.0d);
        java.util.Date date72 = simpleTimePeriod69.getEnd();
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date72);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date72);
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date72, timeZone75);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date60, timeZone75);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date55, timeZone75);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod79 = new org.jfree.data.time.SimpleTimePeriod(date22, date55);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod79, (double) 7);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "2019" + "'", str58.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNull(regularTimePeriod77);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValues3.getTimePeriod(0);
        boolean boolean28 = timePeriodValues3.getNotify();
        int int29 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.update((int) (short) 1, (java.lang.Number) 3);
        java.lang.Comparable comparable33 = timePeriodValues3.getKey();
        java.lang.String str34 = timePeriodValues3.getDescription();
        org.junit.Assert.assertNotNull(timePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + "hi!" + "'", comparable33.equals("hi!"));
        org.junit.Assert.assertNull(str34);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
//        java.util.Date date3 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass6 = day4.getClass();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.String str8 = day7.toString();
//        long long9 = day7.getSerialIndex();
//        long long10 = day7.getLastMillisecond();
//        java.util.Date date11 = day7.getStart();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        long long15 = day12.getLastMillisecond();
//        java.util.Date date16 = day12.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
//        java.lang.Class<?> wildcardClass29 = simpleTimePeriod26.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod53, 10.0d);
//        java.util.Date date56 = simpleTimePeriod53.getEnd();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date56, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date42, timeZone59);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date16, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date11, timeZone59);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date3, timeZone59);
//        java.lang.Class<?> wildcardClass65 = day64.getClass();
//        int int66 = day64.getMonth();
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        java.lang.String str68 = day67.toString();
//        long long69 = day67.getSerialIndex();
//        java.lang.Object obj70 = null;
//        int int71 = day67.compareTo(obj70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = day67.next();
//        long long73 = day67.getMiddleMillisecond();
//        int int74 = day64.compareTo((java.lang.Object) long73);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(wildcardClass65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 12 + "'", int66 == 12);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "13-June-2019" + "'", str68.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 43629L + "'", long69 == 43629L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1560452399999L + "'", long73 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod19);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) 43629L);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues29.addPropertyChangeListener(propertyChangeListener30);
        java.lang.String str32 = timePeriodValues29.getRangeDescription();
        timePeriodValues29.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        java.lang.String str36 = year35.toString();
        int int37 = year35.getYear();
        timePeriodValues29.setKey((java.lang.Comparable) year35);
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
        timePeriodValues42.addChangeListener(seriesChangeListener43);
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener49 = null;
        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod53, 10.0d);
        timePeriodValues42.setKey((java.lang.Comparable) simpleTimePeriod53);
        boolean boolean57 = year35.equals((java.lang.Object) timePeriodValues42);
        org.jfree.data.time.TimePeriodValues timePeriodValues61 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener62 = null;
        timePeriodValues61.addPropertyChangeListener(propertyChangeListener62);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues61.add((org.jfree.data.time.TimePeriod) simpleTimePeriod66, 10.0d);
        java.util.Date date69 = simpleTimePeriod66.getEnd();
        long long70 = simpleTimePeriod66.getStartMillis();
        java.lang.Object obj71 = null;
        boolean boolean72 = simpleTimePeriod66.equals(obj71);
        boolean boolean73 = year35.equals((java.lang.Object) simpleTimePeriod66);
        org.jfree.data.time.TimePeriodValues timePeriodValues76 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod66, "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!", "org.jfree.data.general.SeriesException: hi!");
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod66, (java.lang.Number) (-14400001L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2019" + "'", str36.equals("2019"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[13-June-2019,-1]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        java.util.Date date6 = regularTimePeriod5.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues10.addChangeListener(seriesChangeListener11);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, 10.0d);
//        timePeriodValues10.setKey((java.lang.Comparable) simpleTimePeriod21);
//        java.util.Date date25 = simpleTimePeriod21.getEnd();
//        java.lang.Class class26 = null;
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        java.lang.String str28 = year27.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.previous();
//        java.util.Date date30 = regularTimePeriod29.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date42, timeZone45);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date30, timeZone45);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date25, timeZone45);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date6, timeZone45);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date6);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent51 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date6);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = year52.next();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//    }
//}

